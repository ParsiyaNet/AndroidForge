# WAPFire Mobile 4.2.2 — AIRI VRM character engine

This source starts from **WAPFire-Mobile 4.2.0 Dark Matte Glass**. The WAPFire screens, network features, overview layout, WebView retention and original character framing are preserved. Only the assistant character renderer is replaced with AIRI's VRM stage runtime.

## Character runtime

- Default AIRI character: `AvatarSample_A.vrm`.
- Runtime: Three.js r180, `@pixiv/three-vrm` 3.5.5 and `@pixiv/three-vrm-animation` 3.5.5.
- Motion: AIRI's own `idle_loop.vrma`, pinned by Git blob SHA-1 and loaded once into an AnimationMixer.
- AIRI frame pipeline: MToon material updates, humanoid, LookAt, blink, cubic Emote transitions, expression manager, node constraints and Spring Bone.
- WAPFire state changes adjust emotion and gaze; they do not restart the body idle animation or inject unrelated full-body gesture clips.
- No Unity, Live2D, TTS, microphone, speech recognition, lip sync or assistant audio.

The pinned AIRI VRM stage defines one default full-body idle VRMA. The other natural character behavior comes from the VRM look-at, expression, blink, emote and spring-bone systems. This avoids generic animations that do not match the model's skeleton.

## AndroidForge

Upload this ZIP as a regular Android Gradle project and build the **Debug APK**. During `preBuild`, Gradle fetches pinned Three.js/VRM JavaScript modules and the verified AIRI idle motion into `app/src/main/assets`. The installed APK then runs the character and motion locally, without runtime downloads or voice services.

Local build command:

```powershell
.\gradlew.bat :app:assembleDebug
```

For details in Persian, see `README-4.2.2-FA.md`. Changes are listed in `CHANGELOG-4.2.2.md`.

## Validation status

The source ZIP integrity and JavaScript syntax have been checked. A native Android APK build and on-device visual test were not run in this environment, so this package is source-ready but is not represented as a tested APK.
