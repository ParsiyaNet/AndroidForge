package io.wapfire.mobile.ui.screens

import io.wapfire.mobile.model.*
import io.wapfire.mobile.ui.components.*


import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject


@Composable
internal fun SettingsPage(
    p: Palette, fa: Boolean, s: Snapshot, onToggle: (String, Boolean) -> Unit, onLogout: () -> Unit,
    modifier: Modifier = Modifier, onLanguage: () -> Unit, dark: Boolean, onTheme: () -> Unit,
    targetNetworks: List<JSONObject>, targetScanBusy: Boolean, targetSelecting: Boolean, onTargetScan: () -> Unit,
    onSelectTarget: (JSONObject) -> Unit, onClearTarget: () -> Unit,
    advanced: AdvancedSettingsBundle, trackedClients: List<JSONObject>, onAdvancedSave: (String, JSONObject) -> Unit,
    onAdvancedAction: (String) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onFirmwarePick: () -> Unit,
    backgroundMonitorActive: Boolean, onBackgroundMonitor: () -> Unit, onBatterySettings: () -> Unit
) {
    val hasSelectedTarget = s.target.isNotBlank() || s.targetMac.isNotBlank()
    // targetNetworks is the explicit scan-result list. When a target is selected the
    // selection handler stores exactly one verified AP here; a new scan replaces it
    // with the full result set, so a previous target never blocks re-selection.
    val visibleTargetNetworks = targetNetworks
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(top = 16.dp + LocalContentInset.current.calculateTopPadding(), bottom = 16.dp + LocalContentInset.current.calculateBottomPadding()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(fa, "DEVICE CONFIGURATION", "پیکربندی دستگاه"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Settings & controls", "تنظیمات و کنترل‌ها"), color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Everything in one place, organized by function.", "همه قابلیت‌ها در یک بخش، مرتب‌شده بر اساس کاربرد."), color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        SectionCard(p, title = tx(fa, "01  ·  MONITORING & TARGET", "۰۱  ·  پایش و شبکه هدف"), subtitle = tx(fa, "Choose the exact access point WAPFire should monitor.", "اکسس‌پوینتی را که WAPFire باید پایش کند، دقیق انتخاب کن.")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(s.target.ifBlank { tx(fa, "No target selected", "شبکه هدف انتخاب نشده") }, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (s.targetMac.isNotBlank()) ltrTechnical(fa, s.targetMac) else tx(fa, "Select a network to begin monitoring", "برای شروع پایش یک شبکه انتخاب کن"), color = p.muted, fontSize = 10.sp)
                    Text("CH ${if (s.channel > 0) s.channel else "—"}   ·   ${if (s.targetRssi != 0) "${s.targetRssi} dBm" else "— dBm"}", color = p.muted, fontSize = 10.sp)
                }
                Box(Modifier.clip(CircleShape).background(if (s.targetAvailable) p.green.copy(alpha = .14f) else p.orange.copy(alpha = .13f)).padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text(if (s.targetAvailable) tx(fa, "ONLINE", "فعال") else tx(fa, "OFFLINE", "غیرفعال"), color = if (s.targetAvailable) p.green else p.orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                ActionButton(p, when {
                    targetSelecting -> tx(fa, "Selecting…", "در حال انتخاب…")
                    targetScanBusy -> tx(fa, "Scanning…", "در حال اسکن…")
                    else -> tx(fa, "Scan networks", "اسکن شبکه‌ها")
                }, onTargetScan, enabled = !targetScanBusy && !targetSelecting, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Clear target", "پاک‌کردن هدف"), onClearTarget, enabled = !targetSelecting && (s.target.isNotBlank() || s.targetMac.isNotBlank()), modifier = Modifier.weight(1f))
            }
            if (targetScanBusy || targetSelecting) CircularProgressIndicator(modifier = Modifier.size(20.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
            if (visibleTargetNetworks.isEmpty() && !targetScanBusy && !targetSelecting) Text(
                if (hasSelectedTarget) tx(
                    fa,
                    "You can scan and choose a different access point without clearing the current target.",
                    "برای انتخاب اکسس‌پوینت دیگر نیازی به پاک‌کردن هدف فعلی نیست؛ اسکن کن و شبکه جدید را انتخاب کن."
                ) else tx(
                    fa,
                    "Scan to show nearby access points. Selection is verified by SSID, BSSID and channel.",
                    "برای نمایش اکسس‌پوینت‌های اطراف اسکن کن. انتخاب با SSID، BSSID و کانال بررسی می‌شود."
                ),
                color = p.muted, fontSize = 11.sp, lineHeight = 17.sp
            )
            visibleTargetNetworks.forEach { net ->
                val ssid = net.optString("ssid")
                val bssid = net.optString("bssid")
                val valid = ssid.isNotBlank() && isValidBssid(bssid) && net.optInt("channel") in 1..13
                DeviceResult(p, ssid.ifBlank { tx(fa, "Hidden network", "شبکه مخفی") },
                    "$bssid  ·  CH ${net.optInt("channel")}  ·  ${net.optInt("rssi")} dBm",
                    if (!valid) "HIDDEN" else if (net.optBoolean("secured")) "SECURED" else "OPEN",
                    { if (valid && !targetSelecting && !targetScanBusy) onSelectTarget(net) },
                    if (targetSelecting) tx(fa, "Selecting…", "در حال انتخاب…") else if (targetScanBusy) tx(fa, "Scanning…", "در حال اسکن…") else if (valid) tx(fa, "Select", "انتخاب") else "",
                    enabled = valid && !targetSelecting && !targetScanBusy)
            }
        }
        SectionCard(p, title = tx(fa, "02  ·  PROTECTION", "۰۲  ·  محافظت"), subtitle = tx(fa, "Detection response and channel behavior.", "واکنش به تشخیص‌ها و رفتار کانال.")) {
            ToggleRow(p, tx(fa, "Self-protect mode", "حالت محافظت از خود"), tx(fa, "Apply the configured protection response when threats are detected.", "هنگام تشخیص تهدید، واکنش حفاظتی تعریف‌شده را اجرا می‌کند."), s.selfProtect) { onToggle("self_protect", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Automatic channel tracking", "ردگیری خودکار کانال"), tx(fa, "Follow channel changes of the selected target AP.", "تغییر کانال اکسس‌پوینت هدف را دنبال می‌کند."), s.autoChannel) { onToggle("auto_channel", it) }
        }
        SectionCard(p, title = tx(fa, "03  ·  DEVICE FEEDBACK", "۰۳  ·  بازخورد دستگاه"), subtitle = tx(fa, "Physical LED and audible alerts.", "هشدارهای نوری و صوتی دستگاه.")) {
            ToggleRow(p, tx(fa, "Status LED", "چراغ وضعیت"), tx(fa, "Enable the device status indicator.", "نشانگر وضعیت دستگاه را فعال می‌کند."), s.led) { onToggle("led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Smart LED mode", "حالت هوشمند LED"), tx(fa, "Adjust the LED behavior based on target availability.", "رفتار LED را با وضعیت در دسترس بودن هدف تنظیم می‌کند."), s.smartLed) { onToggle("smart_led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Sound alerts", "هشدار صوتی"), tx(fa, "Play sound for supported security events.", "برای رویدادهای امنیتی پشتیبانی‌شده صدا پخش می‌کند."), s.sound) { onToggle("sound", it) }
        }
        SectionCard(p, title = tx(fa, "04  ·  CONNECTIVITY", "۰۴  ·  ارتباطات"), subtitle = tx(fa, "Access and management connectivity.", "اتصال برای دسترسی و مدیریت دستگاه.")) {
            ToggleRow(p, tx(fa, "WAPFire access point", "اکسس‌پوینت WAPFire"), tx(fa, "Keep the configuration Wi-Fi network available.", "شبکه Wi-Fi پیکربندی دستگاه را در دسترس نگه می‌دارد."), s.softAp) { onToggle("softap_enabled", it) }
            DividerLine(p)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Ethernet", color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (s.ethernet) s.ethernetIp else tx(fa, "No active link", "اتصال فعالی وجود ندارد"), color = p.muted, fontSize = 10.sp)
                }
                Text(if (s.ethernet) "ONLINE" else "OFFLINE", color = if (s.ethernet) p.green else p.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        SectionCard(p, title = tx(fa, "05  ·  DEVICE STATUS", "۰۵  ·  وضعیت دستگاه"), subtitle = "WAPFire ${s.firmware}") {
            InfoLine(p, tx(fa, "Radio mode", "حالت رادیو"), s.prom)
            InfoLine(p, tx(fa, "LED alert state", "وضعیت هشدار LED"), ledModeLabel(s.ledMode, fa))
            InfoLine(p, tx(fa, "Wi-Fi channel", "کانال Wi-Fi"), s.wifiChannel.toString())
            InfoLine(p, tx(fa, "Free memory", "حافظه آزاد"), "${s.freeHeap / 1024} KB")
            InfoLine(p, tx(fa, "Uptime", "مدت فعالیت"), formatUptime(s.uptime))
            InfoLine(p, tx(fa, "Dropped / filtered", "ازدست‌رفته / فیلترشده"), "${s.dropped} / ${s.filtered}")
        }
        SectionCard(p, title = tx(fa, "06  ·  APP EXPERIENCE", "۰۶  ·  تجربه برنامه"), subtitle = tx(fa, "Personal preferences for this phone.", "ترجیحات ظاهری برنامه در این گوشی.")) {
            ToggleRow(p, tx(fa, "Persian interface", "رابط فارسی"), tx(fa, "Switch the native app language.", "زبان رابط برنامه را تغییر می‌دهد."), fa) { onLanguage() }
            DividerLine(p)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(tx(fa, "Appearance", "پوسته ظاهری"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(tx(fa, "Choose dark or light glass mode.", "حالت شیشه‌ای تیره یا روشن را انتخاب کن."), color = p.muted, fontSize = 10.sp)
                }
                ThemeAction(p, dark, onTheme)
            }
        }
        SectionCard(
            p,
            title = tx(fa, "CHARACTER CREDITS", "اعتبار شخصیت"),
            subtitle = tx(fa, "AvatarSample_A · VRoid Project", "AvatarSample_A · پروژه VRoid")
        ) {
            Text(
                tx(fa, "The AvatarSample_A model is provided by VRoid Project under the usage terms embedded in its VRM metadata.", "مدل AvatarSample_A متعلق به VRoid Project است و طبق شرایط استفادهٔ درج‌شده در متادیتای خود مدل ارائه می‌شود."),
                color = p.muted, fontSize = 10.sp, lineHeight = 15.sp
            )
            Text(
                tx(fa, "Motion engine adapted from Project AIRI · Three.js r180 · @pixiv/three-vrm and three-vrm-animation (MIT).", "موتور حرکت اقتباس‌شده از Project AIRI · Three.js r180 · کتابخانه‌های three-vrm و three-vrm-animation با مجوز MIT."),
                color = p.muted, fontSize = 10.sp, lineHeight = 15.sp
            )
        }
        SectionCard(
            p,
            title = tx(fa, "07  ·  BACKGROUND ALERTS", "۰۷  ·  هشدارهای پس‌زمینه"),
            subtitle = tx(fa, "Get attack notifications while WAPFire is connected.", "هنگام اتصال به WAPFire اعلان حمله دریافت کن.")
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        if (backgroundMonitorActive) tx(fa, "Background alerts are on", "هشدارهای پس‌زمینه روشن است")
                        else tx(fa, "Background alerts are off", "هشدارهای پس‌زمینه خاموش است"),
                        color = if (backgroundMonitorActive) p.green else p.text,
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        tx(fa, "A notification stays visible while monitoring is active.", "هنگام فعال بودن پایش، اعلان وضعیت نمایش داده می‌شود."),
                        color = p.muted, fontSize = 10.sp, lineHeight = 14.sp
                    )
                }
                Switch(checked = backgroundMonitorActive, onCheckedChange = { onBackgroundMonitor() })
            }
            TextButton(onClick = onBatterySettings, modifier = Modifier.align(Alignment.End)) {
                Text(tx(fa, "Battery settings", "تنظیمات باتری"), color = p.accent, fontSize = 11.sp)
            }
        }
        AdvancedSettingsPanel(
            p = p, fa = fa, data = advanced, trackedClients = trackedClients,
            onSave = onAdvancedSave, onAction = onAdvancedAction,
            onBackup = onBackup, onRestore = onRestore, onFirmwarePick = onFirmwarePick
        )
        SectionCard(p, title = tx(fa, "SESSION", "نشست کاربری"), subtitle = tx(fa, "Safely end the authenticated device session.", "نشست احراز هویت‌شده دستگاه را به‌صورت امن خاتمه بده.")) {
            ActionButton(p, tx(fa, "Log out", "خروج از حساب"), onLogout, primary = false, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
internal fun ExpandableSettingsCard(
    p: Palette, title: String, subtitle: String = "", initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember(title) { mutableStateOf(initiallyExpanded) }
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().shadow(12.dp, shape, ambientColor = Color.Black.copy(alpha = .10f), spotColor = p.accent.copy(alpha = .08f))
            .clip(shape)
            .background(Brush.linearGradient(listOf(p.panel.copy(alpha = .78f), p.panelAlt.copy(alpha = .66f), p.panel.copy(alpha = .72f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), p.border.copy(alpha = .75f), Color.White.copy(alpha = .06f))), shape)
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { expanded = !expanded }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text(if (expanded) "−" else "+", color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        if (expanded) {
            content.invoke(this)
        }
    }
}

@Composable
internal fun AdvancedSettingsPanel(
    p: Palette,
    fa: Boolean,
    data: AdvancedSettingsBundle,
    trackedClients: List<JSONObject>,
    onSave: (String, JSONObject) -> Unit,
    onAction: (String) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onFirmwarePick: () -> Unit
) {
    var showBackupWarning by remember { mutableStateOf(false) }
    var showRestoreWarning by remember { mutableStateOf(false) }
    var pendingMaintenance by remember { mutableStateOf<String?>(null) }

    if (showBackupWarning) AlertDialog(
        onDismissRequest = { showBackupWarning = false },
        title = { Text(tx(fa, "Export sensitive backup?", "خروجی پشتیبان حساس؟")) },
        text = { Text(tx(fa, "The backup contains administrator and Wi-Fi credentials, MikroTik credentials, target identity and device settings. Store it securely.", "این فایل شامل رمز مدیر، رمز Wi‑Fi، اطلاعات MikroTik، مشخصات شبکه هدف و تنظیمات دستگاه است. آن را در محل امن نگه دار.")) },
        confirmButton = { TextButton(onClick = { showBackupWarning = false; onBackup() }) { Text(tx(fa, "Export backup", "خروجی گرفتن")) } },
        dismissButton = { TextButton(onClick = { showBackupWarning = false }) { Text(tx(fa, "Cancel", "لغو")) } }
    )
    if (showRestoreWarning) AlertDialog(
        onDismissRequest = { showRestoreWarning = false },
        title = { Text(tx(fa, "Restore WAPFire backup?", "بازیابی پشتیبان WAPFire؟")) },
        text = { Text(tx(fa, "This replaces saved device configuration and reboots WAPFire. You may need to reconnect using the restored access-point credentials.", "این کار تنظیمات ذخیره‌شده دستگاه را جایگزین می‌کند و WAPFire را راه‌اندازی مجدد می‌کند. ممکن است لازم باشد با مشخصات Wi‑Fi بازیابی‌شده دوباره متصل شوی.")) },
        confirmButton = { TextButton(onClick = { showRestoreWarning = false; onRestore() }) { Text(tx(fa, "Choose backup", "انتخاب فایل")) } },
        dismissButton = { TextButton(onClick = { showRestoreWarning = false }) { Text(tx(fa, "Cancel", "لغو")) } }
    )
    pendingMaintenance?.let { action ->
        val title = when (action) {
            "reboot" -> tx(fa, "Reboot WAPFire?", "راه‌اندازی مجدد WAPFire؟")
            "wifi_restart" -> tx(fa, "Restart Wi-Fi?", "راه‌اندازی مجدد Wi‑Fi؟")
            "force_setup" -> tx(fa, "Return to initial setup?", "بازگشت به راه‌اندازی اولیه؟")
            else -> tx(fa, "Factory reset?", "بازنشانی کارخانه‌ای؟")
        }
        val body = when (action) {
            "reboot" -> tx(fa, "The device will restart. The mobile app will reconnect after it is online.", "دستگاه راه‌اندازی مجدد می‌شود. برنامه پس از آنلاین‌شدن دوباره متصل خواهد شد.")
            "wifi_restart" -> tx(fa, "The WAPFire access point and radio services will restart; your phone may disconnect briefly.", "اکسس‌پوینت WAPFire و سرویس‌های رادیویی دوباره راه‌اندازی می‌شوند و ممکن است اتصال گوشی موقتاً قطع شود.")
            "force_setup" -> tx(fa, "WAPFire will return to its first-setup state while keeping its saved credentials and advanced settings. You may need to reconnect to the access point.", "WAPFire به وضعیت راه‌اندازی اولیه برمی‌گردد اما رمزها و تنظیمات پیشرفته حفظ می‌شوند. ممکن است لازم باشد دوباره به اکسس‌پوینت وصل شوی.")
            else -> tx(fa, "All saved settings and credentials will be erased. You will need to configure WAPFire again. This cannot be undone.", "تمام تنظیمات و رمزهای ذخیره‌شده پاک می‌شوند و باید WAPFire را از ابتدا پیکربندی کنی. این کار برگشت‌پذیر نیست.")
        }
        AlertDialog(
            onDismissRequest = { pendingMaintenance = null },
            title = { Text(title) }, text = { Text(body) },
            confirmButton = { TextButton(onClick = { pendingMaintenance = null; onAction(action) }) { Text(tx(fa, when (action) { "factory_reset" -> "Erase device"; "force_setup" -> "Return to setup"; else -> "Continue" }, when (action) { "factory_reset" -> "پاک کردن دستگاه"; "force_setup" -> "بازگشت به Setup"; else -> "ادامه" })) } },
            dismissButton = { TextButton(onClick = { pendingMaintenance = null }) { Text(tx(fa, "Cancel", "لغو")) } }
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(tx(fa, "ADVANCED DEVICE CONTROLS", "کنترل‌های پیشرفته دستگاه"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
        Text(tx(fa, "Every firmware feature, in its own group.", "تمام قابلیت‌های فریم‌ور، هرکدام در دسته مخصوص خودشان."), color = p.muted, fontSize = 11.sp)

        // Connectivity: Ethernet and event reporting are independent services.
        ExpandableSettingsCard(p, tx(fa, "Network · Ethernet", "شبکه · اترنت"), tx(fa, "DHCP, static addressing, DNS and hostname" , "DHCP، آدرس ثابت، DNS و نام میزبان")) {
            val src = data.ethernet
            var dhcp by remember(src.toString()) { mutableStateOf(src.optBoolean("use_dhcp", true)) }
            var ip by remember(src.toString()) { mutableStateOf(src.optString("static_ip", "192.168.1.100")) }
            var dns by remember(src.toString()) { mutableStateOf(src.optString("static_dns", "1.1.1.1")) }
            var gateway by remember(src.toString()) { mutableStateOf(src.optString("static_gateway", "192.168.1.1")) }
            var subnet by remember(src.toString()) { mutableStateOf(src.optString("static_subnet", "255.255.255.0")) }
            var hostname by remember(src.toString()) { mutableStateOf(src.optString("ethernet_hostname", "WAPFire")) }
            Text("${tx(fa, "Link", "اتصال")}: ${if (src.optInt("link_status") == 1) tx(fa, "Connected", "متصل") else tx(fa, "No link", "بدون اتصال")}  ·  ${src.optString("current_ip", "0.0.0.0")}", color = p.muted, fontSize = 10.sp)
            InfoLine(p, tx(fa, "Ethernet MAC", "مک اترنت"), ltrTechnical(fa, src.optString("esp32_mac", "—")))
            InfoLine(p, tx(fa, "Current DNS", "DNS فعلی"), src.optString("current_dns", "—"))
            InfoLine(p, tx(fa, "Hardware status", "وضعیت سخت‌افزار"), src.optString("hardware_status", "—"))
            ToggleRow(p, "DHCP", tx(fa, "Obtain IP configuration automatically.", "تنظیمات IP به‌صورت خودکار دریافت شود."), dhcp) { dhcp = it }
            NativeField(p, hostname, { hostname = it }, tx(fa, "Ethernet hostname", "نام میزبان اترنت"))
            if (!dhcp) {
                NativeField(p, ip, { ip = it }, "Static IP")
                NativeField(p, gateway, { gateway = it }, "Gateway")
                NativeField(p, subnet, { subnet = it }, "Subnet mask")
                NativeField(p, dns, { dns = it }, "DNS server")
            }
            ActionButton(p, tx(fa, "Save Ethernet settings", "ذخیره تنظیمات اترنت"), { onSave("ethernet", JSONObject().put("use_dhcp", dhcp).put("static_ip", ip).put("static_dns", dns).put("static_gateway", gateway).put("static_subnet", subnet).put("ethernet_hostname", hostname)) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Network · HTTP event API", "شبکه · گزارش رویداد HTTP"), tx(fa, "Forward WAPFire events to your server over Ethernet." , "ارسال رویدادهای WAPFire به سرور از طریق اترنت.")) {
            val src = data.httpApi
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var url by remember(src.toString()) { mutableStateOf(src.optString("url")) }
            var port by remember(src.toString()) { mutableStateOf(src.optInt("port", 8080).toString()) }
            ToggleRow(p, tx(fa, "Enable HTTP event reporting", "فعال‌سازی گزارش رویداد HTTP"), tx(fa, "Requires an active Ethernet link.", "به اتصال فعال اترنت نیاز دارد."), enabled) { enabled = it }
            Text(tx(fa, "Ethernet service: ", "وضعیت اترنت: ") + if (src.optBoolean("ethernet_available")) tx(fa, "available", "در دسترس") else tx(fa, "unavailable", "در دسترس نیست"), color = p.muted, fontSize = 10.sp)
            NativeField(p, url, { url = it }, tx(fa, "Server URL / host path", "آدرس سرور / مسیر"))
            NativeField(p, port, { port = it.filter(Char::isDigit).take(5) }, "Port", keyboard = KeyboardType.Number)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Save", "ذخیره"), { onSave("http_api", JSONObject().put("enabled", enabled).put("url", url).put("port", port.toIntOrNull() ?: 8080)) }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Send test", "ارسال آزمایشی"), { onAction("test_http_api") }, modifier = Modifier.weight(1f))
            }
        }

        // Clock settings and phone-assisted synchronization.
        ExpandableSettingsCard(p, tx(fa, "Time · NTP & timezone", "زمان · NTP و منطقه زمانی"), tx(fa, "Automatic clock synchronization and local time." , "همگام‌سازی خودکار ساعت و زمان محلی.")) {
            val src = data.ntp
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("ntp_enabled")) }
            var server by remember(src.toString()) { mutableStateOf(src.optString("ntp_server", "pool.ntp.org")) }
            var interval by remember(src.toString()) { mutableStateOf(src.optInt("ntp_interval", 3600).toString()) }
            var timezone by remember(src.toString()) { mutableStateOf(src.optString("timezone", "UTC+0")) }
            ToggleRow(p, "NTP", tx(fa, "Synchronize the device clock automatically.", "ساعت دستگاه به‌صورت خودکار همگام‌سازی شود."), enabled) { enabled = it }
            Text("${src.optString("current_date", "—")}  ${src.optString("current_time", "—")}  ·  ${if (src.optBoolean("ntp_synced")) "SYNCED" else "NOT SYNCED"}", color = p.muted, fontSize = 10.sp)
            NativeField(p, server, { server = it }, tx(fa, "NTP server", "سرور NTP"))
            NativeField(p, interval, { interval = it.filter(Char::isDigit).take(5) }, tx(fa, "Update interval (60–86400 seconds)", "فاصله همگام‌سازی (۶۰ تا ۸۶۴۰۰ ثانیه)"), keyboard = KeyboardType.Number)
            val availableZones = remember(src.toString()) {
                val zones = src.optJSONArray("available_timezones") ?: JSONArray()
                (0 until zones.length()).map { zones.optString(it) }.filter { it.isNotBlank() }
            }
            var zoneMenuOpen by remember { mutableStateOf(false) }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(tx(fa, "Timezone", "منطقه زمانی"), color = p.muted, fontSize = 10.sp)
                Box {
                    OutlinedButton(onClick = { zoneMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(timezone, color = p.text)
                    }
                    DropdownMenu(expanded = zoneMenuOpen, onDismissRequest = { zoneMenuOpen = false }) {
                        availableZones.forEach { zone ->
                            DropdownMenuItem(text = { Text(zone) }, onClick = { timezone = zone; zoneMenuOpen = false })
                        }
                    }
                }
            }
            ActionButton(p, tx(fa, "Save NTP settings", "ذخیره تنظیمات NTP"), { onSave("ntp", JSONObject().put("ntp_enabled", enabled).put("ntp_server", server).put("ntp_interval", interval.toIntOrNull() ?: 3600).put("timezone", timezone)) }, primary = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Sync now", "همگام‌سازی اکنون"), { onAction("ntp_sync_now") }, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Use phone time", "استفاده از ساعت گوشی"), { onAction("ntp_sync_browser") }, modifier = Modifier.weight(1f))
            }
        }

        ExpandableSettingsCard(p, "MikroTik", tx(fa, "RouterOS integration and protection action." , "یکپارچگی RouterOS و اقدام حفاظتی.")) {
            val src = data.mikrotik
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var url by remember(src.toString()) { mutableStateOf(src.optString("url")) }
            var username by remember(src.toString()) { mutableStateOf(src.optString("username")) }
            var password by remember(src.toString()) { mutableStateOf("") }
            var iface by remember(src.toString()) { mutableStateOf(src.optString("interface", "wlan1")) }
            var reenable by remember(src.toString()) { mutableStateOf(src.optBoolean("reenable", true)) }
            var delay by remember(src.toString()) { mutableStateOf(src.optInt("reenable_delay", 60).toString()) }
            ToggleRow(p, tx(fa, "Enable MikroTik integration", "فعال‌سازی یکپارچگی MikroTik"), tx(fa, "Apply the configured RouterOS action when protection is triggered.", "هنگام فعال‌شدن محافظت، اقدام RouterOS تعریف‌شده اجرا شود."), enabled) { enabled = it }
            NativeField(p, url, { url = it }, tx(fa, "Router address / API endpoint", "آدرس روتر / API"))
            NativeField(p, username, { username = it }, tx(fa, "Username", "نام کاربری"))
            NativeField(p, password, { password = it }, tx(fa, "New password (leave blank to keep saved)", "رمز جدید (برای حفظ رمز قبلی خالی بگذار)"), password = true)
            NativeField(p, iface, { iface = it }, tx(fa, "Wireless interface", "رابط بی‌سیم"))
            ToggleRow(p, tx(fa, "Re-enable after action", "فعال‌سازی مجدد پس از اقدام"), tx(fa, "Restore the interface after the configured delay.", "رابط پس از زمان تعیین‌شده دوباره فعال شود."), reenable) { reenable = it }
            NativeField(p, delay, { delay = it.filter(Char::isDigit).take(3) }, tx(fa, "Re-enable delay (5–300 seconds)", "تاخیر فعال‌سازی مجدد (۵ تا ۳۰۰ ثانیه)"), keyboard = KeyboardType.Number)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Save MikroTik", "ذخیره MikroTik"), { val payload = JSONObject().put("enabled", enabled).put("url", url).put("username", username).put("interface", iface).put("reenable", reenable).put("reenable_delay", delay.toIntOrNull() ?: 60); if (password.isNotBlank()) payload.put("password", password); onSave("mikrotik", payload) }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Run test", "اجرای آزمایش"), { onAction("test_mikrotik") }, modifier = Modifier.weight(1f))
            }
            Text(if (src.optBoolean("password_set")) tx(fa, "A router password is stored; it is never shown in the app.", "رمز روتر ذخیره شده و در برنامه نمایش داده نمی‌شود.") else tx(fa, "No router password is stored.", "رمزی برای روتر ذخیره نشده است."), color = p.muted, fontSize = 9.sp)
        }

        ExpandableSettingsCard(p, tx(fa, "Lighting · WS2812 effects", "نورپردازی · افکت‌های WS2812"), tx(fa, "Effect, colors, speed and brightness." , "افکت، رنگ‌ها، سرعت و روشنایی.")) {
            val src = data.led
            var effect by remember(src.toString()) { mutableStateOf(src.optInt("effect", 12).toString()) }
            var color1 by remember(src.toString()) { mutableStateOf(src.optString("color1", "#FF0000")) }
            var color2 by remember(src.toString()) { mutableStateOf(src.optString("color2", "#00FF00")) }
            var speed by remember(src.toString()) { mutableStateOf(src.optInt("speed", 10).toString()) }
            var brightness by remember(src.toString()) { mutableStateOf(src.optInt("brightness", 128).toString()) }
            val effects = listOf(
                8 to tx(fa, "Solid", "ثابت"), 9 to tx(fa, "Breathing", "تنفسی"),
                10 to tx(fa, "Chase", "تعقیبی"), 11 to tx(fa, "Sparkle", "درخشش"),
                12 to tx(fa, "Rainbow", "رنگین‌کمان"), 13 to tx(fa, "Alternate", "متناوب"),
                14 to tx(fa, "Rainbow Chase", "تعقیب رنگین‌کمان"), 15 to tx(fa, "Fire", "آتش"),
                16 to tx(fa, "Twinkle", "چشمک‌زن"), 17 to tx(fa, "Color Wipe", "پاک‌سازی رنگ"),
                18 to tx(fa, "Theater", "تئاتر")
            )
            var effectMenuOpen by remember { mutableStateOf(false) }
            Text(tx(fa, "LED effect", "افکت LED"), color = p.muted, fontSize = 10.sp)
            Box {
                OutlinedButton(onClick = { effectMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(effects.firstOrNull { it.first == (effect.toIntOrNull() ?: 12) }?.second ?: "Rainbow", color = p.text)
                }
                DropdownMenu(expanded = effectMenuOpen, onDismissRequest = { effectMenuOpen = false }) {
                    effects.forEach { (id, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { effect = id.toString(); effectMenuOpen = false })
                    }
                }
            }
            val selectedEffect = effect.toIntOrNull() ?: 12
            val effectUsesPrimaryColor = selectedEffect in setOf(8, 9, 10, 11, 13, 17, 18)
            val effectUsesSecondaryColor = selectedEffect == 13
            if (effectUsesPrimaryColor) {
                ColorPickerField(p, fa, tx(fa, "Primary color", "رنگ اصلی"), color1) { color1 = it }
            }
            if (effectUsesSecondaryColor) {
                ColorPickerField(p, fa, tx(fa, "Secondary color", "رنگ دوم"), color2) { color2 = it }
            }
            if (!effectUsesPrimaryColor) {
                Text(tx(fa, "This effect uses its own generated palette; custom colors are not used.", "این افکت از پالت رنگی داخلی استفاده می‌کند و رنگ سفارشی ندارد."), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
            } else if (effectUsesPrimaryColor && !effectUsesSecondaryColor) {
                Text(tx(fa, "This effect uses only the primary color.", "این افکت فقط از رنگ اصلی استفاده می‌کند."), color = p.muted, fontSize = 10.sp)
            }
            val speedValue = (speed.toIntOrNull() ?: 10).coerceIn(10, 1000)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(fa, "Speed", "سرعت"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("$speedValue ms", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(value = speedValue.toFloat(), onValueChange = { speed = it.roundToInt().coerceIn(10, 1000).toString() }, valueRange = 10f..1000f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("10 ms", color = p.muted, fontSize = 9.sp); Text("1000 ms", color = p.muted, fontSize = 9.sp)
                }
            }
            val brightnessValue = (brightness.toIntOrNull() ?: 128).coerceIn(0, 255)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(fa, "Brightness", "روشنایی"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("$brightnessValue / 255", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(value = brightnessValue.toFloat(), onValueChange = { brightness = it.roundToInt().coerceIn(0, 255).toString() }, valueRange = 0f..255f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("0", color = p.muted, fontSize = 9.sp); Text("255", color = p.muted, fontSize = 9.sp)
                }
            }
            ActionButton(p, tx(fa, "Save lighting", "ذخیره نورپردازی"), { onSave("led", JSONObject().put("effect", effect.toIntOrNull() ?: 12).put("color1", color1).put("color2", color2).put("speed", (speed.toIntOrNull() ?: 10).coerceIn(10, 1000)).put("brightness", (brightness.toIntOrNull() ?: 128).coerceIn(0, 255))) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Lighting · Client disconnect alert", "نورپردازی · هشدار قطع اتصال کلاینت"), tx(fa, "Configure the physical alert for client-initiated disconnects." , "هشدار فیزیکی قطع اتصال آغازشده از سمت کلاینت را تنظیم کن.")) {
            val src = data.disconnectLed
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled", true)) }
            var color by remember(src.toString()) { mutableStateOf(src.optString("color", "#AA00FF")) }
            ToggleRow(p, tx(fa, "Disconnect LED alert", "هشدار LED قطع اتصال"), tx(fa, "AP-originated disconnects do not trigger this alert in the current firmware baseline.", "در نسخه فعلی فریم‌ور، قطع اتصال آغازشده از سمت AP این هشدار را فعال نمی‌کند."), enabled) { enabled = it }
            ColorPickerField(p, fa, tx(fa, "Alert color", "رنگ هشدار"), color) { color = it }
            ActionButton(p, tx(fa, "Save disconnect alert", "ذخیره هشدار قطع اتصال"), { onSave("disconnect_led", JSONObject().put("enabled", enabled).put("color", color)) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Automation · Schedule", "اتوماسیون · زمان‌بندی"), tx(fa, "Set weekly quiet hours for LED and sound." , "ساعت‌های سکوت هفتگی برای LED و صدا.")) {
            val src = data.schedule
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var start by remember(src.toString()) { mutableStateOf(normalizeScheduleTime(src.optString("start", "22:00"), "22:00")) }
            var end by remember(src.toString()) { mutableStateOf(normalizeScheduleTime(src.optString("end", "06:00"), "06:00")) }
            var days by remember(src.toString()) { mutableStateOf(src.optInt("days", 127).coerceIn(0, 127)) }
            var action by remember(src.toString()) { mutableStateOf(src.optInt("action", 2).coerceIn(0, 2)) }
            val scheduleValid = !enabled || (days != 0 && start != end)
            ToggleRow(p, tx(fa, "Enable schedule", "فعال‌سازی زمان‌بندی"), tx(fa, "Schedule follows the device timezone.", "زمان‌بندی از منطقه زمانی خود دستگاه استفاده می‌کند."), enabled) { enabled = it }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                ScheduleTimePickerField(
                    p = p, value = start, label = tx(fa, "Start time", "شروع بازه"),
                    modifier = Modifier.weight(1f), onTimeSelected = { start = it }
                )
                ScheduleTimePickerField(
                    p = p, value = end, label = tx(fa, "End time", "پایان بازه"),
                    modifier = Modifier.weight(1f), onTimeSelected = { end = it }
                )
            }
            Text(tx(fa, "24-hour time · use the keyboard icon in the picker for direct entry.", "ساعت ۲۴ ساعته · برای ورود مستقیم، آیکون صفحه‌کلید داخل انتخابگر را بزن."), color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
            Text(tx(fa, "Days (Monday to Sunday)", "روزها (دوشنبه تا یکشنبه)"), color = p.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            val labels = if (fa) listOf("د", "س", "چ", "پ", "ج", "ش", "ی") else listOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                labels.forEachIndexed { index, label ->
                    val chosen = (days and (1 shl index)) != 0
                    Box(Modifier.weight(1f).clip(CircleShape).background(if (chosen) p.accent.copy(alpha = .2f) else p.panelAlt).border(1.dp, if (chosen) p.accent else p.border, CircleShape).clickable { days = if (chosen) days and (1 shl index).inv() else days or (1 shl index) }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                        Text(label, color = if (chosen) p.accent else p.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(tx(fa, "Action", "اقدام"), color = p.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            listOf(tx(fa, "Turn LED off", "خاموش‌کردن LED"), tx(fa, "Mute sound", "قطع صدا"), tx(fa, "LED + sound off", "خاموش‌کردن LED و صدا")).forEachIndexed { index, label ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (action == index) p.accent.copy(alpha = .12f) else p.panelAlt.copy(alpha = .52f))
                        .border(1.dp, if (action == index) p.accent.copy(alpha = .65f) else p.border, RoundedCornerShape(12.dp))
                        .clickable { action = index }.padding(horizontal = 11.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(17.dp).clip(CircleShape).border(1.5.dp, if (action == index) p.accent else p.muted, CircleShape).padding(3.dp)) {
                        if (action == index) Box(Modifier.fillMaxSize().clip(CircleShape).background(p.accent))
                    }
                    Spacer(Modifier.width(9.dp)); Text(label, color = p.text, fontSize = 11.sp)
                }
            }
            if (enabled && days == 0) {
                Text(tx(fa, "Select at least one day before enabling the schedule.", "برای فعال‌کردن زمان‌بندی، حداقل یک روز را انتخاب کن."), color = p.red, fontSize = 10.sp, lineHeight = 15.sp)
            }
            if (enabled && start == end) {
                Text(tx(fa, "Start and End cannot be the same. The firmware treats that interval as always active.", "زمان شروع و پایان نمی‌توانند یکسان باشند؛ فریم‌ور این حالت را به‌عنوان بازه همیشه‌فعال تفسیر می‌کند."), color = p.red, fontSize = 10.sp, lineHeight = 15.sp)
            }
            if (enabled && start > end) {
                Text(tx(fa, "Overnight interval: VF38 checks the weekday mask again after midnight. Also select the following day to keep the interval active.", "این بازه از نیمه‌شب عبور می‌کند: فریم‌ور VF38 بعد از نیمه‌شب روز هفته را دوباره بررسی می‌کند. برای ادامه‌ی بازه، روز بعد را هم انتخاب کن."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
            }
            Text("${tx(fa, "Schedule state", "وضعیت زمان‌بندی")}: ${if (src.optBoolean("active")) tx(fa, "ACTIVE", "فعال") else tx(fa, "INACTIVE", "غیرفعال")}", color = p.muted, fontSize = 9.sp)
            ActionButton(p, tx(fa, "Save schedule", "ذخیره زمان‌بندی"), { onSave("schedule", JSONObject().put("enabled", enabled).put("start", start).put("end", end).put("days", days).put("action", action)) }, enabled = scheduleValid, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Access control · Deauth whitelist", "کنترل دسترسی · فهرست سفید Deauth"), tx(fa, "Maintain trusted MAC addresses excluded by whitelist-aware logic." , "نشانی‌های MAC مورد اعتماد را برای منطق فهرست سفید نگه دار.")) {
            val src = data.whitelist
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            val initialEntries = remember(src.toString()) {
                val array = src.optJSONArray("entries") ?: JSONArray()
                (0 until array.length()).mapNotNull { index ->
                    val item = array.optJSONObject(index) ?: return@mapNotNull null
                    val mac = item.optString("mac").trim()
                    if (mac.isBlank()) null else mac.uppercase(Locale.US) to item.optString("name")
                }
            }
            var entryRows by remember(src.toString()) { mutableStateOf(initialEntries) }
            var newMac by remember { mutableStateOf("") }
            var newAlias by remember { mutableStateOf("") }
            var selectedTrackedMac by remember { mutableStateOf("") }
            var trackedMenuOpen by remember { mutableStateOf(false) }
            var validation by remember(src.toString()) { mutableStateOf("") }
            val tracked = trackedClients.filter { it.optString("mac").isNotBlank() }
                .distinctBy { it.optString("mac").uppercase(Locale.US) }
            ToggleRow(p, tx(fa, "Enable whitelist", "فعال‌سازی فهرست سفید"),
                tx(fa, "As in the WebUI: automatically deauthenticate clients outside this trusted list on supported WPA/WPA2 networks.", "مانند WebUI: در شبکه‌های WPA/WPA2 پشتیبانی‌شده، کلاینت‌های خارج از این فهرست مورد اعتماد به‌صورت خودکار Deauth می‌شوند."), enabled) { enabled = it }

            Text(tx(fa, "Trusted clients", "کلاینت‌های مورد اعتماد"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (entryRows.isEmpty()) {
                Text(tx(fa, "No clients have been added yet.", "هنوز کلاینتی اضافه نشده است."), color = p.muted, fontSize = 10.sp)
            } else {
                entryRows.forEachIndexed { index, (mac, alias) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.panelAlt.copy(alpha = .62f)).padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(ltrTechnical(fa, mac), color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(alias.ifBlank { tx(fa, "No alias", "بدون نام") }, color = p.muted, fontSize = 10.sp)
                        }
                        TextButton(onClick = { entryRows = entryRows.filterIndexed { i, _ -> i != index }; validation = "" }) {
                            Text(tx(fa, "Remove", "حذف"), color = p.red, fontSize = 11.sp)
                        }
                    }
                }
            }
            Text("${tx(fa, "Entries", "تعداد")}: ${entryRows.size}/32  ·  ${tx(fa, "Live tracked clients", "کلاینت‌های در حال ردیابی")}: ${tracked.size}", color = p.muted, fontSize = 9.sp)

            Text(tx(fa, "Add trusted client", "افزودن کلاینت مورد اعتماد"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(tx(fa, "Select a live tracked client to fill its MAC, or enter a MAC manually.", "یک کلاینت در حال ردیابی انتخاب کن تا MAC آن وارد شود، یا MAC را دستی بنویس."), color = p.muted, fontSize = 10.sp)
            Box {
                OutlinedButton(onClick = { trackedMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        when {
                            selectedTrackedMac.isNotBlank() -> tracked.firstOrNull { it.optString("mac").equals(selectedTrackedMac, true) }?.let { "${it.optString("mac")}  ·  ${it.optInt("rssi")} dBm" } ?: selectedTrackedMac
                            else -> tx(fa, "Choose from tracked clients (${tracked.size})", "انتخاب از کلاینت‌های ردیابی‌شده (${tracked.size})")
                        }, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                DropdownMenu(expanded = trackedMenuOpen, onDismissRequest = { trackedMenuOpen = false }) {
                    if (tracked.isEmpty()) {
                        DropdownMenuItem(text = { Text(tx(fa, "No tracked clients available", "کلاینت ردیابی‌شده‌ای موجود نیست")) }, onClick = { trackedMenuOpen = false }, enabled = false)
                    } else tracked.forEach { client ->
                        val mac = client.optString("mac").uppercase(Locale.US)
                        DropdownMenuItem(
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(ltrTechnical(fa, mac), fontSize = 11.sp)
                                    Text("${client.optInt("rssi")} dBm  ·  ${client.optString("state", "Unknown")}", fontSize = 9.sp, color = p.muted)
                                }
                            },
                            onClick = { selectedTrackedMac = mac; newMac = mac; trackedMenuOpen = false }
                        )
                    }
                }
            }
            NativeField(p, newMac, { newMac = it.uppercase(Locale.US).take(17) }, tx(fa, "MAC address", "آدرس MAC"))
            NativeField(p, newAlias, { newAlias = it.take(64) }, tx(fa, "Device name / alias (optional)", "نام دستگاه / نام مستعار (اختیاری)"))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                ActionButton(p, tx(fa, "Add client", "افزودن کلاینت"), {
                    val normalized = newMac.trim().uppercase(Locale.US)
                    val valid = Regex("(?i)^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(normalized)
                    when {
                        entryRows.size >= 32 -> validation = tx(fa, "Maximum 32 entries are supported.", "حداکثر ۳۲ ورودی پشتیبانی می‌شود.")
                        !valid -> validation = tx(fa, "Enter a valid MAC address.", "یک آدرس MAC معتبر وارد کن.")
                        entryRows.any { it.first.equals(normalized, true) } -> validation = tx(fa, "This MAC is already in the whitelist.", "این MAC از قبل در فهرست مجاز است.")
                        else -> { entryRows = entryRows + (normalized to newAlias.trim()); newMac = ""; newAlias = ""; selectedTrackedMac = ""; validation = "" }
                    }
                }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Refresh clients", "به‌روزرسانی کلاینت‌ها"), { onAction("refresh_clients") }, modifier = Modifier.weight(1f))
            }
            if (validation.isNotBlank()) Text(validation, color = p.red, fontSize = 10.sp)
            ActionButton(p, tx(fa, "Save whitelist", "ذخیره فهرست سفید"), {
                val arr = JSONArray()
                entryRows.forEach { (mac, alias) -> arr.put(JSONObject().put("mac", mac).put("name", alias.take(64))) }
                onSave("whitelist", JSONObject().put("enabled", enabled).put("entries", arr))
            }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Device security · Credentials", "امنیت دستگاه · اعتبارنامه‌ها"), tx(fa, "Change device login and WAPFire access-point credentials." , "تغییر رمز ورود دستگاه و مشخصات اکسس‌پوینت WAPFire.")) {
            val src = data.general
            var ssid by remember(src.toString()) { mutableStateOf(src.optString("ap_ssid", "WAPFire")) }
            var adminPass by remember { mutableStateOf("") }
            var apPass by remember { mutableStateOf("") }
            Text(tx(fa, "Leave password fields empty to keep the current credentials.", "برای حفظ رمزهای فعلی، فیلدهای رمز را خالی بگذار."), color = p.muted, fontSize = 10.sp)
            Text(if (src.optBoolean("ap_pass_set")) tx(fa, "WAPFire Wi-Fi password is configured.", "رمز Wi‑Fi شبکه WAPFire تنظیم شده است.") else tx(fa, "WAPFire access point is open (no password stored).", "اکسس‌پوینت WAPFire بدون رمز است."), color = p.muted, fontSize = 9.sp)
            NativeField(p, ssid, { ssid = it }, tx(fa, "WAPFire AP SSID", "نام شبکه WAPFire"))
            NativeField(p, apPass, { apPass = it }, tx(fa, "New WAPFire Wi-Fi password", "رمز جدید Wi‑Fi WAPFire"), password = true)
            NativeField(p, adminPass, { adminPass = it }, tx(fa, "New administrator password", "رمز جدید مدیر"), password = true)
            InfoLine(p, tx(fa, "Beacon response", "پاسخ Beacon"), if (src.optBoolean("beacon_mode")) tx(fa, "ACTIVE", "فعال") else tx(fa, "Standby", "آماده‌باش"))
            Text(tx(fa, "Beacon transmission is not a normal device-security switch. Firmware activates it automatically during Self-Protect when an attack is detected and the target AP is known, then disables it when protection ends.", "ارسال Beacon یک کلید معمولی در امنیت دستگاه نیست. فریم‌ور هنگام فعال‌شدن Self-Protect، در صورت تشخیص حمله و مشخص‌بودن AP هدف، آن را خودکار فعال می‌کند و پس از پایان محافظت غیرفعال می‌سازد."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
            ActionButton(p, tx(fa, "Save device credentials", "ذخیره اعتبارنامه‌های دستگاه"), {
                val payload = JSONObject().put("ap_ssid", ssid)
                if (apPass.isNotBlank()) payload.put("ap_pass", apPass)
                if (adminPass.isNotBlank()) payload.put("adminpass", adminPass)
                onSave("general", payload)
                apPass = ""; adminPass = ""
            }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Firmware · Backup & maintenance", "فریم‌ور · پشتیبان و نگهداری"), tx(fa, "Device information, export, restore, OTA and system actions." , "اطلاعات دستگاه، خروجی، بازیابی، OTA و عملیات سیستمی.")) {
            val fw = data.firmware
            InfoLine(p, "Firmware", fw.optString("version", "—"))
            InfoLine(p, "Chip", fw.optString("esp_model", "—"))
            InfoLine(p, "ESP-IDF", fw.optString("sdk", "—"))
            InfoLine(p, "Flash", fw.optString("flash", "—"))
            InfoLine(p, "CPU", fw.optString("cpu_freq", "—"))
            InfoLine(p, "Free OTA space", fw.optString("free_space", "—"))
            InfoLine(p, "PSRAM", fw.optString("psram", "—"))
            InfoLine(p, "Free heap", fw.optString("free_heap", "—"))
            InfoLine(p, "Largest free block", fw.optString("max_alloc", "—"))
            if (fw.optString("build_tag").isNotBlank()) InfoLine(p, "Build", fw.optString("build_tag"))
            val backup = data.backupInfo
            if (backup.length() > 0) {
                InfoLine(p, tx(fa, "Saved settings", "تنظیمات ذخیره‌شده"), backup.optString("settings_count", "—"))
                InfoLine(p, tx(fa, "Backup format", "فرمت پشتیبان"), backup.optString("version", "WAPFire"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Export backup", "خروجی پشتیبان"), { showBackupWarning = true }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Restore backup", "بازیابی پشتیبان"), { showRestoreWarning = true }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Check update", "بررسی به‌روزرسانی"), { onAction("check_update") }, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Install .bin", "نصب فایل .bin"), onFirmwarePick, primary = true, modifier = Modifier.weight(1f))
            }
            Text(tx(fa, "OTA accepts a native ESP32 firmware .bin image. Do not power off the board during upload.", "OTA یک فایل firmware با فرمت .bin مخصوص ESP32 می‌پذیرد. هنگام بارگذاری برق برد را قطع نکن."), color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
            DividerLine(p)
            ActionButton(p, tx(fa, "Restart Wi-Fi services", "راه‌اندازی مجدد سرویس‌های Wi‑Fi"), { pendingMaintenance = "wifi_restart" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Reboot device", "راه‌اندازی مجدد دستگاه"), { pendingMaintenance = "reboot" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Return to initial setup", "بازگشت به راه‌اندازی اولیه"), { pendingMaintenance = "force_setup" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Factory reset", "بازنشانی کارخانه‌ای"), { pendingMaintenance = "factory_reset" }, modifier = Modifier.fillMaxWidth())
            Text(tx(fa, "Return to setup preserves saved settings but disables normal configured mode. Factory reset erases saved settings and credentials.", "بازگشت به Setup تنظیمات ذخیره‌شده را نگه می‌دارد اما حالت پیکربندی‌شده را غیرفعال می‌کند. بازنشانی کارخانه‌ای تنظیمات و رمزها را پاک می‌کند."), color = p.red, fontSize = 9.sp)
        }
    }
}
