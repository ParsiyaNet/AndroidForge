# WAPFire Mobile 4.1.50

- Renamed the assistant tab and setup presentation to Nara (نارا).
- Updated the live character title, speech label, and accessibility description to identify Nara as the WAPFire network guardian.
- Kept the AndroidForge `v06_clean.livliv` character model unchanged; its embedded model metadata already declares the name Nara.
- Updated the assistant bootstrap asset/build version and Android versionCode to 91 / versionName 4.1.50.
- Corrected the character notice to identify the v06_clean package.


## Character framing correction (4.1.50 fit update)

- Reduced the LivLiv character zoom in the Assistant view so the left/right edges and upper silhouette remain inside the frame.
- Added a small downward pan in both views; the Overview preview places Nara slightly lower to prevent the top of the head from being clipped.
- Added a small bottom inset to the full Assistant stage so the lower frame edge sits below the character with breathing room.
- Kept the selected 4.1.50 model, textures, labels, UI and runtime behavior unchanged.
- Increased Android versionCode to 92 for install-as-update compatibility while retaining versionName 4.1.50.

### Assistant layout refinement (build 93)
- Overview character framing is slightly more zoomed-in, with a small upward compensation to keep the lower silhouette visible.
- Full Assistant places the Monitoring pill centered at the top, aligned with the Close and theme controls.
- Full Assistant now renders the live speech text in its own native card below the character frame, matching the Overview speech-card treatment.
- The native state selector remains below the speech card.


### Assistant and navigation polish (build 94)

- Moved the full Assistant character slightly lower and increased its scale so the body sits closer to the lower character-frame edge while preserving side/head clearance. Overview framing remains unchanged.
- Removed the unused full-view title and stale text-only Idle placeholder from the immersive Assistant WebView.
- Standardized bottom-navigation icon and label slots so Overview, Clients, Events, Nara and Settings share the same alignment and typography.
- Replaced the Settings emoji with a monochrome vector gear matching the other navigation icons.
- Increased Android versionCode to 94 while retaining versionName 4.1.50.


### Assistant frame cleanup (build 95)

- Bottom navigation: Overview, Clients, Events, Nara and Settings are now identical fixed-size cells in one row (24dp icon slot, 14dp label slot, 54dp tall). The font-glyph icons (⌂ ◎ ≋ ✧) that sat at different heights were replaced by drawn vector icons, so icons and labels line up on one common line.
- Nara (full Assistant): the model is now anchored so its cut-off hem sits on the lower edge of the character frame. The vertical offset is computed from the real frame size and the model's own canvas, and is recalculated on every resize. Animations can no longer lift the hem off the frame edge.
- Nara (full Assistant): the "Idle" text at the top is gone. The web layer no longer contains the old web state buttons or title at all, draws no free-standing text, and sweeps any stray "Idle" text node on startup.
- Nara (full Assistant): removed the dark/light theme button. The close button stays at the top-left, the Monitoring pill stays centred.
- Overview: removed the OPEN button above the character. Nara is opened from the Nara tab. Overview character framing is unchanged.
- Android versionCode 95 (versionName stays 4.1.50).
