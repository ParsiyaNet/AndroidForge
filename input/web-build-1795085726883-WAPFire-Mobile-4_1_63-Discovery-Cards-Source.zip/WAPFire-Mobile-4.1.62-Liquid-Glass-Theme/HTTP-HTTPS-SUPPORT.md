# WAPFire HTTP / HTTPS support

The native Android API client now supports both WAPFire web protocols without a separate host setting. It starts with the saved device host, follows the device's HTTP-to-HTTPS 307 response when HTTPS is enabled, and pins the firmware certificate SHA-256 fingerprint in `WapFireTls.kt`. The host-scoped session cookie is preserved while the scheme changes.

Local discovery probes HTTP first and validates the HTTPS endpoint after a redirect. Backup download and firmware upload use the same certificate pin. The app only falls back from a remembered HTTPS URL to HTTP when the HTTPS TCP endpoint is unavailable; a certificate pin/verification failure never triggers a downgrade.
