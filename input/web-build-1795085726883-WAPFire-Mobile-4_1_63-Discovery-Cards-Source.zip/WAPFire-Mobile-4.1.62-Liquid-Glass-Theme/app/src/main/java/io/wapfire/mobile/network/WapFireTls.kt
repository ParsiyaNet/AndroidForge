package io.wapfire.mobile.network

import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.Locale
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * TLS configuration for WAPFire's built-in self-signed certificate.
 * Trust is limited to the exact SHA-256 certificate fingerprint shipped by the
 * firmware. This is deliberately not a global trust-all certificate manager.
 */
internal object WapFireTls {
    private const val EXPECTED_CERT_SHA256 =
        "6EE67AD912BA88A1D0ABFC0D27E8FD733638B2C356DB46BC63D3972BDE4890C7"

    private val pinnedTrustManager = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
            throw CertificateException("WAPFire client certificates are not supported")
        }

        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            if (chain.isEmpty()) throw CertificateException("WAPFire certificate is missing")
            val digest = MessageDigest.getInstance("SHA-256").digest(chain[0].encoded)
            val actual = digest.joinToString("") { byte ->
                String.format(Locale.ROOT, "%02X", byte.toInt() and 0xFF)
            }
            if (!actual.equals(EXPECTED_CERT_SHA256, ignoreCase = true)) {
                throw CertificateException("The HTTPS certificate does not belong to this WAPFire firmware")
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    private val sslContext: SSLContext by lazy {
        SSLContext.getInstance("TLS").apply {
            init(null, arrayOf<TrustManager>(pinnedTrustManager), SecureRandom())
        }
    }

    fun configure(connection: HttpURLConnection) {
        if (connection is HttpsURLConnection) {
            connection.sslSocketFactory = sslContext.socketFactory
            // The certificate is self-signed and uses a device identity rather than
            // a public DNS name. The cryptographic certificate pin above is the
            // identity check; do not use this verifier without that trust manager.
            connection.hostnameVerifier = HostnameVerifier { _, _ -> true }
        }
    }

    fun openConnection(url: URL): HttpURLConnection {
        return (url.openConnection() as HttpURLConnection).also(::configure)
    }
}
