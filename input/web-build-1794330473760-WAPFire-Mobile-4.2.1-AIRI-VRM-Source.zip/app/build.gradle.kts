import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 103
        versionName = "4.2.1"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// The native WAPFire 4.2.0 app and UI remain unchanged. Build-time vendor the pinned
// Three.js/VRM runtime plus AIRI's own idle_loop.vrma. The installed APK is fully offline.
val vendorAiriVrmRuntime by tasks.registering {
    val vendorDir = file("src/main/assets/assistant/vendor")
    val threeModule = File(vendorDir, "three.module.js")
    val threeCore = File(vendorDir, "three.core.js")
    val gltfLoader = File(vendorDir, "loaders/GLTFLoader.js")
    val geometryUtils = File(vendorDir, "utils/BufferGeometryUtils.js")
    val vrmModule = File(vendorDir, "three-vrm.module.min.js")
    val vrmAnimationModule = File(vendorDir, "three-vrm-animation.module.js")
    val threeLicense = File(vendorDir, "THREE-LICENSE.txt")
    val vrmLicense = File(vendorDir, "THREE-VRM-LICENSE.txt")
    val vrmAnimationLicense = File(vendorDir, "THREE-VRM-ANIMATION-LICENSE.txt")
    outputs.files(threeModule, threeCore, gltfLoader, geometryUtils, vrmModule, vrmAnimationModule,
        threeLicense, vrmLicense, vrmAnimationLicense)
    outputs.upToDateWhen { false }
    doLast {
        fun fetch(url: String, destination: File, minimumBytes: Int, marker: String? = null) {
            if (destination.exists() && destination.length() >= minimumBytes &&
                (marker == null || destination.readText(Charsets.UTF_8).contains(marker))) return
            destination.parentFile.mkdirs()
            val temporary = File(destination.parentFile, destination.name + ".download")
            var connection: HttpURLConnection? = null
            try {
                val active = URL(url).openConnection() as HttpURLConnection
                connection = active
                active.connectTimeout = 30000
                active.readTimeout = 120000
                active.instanceFollowRedirects = true
                active.setRequestProperty("User-Agent", "WAPFire-AIRI-VRM/4.2.1")
                active.setRequestProperty("Accept", "application/javascript,text/plain,*/*")
                if (active.responseCode != HttpURLConnection.HTTP_OK) throw IOException("HTTP ${active.responseCode} from $url")
                active.inputStream.use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
                if (temporary.length() < minimumBytes) throw IOException("Unexpectedly small download from $url")
                if (marker != null && !temporary.readText(Charsets.UTF_8).contains(marker)) throw IOException("Missing marker '$marker' in $url")
                Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                logger.lifecycle("Vendored ${destination.relativeTo(projectDir)} (${destination.length()} bytes)")
            } finally { temporary.delete(); connection?.disconnect() }
        }
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js", threeModule, 1000, "three.core.js")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.core.js", threeCore, 100000, "REVISION = '180'")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/loaders/GLTFLoader.js", gltfLoader, 10000, "class GLTFLoader")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/utils/BufferGeometryUtils.js", geometryUtils, 10000, "toTrianglesDrawMode")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.5.5/lib/three-vrm.module.min.js", vrmModule, 50000, "VRMLoaderPlugin")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-animation@3.5.5/lib/three-vrm-animation.module.js", vrmAnimationModule, 20000, "VRMAnimationLoaderPlugin")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/LICENSE", threeLicense, 200, "MIT License")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.5.5/LICENSE", vrmLicense, 200, "MIT License")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-animation@3.5.5/LICENSE", vrmAnimationLicense, 200, "MIT License")
        fun rewriteImports(sourceFile: File, replacements: Map<String, String>) {
            var source = sourceFile.readText(Charsets.UTF_8)
            for ((bare, local) in replacements) {
                val escaped = Regex.escape(bare)
                source = Regex("""from\s*(['"])$escaped\1""").replace(source) { it.value.replace(bare, local) }
            }
            val unresolved = Regex("""from\s*(['"])(three|@pixiv/three-vrm-core)\1""").find(source)
            if (unresolved != null) throw GradleException("Unresolved module import ${unresolved.value} in ${sourceFile.name}")
            sourceFile.writeText(source, Charsets.UTF_8)
        }
        rewriteImports(gltfLoader, mapOf("three" to "../three.module.js"))
        rewriteImports(geometryUtils, mapOf("three" to "../three.module.js"))
        rewriteImports(vrmModule, mapOf("three" to "./three.module.js"))
        rewriteImports(vrmAnimationModule, mapOf("three" to "./three.module.js", "@pixiv/three-vrm-core" to "./three-vrm.module.min.js"))
        logger.lifecycle("Three.js r180 + three-vrm 3.5.5 + three-vrm-animation 3.5.5 vendored for offline AIRI VRM playback.")
    }
}

val installAiriIdleMotion by tasks.registering {
    val output = file("src/main/assets/assistant/motions/idle_loop.vrma")
    outputs.file(output)
    outputs.upToDateWhen { false }
    doLast {
        fun gitBlobSha1(f: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${f.length()}\u0000".toByteArray(Charsets.UTF_8))
            f.inputStream().use { input ->
                val buffer = ByteArray(65536)
                while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
            }
            return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
        }
        val expected = "26b28f4e4227c48eecdd29d25e3dc6f4c6ac3844"
        val commit = "6e687a81dc74194009d3ca874cc784faf49a3a01"
        val url = "https://raw.githubusercontent.com/tegnike/aituber-kit/$commit/public/idle_loop.vrma"
        output.parentFile.mkdirs()
        if (output.exists() && output.length() > 1024 && gitBlobSha1(output) == expected) {
            logger.lifecycle("Verified AIRI idle_loop.vrma (pinned Git blob SHA-1 $expected)")
        } else {
            val tmp = File(output.parentFile, "idle_loop.vrma.download")
            var connection: HttpURLConnection? = null
            try {
                val active = URL(url).openConnection() as HttpURLConnection
                connection = active
                active.connectTimeout = 30000
                active.readTimeout = 120000
                active.instanceFollowRedirects = true
                active.setRequestProperty("User-Agent", "WAPFire-AIRI-VRM/4.2.1")
                active.setRequestProperty("Accept", "application/octet-stream")
                if (active.responseCode != HttpURLConnection.HTTP_OK) throw IOException("HTTP ${active.responseCode} from $url")
                active.inputStream.use { input -> tmp.outputStream().use { outputStream -> input.copyTo(outputStream) } }
                val actual = gitBlobSha1(tmp)
                if (actual != expected) throw GradleException("AIRI idle_loop.vrma integrity mismatch: expected $expected, received $actual")
                Files.move(tmp.toPath(), output.toPath(), StandardCopyOption.REPLACE_EXISTING)
                logger.lifecycle("Installed pinned AIRI idle_loop.vrma ($actual)")
            } finally { tmp.delete(); connection?.disconnect() }
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(vendorAiriVrmRuntime, installAiriIdleMotion)
}
