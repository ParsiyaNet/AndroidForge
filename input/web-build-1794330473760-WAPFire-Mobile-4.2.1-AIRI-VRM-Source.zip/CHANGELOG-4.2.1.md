# WAPFire Mobile 4.2.1 — AIRI VRM character engine

- Uses WAPFire Mobile 4.2.0 Dark Matte Glass as the application/UI baseline.
- Replaces only the Live2D character rendering path with the AIRI default AvatarSample_A VRM model.
- Ports AIRI's VRM model preparation, VRMA clip creation and normalized-hips root re-anchoring.
- Uses the exact `idle_loop.vrma` asset from the pinned AIRI source as a persistent body idle; state changes never restart the loop.
- Ports AIRI's manual frame order for MToon, Humanoid, LookAt, Blink, Emote, Expression Manager, Node Constraint and Spring Bone (voice/lip-sync intentionally omitted).
- Adds AIRI-style 0.2-second automatic blinking, probabilistic eye saccades/look-at and cubic emotion transitions.
- Avoids unrelated generic full-body clips; the pinned AIRI VRM stage defines a single default body idle clip, with other natural motion handled by gaze, emote and Spring Bone systems.
- Keeps WAPFire's original compact/full framing and zoom values, native state UI and WebView retention behavior.
- Removes assistant TTS/speech output and the speaker/mute control. No AIRI audio or cloud services are included.
- Three.js/VRM runtime and idle animation are pinned and downloaded during Android build; all assets are packaged, so installed runtime is offline.

Build: `gradlew.bat :app:assembleDebug` (AndroidForge may build the supplied ZIP directly).
