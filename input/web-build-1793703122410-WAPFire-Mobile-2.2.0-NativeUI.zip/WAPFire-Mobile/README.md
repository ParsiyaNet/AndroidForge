# WAPFire Mobile 2.2.0 — Native Control Center

A standalone Android application for WAPFire. The entire user interface is built natively with Jetpack Compose; it does not embed, display, or skin the firmware WebUI.

## Native screens
- Device discovery: nearby WAPFire Wi-Fi, local-network discovery, and manual IP.
- Secure sign-in using the firmware session cookie.
- First-run device setup.
- Live dashboard with target status, threat assessment, radio activity chart, telemetry and detection breakdown.
- Target AP scan and exact SSID/BSSID/channel selection.
- Tracked client list and event timeline.
- Native device controls for LED, smart LED, sound, automatic channel tracking, self-protect, and SoftAP.
- Dark/light appearance and English/Persian labels.

## Firmware integration
The app talks directly to the firmware HTTP API (`/api/status`, `/api/settings`, `/api/chart_data`, `/api/scan`, `/api/select_target`, `/api/tracked_clients`, and `/api/logs`). All device actions are acknowledged by the API; the app does not show a successful-save state unless the device returns success.

## Current scope
This release is the first fully native UI pass for the core monitoring workflow. Advanced firmware sections such as Ethernet, NTP, schedules, MikroTik integration, external HTTP event forwarding, custom LED-effect editing, backup/restore and OTA update are not yet exposed as native screens. They are intentionally not represented by fake controls; they remain available through the firmware itself until their native settings pages are implemented.

## Build
Open the project in Android Studio, or run `gradlew assembleDebug`. Application ID: `io.wapfire.mobile`. Minimum Android version: Android 10 (API 29), required for Android's Wi-Fi network request flow.
