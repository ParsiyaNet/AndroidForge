package io.wapfire.mobile

import android.Manifest
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private enum class Stage { DISCOVERY, LOGIN, SETUP, CONTROL }
private enum class Tab(val label: String, val fa: String, val glyph: String) {
    OVERVIEW("Overview", "نمای کلی", "⌂"),
    TARGET("Target", "هدف", "⌖"),
    CLIENTS("Clients", "کلاینت‌ها", "◎"),
    EVENTS("Events", "رویدادها", "≋"),
    SETTINGS("Settings", "تنظیمات", "⚙")
}

private data class Palette(
    val bg: Color,
    val bg2: Color,
    val panel: Color,
    val panelAlt: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val green: Color,
    val orange: Color,
    val red: Color,
    val blue: Color
)

private fun colors(dark: Boolean) = if (dark) Palette(
    bg = Color(0xFF07141D), bg2 = Color(0xFF0C202B), panel = Color(0xFF102633),
    panelAlt = Color(0xFF16313E), border = Color(0xFF254652), text = Color(0xFFEAF5F7),
    muted = Color(0xFF91AAB5), accent = Color(0xFF4DE1CE), accentSoft = Color(0xFF173F45),
    green = Color(0xFF64E4A5), orange = Color(0xFFFFB86C), red = Color(0xFFFF7185), blue = Color(0xFF78A9FF)
) else Palette(
    bg = Color(0xFFF2F7F8), bg2 = Color(0xFFE5EFF2), panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFEAF3F4), border = Color(0xFFD4E2E5), text = Color(0xFF142D39),
    muted = Color(0xFF66808B), accent = Color(0xFF087F78), accentSoft = Color(0xFFD9F0EC),
    green = Color(0xFF168B5A), orange = Color(0xFFB76A18), red = Color(0xFFC33F54), blue = Color(0xFF426BC2)
)

private data class Snapshot(
    val configured: Boolean = false,
    val apSsid: String = "WAPFire",
    val target: String = "",
    val targetMac: String = "",
    val channel: Int = 0,
    val targetRssi: Int = 0,
    val targetAvailable: Boolean = false,
    val prom: String = "UNKNOWN",
    val traffic: Long = 0,
    val packets: Long = 0,
    val dropped: Long = 0,
    val filtered: Long = 0,
    val freeHeap: Long = 0,
    val uptime: Long = 0,
    val wifiChannel: Int = 0,
    val threatLevel: String = "LOW",
    val threatScore: Int = 0,
    val recentEvents: Int = 0,
    val lastEvent: String = "",
    val lastAttack: String = "",
    val led: Boolean = false,
    val smartLed: Boolean = false,
    val sound: Boolean = false,
    val autoChannel: Boolean = false,
    val selfProtect: Boolean = false,
    val softAp: Boolean = false,
    val ethernet: Boolean = false,
    val ethernetIp: String = "0.0.0.0",
    val firmware: String = "—",
    val labels: List<Pair<String, Long>> = emptyList(),
    val radioRates: List<Int> = emptyList(),
    val targetRates: List<Int> = emptyList()
) {
    companion object {
        fun from(status: JSONObject, settings: JSONObject?, chart: JSONObject?, firmwareInfo: JSONObject?): Snapshot {
            val threat = status.optJSONObject("threat_assessment") ?: JSONObject()
            val labelsJson = status.optJSONArray("labels") ?: JSONArray()
            val labels = (0 until labelsJson.length()).mapNotNull { i ->
                labelsJson.optJSONObject(i)?.let { it.optString("name") to it.optLong("count") }
            }
            val radio = chart?.optJSONArray("radioRxRates") ?: JSONArray()
            val target = chart?.optJSONArray("targetApRxRates") ?: JSONArray()
            return Snapshot(
                configured = status.optBoolean("configured"),
                apSsid = status.optString("ap_ssid", "WAPFire"),
                target = status.optString("target"), targetMac = status.optString("target_mac"),
                channel = status.optInt("target_ch"), targetRssi = status.optInt("target_rssi"),
                targetAvailable = status.optBoolean("target_available"), prom = status.optString("promiscuous", "UNKNOWN"),
                traffic = status.optLong("traffic"), packets = status.optLong("packets"),
                dropped = status.optLong("dropped"), filtered = status.optLong("filtered"),
                freeHeap = status.optLong("free_heap"), uptime = status.optLong("uptime"),
                wifiChannel = status.optInt("wifi_channel"), threatLevel = threat.optString("level", "LOW"),
                threatScore = threat.optInt("score_tenths") / 10, recentEvents = threat.optInt("recent_events"),
                lastEvent = threat.optString("last_event_label"), lastAttack = status.optString("last_attack_label"),
                led = settings?.optBoolean("led") ?: status.optBoolean("led"),
                smartLed = settings?.optBoolean("smart_led") ?: status.optBoolean("smart_led"),
                sound = settings?.optBoolean("sound") ?: status.optBoolean("sound_enabled"),
                autoChannel = settings?.optBoolean("auto_channel") ?: status.optBoolean("auto_channel"),
                selfProtect = settings?.optBoolean("self_protect") ?: status.optBoolean("self_protect"),
                softAp = settings?.optBoolean("softap_enabled") ?: status.optBoolean("softap_enabled"),
                ethernet = status.optBoolean("ethernet_link_on"), ethernetIp = status.optString("ethernet_ip", "0.0.0.0"),
                firmware = firmwareInfo?.optString("version", "—") ?: "—", labels = labels,
                radioRates = (0 until radio.length()).map { radio.optInt(it) },
                targetRates = (0 until target.length()).map { target.optInt(it) }
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(7, 20, 29)
        window.navigationBarColor = AndroidColor.rgb(7, 20, 29)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        setContent { WapFireNativeApp() }
    }
}

@Composable
private fun WapFireNativeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wapfire_native_v22", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val discovery = remember { WifiDiscovery(context) }
    val connector = remember { WifiConnector(context) }
    var isDark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var isFa by remember { mutableStateOf(prefs.getBoolean("fa", false)) }
    var stage by remember { mutableStateOf(Stage.DISCOVERY) }
    var tab by remember { mutableStateOf(Tab.OVERVIEW) }
    var host by remember { mutableStateOf(prefs.getString("host", "192.168.4.1") ?: "192.168.4.1") }
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("") }
    var api by remember { mutableStateOf<WapFireApi?>(null) }
    var snapshot by remember { mutableStateOf(Snapshot()) }
    var logs by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var clients by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var networks by remember { mutableStateOf<List<WifiAccessPoint>>(emptyList()) }
    var lanDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedSsid by remember { mutableStateOf("") }
    var wifiPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var setupAdminPass by remember { mutableStateOf("") }
    var setupApSsid by remember { mutableStateOf("WAPFire") }
    var setupApPass by remember { mutableStateOf("") }
    var targetNetworks by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var targetScanBusy by remember { mutableStateOf(false) }

    val p = colors(isDark)
    LaunchedEffect(isDark) {
        (context as? ComponentActivity)?.window?.let { window ->
            window.statusBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            window.navigationBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
    }
    val scheme = if (isDark) darkColorScheme(
        primary = p.accent, onPrimary = Color(0xFF05201F), background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    ) else lightColorScheme(
        primary = p.accent, onPrimary = Color.White, background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    )

    fun applySnapshot(status: JSONObject, settings: JSONObject? = null, chart: JSONObject? = null, firmwareInfo: JSONObject? = null) {
        snapshot = Snapshot.from(status, settings, chart, firmwareInfo)
        if (!status.optBoolean("configured", false) && stage == Stage.CONTROL) stage = Stage.SETUP
    }

    suspend fun refreshAll(activeTab: Tab = tab) {
        val client = api ?: return
        val statusResult = client.status()
        if (statusResult.isFailure) {
            val reason = statusResult.exceptionOrNull()?.message ?: "Device connection lost"
            if (reason.contains("401") || reason.contains("Unauthorized", true)) {
                api = null
                stage = Stage.LOGIN
            } else error = reason
            return
        }
        val status = statusResult.getOrThrow()
        val settings = client.settings().getOrNull()
        val chart = client.chart().getOrNull()
        val firmwareInfo = client.firmwareInfo().getOrNull()
        applySnapshot(status, settings, chart, firmwareInfo)
        if (activeTab == Tab.EVENTS) client.logs().getOrNull()?.let { arr -> logs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
        if (activeTab == Tab.CLIENTS) client.clients().getOrNull()?.let { arr -> clients = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            scope.launch {
                scanning = true; error = ""; notice = ""
                connector.bindToCurrentWifi()
                networks = discovery.scan()
                lanDevices = discovery.findWapFireOnLan()
                scanning = false
                if (networks.isEmpty() && lanDevices.isEmpty()) error = tx(isFa, "No devices discovered. Enter the WAPFire IP manually.", "دستگاهی پیدا نشد. IP دستگاه را دستی وارد کن.")
            }
        } else error = tx(isFa, "Wi-Fi permission was not granted. Manual IP remains available.", "مجوز Wi-Fi داده نشد؛ ورود دستی IP همچنان فعال است.")
    }

    fun discoverNow() {
        val permissions = WifiDiscovery.requiredPermissions()
        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            error = tx(isFa, "Allow nearby Wi-Fi access to scan automatically. You can still enter an IP below.", "برای جستجوی خودکار مجوز Wi-Fi را بده؛ ورود دستی IP هم فعال است.")
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        scope.launch {
            scanning = true; error = ""; notice = ""
            connector.bindToCurrentWifi()
            val wifi = discovery.scan()
            val lan = discovery.findWapFireOnLan()
            networks = wifi
            lanDevices = lan
            scanning = false
            if (wifi.isEmpty() && lan.isEmpty()) error = tx(isFa, "No devices discovered. Enter the WAPFire IP manually.", "دستگاهی پیدا نشد. IP دستگاه را دستی وارد کن.")
        }
    }

    fun useHost(value: String) {
        host = value.trim().removePrefix("http://").removePrefix("https://").substringBefore('/')
        prefs.edit().putString("host", host).apply()
        connector.bindToCurrentWifi()
        error = ""; notice = ""
        stage = Stage.LOGIN
    }

    fun startWifiConnect(ap: WifiAccessPoint) {
        if (ap.secured && selectedSsid != ap.ssid) {
            selectedSsid = ap.ssid
            wifiPassword = ""
            notice = tx(isFa, "Enter the Wi-Fi password below, then connect again.", "رمز Wi-Fi را پایین وارد کن و دوباره اتصال را بزن.")
            return
        }
        busy = true; error = ""
        connector.connect(ap.ssid, wifiPassword,
            onAvailable = {
                busy = false
                host = "192.168.4.1"
                prefs.edit().putString("host", host).apply()
                notice = tx(isFa, "Connected to ${ap.ssid}. Continue to sign in.", "به ${ap.ssid} وصل شدی. وارد حساب شو.")
                stage = Stage.LOGIN
            },
            onUnavailable = { busy = false; error = tx(isFa, "Android could not join this Wi-Fi network.", "اندروید نتوانست به این شبکه وصل شود.") },
            onLost = { if (stage == Stage.CONTROL) error = tx(isFa, "Wi-Fi connection was lost.", "اتصال Wi-Fi قطع شد.") }
        )
    }

    fun signIn() {
        scope.launch {
            busy = true; error = ""; notice = ""
            val client = WapFireApi(host)
            val result = client.login(username, password)
            busy = false
            if (result.isSuccess) {
                api = client
                prefs.edit().putString("host", host).apply()
                val status = client.status()
                if (status.isSuccess) {
                    val value = status.getOrThrow()
                    val settings = client.settings().getOrNull()
                    applySnapshot(value, settings, firmwareInfo = client.firmwareInfo().getOrNull())
                    setupApSsid = value.optString("ap_ssid", "WAPFire").ifBlank { "WAPFire" }
                    stage = if (value.optBoolean("configured", false)) Stage.CONTROL else Stage.SETUP
                    notice = tx(isFa, "Secure session established.", "اتصال امن برقرار شد.")
                } else error = status.exceptionOrNull()?.message ?: "Could not read device status"
            } else error = result.exceptionOrNull()?.message ?: tx(isFa, "Authentication failed.", "ورود ناموفق بود.")
        }
    }

    LaunchedEffect(stage, tab, api) {
        if (stage == Stage.CONTROL && api != null) {
            while (stage == Stage.CONTROL) {
                refreshAll(tab)
                delay(if (tab == Tab.OVERVIEW) 3000 else 5000)
            }
        }
    }

    BackHandler(enabled = stage != Stage.DISCOVERY) {
        when (stage) {
            Stage.LOGIN -> stage = Stage.DISCOVERY
            Stage.SETUP -> stage = Stage.DISCOVERY
            Stage.CONTROL -> { tab = Tab.OVERVIEW }
            else -> Unit
        }
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg, p.bg2)))) {
            when (stage) {
                Stage.DISCOVERY -> DiscoveryScreen(
                    p, isFa, isDark, host, { host = it }, discovery.current(), networks, lanDevices,
                    scanning, busy, selectedSsid, wifiPassword, { wifiPassword = it }, error, notice,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    onScan = { discoverNow() }, onConnect = { startWifiConnect(it) },
                    onUseLan = { useHost(it) }, onUseCurrent = { val current = discovery.current(); useHost(if (current.ssid.contains("WAPFire", true)) current.gateway.ifBlank { host } else host) },
                    onManual = { useHost(host) }, onClear = { error = ""; notice = "" }
                )
                Stage.LOGIN -> LoginScreen(
                    p, isFa, host, { host = it }, username, { username = it }, password, { password = it },
                    busy, error, notice, onBack = { stage = Stage.DISCOVERY }, onLogin = { signIn() },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() }
                )
                Stage.SETUP -> FirstSetupScreen(
                    p, isFa, setupApSsid, { setupApSsid = it }, setupApPass, { setupApPass = it },
                    setupAdminPass, { setupAdminPass = it }, targetNetworks, targetScanBusy, saving,
                    snapshot, error, notice,
                    onScan = {
                        scope.launch {
                            targetScanBusy = true; error = ""
                            val found = api?.scan()?.getOrNull()
                            targetNetworks = found?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }.orEmpty()
                            targetScanBusy = false
                        }
                    },
                    onFinish = {
                        scope.launch {
                            saving = true; error = ""; notice = ""
                            val payload = JSONObject()
                                .put("adminpass", setupAdminPass)
                                .put("ap_ssid", setupApSsid)
                                .put("ap_pass", setupApPass)
                                .put("led", true).put("sound", true)
                                .put("auto_channel", true).put("self_protect", false)
                                .put("softap_enabled", true)
                            val client = api
                            val result = client?.updateSettings(payload)
                            saving = false
                            if (result?.isSuccess == true) {
                                val response = result.getOrThrow()
                                password = setupAdminPass
                                if (response.optBoolean("wifi_restart_needed", false)) {
                                    notice = tx(isFa, "Setup was saved. WAPFire is restarting its Wi-Fi; reconnect using the new access point credentials, then sign in again.", "تنظیمات ذخیره شد. Wi-Fi دستگاه در حال راه‌اندازی مجدد است؛ با مشخصات جدید وصل شو و دوباره وارد شو.")
                                    api = null
                                    connector.release()
                                    stage = Stage.DISCOVERY
                                } else {
                                    notice = tx(isFa, "Initial configuration saved by the device.", "تنظیمات اولیه توسط دستگاه ذخیره شد.")
                                    val status = client.status().getOrNull()
                                    if (status?.optBoolean("configured") == true) {
                                        applySnapshot(status, client.settings().getOrNull(), firmwareInfo = client.firmwareInfo().getOrNull())
                                        stage = Stage.CONTROL
                                        tab = Tab.OVERVIEW
                                    }
                                }
                            } else error = result?.exceptionOrNull()?.message ?: "Setup could not be saved"
                        }
                    },
                    onLogout = { api = null; stage = Stage.DISCOVERY }
                )
                Stage.CONTROL -> ControlCenter(
                    p, isFa, isDark, tab, snapshot, logs, clients, error, notice,
                    onTab = { tab = it; error = ""; notice = "" },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    onRefresh = { scope.launch { refreshAll(tab) } },
                    onToggle = { key, value ->
                        scope.launch {
                            val result = api?.updateSettings(JSONObject().put(key, value))
                            if (result?.isSuccess == true) {
                                notice = tx(isFa, "${key.replace('_', ' ')} updated on WAPFire.", "تنظیم ${key.replace('_', ' ')} در WAPFire اعمال شد.")
                                refreshAll(tab)
                            } else error = result?.exceptionOrNull()?.message ?: "Setting was not applied"
                        }
                    },
                    targetNetworks = targetNetworks, targetScanBusy = targetScanBusy,
                    onTargetScan = {
                        scope.launch {
                            targetScanBusy = true; error = ""
                            val found = api?.scan()?.getOrNull()
                            targetNetworks = found?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }.orEmpty()
                            targetScanBusy = false
                            if (targetNetworks.isEmpty()) notice = tx(isFa, "No networks returned by the scan.", "اسکن شبکه‌ای برنگرداند.")
                        }
                    },
                    onSelectTarget = { network ->
                        scope.launch {
                            val result = api?.selectTarget(network.optString("ssid"), network.optString("bssid"), network.optInt("channel"))
                            if (result?.isSuccess == true) {
                                notice = tx(isFa, "Target selected and applied.", "شبکه هدف انتخاب و اعمال شد.")
                                refreshAll(Tab.OVERVIEW)
                            } else error = result?.exceptionOrNull()?.message ?: "Target selection failed"
                        }
                    },
                    onClearLogs = {
                        scope.launch {
                            val result = api?.clearLogs()
                            if (result?.isSuccess == true) { notice = tx(isFa, "Device event log cleared.", "گزارش رویدادهای دستگاه پاک شد."); refreshAll(Tab.EVENTS) }
                            else error = result?.exceptionOrNull()?.message ?: "Could not clear logs"
                        }
                    },
                    onLogout = { api = null; connector.release(); stage = Stage.DISCOVERY; tab = Tab.OVERVIEW }
                )
            }
        }
        }
    }
}

@Composable
private fun DiscoveryScreen(
    p: Palette, fa: Boolean, dark: Boolean, host: String, onHost: (String) -> Unit,
    current: CurrentWifi, networks: List<WifiAccessPoint>, lan: List<String>, scanning: Boolean, connecting: Boolean,
    selectedSsid: String, wifiPassword: String, onWifiPassword: (String) -> Unit, error: String, notice: String,
    onTheme: () -> Unit, onLanguage: () -> Unit, onScan: () -> Unit, onConnect: (WifiAccessPoint) -> Unit,
    onUseLan: (String) -> Unit, onUseCurrent: () -> Unit, onManual: () -> Unit, onClear: () -> Unit
) {
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand(p)
            Spacer(Modifier.weight(1f))
            SmallAction(p, if (dark) "☼" else "☾", onTheme)
            Spacer(Modifier.width(8.dp)); SmallAction(p, if (fa) "EN" else "FA", onLanguage)
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(fa, "YOUR WIRELESS SECURITY HUB", "مرکز امنیت شبکه بی‌سیم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(tx(fa, "Connect to\nWAPFire.", "به WAPFire\nمتصل شو."), color = p.text, fontSize = 36.sp, lineHeight = 39.sp, fontWeight = FontWeight.ExtraBold)
            Text(tx(fa, "A native control app for discovery, monitoring and device configuration.", "اپلیکیشن مستقل برای پیدا کردن دستگاه، پایش زنده و مدیریت تنظیمات."), color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        if (error.isNotBlank() || notice.isNotBlank()) MessageCard(p, if (error.isNotBlank()) error else notice, error.isNotBlank(), onClear)
        SectionCard(p, title = tx(fa, "CURRENT NETWORK", "شبکه فعلی"), subtitle = current.ssid.ifBlank { tx(fa, "No Wi-Fi connection detected", "اتصال Wi-Fi شناسایی نشد") }) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("IP  ${current.localIp.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                    Text("Gateway  ${current.gateway.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                }
                ActionButton(p, tx(fa, "Use network", "استفاده"), onUseCurrent, primary = true)
            }
        }
        SectionCard(p, title = tx(fa, "DEVICE DISCOVERY", "پیدا کردن دستگاه"), subtitle = tx(fa, "Scan the local network or join the WAPFire access point.", "شبکه محلی را جستجو کن یا به اکسس‌پوینت WAPFire وصل شو.")) {
            ActionButton(p, if (scanning) tx(fa, "Scanning…", "در حال جستجو…") else tx(fa, "Scan nearby devices", "جستجوی دستگاه‌ها"), onScan, enabled = !scanning, primary = true, modifier = Modifier.fillMaxWidth())
            if (scanning) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = p.accent, strokeWidth = 2.dp)
                Text(tx(fa, "Looking for WAPFire…", "در حال جستجوی WAPFire…"), color = p.muted, fontSize = 12.sp)
            }
            lan.forEach { ip -> DeviceResult(p, "WAPFire device", ip, "LAN DEVICE", onClick = { onUseLan(ip) }, action = tx(fa, "Connect", "اتصال")) }
            networks.filter { it.isWapFire }.forEach { ap ->
                DeviceResult(p, ap.ssid, "${ap.rssi} dBm  ·  ${ap.frequency} MHz", tx(fa, "WAPFIRE WI-FI", "شبکه WAPFire"), onClick = { onConnect(ap) }, action = tx(fa, if (connecting) "Joining…" else "Join", if (connecting) "در حال اتصال…" else "اتصال"))
            }
            if (networks.none { it.isWapFire } && networks.isNotEmpty()) Text(tx(fa, "Nearby Wi-Fi networks were found, but none had a WAPFire name. You can still join the device network manually from Android Wi-Fi settings.", "شبکه‌های اطراف پیدا شدند اما نام WAPFire نداشتند. می‌توانی از تنظیمات Wi-Fi اندروید دستی به شبکه دستگاه وصل شوی."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        if (selectedSsid.isNotBlank()) SectionCard(p, title = tx(fa, "WI-FI PASSWORD", "رمز شبکه"), subtitle = selectedSsid) {
            NativeField(p, wifiPassword, onWifiPassword, tx(fa, "Network password", "رمز Wi-Fi"), password = true)
            Text(tx(fa, "Tap Join on the WAPFire network above again after entering the password.", "بعد از وارد کردن رمز، دوباره روی اتصال شبکه WAPFire بزن."), color = p.muted, fontSize = 11.sp)
        }
        SectionCard(p, title = tx(fa, "MANUAL DEVICE ADDRESS", "نشانی دستی دستگاه"), subtitle = tx(fa, "For Ethernet, custom subnets or a fixed IP.", "برای Ethernet، زیرشبکه سفارشی یا IP ثابت.")) {
            NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri)
            ActionButton(p, tx(fa, "Continue to sign in", "ادامه و ورود"), onManual, primary = true, modifier = Modifier.fillMaxWidth())
        }
        Text("WAPFIRE MOBILE  ·  NATIVE ANDROID", color = p.muted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp))
    }
}

@Composable
private fun LoginScreen(
    p: Palette, fa: Boolean, host: String, onHost: (String) -> Unit, username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, busy: Boolean, error: String, notice: String,
    onBack: () -> Unit, onLogin: () -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit
) {
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallAction(p, "‹", onBack); Spacer(Modifier.width(12.dp)); Brand(p); Spacer(Modifier.weight(1f)); SmallAction(p, if (fa) "EN" else "FA", onLanguage); Spacer(Modifier.width(7.dp)); SmallAction(p, "◐", onTheme)
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.size(74.dp).clip(RoundedCornerShape(24.dp)).background(p.accentSoft).border(1.dp, p.border, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Text("⌑", color = p.accent, fontSize = 40.sp, fontWeight = FontWeight.Light)
            }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(tx(fa, "AUTHENTICATION", "احراز هویت"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(tx(fa, "Welcome back.", "خوش برگشتی."), color = p.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(tx(fa, "Sign in to your WAPFire device.", "برای ورود به دستگاه WAPFire اطلاعات حساب را وارد کن."), color = p.muted, fontSize = 13.sp)
            }
            if (error.isNotBlank()) MessageCard(p, error, true) {}
            if (notice.isNotBlank()) MessageCard(p, notice, false) {}
            SectionCard(p, title = tx(fa, "DEVICE", "دستگاه"), subtitle = host) { NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri) }
            SectionCard(p, title = tx(fa, "ADMINISTRATOR ACCESS", "دسترسی مدیر"), subtitle = tx(fa, "Your device credentials", "اطلاعات ورود دستگاه")) {
                NativeField(p, username, onUsername, tx(fa, "Username", "نام کاربری"))
                NativeField(p, password, onPassword, tx(fa, "Password", "رمز عبور"), password = true)
                ActionButton(p, if (busy) tx(fa, "Authenticating…", "در حال بررسی…") else tx(fa, "Secure sign in", "ورود امن"), onLogin, enabled = !busy, primary = true, modifier = Modifier.fillMaxWidth())
                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
            }
            Text(tx(fa, "Credentials are sent directly to the device on your local network.", "اطلاعات ورود مستقیماً و فقط در شبکه محلی به دستگاه ارسال می‌شود."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun FirstSetupScreen(
    p: Palette, fa: Boolean, apSsid: String, onApSsid: (String) -> Unit, apPass: String, onApPass: (String) -> Unit,
    adminPass: String, onAdminPass: (String) -> Unit, targetNetworks: List<JSONObject>, scanning: Boolean, saving: Boolean,
    snapshot: Snapshot, error: String, notice: String, onScan: () -> Unit, onFinish: () -> Unit, onLogout: () -> Unit
) {
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Brand(p); Spacer(Modifier.weight(1f)); TextButton(onClick = onLogout) { Text(tx(fa, "Disconnect", "قطع اتصال"), color = p.muted) } }
        Text(tx(fa, "FIRST-TIME SETUP", "راه‌اندازی اولیه"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(tx(fa, "Make WAPFire yours.", "WAPFire را پیکربندی کن."), color = p.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(tx(fa, "Set secure administrator and access point credentials. You can choose a monitoring target afterwards.", "رمز مدیریت و مشخصات شبکه دسترسی را تعیین کن. انتخاب شبکه هدف را می‌توانی بعداً انجام بدهی."), color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
        if (error.isNotBlank()) MessageCard(p, error, true) {}
        if (notice.isNotBlank()) MessageCard(p, notice, false) {}
        SectionCard(p, title = "01  ·  ${tx(fa, "ADMIN ACCOUNT", "حساب مدیر")}", subtitle = tx(fa, "Create a password between 8 and 64 characters.", "رمزی بین ۸ تا ۶۴ نویسه انتخاب کن.")) {
            NativeField(p, adminPass, onAdminPass, tx(fa, "New administrator password", "رمز جدید مدیر"), password = true)
        }
        SectionCard(p, title = "02  ·  ${tx(fa, "DEVICE WI-FI", "شبکه Wi-Fi دستگاه")}", subtitle = tx(fa, "This is the access point your phone can join later.", "این همان شبکه‌ای است که بعداً گوشی به آن وصل می‌شود.")) {
            NativeField(p, apSsid, onApSsid, tx(fa, "Access point name", "نام شبکه"))
            NativeField(p, apPass, onApPass, tx(fa, "Wi-Fi password (8–63 characters)", "رمز Wi-Fi (۸ تا ۶۳ نویسه)"), password = true)
        }
        SectionCard(p, title = "03  ·  ${tx(fa, "MONITORING TARGET", "شبکه تحت پایش")}", subtitle = tx(fa, "Optional now — select a target from the Target tab after setup.", "فعلاً اختیاری است؛ پس از راه‌اندازی از بخش هدف انتخاب کن.")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tx(fa, "Nearby networks", "شبکه‌های اطراف"), color = p.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                ActionButton(p, if (scanning) "…" else tx(fa, "Scan", "اسکن"), onScan, enabled = !scanning)
            }
            targetNetworks.take(8).forEach { net ->
                DeviceResult(p, net.optString("ssid", "Hidden network"), "${net.optString("bssid")}  ·  CH ${net.optInt("channel")}  ·  ${net.optInt("rssi")} dBm", if (net.optBoolean("secured")) "SECURED" else "OPEN", {}, action = "")
            }
            if (targetNetworks.isNotEmpty()) Text(tx(fa, "Target selection is available in the Target screen after setup.", "انتخاب هدف پس از راه‌اندازی در صفحه هدف در دسترس است."), color = p.muted, fontSize = 10.sp)
        }
        SectionCard(p, title = tx(fa, "READY TO APPLY", "آماده اعمال"), subtitle = "${tx(fa, "Device", "دستگاه")}: ${snapshot.apSsid}") {
            ActionButton(p, if (saving) tx(fa, "Applying configuration…", "در حال اعمال…") else tx(fa, "Apply initial configuration", "اعمال تنظیمات اولیه"), onFinish, enabled = !saving, primary = true, modifier = Modifier.fillMaxWidth())
            if (saving) CircularProgressIndicator(modifier = Modifier.size(22.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ControlCenter(
    p: Palette, fa: Boolean, dark: Boolean, tab: Tab, snapshot: Snapshot, logs: List<JSONObject>, clients: List<JSONObject>, error: String, notice: String,
    onTab: (Tab) -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit, onRefresh: () -> Unit,
    onToggle: (String, Boolean) -> Unit, targetNetworks: List<JSONObject>, targetScanBusy: Boolean,
    onTargetScan: () -> Unit, onSelectTarget: (JSONObject) -> Unit, onClearLogs: () -> Unit, onLogout: () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Column(Modifier.fillMaxWidth().background(p.bg.copy(alpha = .96f)).windowInsetsPadding(WindowInsets.statusBars)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Brand(p)
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.clip(CircleShape).background(if (snapshot.prom == "ACTIVE") p.accentSoft else p.panelAlt).padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(if (snapshot.prom == "ACTIVE") p.green else p.orange))
                            Text(if (snapshot.prom == "ACTIVE") tx(fa, "LIVE", "زنده") else snapshot.prom, color = p.text, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                    }
                    Spacer(Modifier.width(8.dp)); SmallAction(p, "↻", onRefresh)
                    Spacer(Modifier.width(6.dp)); SmallAction(p, if (dark) "☼" else "☾", onTheme)
                }
                if (error.isNotBlank() || notice.isNotBlank()) {
                    MessageCard(p, if (error.isNotBlank()) error else notice, error.isNotBlank()) {}
                }
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().background(p.panel).border(1.dp, p.border).windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = 4.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Tab.values().forEach { item ->
                    val selected = tab == item
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { onTab(item) }.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(item.glyph, color = if (selected) p.accent else p.muted, fontSize = 19.sp)
                        Text(if (fa) item.fa else item.label, color = if (selected) p.accent else p.muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    ) { padding ->
        when (tab) {
            Tab.OVERVIEW -> OverviewPage(p, fa, snapshot, Modifier.padding(padding))
            Tab.TARGET -> TargetPage(p, fa, snapshot, targetNetworks, targetScanBusy, onTargetScan, onSelectTarget, Modifier.padding(padding))
            Tab.CLIENTS -> ClientsPage(p, fa, clients, Modifier.padding(padding))
            Tab.EVENTS -> EventsPage(p, fa, logs, onClearLogs, Modifier.padding(padding))
            Tab.SETTINGS -> SettingsPage(p, fa, snapshot, onToggle, onLogout, Modifier.padding(padding), onLanguage, dark, onTheme)
        }
    }
}

@Composable
private fun OverviewPage(p: Palette, fa: Boolean, s: Snapshot, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 14.dp, bottom = 18.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(tx(fa, "SYSTEM OVERVIEW", "نمای کلی سیستم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text(tx(fa, "Wireless intelligence", "هوشمندی شبکه بی‌سیم"), color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("${tx(fa, "Firmware", "فریمور")}: ${s.firmware}   ·   ${tx(fa, "Uptime", "مدت فعالیت")}: ${formatUptime(s.uptime)}", color = p.muted, fontSize = 10.sp)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF16424C), Color(0xFF102733)))).border(1.dp, Color(0xFF2B6269), RoundedCornerShape(24.dp)).padding(18.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "MONITORING STATUS", "وضعیت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                            Text(if (s.configured) tx(fa, "Protection engine active", "موتور پایش فعال است") else tx(fa, "Setup required", "نیازمند راه‌اندازی"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        ThreatRing(p, s.threatScore, s.threatLevel)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2C535D)))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "MONITORED ACCESS POINT", "اکسس‌پوینت تحت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.sp)
                            Text(s.target.ifBlank { tx(fa, "No target selected", "هدف انتخاب نشده") }, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (s.targetMac.isNotBlank()) s.targetMac else "${tx(fa, "Channel", "کانال")}: ${if (s.channel > 0) s.channel else "—"}", color = Color(0xFFA4C2C8), fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(if (s.targetAvailable) tx(fa, "ONLINE", "متصل") else tx(fa, "OFFLINE", "قطع"), color = if (s.targetAvailable) Color(0xFF71E4AE) else Color(0xFFFFB86C), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(if (s.targetRssi != 0) "${s.targetRssi} dBm" else "— dBm", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Text(tx(fa, "NETWORK TELEMETRY", "آمار شبکه"), color = p.muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${s.traffic.compact()}", tx(fa, "Traffic frames", "فریم شبکه"), "⌁", p.accent, Modifier.weight(1f))
                MetricTile(p, "${s.packets.compact()}", tx(fa, "Packets", "بسته‌ها"), "▤", p.blue, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${(s.freeHeap / 1024).compact()} KB", tx(fa, "Free memory", "حافظه آزاد"), "◫", p.green, Modifier.weight(1f))
                MetricTile(p, "${s.recentEvents}", tx(fa, "Recent events", "رویداد اخیر"), "⚑", p.orange, Modifier.weight(1f))
            }
        }
        item {
            SectionCard(p, title = tx(fa, "RADIO ACTIVITY", "فعالیت رادیویی"), subtitle = tx(fa, "Recent receive-rate samples", "نمونه‌های اخیر نرخ دریافت")) {
                NativeLineChart(p, s.radioRates, s.targetRates, Modifier.fillMaxWidth().height(150.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    LegendDot(p.accent, tx(fa, "Radio RX", "دریافت رادیو"), p)
                    LegendDot(p.blue, tx(fa, "Target AP", "اکسس‌پوینت هدف"), p)
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    MiniValue(p, "${s.wifiChannel}", tx(fa, "Wi-Fi channel", "کانال Wi-Fi"))
                    MiniValue(p, s.prom, tx(fa, "Promiscuous", "حالت شنود"))
                    MiniValue(p, "${s.dropped}", tx(fa, "Dropped", "از دست‌رفته"))
                }
            }
        }
        item {
            SectionCard(p, title = tx(fa, "DETECTION BREAKDOWN", "دسته‌بندی تشخیص‌ها"), subtitle = tx(fa, "Labels reported by the firmware", "برچسب‌های گزارش‌شده توسط فریمور")) {
                if (s.labels.isEmpty()) Text(tx(fa, "No classification events reported yet.", "هنوز رویداد طبقه‌بندی گزارش نشده است."), color = p.muted, fontSize = 12.sp)
                s.labels.sortedByDescending { it.second }.take(5).forEach { (name, count) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(name, color = p.text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(count.toString(), color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            SectionCard(p, title = tx(fa, "LAST DETECTION", "آخرین تشخیص"), subtitle = if (s.lastEvent.isBlank()) tx(fa, "No recent event", "رویداد تازه‌ای نیست") else s.lastEvent) {
                Text(if (s.lastAttack.isBlank()) tx(fa, "The device has not reported an active attack label.", "دستگاه برچسب حمله فعالی گزارش نکرده است.") else s.lastAttack, color = p.text, fontSize = 13.sp)
                Text("${tx(fa, "Filtered", "فیلترشده")}: ${s.filtered}   ·   ${tx(fa, "Dropped", "از دست‌رفته")}: ${s.dropped}", color = p.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun TargetPage(p: Palette, fa: Boolean, s: Snapshot, networks: List<JSONObject>, busy: Boolean, onScan: () -> Unit, onSelect: (JSONObject) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 14.dp, bottom = 18.dp)) {
        item {
            Text(tx(fa, "TARGET MANAGEMENT", "مدیریت هدف"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Choose what to monitor", "شبکه مورد پایش را انتخاب کن"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "WAPFire binds the selected SSID to its exact BSSID and channel.", "WAPFire شبکه انتخابی را به BSSID و کانال دقیق آن متصل می‌کند."), color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        item {
            SectionCard(p, title = tx(fa, "CURRENT TARGET", "هدف فعلی"), subtitle = if (s.target.isBlank()) tx(fa, "No access point selected", "اکسس‌پوینتی انتخاب نشده") else s.target) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (s.targetMac.isBlank()) "BSSID —" else s.targetMac, color = p.muted, fontSize = 11.sp)
                        Text("CH ${s.channel}   ·   ${s.targetRssi} dBm", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Box(Modifier.clip(CircleShape).background(if (s.targetAvailable) p.accentSoft else p.panelAlt).padding(horizontal = 11.dp, vertical = 7.dp)) {
                        Text(if (s.targetAvailable) tx(fa, "ONLINE", "متصل") else tx(fa, "OFFLINE", "قطع"), color = if (s.targetAvailable) p.green else p.orange, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            SectionCard(p, title = tx(fa, "AVAILABLE ACCESS POINTS", "اکسس‌پوینت‌های موجود"), subtitle = tx(fa, "Scan and select one network", "شبکه‌ها را اسکن و یکی را انتخاب کن")) {
                ActionButton(p, if (busy) tx(fa, "Scanning…", "در حال اسکن…") else tx(fa, "Scan Wi-Fi networks", "اسکن شبکه‌های Wi-Fi"), onScan, enabled = !busy, primary = true, modifier = Modifier.fillMaxWidth())
                if (busy) CircularProgressIndicator(modifier = Modifier.size(19.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
                if (networks.isEmpty() && !busy) Text(tx(fa, "No scan results. Start a scan to list nearby access points.", "نتیجه‌ای وجود ندارد؛ برای نمایش شبکه‌های اطراف اسکن را اجرا کن."), color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
                networks.forEach { net ->
                    val ssid = net.optString("ssid")
                    val canSelect = ssid.isNotBlank() && net.optString("bssid").isNotBlank()
                    DeviceResult(
                        p, ssid.ifBlank { tx(fa, "Hidden network", "شبکه مخفی") },
                        "${net.optString("bssid")}  ·  CH ${net.optInt("channel")}  ·  ${net.optInt("rssi")} dBm",
                        if (!canSelect) tx(fa, "HIDDEN", "مخفی") else if (net.optBoolean("secured")) "SECURED" else "OPEN",
                        { if (canSelect) onSelect(net) },
                        if (canSelect) tx(fa, "Select", "انتخاب") else ""
                    )
                }
            }
        }
    }
}

@Composable
private fun ClientsPage(p: Palette, fa: Boolean, clients: List<JSONObject>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 20.dp)) {
        item {
            Text(tx(fa, "CLIENT INTELLIGENCE", "اطلاعات کلاینت‌ها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Tracked stations", "ایستگاه‌های ردگیری‌شده"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${clients.size} ${tx(fa, "observations", "مشاهده")}", color = p.muted, fontSize = 12.sp)
        }
        if (clients.isEmpty()) item { SectionCard(p, title = tx(fa, "NO CLIENT DATA", "داده‌ای وجود ندارد"), subtitle = tx(fa, "Clients appear as they are observed by the radio.", "کلاینت‌ها پس از مشاهده توسط رادیو نمایش داده می‌شوند.")) { Text(tx(fa, "Keep monitoring active and refresh this page.", "پایش را فعال نگه دار و صفحه را تازه‌سازی کن."), color = p.muted, fontSize = 12.sp) } }
        items(clients) { client ->
            SectionCard(p, title = client.optString("mac", "Unknown station"), subtitle = client.optString("state", "UNKNOWN")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${client.optInt("rssi")} dBm  ·  ${client.optInt("age_sec")}s ${tx(fa, "ago", "قبل")}", color = p.muted, fontSize = 11.sp)
                        Text(client.optString("bssid").ifBlank { tx(fa, "BSSID unavailable", "BSSID موجود نیست") }, color = p.muted, fontSize = 10.sp)
                    }
                    Text(if (client.optString("state").contains("DISCONNECT")) "!" else "•", color = if (client.optString("state").contains("DISCONNECT")) p.orange else p.green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                if (client.optInt("reason_code") != 0) Text("${tx(fa, "Reason", "دلیل")}: ${client.optInt("reason_code")} · ${client.optString("reason_text")}", color = p.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun EventsPage(p: Palette, fa: Boolean, logs: List<JSONObject>, onClear: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tx(fa, "EVENT TIMELINE", "خط زمانی رویدادها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Device activity", "فعالیت دستگاه"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${logs.size} ${tx(fa, "records", "رکورد")}", color = p.muted, fontSize = 12.sp)
                }
                ActionButton(p, tx(fa, "Clear", "پاک‌کردن"), onClear)
            }
        }
        if (logs.isEmpty()) item { SectionCard(p, title = tx(fa, "NO EVENTS", "رویدادی وجود ندارد"), subtitle = tx(fa, "The device event log is currently empty.", "گزارش رویداد دستگاه خالی است.")) { Text(tx(fa, "New detections and system messages will appear here.", "تشخیص‌های جدید و پیام‌های سیستم اینجا نمایش داده می‌شوند."), color = p.muted, fontSize = 12.sp) } }
        items(logs) { event ->
            val type = event.optString("event_type", "system").lowercase()
            val color = when { type.contains("attack") -> p.red; type.contains("wrong") || type.contains("attempt") -> p.orange; type.contains("correct") -> p.green; type.contains("disconnect") -> p.blue; else -> p.accent }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.panel).border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Box(Modifier.width(3.dp).height(52.dp).clip(CircleShape).background(color))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(event.optString("message", "System event"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(type.replace('_', ' ').uppercase(), color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(event.optString("formatted_time", ""), color = p.muted, fontSize = 10.sp)
                    if (event.optString("details").isNotBlank()) Text(event.optString("details"), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(p: Palette, fa: Boolean, s: Snapshot, onToggle: (String, Boolean) -> Unit, onLogout: () -> Unit, modifier: Modifier = Modifier, onLanguage: () -> Unit, dark: Boolean, onTheme: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text(tx(fa, "DEVICE CONFIGURATION", "پیکربندی دستگاه"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
        Text(tx(fa, "Settings & controls", "تنظیمات و کنترل‌ها"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(tx(fa, "Changes are sent to the firmware and confirmed by its API.", "تغییرات به فریمور ارسال و پاسخ آن بررسی می‌شود."), color = p.muted, fontSize = 12.sp)
        SectionCard(p, title = tx(fa, "PROTECTION", "محافظت"), subtitle = tx(fa, "Detection and response behavior", "رفتار تشخیص و واکنش")) {
            ToggleRow(p, tx(fa, "Self-protect mode", "حالت محافظت از خود"), tx(fa, "Apply configured protection actions when detections occur.", "هنگام تشخیص، اقدامات حفاظتی تعریف‌شده را اعمال می‌کند."), s.selfProtect) { onToggle("self_protect", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Automatic channel tracking", "ردگیری خودکار کانال"), tx(fa, "Follow channel changes of the target access point.", "تغییر کانال اکسس‌پوینت هدف را دنبال می‌کند."), s.autoChannel) { onToggle("auto_channel", it) }
        }
        SectionCard(p, title = tx(fa, "INDICATORS", "نشانگرها"), subtitle = tx(fa, "Physical LED and sound feedback", "بازخورد LED و صدا")) {
            ToggleRow(p, tx(fa, "Status LED", "چراغ وضعیت"), tx(fa, "Enable the device status LED.", "چراغ وضعیت دستگاه را فعال می‌کند."), s.led) { onToggle("led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Smart LED mode", "حالت هوشمند LED"), tx(fa, "Adjust the LED behavior based on target availability.", "رفتار LED را با در دسترس بودن هدف تطبیق می‌دهد."), s.smartLed) { onToggle("smart_led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Sound alerts", "هشدار صوتی"), tx(fa, "Play audible alerts for supported events.", "برای رویدادهای پشتیبانی‌شده هشدار صوتی پخش می‌کند."), s.sound) { onToggle("sound", it) }
        }
        SectionCard(p, title = tx(fa, "CONNECTIVITY", "اتصال"), subtitle = tx(fa, "Network access for device management", "دسترسی شبکه برای مدیریت دستگاه")) {
            ToggleRow(p, tx(fa, "Enable WAPFire access point", "فعال‌سازی اکسس‌پوینت WAPFire"), tx(fa, "Keep the device's configuration Wi-Fi available.", "شبکه Wi-Fi پیکربندی دستگاه را فعال نگه می‌دارد."), s.softAp) { onToggle("softap_enabled", it) }
            Text("${tx(fa, "Ethernet link", "لینک Ethernet")}: ${if (s.ethernet) "ONLINE · ${s.ethernetIp}" else "OFFLINE"}", color = p.muted, fontSize = 11.sp)
        }
        SectionCard(p, title = tx(fa, "SYSTEM INFORMATION", "اطلاعات سیستم"), subtitle = "WAPFire ${s.firmware}") {
            InfoLine(p, "Promiscuous mode", s.prom)
            InfoLine(p, "Wi-Fi channel", s.wifiChannel.toString())
            InfoLine(p, "Free heap", "${(s.freeHeap / 1024)} KB")
            InfoLine(p, "Uptime", formatUptime(s.uptime))
            InfoLine(p, "Dropped / filtered", "${s.dropped} / ${s.filtered}")
        }
        SectionCard(p, title = tx(fa, "APP PREFERENCES", "تنظیمات اپ"), subtitle = tx(fa, "These preferences are stored on this phone.", "این ترجیحات فقط روی گوشی ذخیره می‌شوند.")) {
            ToggleRow(p, tx(fa, "Persian interface", "رابط فارسی"), tx(fa, "Switch the native app language.", "زبان رابط مستقل اپ را تغییر می‌دهد."), fa) { onLanguage() }
            ToggleRow(p, tx(fa, "Dark appearance", "پوسته تیره"), tx(fa, "Use the dark color palette.", "از پوسته تیره استفاده می‌کند."), dark) { onTheme() }
        }
        ActionButton(p, tx(fa, "Disconnect from device", "قطع اتصال از دستگاه"), onLogout, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Brand(p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(p.accent, p.blue))), contentAlignment = Alignment.Center) {
            Text("W", color = Color(0xFF08202A), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("WAPFIRE", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.7.sp)
            Text("WIRELESS INTELLIGENCE", color = p.muted, fontSize = 8.sp, letterSpacing = 1.1.sp)
        }
    }
}

@Composable
private fun SmallAction(p: Palette, label: String, onClick: () -> Unit) {
    Box(Modifier.sizeIn(minWidth = 36.dp, minHeight = 36.dp).clip(RoundedCornerShape(12.dp)).background(p.panelAlt).border(1.dp, p.border, RoundedCornerShape(12.dp)).clickable { onClick() }.padding(horizontal = 9.dp, vertical = 7.dp), contentAlignment = Alignment.Center) {
        Text(label, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionCard(p: Palette, title: String, subtitle: String = "", content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(21.dp)).background(p.panel).border(1.dp, p.border, RoundedCornerShape(21.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        content.invoke(this)
    }
}

@Composable
private fun MessageCard(p: Palette, message: String, danger: Boolean, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (danger) p.red.copy(alpha = .10f) else p.green.copy(alpha = .10f)).border(1.dp, (if (danger) p.red else p.green).copy(alpha = .35f), RoundedCornerShape(14.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (danger) "!" else "✓", color = if (danger) p.red else p.green, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(9.dp)); Text(message, color = p.text, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.weight(1f))
        Text("×", color = p.muted, modifier = Modifier.clickable { onClose() }.padding(horizontal = 4.dp))
    }
}

@Composable
private fun ActionButton(p: Palette, label: String, onClick: () -> Unit, enabled: Boolean = true, primary: Boolean = false, modifier: Modifier = Modifier) {
    val bg = if (primary) p.accent else p.panelAlt
    val fg = if (primary) Color(0xFF06232A) else p.text
    Box(modifier.clip(RoundedCornerShape(13.dp)).background(if (enabled) bg else bg.copy(alpha = .45f)).border(1.dp, if (primary) p.accent else p.border, RoundedCornerShape(13.dp)).clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) fg else p.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NativeField(p: Palette, value: String, onValue: (String) -> Unit, label: String, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 12.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(13.dp),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = p.text, unfocusedTextColor = p.text,
            focusedBorderColor = p.accent, unfocusedBorderColor = p.border,
            focusedLabelColor = p.accent, unfocusedLabelColor = p.muted,
            cursorColor = p.accent
        )
    )
}

@Composable
private fun DeviceResult(p: Palette, title: String, detail: String, badge: String, onClick: () -> Unit, action: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(p.panelAlt).clickable(enabled = action.isNotBlank()) { onClick() }.padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(p.accentSoft), contentAlignment = Alignment.Center) { Text("⌁", color = p.accent, fontSize = 18.sp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (badge.isNotBlank()) Text(badge, color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        if (action.isNotBlank()) Text(action, color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricTile(p: Palette, value: String, label: String, glyph: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(p.panel).border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(glyph, color = color, fontSize = 15.sp); Spacer(Modifier.weight(1f)); Box(Modifier.size(5.dp).clip(CircleShape).background(color)) }
        Text(value, color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = p.muted, fontSize = 10.sp)
    }
}

@Composable
private fun ThreatRing(p: Palette, score: Int, level: String) {
    val color = when (level.uppercase()) { "HIGH", "CRITICAL" -> p.red; "MEDIUM", "MODERATE" -> p.orange; else -> p.green }
    Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(color.copy(alpha = .18f), -90f, 360f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
            drawArc(color, -90f, (score.coerceIn(0, 100) * 3.6f), false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("$score", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(level, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun NativeLineChart(p: Palette, primary: List<Int>, secondary: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val pad = 8.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        for (i in 0..3) {
            val y = pad + h * i / 3f
            drawLine(p.border, Offset(pad, y), Offset(size.width - pad, y), 1.dp.toPx())
        }
        fun drawSeries(values: List<Int>, color: Color, stroke: Float) {
            if (values.size < 2) return
            val max = (primary + secondary).maxOrNull()?.coerceAtLeast(1) ?: 1
            val path = Path()
            values.forEachIndexed { index, v ->
                val x = pad + (w * index / (values.size - 1).toFloat())
                val y = pad + h - (v.coerceAtLeast(0).toFloat() / max) * h
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        drawSeries(primary, p.accent, 2.5.dp.toPx())
        drawSeries(secondary, p.blue, 2.dp.toPx())
    }
}

@Composable
private fun LegendDot(color: Color, label: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(label, color = p.muted, fontSize = 9.sp)
    }
}

@Composable
private fun MiniValue(p: Palette, value: String, label: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.muted, fontSize = 8.sp)
    }
}

@Composable
private fun ToggleRow(p: Palette, title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun DividerLine(p: Palette) { Box(Modifier.fillMaxWidth().height(1.dp).background(p.border)) }

@Composable
private fun InfoLine(p: Palette, key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun tx(fa: Boolean, en: String, persian: String) = if (fa) persian else en
private fun Long.compact(): String = when {
    this >= 1_000_000 -> String.format("%.1fM", this / 1_000_000.0)
    this >= 1_000 -> String.format("%.1fK", this / 1_000.0)
    else -> toString()
}
private fun formatUptime(ms: Long): String {
    if (ms <= 0) return "—"
    val seconds = ms / 1000
    val days = seconds / 86400
    val hours = (seconds % 86400) / 3600
    val minutes = (seconds % 3600) / 60
    return if (days > 0) "${days}d ${hours}h" else if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
}
