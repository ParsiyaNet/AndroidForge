package io.wapfire.mobile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Native HTTP client for the firmware's documented API. */
class WapFireApi(hostOrUrl: String) {
    val baseUrl: String = normalizeBase(hostOrUrl)
    @Volatile private var authCookie: String? = null

    data class Reply(val code: Int, val body: String, val cookie: String? = null)

    private fun request(path: String, method: String = "GET", body: String? = null, contentType: String? = null): Reply {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 6500
            readTimeout = 8500
            useCaches = false
            instanceFollowRedirects = false
            setRequestProperty("Accept", "application/json, text/plain, */*")
            authCookie?.let { setRequestProperty("Cookie", it) }
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType ?: "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val cookie = connection.getHeaderField("Set-Cookie")
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            Reply(code, text, cookie)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun login(user: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            authCookie = null
            val form = "user=${encode(user)}&pass=${encode(password)}"
            val reply = request("/login", "POST", form, "application/x-www-form-urlencoded")
            if (reply.code !in 200..299) error(reply.body.ifBlank { "Login rejected (${reply.code})" })
            val raw = reply.cookie ?: error("The device did not return an authentication session")
            val token = raw.substringBefore(';').trim()
            if (!token.startsWith("wg_auth=") || token.substringAfter('=').length < 32) {
                error("The device returned an invalid authentication session")
            }
            authCookie = token
        }
    }

    suspend fun status(): Result<JSONObject> = jsonGet("/api/status")
    suspend fun settings(): Result<JSONObject> = jsonGet("/api/settings")
    suspend fun chart(): Result<JSONObject> = jsonGet("/api/chart_data")
    suspend fun firmwareInfo(): Result<JSONObject> = jsonGet("/api/firmware_info")
    suspend fun logs(): Result<JSONArray> = arrayGet("/api/logs")
    suspend fun clients(): Result<JSONArray> = arrayGet("/api/tracked_clients")
    suspend fun scan(): Result<JSONArray> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request("/api/scan", "POST", "", "application/json")
            if (r.code !in 200..299) error(r.body.ifBlank { "Network scan failed (${r.code})" })
            JSONArray(r.body)
        }
    }
    suspend fun selectTarget(ssid: String, bssid: String, channel: Int): Result<JSONObject> = jsonPost(
        "/api/select_target", JSONObject().put("ssid", ssid).put("bssid", bssid).put("channel", channel)
    )
    suspend fun updateSettings(values: JSONObject): Result<JSONObject> = jsonPost("/api/settings", values)
    suspend fun clearLogs(): Result<JSONObject> = jsonPost("/api/clear_logs", JSONObject())

    private suspend fun jsonGet(path: String): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path)
            if (r.code !in 200..299) error(httpError(r))
            JSONObject(r.body)
        }
    }

    private suspend fun arrayGet(path: String): Result<JSONArray> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path)
            if (r.code !in 200..299) error(httpError(r))
            JSONArray(r.body)
        }
    }

    private suspend fun jsonPost(path: String, body: JSONObject): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path, "POST", body.toString())
            if (r.code !in 200..299) error(httpError(r))
            JSONObject(r.body).also {
                if (it.has("success") && !it.optBoolean("success", true)) error(it.optString("message", "Operation failed"))
            }
        }
    }

    private fun httpError(reply: Reply): String = try {
        JSONObject(reply.body).optString("message").takeIf { it.isNotBlank() } ?: reply.body.take(160)
    } catch (_: Exception) { reply.body.take(160).ifBlank { "Request failed (${reply.code})" } }

    fun clearSession() { authCookie = null }

    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")

    companion object {
        private fun normalizeBase(input: String): String {
            var value = input.trim().removeSuffix("/")
            if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://$value"
            return value
        }
    }
}
