package io.wapfire.mobile.network

import org.json.JSONObject

/**
 * Owns the app-side authentication recovery policy.
 *
 * The VF38 firmware binds sessions to the remote client IP as well as its cookie.
 * A phone can therefore keep the same gateway and cookie while its IP changes;
 * the server then answers 401. We verify the WAPFire login page before ever
 * resending credentials, then create one fresh session and retry only the safe
 * status read. Mutating requests are never replayed by this manager.
 */
internal class WapFireSessionManager {
    private var retryRecoveryAfterNanos: Long = 0L

    sealed interface StatusResult {
        data class Online(val status: JSONObject, val recovered: Boolean) : StatusResult
        data class Offline(val message: String) : StatusResult
        data class LoginRequired(val message: String) : StatusResult
    }

    data class VerifiedSession(
        val api: WapFireApi,
        val status: JSONObject
    )

    suspend fun statusWithRecovery(
        api: WapFireApi,
        username: String,
        password: String
    ): StatusResult {
        val first = api.status()
        if (first.isSuccess) return StatusResult.Online(first.getOrThrow(), recovered = false)

        val failure = first.exceptionOrNull()
            ?: return StatusResult.Offline("WAPFire did not return a status response.")
        val http = failure as? WapFireHttpException
        if (http?.statusCode != 401) return StatusResult.Offline(failure.message ?: "Device connection lost")

        val now = System.nanoTime()
        if (now < retryRecoveryAfterNanos) {
            return StatusResult.Offline("WAPFire session recovery is paused briefly after a temporary network failure.")
        }

        val identity = api.verifyDeviceIdentity()
        if (identity.isFailure || identity.getOrDefault(false).not()) {
            return StatusResult.Offline(
                identity.exceptionOrNull()?.message
                    ?: "The endpoint did not identify itself as the WAPFire VF38 login page. Credentials were not resent."
            )
        }
        if (username.isBlank() || password.isBlank()) {
            return StatusResult.LoginRequired("The WAPFire session expired. Sign in again to continue.")
        }

        val login = api.login(username, password)
        if (login.isFailure) {
            val loginError = login.exceptionOrNull()
            val httpCode = (loginError as? WapFireHttpException)?.statusCode
            return if (httpCode == 401 || httpCode == 429) {
                StatusResult.LoginRequired(
                    loginError?.message ?: "The session expired. Please sign in again."
                )
            } else {
                // Avoid turning a temporary timeout into a burst of login requests.
                retryRecoveryAfterNanos = System.nanoTime() + 8_000_000_000L
                StatusResult.Offline(loginError?.message ?: "Automatic session recovery could not reach WAPFire.")
            }
        }

        val retry = api.status()
        if (retry.isSuccess) return StatusResult.Online(retry.getOrThrow(), recovered = true)
        val retryError = retry.exceptionOrNull()
        return if ((retryError as? WapFireHttpException)?.statusCode == 401) {
            StatusResult.LoginRequired("A new WAPFire session was created, but the status endpoint still rejected it. Please sign in again.")
        } else {
            StatusResult.Offline(retryError?.message ?: "WAPFire did not answer after session recovery.")
        }
    }

    /** Used only when a reconnect callback proves the same AP by its exact BSSID. */
    suspend fun connectToVerifiedHost(
        host: String,
        username: String,
        password: String
    ): Result<VerifiedSession> {
        if (username.isBlank() || password.isBlank()) {
            return Result.failure(IllegalStateException("Saved sign-in details are not available."))
        }
        val candidate = WapFireApi(host)
        val identity = candidate.verifyDeviceIdentity()
        if (identity.isFailure) return Result.failure(identity.exceptionOrNull()!!)
        if (!identity.getOrDefault(false)) {
            return Result.failure(IllegalStateException("The new address did not verify as a WAPFire VF38 device. Credentials were not sent."))
        }
        val login = candidate.login(username, password)
        if (login.isFailure) return Result.failure(login.exceptionOrNull()!!)
        val status = candidate.status()
        if (status.isFailure) {
            candidate.clearSession()
            return Result.failure(status.exceptionOrNull()!!)
        }
        return Result.success(VerifiedSession(candidate, status.getOrThrow()))
    }
}
