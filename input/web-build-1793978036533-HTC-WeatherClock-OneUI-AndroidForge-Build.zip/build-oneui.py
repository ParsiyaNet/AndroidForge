#!/usr/bin/env python3
"""Compile the bridge Java sources and replace only Manifest + classes3.dex in the supplied APK."""
from __future__ import annotations
import os, shutil, subprocess, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "base" / "original.apk"
BUILD = ROOT / "oneui-work"
SRC = ROOT / "source" / "breezybridge"
MANIFEST_TOOL = ROOT / "scripts" / "patch_manifest.py"


def tool(name: str, candidates: list[Path]) -> Path:
    for p in candidates:
        if p.is_file() and os.access(p, os.X_OK):
            return p
    raise SystemExit(f"Missing Android build tool: {name}. Checked: " + ", ".join(map(str, candidates)))


def main() -> None:
    sdk = Path(os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or (Path.home() / "Android" / "Sdk"))
    # AndroidForge runners and Linux CI images commonly use one of these paths.
    if not (sdk / "platforms" / "android-36" / "android.jar").exists():
        for candidate in (Path("/opt/android-sdk"), Path("/usr/lib/android-sdk"), Path("/usr/local/android-sdk")):
            if (candidate / "platforms" / "android-36" / "android.jar").exists():
                sdk = candidate; break
    android_jar = sdk / "platforms" / "android-36" / "android.jar"
    bt = sdk / "build-tools" / "36.0.0"
    d8 = tool("d8", [bt / "d8", bt / "d8.bat"])
    zipalign = tool("zipalign", [bt / "zipalign", bt / "zipalign.exe"])
    apksigner = tool("apksigner", [bt / "apksigner", bt / "apksigner.bat"])
    keytool = shutil.which("keytool")
    javac = shutil.which("javac")
    if not android_jar.exists():
        raise SystemExit(f"Missing Android 36 platform jar: {android_jar}")
    if not javac or not keytool:
        raise SystemExit("JDK javac and keytool are required")
    if not BASE.exists():
        raise SystemExit(f"Base APK not found: {BASE}")

    shutil.rmtree(BUILD, ignore_errors=True)
    for d in ("stubs", "classes", "dex", "tmp"):
        (BUILD / d).mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE) as z:
        (BUILD / "tmp" / "AndroidManifest.xml").write_bytes(z.read("AndroidManifest.xml"))
    stub_java = sorted((SRC / "stubs").rglob("*.java"))
    src_java = sorted((SRC / "src").rglob("*.java"))
    if not stub_java or not src_java:
        raise SystemExit("Bridge source or compile-time stubs are missing")

    def run(cmd: list[str]) -> None:
        print("+", " ".join(map(str, cmd)))
        subprocess.run(list(map(str, cmd)), check=True)

    run([javac, "-nowarn", "-source", "11", "-target", "11", "-cp", android_jar,
         "-d", BUILD / "stubs", *stub_java])
    run([javac, "-nowarn", "-source", "11", "-target", "11", "-cp",
         os.pathsep.join((str(android_jar), str(BUILD / "stubs"))),
         "-d", BUILD / "classes", *src_java])
    run([d8, "--lib", android_jar, "--min-api", "24", "--output", BUILD / "dex",
         *sorted((BUILD / "classes").rglob("*.class"))])

    new_dex = BUILD / "dex" / "classes.dex"
    if not new_dex.exists():
        raise SystemExit("D8 did not create classes.dex")
    manifest_in = BUILD / "tmp" / "AndroidManifest.xml"
    subprocess.run([sys.executable, str(MANIFEST_TOOL), str(manifest_in), str(BUILD / "tmp" / "AndroidManifest.patched.xml")], check=True)

    unsigned = BUILD / "unsigned.apk"
    replaced = {"AndroidManifest.xml": (BUILD / "tmp" / "AndroidManifest.patched.xml").read_bytes(),
                "classes3.dex": new_dex.read_bytes()}
    signatures = ("META-INF/MANIFEST.MF",)
    with zipfile.ZipFile(BASE, "r") as zin, zipfile.ZipFile(unsigned, "w") as zout:
        names = set()
        for info in zin.infolist():
            name = info.filename
            if name in names:
                continue
            names.add(name)
            if name.upper().startswith("META-INF/") and name.upper().endswith((".SF", ".RSA", ".DSA", ".EC", ".MF")):
                continue
            data = replaced.pop(name, None)
            if data is None:
                data = zin.read(name)
            zout.writestr(info, data)
        if replaced:
            raise SystemExit("Base APK is missing required replacement entries: " + ", ".join(replaced))

    aligned = BUILD / "aligned.apk"
    output = ROOT / "build" / "outputs" / "apk" / "debug" / "HTC-WeatherClock-v1.3.0-oneui-debug.apk"
    output.parent.mkdir(parents=True, exist_ok=True)
    run([zipalign, "-f", "-p", "4", unsigned, aligned])

    # Keep a stable signing key across repeated builds in the same workspace.
    ks = ROOT / ".oneui-debug.keystore"
    if not ks.exists():
        run([keytool, "-genkeypair", "-keystore", ks, "-storepass", "android", "-keypass", "android",
             "-alias", "oneui", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-dname", "CN=HTC Weather Clock OneUI Debug, OU=Local Build, O=Open Source Patch, C=US"])
    run([apksigner, "sign", "--ks", ks, "--ks-pass", "pass:android", "--key-pass", "pass:android",
         "--ks-key-alias", "oneui", "--out", output, aligned])
    run([apksigner, "verify", "--verbose", "--print-certs", output])
    print(f"\nAPK created: {output}")
    print("NOTE: signed with a new local debug key; uninstall the prior app before installing this APK.")


if __name__ == "__main__":
    main()
