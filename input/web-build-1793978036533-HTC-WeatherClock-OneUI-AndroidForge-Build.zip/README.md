# HTC Weather Clock — One UI build bundle (v1.3.0)

This bundle combines the supplied **v1.2.9-breezy APK** with the One UI/standalone Java sources from the supplied project archive. It is a build project, **not a prebuilt or device-tested APK**.

## What the build does

- Compiles the bridge Java sources in `source/breezybridge/src` with the compile-time stubs in `source/breezybridge/stubs`.
- Replaces only `classes3.dex` in the supplied APK; the original application DEX files, widget resources, layouts, images and animations are kept.
- Patches the binary manifest for direct Open-Meteo network access and approximate foreground location.
- Removes the Breezy provider permission, Breezy package-visibility entry and Breezy update receiver.
- Sets versionCode `663091327` and versionName `10.10.1059527-android36-v1.3.0-oneui`.
- Aligns and signs the result using Android SDK Build Tools 36.0.0.

The original APK still has the v1.2.9 Breezy dependency. The standalone weather implementation is in the replacement Java/Dex sources, not in the original uploaded APK.

## Build in AndroidForge / CI

The project root contains `settings.gradle` and `build.gradle`. The `assembleDebug` and `bundleDebug` Gradle tasks both run the custom builder.

Required on the runner:

- JDK with `javac` and `keytool`
- Python 3
- Android SDK Platform 36 (`android.jar`)
- Android SDK Build Tools 36.0.0 (`d8`, `zipalign`, `apksigner`)
- Gradle 8+ (or a compatible installed Gradle)

Run from the extracted ZIP root:

```bash
gradle assembleDebug
```

Output:

`build/outputs/apk/debug/HTC-WeatherClock-v1.3.0-oneui-debug.apk`

## Build status / installation note

- The manifest transformation was run against the exact uploaded APK and parsed back successfully. Python syntax checks also passed.
- This workspace does not have Android SDK Platform 36 or Build Tools 36.0.0, and Gradle is not installed, so Java compilation, D8, APK signing and device installation have **not** been run here.
- The build script creates a new local debug signing key. The result cannot be installed as an in-place update over the original signed APK. Uninstall the old package before installing the rebuilt one; app-private settings may be lost.
- Runtime testing is still required on the Samsung phone: widget recreation, location permission/setup, offline cache, and unlock-weather animation.
