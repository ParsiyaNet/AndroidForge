#!/usr/bin/env python3
"""Make the v1.2.9 APK manifest match the standalone One UI source build."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source" / "tools"))
from axml import Axml  # noqa: E402

ANDROID = "http://schemas.android.com/apk/res/android"
OPENMETEO = "com.htc.widget.weatherclock.openmeteo."
TYPE_INT_DEC = 0x10
TYPE_INT_BOOLEAN = 0x12
TYPE_STRING = 0x03
NO_INDEX = 0xFFFFFFFF


def set_bool(a: Axml, i: int, name: str, value: bool) -> None:
    for attr in a.nodes[i].attrs:
        if a.s(attr[1]) == name:
            attr[2] = NO_INDEX
            attr[5] = TYPE_INT_BOOLEAN
            attr[6] = 0xFFFFFFFF if value else 0
            return
    raise KeyError(f"missing android:{name} on {a.name(a.nodes[i])}")


def set_int(a: Axml, i: int, name: str, value: int) -> None:
    for attr in a.nodes[i].attrs:
        if a.s(attr[1]) == name:
            attr[2] = NO_INDEX
            attr[5] = TYPE_INT_DEC
            attr[6] = value
            return
    raise KeyError(f"missing android:{name} on {a.name(a.nodes[i])}")


def set_string(a: Axml, i: int, name: str, value: str) -> None:
    for attr in a.nodes[i].attrs:
        if a.s(attr[1]) == name:
            idx = a.pool.index(value)
            attr[2] = idx
            attr[5] = TYPE_STRING
            attr[6] = idx
            return
    raise KeyError(f"missing android:{name} on {a.name(a.nodes[i])}")


def remove_matches(a: Axml, tag: str, **attrs: str) -> int:
    matches = a.find(tag, **attrs)
    for i in reversed(matches):
        a.remove(i)
    return len(matches)


def add_permission(a: Axml, permission: str) -> bool:
    if a.find("uses-permission", name=permission):
        return False
    node = a.element("uses-permission", [("name", permission)], ns_uri=ANDROID)
    existing = a.find("uses-permission")
    if existing:
        end = a.end_of(existing[-1]) + 1
        a.nodes[end:end] = node
    else:
        manifest = a.find("manifest")[0]
        a.insert_after_start(manifest, node)
    return True


def query_has_home(a: Axml) -> bool:
    q = a.find("queries")
    if not q:
        return False
    q_end = a.end_of(q[0])
    for i, node in enumerate(a.nodes):
        if i <= q[0] or i >= q_end or node.type != 0x0102 or a.name(node) != "intent":
            continue
        intent_end = a.end_of(i)
        actions, categories = set(), set()
        for child in a.nodes[i + 1:intent_end]:
            if child.type != 0x0102:
                continue
            tag, val = a.name(child), a.attr(child, "name")
            if tag == "action": actions.add(val)
            elif tag == "category": categories.add(val)
        if "android.intent.action.MAIN" in actions and "android.intent.category.HOME" in categories:
            return True
    return False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    a = Axml(Path(args.input).read_bytes())

    # This APK is the actual v1.2.9-breezy package, not the older 1.2.4 manifest
    # used by the upstream builder. Make the transformation idempotent.
    removed = 0
    for perm in (
        "org.breezyweather.READ_PROVIDER",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
        "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
        "android.permission.WAKE_LOCK",
    ):
        removed += remove_matches(a, "uses-permission", name=perm)
    removed += remove_matches(a, "package", name="org.breezyweather")
    removed += remove_matches(a, "receiver", name=OPENMETEO + "BreezyUpdateReceiver")
    removed += remove_matches(a, "receiver", name=OPENMETEO + "WeatherMotion$Receiver")
    removed += remove_matches(a, "service", name=OPENMETEO + "ClockTickService")

    added = []
    for perm in (
        "android.permission.INTERNET",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.PACKAGE_USAGE_STATS",
        "android.permission.USE_EXACT_ALARM",
    ):
        if add_permission(a, perm):
            added.append(perm)

    manifest = a.find("manifest")[0]
    set_int(a, manifest, "versionCode", 663091327)
    set_string(a, manifest, "versionName", "10.10.1059527-android36-v1.3.0-oneui")
    set_bool(a, a.find("application")[0], "allowBackup", False)

    # Disable the adb-only/test components in the release APK.
    for tag, name in (
        ("receiver", OPENMETEO + "FlipClockTicker"),
        ("receiver", OPENMETEO + "ScreenWatch"),
        ("receiver", OPENMETEO + "UpdateReceiver"),
        ("service", OPENMETEO + "UnlockWatchJob"),
        ("activity", OPENMETEO + "FlipStyleActivity"),
        ("activity", OPENMETEO + "ClockPulseActivity"),
        ("activity", OPENMETEO + "DiagnosticsActivity"),
        ("activity", OPENMETEO + "WeatherSettingsActivity"),
    ):
        for i in a.find(tag, name=name):
            set_bool(a, i, "exported", False)

    # The base APK already has the HOME query; add only if it is absent.
    if not query_has_home(a):
        home = a.element("intent", [], [
            a.element("action", [("name", "android.intent.action.MAIN")], ns_uri=ANDROID),
            a.element("category", [("name", "android.intent.category.HOME")], ns_uri=ANDROID),
        ], ns_uri=ANDROID)
        q = a.find("queries")
        if not q:
            raise ValueError("manifest has no <queries>; cannot add launcher visibility query")
        a.insert_before_end(q[0], home)

    Path(args.output).write_bytes(a.build())
    # Parse the output again, and assert the critical standalone properties.
    check = Axml(Path(args.output).read_bytes())
    perms = {check.attr(check.nodes[i], "name") for i in check.find("uses-permission")}
    assert "android.permission.INTERNET" in perms
    assert "android.permission.ACCESS_COARSE_LOCATION" in perms
    assert "org.breezyweather.READ_PROVIDER" not in perms
    assert not check.find("package", name="org.breezyweather")
    assert check.attr(check.nodes[check.find("manifest")[0]], "versionCode") == 663091327
    print(f"manifest patched; removed={removed}, added_permissions={added}")
    print(f"permissions={len(perms)}, versionCode=663091327, versionName=10.10.1059527-android36-v1.3.0-oneui")


if __name__ == "__main__":
    main()
