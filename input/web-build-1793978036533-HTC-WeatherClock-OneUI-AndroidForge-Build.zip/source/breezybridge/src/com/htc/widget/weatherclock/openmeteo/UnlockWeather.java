package com.htc.widget.weatherclock.openmeteo;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;

import java.util.HashSet;
import java.util.Set;

/**
 * Samsung/One UI-friendly unlock weather animation.
 * Samsung's launcher can take longer than the old fixed 150/400/800 ms window to finish its
 * unlock transition. We keep checking the foreground package for up to five seconds and only
 * mark the attempt complete after the overlay has actually been attached.
 */
final class UnlockWeather {
    private static final String TAG = "UnlockWeather";
    private static final String KEY = "unlock_weather";
    private static final long RETRY_MS = 150;
    private static final long MAX_WAIT_MS = 5_000;
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private static volatile long sAttemptId;
    private static Runnable sPending;

    private UnlockWeather() { }

    static boolean enabled(Context ctx) {
        try {
            return ctx.getSharedPreferences("breezy", 0).getBoolean(KEY, false);
        } catch (Throwable th) {
            return false;
        }
    }

    static void setEnabled(Context ctx, boolean on) {
        ctx.getSharedPreferences("breezy", 0).edit().putBoolean(KEY, on).apply();
    }

    static boolean canOverlay(Context ctx) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx);
    }

    static boolean hasUsageAccess(Context ctx) {
        try {
            AppOpsManager ops = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
            if (ops == null) return false;
            int mode = Build.VERSION.SDK_INT >= 29
                    ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName())
                    : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED || (mode == AppOpsManager.MODE_DEFAULT
                    && ctx.checkSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS)
                    == PackageManager.PERMISSION_GRANTED);
        } catch (Throwable th) {
            return false;
        }
    }

    static Intent missingPermission(Context ctx) {
        return missingPermission(ctx, true);
    }

    static Intent missingPermission(Context ctx, boolean overlay) {
        Uri pkg = Uri.parse("package:" + ctx.getPackageName());
        if (overlay && !canOverlay(ctx)) {
            return new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
        }
        if (!hasUsageAccess(ctx)) {
            return new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, pkg);
        }
        return null;
    }

    /** Called once the keyguard goes away. Retry until One UI's launcher is really foreground. */
    static void play(final Context app) {
        if (!enabled(app) || !canOverlay(app) || !hasUsageAccess(app)) return;

        final long id = ++sAttemptId;
        if (sPending != null) HANDLER.removeCallbacks(sPending);
        final long started = SystemClock.elapsedRealtime();
        final boolean[] syncRequested = {false};
        final Set<String> launchers = homePackages(app);

        Runnable attempt = new Runnable() {
            @Override public void run() {
                if (id != sAttemptId) return;
                if (!FlipAnimV3.isScreenOn(app) || FlipAnimV3.locked(app)) {
                    sPending = null;
                    return;
                }

                // A first-run widget may have a valid location but no weather row yet. Kick one sync,
                // then keep the same bounded retry window rather than permanently losing this unlock.
                if (!syncRequested[0] && BreezyWeather.quickState(app) != BreezyWeather.State.READY) {
                    syncRequested[0] = true;
                    OpenMeteoBridge.requestSync(app, true);
                }

                String front = frontPackage(app);
                if (front != null && launchers.contains(front)) {
                    if (WeatherAnim.playOverlay(app)) {
                        ClockLog.tick(app, "UNLOCK_WEATHER shown");
                        sPending = null;
                        return;
                    }
                }

                if (SystemClock.elapsedRealtime() - started < MAX_WAIT_MS) {
                    HANDLER.postDelayed(this, RETRY_MS);
                } else {
                    ClockLog.tick(app, "UNLOCK_WEATHER skipped: launcher or weather not ready");
                    sPending = null;
                }
            }
        };
        sPending = attempt;
        HANDLER.postDelayed(attempt, RETRY_MS);
    }

    /** The home screen is in front now (needs usage access). */
    static boolean homeInFront(Context ctx) {
        if (!hasUsageAccess(ctx)) return false;
        String front = frontPackage(ctx);
        return front != null && homePackages(ctx).contains(front);
    }

    /** The package of the activity resumed last (the one in front now). */
    private static String frontPackage(Context ctx) {
        try {
            UsageStatsManager usm = (UsageStatsManager) ctx.getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return null;
            long now = System.currentTimeMillis();
            for (long back : new long[]{30 * 60_000L, 12 * 60 * 60_000L}) {
                UsageEvents ev = usm.queryEvents(now - back, now + 1_000L);
                UsageEvents.Event e = new UsageEvents.Event();
                String last = null;
                while (ev != null && ev.hasNextEvent()) {
                    ev.getNextEvent(e);
                    if (e.getEventType() == 1) { // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
                        last = e.getPackageName();
                    }
                }
                if (last != null) return last;
            }
        } catch (Throwable th) {
            Log.w(TAG, "usage events failed", th);
        }
        return null;
    }

    /** The default launcher, or every launcher if none is chosen (not Settings' FallbackHome). */
    private static Set<String> homePackages(Context ctx) {
        Set<String> out = new HashSet<>();
        try {
            PackageManager pm = ctx.getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo def = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (def != null && def.activityInfo != null && !"android".equals(def.activityInfo.packageName)) {
                out.add(def.activityInfo.packageName);
                return out;
            }
            for (ResolveInfo ri : pm.queryIntentActivities(home, 0)) {
                if (ri.activityInfo != null) out.add(ri.activityInfo.packageName);
            }
            out.remove("com.android.settings");
        } catch (Throwable th) {
            Log.w(TAG, "home lookup failed", th);
        }
        return out;
    }
}
