package com.htc.widget.weatherclock.openmeteo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Standalone weather/location backend for One UI and other Android launchers.
 * Location is requested only from the foreground settings screen; the saved coordinates are then
 * used for weather refreshes. No background-location permission or always-on GPS is used.
 * Open-Meteo supplies forecast data without an API key.
 */
final class StandaloneWeather {
    private static final String TAG = "StandaloneWeather";
    private static final String PREFS = "standalone_weather";
    private static final long WEATHER_CACHE_MS = 5 * 60_000L;
    private static final long LOCATION_FALLBACK_MAX_AGE_MS = 6 * 60 * 60_000L;
    private static final long LOCATION_TIMEOUT_MS = 15_000L;

    interface LocationCallback {
        void onResult(boolean success, String message);
    }

    private StandaloneWeather() { }

    static boolean hasPermission(Context context) {
        if (Build.VERSION.SDK_INT < 23) return true;
        return context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    static boolean shouldRequestLocationPermission(Context context) {
        return !hasPermission(context) && !prefs(context).getBoolean("location_permission_prompted", false);
    }

    static void markLocationPermissionPrompted(Context context) {
        prefs(context).edit().putBoolean("location_permission_prompted", true).apply();
    }

    static boolean hasCurrentLocation(Context context) {
        return prefs(context).getBoolean("configured", false)
                && valid(prefs(context).getFloat("latitude", Float.NaN),
                         prefs(context).getFloat("longitude", Float.NaN));
    }

    static boolean hasLocation(Context context) {
        if (hasCurrentLocation(context)) return true;
        try {
            JSONArray rows = new JSONArray(context.getSharedPreferences("openmeteo_weather", 0)
                    .getString("locations", "[]"));
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                double lat = number(row.optString("latitude", "NaN"), Double.NaN);
                double lon = number(row.optString("longitude", "NaN"), Double.NaN);
                if (!valid(lat, lon)) {
                    String code = row.optString("code", "");
                    int comma = code.indexOf(',');
                    if (comma > 0) {
                        lat = number(code.substring(0, comma), Double.NaN);
                        lon = number(code.substring(comma + 1), Double.NaN);
                    }
                }
                if (valid(lat, lon)) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    static boolean shouldAutoRefreshLocation(Context context) {
        if (!hasPermission(context)) return false;
        long now = System.currentTimeMillis();
        long lastAttempt = prefs(context).getLong("location_attempt", 0L);
        long lastFix = prefs(context).getLong("location_updated", 0L);
        boolean missing = !hasCurrentLocation(context);
        boolean stale = lastFix <= 0 || now - lastFix > 12 * 60 * 60_000L;
        return (missing || stale) && now - lastAttempt > 6 * 60 * 60_000L;
    }

    static String locationSummary(Context context) {
        if (!hasCurrentLocation(context)) {
            List<BreezyWeather.Place> saved = places(context);
            if (saved.isEmpty()) return "No current location saved";
            return saved.get(0).name + " · saved city";
        }
        String name = prefs(context).getString("name", "Current location");
        String timezone = prefs(context).getString("timezone", TimeZone.getDefault().getID());
        return (name == null || name.trim().isEmpty() ? "Current location" : name)
                + " · " + timezone;
    }

    /**
     * One-shot foreground location fix. API 30+ uses LocationManager.getCurrentLocation (One UI 3+).
     * Older Android versions fall back to requestSingleUpdate. A recent cached fix is used if the
     * provider cannot return a fresh one before the timeout.
     */
    static void requestCurrentLocation(Context context, LocationCallback callback) {
        final Context app = context.getApplicationContext() != null
                ? context.getApplicationContext() : context;
        final Handler main = new Handler(Looper.getMainLooper());
        if (!hasPermission(app)) {
            callback.onResult(false, "Location permission was not granted.");
            return;
        }
        prefs(app).edit().putLong("location_attempt", System.currentTimeMillis()).apply();
        final LocationManager manager = (LocationManager) app.getSystemService(Context.LOCATION_SERVICE);
        if (manager == null) {
            callback.onResult(false, "Android location service is unavailable.");
            return;
        }

        final Location fallback = bestLastKnown(manager);
        final AtomicBoolean completed = new AtomicBoolean(false);
        final Runnable[] timeout = new Runnable[1];
        final LocationListener[] listenerRef = new LocationListener[1];
        final java.util.function.Consumer<Location> complete = location -> main.post(() -> {
            if (!completed.compareAndSet(false, true)) return;
            if (timeout[0] != null) main.removeCallbacks(timeout[0]);
            if (listenerRef[0] != null) {
                try { manager.removeUpdates(listenerRef[0]); } catch (Throwable ignored) { }
            }
            Location chosen = location;
            if (chosen == null && fallback != null
                    && System.currentTimeMillis() - fallback.getTime() <= LOCATION_FALLBACK_MAX_AGE_MS) {
                chosen = fallback;
            }
            if (chosen == null) {
                callback.onResult(false, "Could not obtain a location. Check Location services and try again.");
                return;
            }
            saveLocation(app, chosen);
            callback.onResult(true, "Location saved.");
        });
        timeout[0] = () -> complete.accept(null);
        main.postDelayed(timeout[0], LOCATION_TIMEOUT_MS);

        String provider = chooseProvider(manager);
        if (provider == null) {
            complete.accept(null);
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Executor executor = command -> main.post(command);
                manager.getCurrentLocation(provider, null, executor, location -> complete.accept(location));
            } else {
                listenerRef[0] = new LocationListener() {
                    @Override public void onLocationChanged(Location location) { complete.accept(location); }
                    @Override public void onStatusChanged(String name, int status, android.os.Bundle extras) { }
                    @Override public void onProviderEnabled(String name) { }
                    @Override public void onProviderDisabled(String name) { }
                };
                manager.requestSingleUpdate(provider, listenerRef[0], Looper.getMainLooper());
            }
        } catch (SecurityException e) {
            complete.accept(null);
        } catch (Throwable t) {
            Log.w(TAG, "location request failed", t);
            complete.accept(null);
        }
    }

    private static String chooseProvider(LocationManager manager) {
        try {
            List<String> enabled = manager.getProviders(true);
            if (enabled.contains(LocationManager.NETWORK_PROVIDER)) return LocationManager.NETWORK_PROVIDER;
            if (enabled.contains("fused")) return "fused";
            if (enabled.contains(LocationManager.GPS_PROVIDER)) return LocationManager.GPS_PROVIDER;
        } catch (Throwable ignored) { }
        return null;
    }

    private static Location bestLastKnown(LocationManager manager) {
        Location best = null;
        try {
            for (String provider : manager.getProviders(true)) {
                try {
                    Location candidate = manager.getLastKnownLocation(provider);
                    if (candidate != null && (best == null || candidate.getTime() > best.getTime())) best = candidate;
                } catch (SecurityException ignored) { }
            }
        } catch (Throwable ignored) { }
        return best;
    }

    private static void saveLocation(Context context, Location location) {
        double lat = location.getLatitude(), lon = location.getLongitude();
        if (!valid(lat, lon)) return;
        prefs(context).edit()
                .putBoolean("configured", true)
                .putFloat("latitude", (float) lat)
                .putFloat("longitude", (float) lon)
                .putString("name", "Current location")
                .putString("timezone", TimeZone.getDefault().getID())
                .putLong("location_updated", System.currentTimeMillis())
                .apply();
    }

    /** Current device position followed by any manual coordinates already saved by the HTC widget. */
    static List<BreezyWeather.Place> places(Context context) {
        List<BreezyWeather.Place> out = new ArrayList<>();
        if (hasCurrentLocation(context)) {
            BreezyWeather.Place current = new BreezyWeather.Place();
            current.id = "device-current";
            current.name = prefs(context).getString("name", "Current location");
            current.state = "";
            current.country = "";
            current.lat = prefs(context).getFloat("latitude", 0f);
            current.lon = prefs(context).getFloat("longitude", 0f);
            current.timezone = prefs(context).getString("timezone", TimeZone.getDefault().getID());
            current.current = true;
            out.add(current);
        }

        // Preserve hand-entered city locations from existing installations; weather is fetched by coordinates.
        try {
            JSONArray rows = new JSONArray(context.getSharedPreferences("openmeteo_weather", 0)
                    .getString("locations", "[]"));
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                double lat = number(row.optString("latitude", "NaN"), Double.NaN);
                double lon = number(row.optString("longitude", "NaN"), Double.NaN);
                if (!valid(lat, lon)) {
                    String code = row.optString("code", "");
                    int comma = code.indexOf(',');
                    if (comma > 0) {
                        lat = number(code.substring(0, comma), Double.NaN);
                        lon = number(code.substring(comma + 1), Double.NaN);
                    }
                }
                if (!valid(lat, lon) || contains(out, lat, lon)) continue;
                BreezyWeather.Place p = new BreezyWeather.Place();
                p.id = "saved-" + coordKey(lat, lon);
                p.name = row.optString("name", "Saved location");
                p.state = row.optString("state", "");
                p.country = row.optString("country", "");
                p.lat = lat;
                p.lon = lon;
                p.timezone = row.optString("timezone", "");
                if (p.timezone.isEmpty()) p.timezone = row.optString("timezoneId", TimeZone.getDefault().getID());
                if (p.timezone.isEmpty()) p.timezone = TimeZone.getDefault().getID();
                p.current = "1".equals(row.optString("type", "2"))
                        && "cur".equals(row.optString("code", "")) && !hasCurrentLocation(context);
                out.add(p);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private static boolean contains(List<BreezyWeather.Place> places, double lat, double lon) {
        for (BreezyWeather.Place p : places) {
            if (Math.abs(p.lat - lat) < 0.0002 && Math.abs(p.lon - lon) < 0.0002) return true;
        }
        return false;
    }

    /** Fetches Open-Meteo and adapts its JSON to the shape already consumed by BreezyWeather.toRow(). */
    static JSONObject weather(Context context, BreezyWeather.Place place) {
        String key = "weather_" + coordKey(place.lat, place.lon);
        long now = System.currentTimeMillis();
        String cached = prefs(context).getString(key, null);
        long cachedAt = prefs(context).getLong(key + "_at", 0L);
        if (cached != null && now - cachedAt >= 0 && now - cachedAt < WEATHER_CACHE_MS) {
            try { return new JSONObject(cached); } catch (JSONException ignored) { }
        }

        HttpURLConnection connection = null;
        try {
            String url = "https://api.open-meteo.com/v1/forecast?latitude=" + place.lat
                    + "&longitude=" + place.lon
                    + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m,visibility"
                    + "&hourly=temperature_2m,apparent_temperature,precipitation_probability,weather_code,is_day"
                    + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max"
                    + "&forecast_days=7&timezone=auto&timeformat=unixtime&wind_speed_unit=mph";
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(8_000);
            connection.setReadTimeout(10_000);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "HTC-WeatherClock-OneUI/1.3");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new java.io.IOException("HTTP " + status);
            String body = readAll(connection.getInputStream());
            JSONObject api = new JSONObject(body);
            JSONObject adapted = adapt(api, place, now);
            if (adapted != null) {
                prefs(context).edit().putString(key, adapted.toString()).putLong(key + "_at", now).apply();
                String tz = api.optString("timezone", place.timezone);
                if (tz != null && !tz.isEmpty()) {
                    place.timezone = tz;
                    if (place.current) {
                        prefs(context).edit().putString("timezone", tz).apply();
                        BreezyWeather.rememberSunPlace(context, place);
                    }
                }
                return adapted;
            }
            throw new JSONException("Open-Meteo response did not contain current weather");
        } catch (Throwable t) {
            // Never log coordinates; keep the last successful response available while offline.
            Log.w(TAG, "weather refresh failed: " + t.getClass().getSimpleName());
            if (cached != null) {
                try { return new JSONObject(cached); } catch (JSONException ignored) { }
            }
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static JSONObject adapt(JSONObject api, BreezyWeather.Place place, long refreshed) throws JSONException {
        JSONObject raw = api.optJSONObject("current");
        if (raw == null || !raw.has("temperature_2m")) return null;
        JSONObject out = new JSONObject();
        double temp = raw.optDouble("temperature_2m", Double.NaN);
        if (Double.isNaN(temp)) return null;
        double apparent = raw.optDouble("apparent_temperature", temp);
        JSONObject temperature = new JSONObject()
                .put("temperature", value(temp)).put("sourceFeelsLike", value(apparent));
        JSONObject current = new JSONObject()
                .put("temperature", temperature)
                .put("relativeHumidity", value(raw.optDouble("relative_humidity_2m", 0)))
                .put("wind", new JSONObject().put("degree", raw.optDouble("wind_direction_10m", 0))
                        .put("speed", value(raw.optDouble("wind_speed_10m", 0))))
                .put("visibility", value(Math.max(0.0, raw.optDouble("visibility", 16_093.44)) / 1609.344))
                .put("weatherCode", wmo(raw.optInt("weather_code", -1)))
                .put("isDaylight", raw.optInt("is_day", 1) == 1);
        out.put("current", current).put("refreshTime", refreshed);

        JSONObject hourly = api.optJSONObject("hourly");
        JSONArray hourRows = new JSONArray();
        if (hourly != null) {
            JSONArray times = hourly.optJSONArray("time");
            JSONArray temps = hourly.optJSONArray("temperature_2m");
            JSONArray feels = hourly.optJSONArray("apparent_temperature");
            JSONArray codes = hourly.optJSONArray("weather_code");
            JSONArray days = hourly.optJSONArray("is_day");
            JSONArray rain = hourly.optJSONArray("precipitation_probability");
            for (int i = 0; times != null && i < times.length() && i < 168; i++) {
                double ht = at(temps, i, temp);
                double hf = at(feels, i, ht);
                JSONObject row = new JSONObject()
                        .put("date", (long) at(times, i, 0) * 1000L)
                        .put("weatherCode", wmo((int) at(codes, i, -1)))
                        .put("isDaylight", at(days, i, 1) == 1)
                        .put("temperature", new JSONObject().put("temperature", value(ht))
                                .put("sourceFeelsLike", value(hf)))
                        .put("precipitationProbability", new JSONObject().put("total", value(at(rain, i, 0))));
                hourRows.put(row);
            }
        }
        out.put("hourly", hourRows);

        JSONObject daily = api.optJSONObject("daily");
        JSONArray dayRows = new JSONArray();
        if (daily != null) {
            JSONArray times = daily.optJSONArray("time");
            JSONArray codes = daily.optJSONArray("weather_code");
            JSONArray highs = daily.optJSONArray("temperature_2m_max");
            JSONArray lows = daily.optJSONArray("temperature_2m_min");
            JSONArray rain = daily.optJSONArray("precipitation_probability_max");
            for (int i = 0; times != null && i < times.length() && i < 7; i++) {
                double hi = at(highs, i, temp), lo = at(lows, i, temp);
                String condition = wmo((int) at(codes, i, -1));
                double precip = at(rain, i, 0);
                JSONObject day = new JSONObject().put("weatherCode", condition)
                        .put("temperature", new JSONObject().put("temperature", value(hi)).put("sourceFeelsLike", value(hi)))
                        .put("precipitationProbability", new JSONObject().put("total", value(precip)));
                JSONObject night = new JSONObject().put("weatherCode", condition)
                        .put("temperature", new JSONObject().put("temperature", value(lo)).put("sourceFeelsLike", value(lo)))
                        .put("precipitationProbability", new JSONObject().put("total", value(precip)));
                dayRows.put(new JSONObject().put("date", (long) at(times, i, 0) * 1000L)
                        .put("day", day).put("night", night));
            }
        }
        out.put("daily", dayRows);
        out.put("alerts", new JSONArray());
        return out;
    }

    private static JSONObject value(double number) throws JSONException {
        return new JSONObject().put("value", number);
    }

    private static double at(JSONArray values, int index, double fallback) {
        if (values == null || index < 0 || index >= values.length() || values.isNull(index)) return fallback;
        return values.optDouble(index, fallback);
    }

    private static String wmo(int code) {
        switch (code) {
            case 0: return "clear";
            case 1: case 2: return "partly_cloudy";
            case 3: return "cloudy";
            case 45: case 48: return "fog";
            case 56: case 57: case 66: case 67: return "sleet";
            case 51: case 53: case 55: case 61: case 63: case 65:
            case 80: case 81: case 82: return "rain";
            case 71: case 73: case 75: case 77: case 85: case 86: return "snow";
            case 95: case 96: case 99: return "thunderstorm";
            default: return "cloudy";
        }
    }

    private static String readAll(InputStream input) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private static String coordKey(double lat, double lon) {
        return String.format(Locale.US, "%.4f_%.4f", lat, lon).replace('-', 'm').replace('.', '_');
    }

    private static boolean valid(double lat, double lon) {
        return !Double.isNaN(lat) && !Double.isNaN(lon) && !Double.isInfinite(lat) && !Double.isInfinite(lon)
                && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
    }

    private static double number(String value, double fallback) {
        try { return Double.parseDouble(value); } catch (Exception e) { return fallback; }
    }

    private static android.content.SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
