package io.wapfire.mobile.ui.screens

import io.wapfire.mobile.model.*
import io.wapfire.mobile.ui.components.*


import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.animation.animateColorAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject


@Composable
internal fun ControlCenter(
    p: Palette, fa: Boolean, dark: Boolean, tab: Tab, snapshot: Snapshot, deviceOnline: Boolean, logs: List<JSONObject>, clients: List<JSONObject>, error: String, notice: String,
    onTab: (Tab) -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit, onRefresh: () -> Unit,
    onToggle: (String, Boolean) -> Unit, targetNetworks: List<JSONObject>, targetScanBusy: Boolean, targetSelecting: Boolean,
    onTargetScan: () -> Unit, onSelectTarget: (JSONObject) -> Unit, onClearTarget: () -> Unit,
    onClearLogs: () -> Unit, onLogout: () -> Unit, onClearMessage: () -> Unit,
    advanced: AdvancedSettingsBundle, onAdvancedSave: (String, JSONObject) -> Unit,
    onAdvancedAction: (String) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onFirmwarePick: () -> Unit,
    backgroundMonitorActive: Boolean, onBackgroundMonitor: () -> Unit,
    onBatterySettings: () -> Unit
) {
    // The Assistant is an immersive workspace: Android system bars remain visible,
    // while the app toolbar and five-tab navigation are hidden until the user exits.
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            if (tab != Tab.ASSISTANT) Column(
                Modifier.fillMaxWidth()
                    // Frosted-glass header: tinted but see-through, so scrolling content shows behind it.
                    .background(Brush.verticalGradient(listOf(
                        p.bg.copy(alpha = if (dark) .84f else .88f),
                        p.bg.copy(alpha = if (dark) .46f else .52f)
                    )))
                    .drawBehind {
                        drawLine(
                            Color.White.copy(alpha = if (dark) .10f else .55f),
                            Offset(0f, size.height - 0.5f), Offset(size.width, size.height - 0.5f),
                            strokeWidth = 1f
                        )
                    }
                    .windowInsetsPadding(WindowInsets.statusBars)
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Brand(p)
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.clip(CircleShape).background(if (deviceOnline) p.accentSoft else p.panelAlt).padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(if (deviceOnline) p.green else p.orange))
                            Text(
                                if (deviceOnline) tx(fa, "LIVE", "زنده") else tx(fa, "OFFLINE", "قطع ارتباط"),
                                color = if (deviceOnline) p.text else p.orange,
                                fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp)); SmallAction(p, "↻", onRefresh)
                    Spacer(Modifier.width(6.dp)); ThemeAction(p, dark, onTheme)
                }
            }
        },
        bottomBar = {
            if (tab != Tab.ASSISTANT) Box(
                Modifier.fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                // Telegram-style floating pill: translucent glass with a soft top sheen and a thin
                // bright rim. The selected tab gets its own lighter capsule. The page scrolls behind it.
                val pill = RoundedCornerShape(32.dp)
                Row(
                    Modifier.fillMaxWidth()
                        .clip(pill)
                        .background(Brush.verticalGradient(listOf(
                            // Stronger frosted tint keeps scrolling cards from competing with tab labels.
                            // A little translucency remains so the floating glass treatment is preserved.
                            p.panel.copy(alpha = if (dark) .90f else .92f),
                            p.panel.copy(alpha = if (dark) .86f else .88f)
                        )))
                        .background(Brush.verticalGradient(listOf(
                            Color.White.copy(alpha = if (dark) .10f else .38f),
                            Color.Transparent
                        )))
                        .border(
                            1.dp,
                            Brush.verticalGradient(listOf(
                                Color.White.copy(alpha = if (dark) .34f else .85f),
                                Color.White.copy(alpha = if (dark) .06f else .22f)
                            )),
                            pill
                        )
                        .padding(5.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Every tab is the same fixed-size cell: 24dp icon slot, 3dp gap, 14dp label slot,
                    // centred as a block. Icons are drawn vectors, so icons and labels share one line.
                    Tab.values().forEach { item ->
                        val selected = tab == item
                        val tint = if (selected) p.accent else p.muted
                        val capsule by animateColorAsState(
                            if (selected) p.accent.copy(alpha = if (dark) .20f else .16f) else Color.Transparent,
                            label = "navCapsule"
                        )
                        val capsuleRim by animateColorAsState(
                            if (selected) p.accent.copy(alpha = .38f) else Color.Transparent,
                            label = "navCapsuleRim"
                        )
                        val capsuleShape = RoundedCornerShape(27.dp)
                        Column(
                            Modifier.weight(1f).height(54.dp).clip(capsuleShape)
                                .background(capsule)
                                .border(1.dp, capsuleRim, capsuleShape)
                                .clickable { onTab(item) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
                                NavigationIcon(item, tint)
                            }
                            Spacer(Modifier.height(3.dp))
                            Box(Modifier.fillMaxWidth().height(14.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    if (fa) item.fa else item.label,
                                    modifier = Modifier.fillMaxWidth(),
                                    color = tint,
                                    fontSize = 10.sp, lineHeight = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                                    overflow = TextOverflow.Clip
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        val threatIsActive = sThreatIsActive(snapshot)
        var assistantBaseState by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("idle") }
        var assistantWasOnline by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
        var assistantEventState by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
        var assistantEventSequence by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
        var detectionBaseline by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Map<String, Long>?>(null) }

        // Connection and overall risk remain the assistant's background/ambient state.
        androidx.compose.runtime.LaunchedEffect(deviceOnline, snapshot.configured, snapshot.threatLevel, snapshot.threatScore, snapshot.prom) {
            when {
                !snapshot.configured -> {
                    assistantBaseState = "setup"
                    assistantWasOnline = deviceOnline
                }
                !deviceOnline -> {
                    assistantBaseState = "connecting"
                    assistantWasOnline = false
                }
                threatIsActive -> {
                    assistantBaseState = "warning"
                    assistantWasOnline = true
                }
                !assistantWasOnline -> {
                    assistantWasOnline = true
                    assistantBaseState = "success"
                    kotlinx.coroutines.delay(2300)
                    if (deviceOnline && snapshot.configured && !threatIsActive) {
                        assistantBaseState = if (snapshot.prom.equals("ACTIVE", ignoreCase = true)) "scanning" else "idle"
                    }
                }
                else -> assistantBaseState = if (snapshot.prom.equals("ACTIVE", ignoreCase = true)) "scanning" else "idle"
            }
        }

        // Detection Breakdown values are cumulative counters. The first complete snapshot is
        // only a baseline (never replay historical detections); only later increases create reactions.
        androidx.compose.runtime.LaunchedEffect(snapshot.labels) {
            val current = snapshot.labels.associate { (name, count) -> name to count.coerceAtLeast(0L) }
            val previous = detectionBaseline
            detectionBaseline = current
            if (previous == null || previous.keys != current.keys) return@LaunchedEffect
            // A counter reset/device reboot is a new baseline, not a burst of detections.
            if (current.any { (name, count) -> count < (previous[name] ?: count) }) return@LaunchedEffect

            val increased = current.filter { (name, count) -> count > (previous[name] ?: count) }.keys
            val attackLabels = setOf(
                "Auth Attack", "Deauth Attack", "Deauth Airplay",
                "WPS Pixie Reaver", "WPS Pixie Bully", "Evil Twin"
            )
            val eventState = when {
                increased.any { it in attackLabels } -> "angry"
                "WPA Wrong Password" in increased -> "password_warning"
                "WPA Correct Password" in increased -> "password_success"
                else -> null
            }
            if (eventState != null) {
                assistantEventState = eventState
                assistantEventSequence++
            }
        }

        // Keep the event expression visible for a moment; a newer detection restarts this timer.
        androidx.compose.runtime.LaunchedEffect(assistantEventSequence) {
            if (assistantEventSequence == 0) return@LaunchedEffect
            val sequence = assistantEventSequence
            kotlinx.coroutines.delay(4200)
            if (assistantEventSequence == sequence) assistantEventState = null
        }

        val assistantState = assistantEventState ?: assistantBaseState
        // The glass bars float OVER the pages: pages receive the bar heights through LocalContentInset
        // and add them inside their scroll area, so content scrolls behind the bars and shows through.
        CompositionLocalProvider(LocalContentInset provides padding) {
            when (tab) {
                Tab.OVERVIEW -> OverviewPage(p, fa, snapshot, assistantState, Modifier)
                Tab.CLIENTS -> ClientsPage(p, fa, clients, Modifier)
                Tab.EVENTS -> EventsPage(p, fa, logs, onClearLogs, Modifier)
                Tab.ASSISTANT -> AssistantPreviewScreen(
                    p = p, fa = fa, onBack = { onTab(Tab.OVERVIEW) },
                    modifier = Modifier.padding(padding), embedded = true, state = assistantState
                )
                Tab.SETTINGS -> SettingsPage(p, fa, snapshot, onToggle, onLogout, Modifier, onLanguage, dark, onTheme,
                    targetNetworks, targetScanBusy, targetSelecting, onTargetScan, onSelectTarget, onClearTarget,
                    advanced, clients, onAdvancedSave, onAdvancedAction, onBackup, onRestore, onFirmwarePick,
                    backgroundMonitorActive, onBackgroundMonitor, onBatterySettings)
            }
        }
    }
}

@Composable
private fun NavigationIcon(tab: Tab, color: Color) {
    when (tab) {
        Tab.SETTINGS -> SettingsNavigationIcon(color)
        else -> Canvas(Modifier.size(22.dp)) {
            val w = size.width
            val h = size.height
            val stroke = 1.6.dp.toPx()
            val line = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)
            when (tab) {
                Tab.OVERVIEW -> {
                    val house = Path().apply {
                        moveTo(w * 0.12f, h * 0.50f); lineTo(w * 0.50f, h * 0.14f); lineTo(w * 0.88f, h * 0.50f)
                        moveTo(w * 0.22f, h * 0.44f); lineTo(w * 0.22f, h * 0.86f)
                        lineTo(w * 0.78f, h * 0.86f); lineTo(w * 0.78f, h * 0.44f)
                    }
                    drawPath(house, color, style = line)
                    drawLine(color, Offset(w * 0.50f, h * 0.86f), Offset(w * 0.50f, h * 0.60f), strokeWidth = stroke, cap = StrokeCap.Round)
                }
                Tab.CLIENTS -> {
                    drawCircle(color, radius = w * 0.17f, center = Offset(w * 0.50f, h * 0.31f), style = line)
                    val shoulders = Path().apply {
                        moveTo(w * 0.18f, h * 0.88f)
                        cubicTo(w * 0.18f, h * 0.56f, w * 0.82f, h * 0.56f, w * 0.82f, h * 0.88f)
                    }
                    drawPath(shoulders, color, style = line)
                }
                Tab.EVENTS -> {
                    listOf(0.26f, 0.50f, 0.74f).forEach { y ->
                        drawCircle(color, radius = stroke * 0.85f, center = Offset(w * 0.18f, h * y))
                        drawLine(color, Offset(w * 0.36f, h * y), Offset(w * 0.86f, h * y), strokeWidth = stroke, cap = StrokeCap.Round)
                    }
                }
                Tab.ASSISTANT -> {
                    val spark = Path().apply {
                        moveTo(w * 0.50f, h * 0.08f)
                        cubicTo(w * 0.50f, h * 0.50f, w * 0.50f, h * 0.50f, w * 0.92f, h * 0.50f)
                        cubicTo(w * 0.50f, h * 0.50f, w * 0.50f, h * 0.50f, w * 0.50f, h * 0.92f)
                        cubicTo(w * 0.50f, h * 0.50f, w * 0.50f, h * 0.50f, w * 0.08f, h * 0.50f)
                        cubicTo(w * 0.50f, h * 0.50f, w * 0.50f, h * 0.50f, w * 0.50f, h * 0.08f)
                        close()
                    }
                    drawPath(spark, color, style = line)
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun SettingsNavigationIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.30f
        val inner = r * 1.24f
        val outer = size.minDimension * 0.46f
        val stroke = 1.6.dp.toPx()
        for (i in 0 until 8) {
            val angle = Math.toRadians(i * 45.0)
            val start = Offset(cx + kotlin.math.cos(angle).toFloat() * inner, cy + kotlin.math.sin(angle).toFloat() * inner)
            val end = Offset(cx + kotlin.math.cos(angle).toFloat() * outer, cy + kotlin.math.sin(angle).toFloat() * outer)
            drawLine(color, start, end, strokeWidth = stroke, cap = StrokeCap.Round)
        }
        drawCircle(color, radius = r, center = Offset(cx, cy), style = Stroke(width = stroke))
        drawCircle(color, radius = r * 0.34f, center = Offset(cx, cy), style = Stroke(width = stroke))
    }
}

private fun sThreatIsActive(snapshot: Snapshot): Boolean {
    val level = snapshot.threatLevel.trim().uppercase(Locale.ROOT)
    return level in setOf("HIGH", "CRITICAL", "SEVERE", "DANGER", "ELEVATED") || snapshot.threatScore >= 7.0f
}

@Composable
internal fun OverviewPage(
    p: Palette,
    fa: Boolean,
    s: Snapshot,
    assistantState: String,
    modifier: Modifier = Modifier
) {
    // Unlike LazyColumn, this keeps the embedded WebView composed even while its card
    // is outside the visible scroll viewport, so the LivLiv model is not destroyed/reloaded.
    Column(
        modifier = modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(
                top = 14.dp + LocalContentInset.current.calculateTopPadding(),
                bottom = 18.dp + LocalContentInset.current.calculateBottomPadding()
            ),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(fa, "SYSTEM OVERVIEW", "نمای کلی سیستم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text(tx(fa, "Wireless intelligence", "هوشمندی شبکه بی‌سیم"), color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("${tx(fa, "Firmware", "فریمور")}: ${s.firmware}   ·   ${tx(fa, "Uptime", "مدت فعالیت")}: ${formatUptime(s.uptime)}", color = p.muted, fontSize = 10.sp)
        }

        LivLivAssistantOverviewCard(
            p = p,
            fa = fa,
            state = assistantState,
            modifier = Modifier.fillMaxWidth()
        )

        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xCC1C5962), Color(0xB815303C), Color(0xA81A3C4B)))).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(24.dp)).padding(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx(fa, "MONITORING STATUS", "وضعیت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        val engineStatus = when {
                            !s.configured -> tx(fa, "Setup required", "نیازمند راه‌اندازی")
                            s.selfProtectActive -> tx(fa, "Protection response active", "واکنش حفاظتی فعال است")
                            s.prom.equals("ACTIVE", ignoreCase = true) && s.selfProtect -> tx(fa, "Self-protect armed", "محافظت خودکار آماده است")
                            s.prom.equals("ACTIVE", ignoreCase = true) -> tx(fa, "Monitoring active · protection off", "پایش فعال · محافظت خودکار خاموش")
                            else -> tx(fa, "Radio monitoring inactive", "پایش رادیویی غیرفعال است")
                        }
                        Text(engineStatus, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    }
                    ThreatRing(p, s.threatScore, s.threatLevel)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2C535D)))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx(fa, "MONITORED ACCESS POINT", "اکسس‌پوینت تحت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.sp)
                        Text(s.target.ifBlank { tx(fa, "No target selected", "هدف انتخاب نشده") }, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (s.targetMac.isNotBlank()) s.targetMac else "${tx(fa, "Channel", "کانال")}: ${if (s.channel > 0) s.channel else "—"}", color = Color(0xFFA4C2C8), fontSize = 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (s.targetAvailable) tx(fa, "ONLINE", "متصل") else tx(fa, "OFFLINE", "قطع"), color = if (s.targetAvailable) Color(0xFF91F2C4) else Color(0xFFFFB86C), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(if (s.targetRssi != 0) "${s.targetRssi} dBm" else "— dBm", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tx(fa, "NETWORK TELEMETRY", "آمار شبکه"), color = p.muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${s.traffic.compact()}", tx(fa, "Traffic frames", "فریم شبکه"), "⌁", p.accent, Modifier.weight(1f))
                MetricTile(p, "${s.packets.compact()}", tx(fa, "Packets", "بسته‌ها"), "▤", p.blue, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${s.targetApRx.compact()}", tx(fa, "Target AP RX", "دریافت AP هدف"), "⇣", p.orange, Modifier.weight(1f))
                MetricTile(p, "${s.filtered.compact()}", tx(fa, "Filtered frames", "فریم فیلترشده"), "≋", p.green, Modifier.weight(1f))
            }
        }

        SectionCard(p, title = tx(fa, "RADIO ACTIVITY", "فعالیت رادیویی"), subtitle = tx(fa, "Recent receive-rate samples", "نمونه‌های اخیر نرخ دریافت")) {
            NativeLineChart(p, s.radioRates, s.targetRates, Modifier.fillMaxWidth().height(150.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LegendDot(p.accent, tx(fa, "Radio RX", "دریافت رادیو"), p)
                LegendDot(p.blue, tx(fa, "Target AP", "اکسس‌پوینت هدف"), p)
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                MiniValue(p, "${s.wifiChannel}", tx(fa, "Wi-Fi channel", "کانال Wi-Fi"))
                MiniValue(p, s.prom, tx(fa, "Promiscuous", "حالت شنود"))
                MiniValue(p, "${s.dropped}", tx(fa, "Dropped", "از دست‌رفته"))
            }
        }

        SectionCard(p, title = tx(fa, "DETECTION BREAKDOWN", "دسته‌بندی تشخیص‌ها"), subtitle = tx(fa, "Labels reported by the firmware", "برچسب‌های گزارش‌شده توسط فریمور")) {
            Text(tx(fa, "All eight firmware detection classes are shown. Counts are cumulative since the device counters were initialized.", "هر هشت دسته تشخیص فریم‌ور نمایش داده شده‌اند. شمارنده‌ها از زمان مقداردهی اولیه دستگاه محاسبه می‌شوند."), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
            s.labels.forEach { (name, count) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = p.text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(count.toString(), color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        SectionCard(p, title = tx(fa, "LAST DETECTION", "آخرین تشخیص"), subtitle = if (s.lastEvent.isBlank()) tx(fa, "No recent event", "رویداد تازه‌ای نیست") else s.lastEvent) {
            Text(if (s.lastAttack.isBlank()) tx(fa, "The device has not reported an active attack label.", "دستگاه برچسب حمله فعالی گزارش نکرده است.") else s.lastAttack, color = p.text, fontSize = 13.sp)
            Text("${tx(fa, "Filtered", "فیلترشده")}: ${s.filtered}   ·   ${tx(fa, "Dropped", "از دست‌رفته")}: ${s.dropped}", color = p.muted, fontSize = 10.sp)
        }
    }
}

@Composable
internal fun ClientsPage(p: Palette, fa: Boolean, clients: List<JSONObject>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp + LocalContentInset.current.calculateTopPadding(), bottom = 20.dp + LocalContentInset.current.calculateBottomPadding())) {
        item {
            Text(tx(fa, "CLIENT INTELLIGENCE", "اطلاعات کلاینت‌ها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Tracked stations", "ایستگاه‌های ردگیری‌شده"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${clients.size} ${tx(fa, "observations", "مشاهده")}", color = p.muted, fontSize = 12.sp)
        }
        if (clients.isEmpty()) item { SectionCard(p, title = tx(fa, "NO CLIENT DATA", "داده‌ای وجود ندارد"), subtitle = tx(fa, "Clients appear as they are observed by the radio.", "کلاینت‌ها پس از مشاهده توسط رادیو نمایش داده می‌شوند.")) { Text(tx(fa, "Keep monitoring active and refresh this page.", "پایش را فعال نگه دار و صفحه را تازه‌سازی کن."), color = p.muted, fontSize = 12.sp) } }
        items(clients) { client ->
            SectionCard(p, title = client.optString("mac", "Unknown station"), subtitle = client.optString("state", "UNKNOWN")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${client.optInt("rssi")} dBm  ·  ${client.optInt("age_sec")}s ${tx(fa, "ago", "قبل")}", color = p.muted, fontSize = 11.sp)
                        Text(client.optString("bssid").ifBlank { tx(fa, "BSSID unavailable", "BSSID موجود نیست") }, color = p.muted, fontSize = 10.sp)
                    }
                    Text(if (client.optString("state").contains("DISCONNECT")) "!" else "•", color = if (client.optString("state").contains("DISCONNECT")) p.orange else p.green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                if (client.optInt("reason_code") != 0) Text("${tx(fa, "Reason", "دلیل")}: ${client.optInt("reason_code")} · ${client.optString("reason_text")}", color = p.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
internal fun EventsPage(p: Palette, fa: Boolean, logs: List<JSONObject>, onClear: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp + LocalContentInset.current.calculateTopPadding(), bottom = 20.dp + LocalContentInset.current.calculateBottomPadding())) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tx(fa, "EVENT TIMELINE", "خط زمانی رویدادها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Device activity", "فعالیت دستگاه"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${logs.size} ${tx(fa, "records", "رکورد")}", color = p.muted, fontSize = 12.sp)
                }
                ActionButton(p, tx(fa, "Clear", "پاک‌کردن"), onClear)
            }
        }
        if (logs.isEmpty()) item {
            val emptyShape = RoundedCornerShape(18.dp)
            Column(Modifier.fillMaxWidth().shadow(7.dp, emptyShape).clip(emptyShape)
                .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
                .border(1.dp, p.border, emptyShape).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(tx(fa, "NO EVENTS", "رویدادی وجود ندارد"), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(tx(fa, "The device event log is currently empty.", "گزارش رویداد دستگاه خالی است."), color = p.muted, fontSize = 10.sp)
                Text(tx(fa, "New detections and system messages will appear here.", "تشخیص‌های جدید و پیام‌های سیستم اینجا نمایش داده می‌شوند."), color = p.text, fontSize = 12.sp)
            }
        }
        items(logs) { event ->
            val type = event.optString("event_type", "system").lowercase()
            val title = eventDisplayName(event)
            val isThreat = type == "attack" || friendlyThreatName(type) != null ||
                friendlyThreatName(event.optString("message")) != null || friendlyThreatName(event.optString("details")) != null
            val isCredential = type == "wrong_password" || type == "correct_password"
            val badge = when {
                isCredential -> "CREDENTIAL"
                isThreat -> "THREAT"
                type == "attempt" -> "ATTEMPT"
                type == "disconnect" -> "DISCONNECT"
                type == "system" -> "SYSTEM"
                else -> "DEVICE"
            }
            val color = when {
                type == "wrong_password" -> p.orange
                type == "correct_password" -> p.green
                type == "disconnect" -> p.blue
                type == "attempt" -> p.orange
                isThreat -> p.red
                else -> p.accent
            }
            Row(Modifier.fillMaxWidth().shadow(9.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
                .border(1.dp, p.border, RoundedCornerShape(18.dp))
                .padding(14.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Box(Modifier.width(3.dp).height(52.dp).clip(CircleShape).background(color))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(badge, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(event.optString("formatted_time", ""), color = p.muted, fontSize = 10.sp)
                    val message = event.optString("message", "")
                    val details = event.optString("details", "")
                    if (details.isNotBlank()) Text(friendlyTechnicalText(details), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                    else if (message.isNotBlank() && friendlyThreatName(message) == null && type !in listOf("correct_password", "wrong_password")) Text(message, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}
