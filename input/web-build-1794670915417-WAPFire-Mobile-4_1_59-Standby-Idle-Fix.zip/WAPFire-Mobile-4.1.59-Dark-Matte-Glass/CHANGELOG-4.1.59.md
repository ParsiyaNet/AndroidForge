# 4.1.59 — Correct WAPFire Standby vs normal Idle

- Removed the incorrect assumption that `beacon_mode == false` means WAPFire Standby. Beacon Response is a separate radio feature.
- Android now uses the existing `/api/status` field `packet_inactivity_ms`, matching the firmware WebUI rule exactly: configured target + target available + more than 60,000 ms without packet activity means Standby.
- Normal operation resolves to the LivLiv `idle` state (`setAway(false)`); the model's native idle driver continues natural movement and blinks.
- Only the actual Standby state uses `setAway(true)` (closed-eye Away pose).
- No firmware change is required: the uploaded WAPFire firmware already emits `packet_inactivity_ms`. The `beacon_mode` API field remains available for the separate Beacon Response setting.
- The threshold is derived as a boolean effect key so regularly increasing telemetry does not restart/cancel the connection-success timer.
