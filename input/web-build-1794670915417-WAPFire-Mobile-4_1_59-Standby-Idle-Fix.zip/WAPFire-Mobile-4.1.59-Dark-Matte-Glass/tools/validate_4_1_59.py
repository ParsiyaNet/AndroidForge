#!/usr/bin/env python3
"""Source-level checks for WAPFire 4.1.59 Standby/Idle state mapping."""
from pathlib import Path
import json, re, zipfile
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets/assistant"
JS = (ASSETS / "assistant-preflight-4.1.59.js").read_text(encoding="utf-8")
HTML = (ASSETS / "assistant-live.html").read_text(encoding="utf-8")
MODELS = (ROOT / "app/src/main/java/io/wapfire/mobile/model/AppModels.kt").read_text(encoding="utf-8")
APP = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt").read_text(encoding="utf-8")
DASH = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt").read_text(encoding="utf-8")
VIEW = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
MODEL = ASSETS / "characters/v03.livliv"
with zipfile.ZipFile(MODEL) as z:
    model = json.loads(z.read("model.json"))
expr_ids = {e["id"] for e in model["expressions"]}

assert "packet_inactivity_ms" in MODELS and "packetInactivityMs: Long? = null" in MODELS
assert 'status.has("packet_inactivity_ms")' in MODELS
assert "packetInactivityMs = updated.packetInactivityMs ?: snapshot.packetInactivityMs" in APP
assert "snapshot.packetInactivityMs ?: 0L" in DASH
assert "> 60_000L" in DASH
assert "snapshot.targetAvailable" in DASH and "targetSelected" in DASH
assert "snapshot.beaconMode" not in DASH, "Beacon Response must not decide Standby"
assert "assistantStandby" in DASH
assert "assistantBaseState = \"standby\"" in DASH
assert 'else -> "idle"' in DASH
assert re.search(r'idle:\s*\{.*?expr:null,\s*away:false', JS, re.S)
assert re.search(r'standby:\s*\{.*?expr:null,\s*away:true', JS, re.S)
assert "player.setAway(row.away === true);" in JS
assert "setAway(false)" in JS or "away:false" in JS
assert "window.__wfAssistantBuildVersion = '4.1.59';" in JS
assert 'assistant-preflight-4.1.59.js?build=4.1.59' in HTML
assert 'content="4.1.59"' in HTML
assert 'assistant/assistant-preflight-4.1.59.js' in VIEW
assert 'ASSISTANT_BUILD = "4.1.59"' in VIEW
assert 'versionCode = 105' in GRADLE and 'versionName = "4.1.59"' in GRADLE
for required in ('smile', 'x_expr_03637e', 'x_expr_0cfa09', 'x_expr_7d048e'):
    assert required in expr_ids, f"model missing expression {required}"
for state in ('target_offline', 'angry', 'password_warning', 'password_success', 'connecting', 'warning'):
    assert re.search(rf'{state}:\s*\{{', JS), f'missing reaction {state}'
assert 'assistantEventSequence++' in DASH
print('PASS: firmware telemetry packet_inactivity_ms parsed and cached')
print('PASS: WAPFire Standby matches WebUI rule (>60 seconds, configured target, target available)')
print('PASS: beacon_mode no longer controls character state')
print('PASS: normal Idle releases Away; only Standby applies Away')
print('PASS: renderer build metadata and Android app versions are aligned at 4.1.59')
print('PASS: model expression IDs and existing attack/password/target-offline reactions remain available')
