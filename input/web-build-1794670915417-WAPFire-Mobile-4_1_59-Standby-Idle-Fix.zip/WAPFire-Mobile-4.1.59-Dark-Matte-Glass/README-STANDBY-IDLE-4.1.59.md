# WAPFire Mobile 4.1.59 — Standby / Idle correction

Normal network operation is LivLiv `idle` with the Away pose released. WAPFire Standby is a different state: the configured target AP must be available and `packet_inactivity_ms` must exceed 60,000 ms, matching the firmware WebUI's existing rule. Only then does Nara enter the closed-eye Away pose.

The Beacon Response preference (`beacon_mode`) is separate and does not select the assistant pose. The existing target-offline, attack and password reactions are preserved.

`packet_inactivity_ms` is already part of `/api/status`; this correction does not require a firmware reflash.

Run `python tools/validate_4_1_59.py` for source-contract checks. Build the Android app with Android Studio or `gradlew.bat assembleDebug`.
