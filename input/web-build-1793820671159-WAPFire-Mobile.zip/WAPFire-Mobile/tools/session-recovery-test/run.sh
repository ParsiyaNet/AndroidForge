#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
KOTLIN_BIN="$(command -v kotlinc || true)"
if [[ -z "$KOTLIN_BIN" ]]; then
  echo "kotlinc is required" >&2
  exit 2
fi
KOTLIN_HOME="$(cd "$(dirname "$KOTLIN_BIN")/.." && pwd)"
COROUTINES="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
if [[ ! -f "$COROUTINES" ]]; then
  echo "kotlinx-coroutines-core-jvm.jar was not found under $KOTLIN_HOME/lib" >&2
  exit 2
fi
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/app/src/main/java/io/wapfire/mobile/network/WapFireApi.kt" \
  "$ROOT/app/src/main/java/io/wapfire/mobile/network/WapFireSessionManager.kt" \
  "$ROOT/tools/session-recovery-test/stubs/org/json/JSONObject.kt" \
  "$ROOT/tools/session-recovery-test/SessionRecoveryIntegrationTest.kt" \
  -classpath "$COROUTINES" -d "$OUT"
kotlin -classpath "$OUT:$COROUTINES" SessionRecoveryIntegrationTestKt
