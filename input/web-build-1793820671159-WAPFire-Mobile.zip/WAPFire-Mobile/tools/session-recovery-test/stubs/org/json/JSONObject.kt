package org.json
class JSONObject {
    constructor()
    constructor(source: String)
    fun optString(name: String): String = ""
    fun optString(name: String, fallback: String): String = fallback
    fun optBoolean(name: String, fallback: Boolean = false): Boolean = fallback
    fun has(name: String): Boolean = false
    fun put(name: String, value: Any?): JSONObject = this
}
class JSONArray {
    constructor()
    constructor(source: String)
    fun length(): Int = 0
    fun optJSONObject(index: Int): JSONObject? = null
}
