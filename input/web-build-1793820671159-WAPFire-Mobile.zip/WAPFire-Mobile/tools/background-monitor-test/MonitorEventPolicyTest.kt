package io.wapfire.mobile.monitor

import org.json.JSONObject

fun main() {
    fun event(type: String, message: String = "", details: String = "", time: String = "18:00:00") =
        JSONObject(mapOf("event_type" to type, "message" to message, "details" to details, "formatted_time" to time))

    val deauth = event("attack", "Deauth Attack", "AP disconnect flood")
    val reaver = event("system", "WPS Pixie Reaver", "Repeated WPS exchange")
    val evilTwin = event("evil_twin", "Rogue AP detected")
    val wrongPassword = event("wrong_password", "WPA Wrong Password")
    val deauthAirplay = event("deauth_airplay", "Deauth Airplay")
    val authAttack = event("auth_attack", "Authentication attack")
    val correctPassword = event("correct_password", "WPA Correct Password")
    val disconnect = event("disconnect", "Client disconnected")

    check(MonitorEventPolicy.isSecurityEvent(deauth))
    check(MonitorEventPolicy.isSecurityEvent(reaver))
    check(MonitorEventPolicy.isSecurityEvent(evilTwin))
    check(MonitorEventPolicy.isSecurityEvent(wrongPassword))
    check(MonitorEventPolicy.isSecurityEvent(deauthAirplay))
    check(MonitorEventPolicy.isSecurityEvent(authAttack))
    check(!MonitorEventPolicy.isSecurityEvent(correctPassword))
    check(!MonitorEventPolicy.isSecurityEvent(disconnect))
    check(MonitorEventPolicy.signature(deauth) == MonitorEventPolicy.signature(deauth))
    check(MonitorEventPolicy.signature(deauth) != MonitorEventPolicy.signature(event("attack", "Deauth Attack", "AP disconnect flood", "18:00:05")))
    val reusedIdOld = JSONObject(mapOf("id" to "7", "event_type" to "attack", "formatted_time" to "18:00:00", "message" to "Deauth"))
    val reusedIdNew = JSONObject(mapOf("id" to "7", "event_type" to "attack", "formatted_time" to "18:10:00", "message" to "Deauth"))
    check(MonitorEventPolicy.signature(reusedIdOld) != MonitorEventPolicy.signature(reusedIdNew))
    check(MonitorEventPolicy.title(reaver).contains("WPS Pixie Reaver"))
    check(MonitorEventPolicy.title(deauthAirplay).contains("Deauth Airplay"))

    println("PASS: attack types classified; benign events ignored; signatures stable and timestamp-sensitive")
}
