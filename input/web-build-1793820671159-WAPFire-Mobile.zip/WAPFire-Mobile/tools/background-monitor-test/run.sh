#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
KOTLIN_BIN="$(command -v kotlinc || true)"
if [[ -z "$KOTLIN_BIN" ]]; then
  echo "kotlinc is required" >&2
  exit 2
fi
KOTLIN_HOME="$(cd "$(dirname "$KOTLIN_BIN")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/tools/background-monitor-test/stubs/org/json/JSONObject.kt" \
  "$ROOT/app/src/main/java/io/wapfire/mobile/monitor/MonitorEventPolicy.kt" \
  "$ROOT/tools/background-monitor-test/MonitorEventPolicyTest.kt" \
  -d "$OUT"
kotlin -classpath "$OUT" io.wapfire.mobile.monitor.MonitorEventPolicyTestKt
