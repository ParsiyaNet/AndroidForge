package org.json

class JSONObject(private val values: Map<String, String>) {
    fun optString(key: String): String = values[key].orEmpty()
    override fun toString(): String = values.toSortedMap().toString()
}
