package io.wapfire.mobile.ui.screens

import io.wapfire.mobile.model.*
import io.wapfire.mobile.network.*
import io.wapfire.mobile.ui.components.*


import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject


@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun DiscoveryScreen(
    p: Palette, fa: Boolean, dark: Boolean, host: String, onHost: (String) -> Unit,
    current: CurrentWifi, networks: List<WifiAccessPoint>, lan: List<String>, scanning: Boolean, connecting: Boolean,
    selectedSsid: String, selectedBssid: String, wifiPassword: String, onWifiPassword: (String) -> Unit, error: String, notice: String,
    onTheme: () -> Unit, onLanguage: () -> Unit, onScan: () -> Unit,
    onSelectWifi: (WifiAccessPoint) -> Unit, onConnect: (WifiAccessPoint) -> Unit,
    onUseLan: (String) -> Unit, onUseCurrent: () -> Unit, onManual: () -> Unit, onChangeWifiSelection: () -> Unit
) {
    val selectedAp = networks.firstOrNull { it.bssid.equals(selectedBssid, ignoreCase = true) }
    val passwordFocusRequester = remember { FocusRequester() }
    val passwordBringIntoViewRequester = remember { BringIntoViewRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(selectedBssid, selectedAp?.bssid) {
        if (selectedAp != null) {
            // Let the selected-network card enter composition before requesting visibility/focus.
            delay(180)
            passwordBringIntoViewRequester.bringIntoView()
            if (selectedAp.secured && !selectedAp.isCurrentConnection) {
                passwordFocusRequester.requestFocus()
                keyboardController?.show()
            } else {
                keyboardController?.hide()
            }
        } else {
            keyboardController?.hide()
        }
    }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand(p)
            Spacer(Modifier.weight(1f))
            SmallAction(p, if (fa) "EN" else "FA", onLanguage)
            Spacer(Modifier.width(8.dp)); ThemeAction(p, dark, onTheme)
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(fa, "YOUR WIRELESS SECURITY HUB", "مرکز امنیت شبکه بی‌سیم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("WAPFire", color = p.text, fontSize = 42.sp, lineHeight = 46.sp, fontWeight = FontWeight.ExtraBold)
            Text(tx(fa, "A native control app for discovery, monitoring and device configuration.", "اپلیکیشن مستقل برای پیدا کردن دستگاه، پایش زنده و مدیریت تنظیمات."), color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        SectionCard(
            p,
            title = tx(fa, "CURRENT NETWORK", "شبکه فعلی"),
            subtitle = current.ssid.ifBlank {
                if (current.connected) tx(fa, "Wi-Fi connection detected", "اتصال Wi-Fi برقرار است")
                else tx(fa, "No Wi-Fi connection detected", "اتصال Wi-Fi شناسایی نشد")
            }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("IP  ${current.localIp.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                    Text("Gateway  ${current.gateway.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                    Text("BSSID  ${current.bssid.ifBlank { "—" }}", color = p.muted, fontSize = 10.sp)
                }
                ActionButton(p, tx(fa, "Use network", "استفاده"), onUseCurrent, primary = true)
            }
        }
        SectionCard(p, title = tx(fa, "DEVICE DISCOVERY", "پیدا کردن دستگاه"), subtitle = tx(fa, "Find WAPFire devices by their hardware BSSID signature. SSID names can change.", "دستگاه‌های WAPFire با شناسه سخت‌افزاری BSSID پیدا می‌شوند؛ نام Wi-Fi می‌تواند تغییر کند.")) {
            if (selectedAp == null) {
                ActionButton(p, if (scanning) tx(fa, "Scanning…", "در حال جستجو…") else tx(fa, "Scan nearby devices", "جستجوی دستگاه‌ها"), onScan, enabled = !scanning, primary = true, modifier = Modifier.fillMaxWidth())
                if (scanning) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = p.accent, strokeWidth = 2.dp)
                    Text(tx(fa, "Looking for WAPFire…", "در حال جستجوی WAPFire…"), color = p.muted, fontSize = 12.sp)
                }
                lan.forEach { ip -> DeviceResult(p, "WAPFire device", ip, "LAN DEVICE", onClick = { onUseLan(ip) }, action = tx(fa, "Connect", "اتصال")) }
                networks.sortedByDescending { it.isWapFire }.forEach { ap ->
                    val label = tx(fa, "WAPFIRE DEVICE", "دستگاه WAPFire")
                    val security = when (ap.securityMode) {
                        "WPA2_WPA3" -> "WPA2/WPA3"
                        else -> ap.securityMode
                    }
                    DeviceResult(p, ap.ssid, "${ap.bssid}  ·  Ch ${((ap.frequency - 2407) / 5).coerceAtLeast(1)}  ·  ${ap.rssi} dBm  ·  $security", label,
                        onClick = { onSelectWifi(ap) }, action = tx(fa, "Select", "انتخاب"))
                }
                if (networks.isEmpty() && lan.isEmpty() && !scanning) Text(tx(fa, "No WAPFire devices found. Make sure the WAPFire SoftAP is enabled and try again, or enter its IP manually.", "هیچ دستگاه WAPFire پیدا نشد. مطمئن شو SoftAP دستگاه روشن است و دوباره تلاش کن؛ یا IP را دستی وارد کن."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
            } else {
                val security = if (selectedAp.secured) selectedAp.securityMode else tx(fa, "Open network", "شبکه بدون رمز")
                DeviceResult(
                    p, selectedAp.ssid, "${selectedAp.bssid}  ·  ${selectedAp.rssi} dBm  ·  $security",
                    tx(fa, "SELECTED WI-FI", "شبکه انتخاب‌شده"), onClick = {}, action = "", selected = true, enabled = false
                )
                ActionButton(p, tx(fa, "Choose another network", "انتخاب شبکه دیگر"), onChangeWifiSelection,
                    enabled = !connecting, modifier = Modifier.fillMaxWidth())
            }
        }
        if (selectedSsid.isNotBlank() && selectedAp != null) {
            Box(Modifier.fillMaxWidth().bringIntoViewRequester(passwordBringIntoViewRequester)) {
                SectionCard(p, title = tx(fa, "CONNECT TO SELECTED WI-FI", "اتصال به شبکه انتخاب‌شده"), subtitle = "$selectedSsid  ·  $selectedBssid") {
                    if (selectedAp.secured && !selectedAp.isCurrentConnection) NativeField(
                        p, wifiPassword, onWifiPassword, tx(fa, "Network password", "رمز Wi-Fi"), password = true,
                        focusRequester = passwordFocusRequester
                    )
                    Text(
                        if (selectedAp.isCurrentConnection)
                            tx(fa, "Already connected to this WAPFire access point. Continue to its WebUI.", "همین حالا به این اکسس‌پوینت WAPFire متصل هستی؛ وارد WebUI شو.")
                        else tx(fa, "Security: ${selectedAp.securityMode}. Android may ask you to approve the local Wi-Fi connection.", "امنیت: ${selectedAp.securityMode}. ممکن است اندروید برای اتصال محلی Wi-Fi تأیید بخواهد."),
                        color = p.muted, fontSize = 10.sp, lineHeight = 15.sp
                    )
                    ActionButton(
                        p,
                        if (connecting) tx(fa, "Joining WAPFire…", "در حال اتصال به WAPFire…")
                        else if (selectedAp.isCurrentConnection) tx(fa, "Open WAPFire", "باز کردن WAPFire")
                        else tx(fa, "Connect to WAPFire", "اتصال به WAPFire"),
                        { onConnect(selectedAp) },
                        enabled = !connecting && (selectedAp.isCurrentConnection || !selectedAp.secured || wifiPassword.length in 8..63),
                        primary = true, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        SectionCard(p, title = tx(fa, "MANUAL DEVICE ADDRESS", "نشانی دستی دستگاه"), subtitle = tx(fa, "For Ethernet, custom subnets or a fixed IP.", "برای Ethernet، زیرشبکه سفارشی یا IP ثابت.")) {
            NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri)
            ActionButton(p, tx(fa, "Continue to sign in", "ادامه و ورود"), onManual, primary = true, modifier = Modifier.fillMaxWidth())
        }
        Text("WAPFIRE MOBILE  ·  NATIVE ANDROID", color = p.muted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp))
    }
}

@Composable
internal fun LoginScreen(
    p: Palette, fa: Boolean, dark: Boolean, host: String, onHost: (String) -> Unit, username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, rememberPassword: Boolean, onRememberPassword: (Boolean) -> Unit,
    busy: Boolean, error: String, notice: String,
    onBack: () -> Unit, onLogin: () -> Unit, onClear: () -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit
) {
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallAction(p, "‹", onBack); Spacer(Modifier.width(12.dp)); Brand(p); Spacer(Modifier.weight(1f)); SmallAction(p, if (fa) "EN" else "FA", onLanguage); Spacer(Modifier.width(7.dp)); ThemeAction(p, dark, onTheme)
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.size(74.dp).clip(RoundedCornerShape(24.dp)).background(p.accentSoft).border(1.dp, p.border, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Text("⌑", color = p.accent, fontSize = 40.sp, fontWeight = FontWeight.Light)
            }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(tx(fa, "AUTHENTICATION", "احراز هویت"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(tx(fa, "Welcome back.", "خوش برگشتی."), color = p.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(tx(fa, "Sign in to your WAPFire device.", "برای ورود به دستگاه WAPFire اطلاعات حساب را وارد کن."), color = p.muted, fontSize = 13.sp)
            }
            SectionCard(p, title = tx(fa, "DEVICE", "دستگاه"), subtitle = host) { NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri) }
            SectionCard(p, title = tx(fa, "ADMINISTRATOR ACCESS", "دسترسی مدیر"), subtitle = tx(fa, "Your device credentials", "اطلاعات ورود دستگاه")) {
                NativeField(p, username, onUsername, tx(fa, "Username", "نام کاربری"))
                NativeField(p, password, onPassword, tx(fa, "Password", "رمز عبور"), password = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Checkbox(
                        checked = rememberPassword,
                        onCheckedChange = onRememberPassword,
                        colors = CheckboxDefaults.colors(checkedColor = p.accent, uncheckedColor = p.muted)
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(tx(fa, "Remember password", "ذخیره رمز عبور"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(tx(fa, "Encrypted on this phone using Android Keystore.", "رمز روی همین گوشی با Android Keystore رمزنگاری می‌شود."), color = p.muted, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
                ActionButton(p, if (busy) tx(fa, "Authenticating…", "در حال بررسی…") else tx(fa, "Sign in", "ورود امن"), onLogin, enabled = !busy, primary = true, modifier = Modifier.fillMaxWidth())
                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
            }
            Text(tx(fa, "Credentials are sent directly to the device on your local network.", "اطلاعات ورود مستقیماً و فقط در شبکه محلی به دستگاه ارسال می‌شود."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
internal fun FirstSetupScreen(
    p: Palette, fa: Boolean, dark: Boolean, onTheme: () -> Unit, onLanguage: () -> Unit,
    step: Int, onStep: (Int) -> Unit,
    apSsid: String, onApSsid: (String) -> Unit, apPass: String, onApPass: (String) -> Unit,
    adminPass: String, onAdminPass: (String) -> Unit,
    led: Boolean, onLed: (Boolean) -> Unit, sound: Boolean, onSound: (Boolean) -> Unit,
    autoChannel: Boolean, onAutoChannel: (Boolean) -> Unit, selfProtect: Boolean, onSelfProtect: (Boolean) -> Unit,
    softAp: Boolean, onSoftAp: (Boolean) -> Unit,
    targetNetworks: List<JSONObject>, target: JSONObject?, targetScanning: Boolean, targetSelecting: Boolean,
    onTargetScan: () -> Unit, onTargetSelect: (JSONObject) -> Unit, onChangeTarget: () -> Unit, onRestore: () -> Unit,
    saving: Boolean, snapshot: Snapshot, error: String, notice: String,
    onFinish: () -> Unit, onClear: () -> Unit, onLogout: () -> Unit
) {
    var validationError by remember(step) { mutableStateOf("") }
    val selectedTargetBssid = target?.optString("bssid").orEmpty().trim()
    val visibleTargetNetworks = if (target == null) targetNetworks else
        targetNetworks.filter { it.optString("bssid").trim().equals(selectedTargetBssid, ignoreCase = true) }
    val stepTitles = listOf(
        tx(fa, "Welcome", "خوش‌آمدگویی"),
        tx(fa, "Access Point", "اکسس‌پوینت"),
        tx(fa, "Target Network", "شبکه هدف"),
        tx(fa, "Advanced Options", "تنظیمات پیشرفته"),
        tx(fa, "Final Review", "بازبینی نهایی")
    )
    fun nextStep() {
        validationError = ""
        when (step) {
            1 -> when {
                apSsid.isBlank() || apSsid.toByteArray(Charsets.UTF_8).size !in 1..32 -> validationError = tx(fa, "Access point SSID must be 1–32 UTF-8 bytes.", "نام شبکه باید بین ۱ تا ۳۲ بایت UTF-8 باشد.")
                apPass.length !in 8..63 -> validationError = tx(fa, "WPA2/WPA3 access point password must be 8–63 characters.", "رمز WPA2/WPA3 باید بین ۸ تا ۶۳ نویسه باشد.")
                apPass.any { it.code !in 0x20..0x7E } -> validationError = tx(fa, "Use printable ASCII characters for the Wi-Fi password so Android can reconnect using WPA2/WPA3.", "برای اینکه اندروید بتواند با WPA2/WPA3 دوباره وصل شود، رمز Wi-Fi را با نویسه‌های ASCII قابل‌چاپ وارد کن.")
                adminPass.length !in 8..64 -> validationError = tx(fa, "Administrator password must be 8–64 characters.", "رمز مدیر باید بین ۸ تا ۶۴ نویسه باشد.")
            }
            2 -> if (target == null || target.optString("ssid").isBlank() || target.optString("bssid").isBlank() || target.optInt("channel") !in 1..13) {
                validationError = tx(fa, "Scan and select a valid target network before continuing.", "برای ادامه یک شبکه هدف معتبر اسکن و انتخاب کن.")
            }
        }
        if (validationError.isBlank()) onStep((step + 1).coerceAtMost(4))
    }

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand(p)
            Spacer(Modifier.weight(1f))
            SmallAction(p, if (fa) "EN" else "FA", onLanguage)
            Spacer(Modifier.width(8.dp))
            ThemeAction(p, dark, onTheme)
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onLogout) { Text(tx(fa, "Disconnect", "قطع اتصال"), color = p.muted) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(fa, "WAPFIRE CONFIGURATION", "پیکربندی WAPFIRE"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text(tx(fa, "Initial Setup", "راه‌اندازی اولیه"), color = p.text, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("${tx(fa, "STEP", "مرحله")} ${step + 1} / 5  ·  ${stepTitles[step]}", color = p.muted, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(5) { index ->
                Box(Modifier.weight(1f).height(4.dp).clip(CircleShape).background(if (index <= step) p.accent else p.border))
            }
        }
        if (validationError.isNotBlank()) MessageCard(p, validationError, true) { validationError = "" }

        when (step) {
            0 -> {
                SectionCard(p, title = tx(fa, "WELCOME TO WAPFIRE", "به WAPFIRE خوش آمدی"), subtitle = tx(fa, "This native wizard mirrors the five stages of the device WebUI setup.", "این راهنمای Native همان پنج مرحله راه‌اندازی WebUI دستگاه را پوشش می‌دهد.")) {
                    Text(tx(fa, "WAPFire monitors your selected access point, detects wireless security events and protects the network using the options you choose.", "WAPFire اکسس‌پوینت انتخابی تو را پایش می‌کند، رویدادهای امنیتی بی‌سیم را تشخیص می‌دهد و با گزینه‌هایی که انتخاب می‌کنی از شبکه محافظت می‌کند."), color = p.text, fontSize = 12.sp, lineHeight = 19.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(
                            tx(fa, "Access point SSID and WPA2/WPA3 password", "نام و رمز WPA2/WPA3 اکسس‌پوینت"),
                            tx(fa, "Target AP selection by SSID, BSSID and channel", "انتخاب AP هدف با SSID، BSSID و کانال"),
                            tx(fa, "LED, sound, auto-channel and self-protect", "LED، صدا، کانال خودکار و Self-Protect"),
                            tx(fa, "Final review before saving configuration", "بازبینی نهایی پیش از ذخیره تنظیمات")
                        ).forEach { item ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("✓", color = p.green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(item, color = p.muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "DEVICE STATUS", "وضعیت دستگاه"), color = p.text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${tx(fa, "Firmware", "فریم‌ور")}: ${snapshot.firmware}  ·  Heap: ${snapshot.freeHeap / 1024} KB", color = p.muted, fontSize = 10.sp)
                        }
                    }
                }
                SectionCard(p, title = tx(fa, "RESTORE FROM BACKUP", "بازیابی از پشتیبان"), subtitle = tx(fa, "You can restore a previous WAPFire JSON backup. The device will reboot after a successful restore.", "می‌توانی نسخه پشتیبان JSON قبلی را بازیابی کنی. پس از بازیابی موفق، دستگاه راه‌اندازی مجدد می‌شود.")) {
                    ActionButton(p, tx(fa, "Choose backup file", "انتخاب فایل پشتیبان"), onRestore, primary = true, modifier = Modifier.fillMaxWidth())
                    Text(tx(fa, "Backup files contain administrator, Wi-Fi and integration credentials. Keep them private.", "فایل پشتیبان شامل رمز مدیر، Wi-Fi و اطلاعات اتصال سرویس‌هاست؛ آن را محرمانه نگه دار."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            1 -> {
                SectionCard(p, title = tx(fa, "ACCESS POINT CONFIGURATION", "تنظیمات اکسس‌پوینت"), subtitle = tx(fa, "These credentials are used when your phone reconnects to WAPFire.", "این مشخصات برای اتصال دوباره گوشی به WAPFire استفاده می‌شوند.")) {
                    NativeField(p, apSsid, onApSsid, tx(fa, "Network name (SSID)", "نام شبکه (SSID)"))
                    NativeField(p, apPass, onApPass, tx(fa, "Wi-Fi password (8–63 characters)", "رمز Wi-Fi (۸ تا ۶۳ نویسه)"), password = true)
                    Text(tx(fa, "Security mode: WPA2/WPA3 Transition · PMF capable, not required", "حالت امنیتی: WPA2/WPA3 Transition · PMF فعال و غیرالزامی"), color = p.green, fontSize = 10.sp)
                }
                SectionCard(p, title = tx(fa, "ADMINISTRATOR ACCOUNT", "حساب مدیر"), subtitle = tx(fa, "Set the administrator password required for WebUI and Mobile sign-in.", "رمز مدیر موردنیاز برای ورود به WebUI و اپ موبایل را تعیین کن.")) {
                    NativeField(p, adminPass, onAdminPass, tx(fa, "Administrator password (8–64 characters)", "رمز مدیر (۸ تا ۶۴ نویسه)"), password = true)
                    Text(tx(fa, "The firmware accepts the new password only when the first setup is applied successfully.", "فریم‌ور رمز جدید را هنگام اعمال موفق راه‌اندازی اولیه ذخیره می‌کند."), color = p.muted, fontSize = 10.sp)
                }
            }
            2 -> {
                SectionCard(p, title = tx(fa, "SELECT TARGET NETWORK", "انتخاب شبکه هدف"), subtitle = tx(fa, "Choose the AP WAPFire should monitor. The device verifies the exact BSSID before accepting it.", "اکسس‌پوینتی را انتخاب کن که WAPFire باید پایش کند. دستگاه پیش از پذیرش، BSSID دقیق را بررسی می‌کند.")) {
                    ActionButton(p, if (targetScanning) tx(fa, "Scanning radio…", "در حال اسکن رادیویی…") else tx(fa, "Scan networks", "اسکن شبکه‌ها"), onTargetScan, enabled = !targetScanning && !targetSelecting, primary = true, modifier = Modifier.fillMaxWidth())
                    if (targetScanning || targetSelecting) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(17.dp), color = p.accent, strokeWidth = 2.dp)
                        Text(if (targetSelecting) tx(fa, "Verifying selected BSSID…", "در حال تأیید BSSID انتخابی…") else tx(fa, "Scanning with WAPFire radio…", "در حال اسکن با رادیوی WAPFire…"), color = p.muted, fontSize = 10.sp)
                    }
                    if (visibleTargetNetworks.isEmpty() && target == null && !targetScanning) Text(tx(fa, "No scan results yet. Tap Scan networks to use the WAPFire radio scan.", "هنوز نتیجه‌ای از اسکن وجود ندارد. برای اسکن رادیویی WAPFire روی اسکن شبکه‌ها بزن."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                    visibleTargetNetworks.sortedByDescending { it.optInt("rssi") }.forEach { net ->
                        val ssid = net.optString("ssid").ifBlank { "[Hidden]" }
                        val bssid = net.optString("bssid")
                        val channel = net.optInt("channel")
                        val isSelected = target?.optString("bssid", "")?.equals(bssid, true) == true
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) p.accentSoft.copy(alpha = .75f) else p.panelAlt.copy(alpha = .72f))
                                .border(1.dp, if (isSelected) p.accent else p.border, RoundedCornerShape(14.dp))
                                .clickable(enabled = !targetSelecting && ssid != "[Hidden]" && bssid.isNotBlank() && channel in 1..13) { onTargetSelect(net) }
                                .padding(11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(ssid, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("$bssid  ·  Ch $channel  ·  ${net.optInt("rssi")} dBm", color = p.muted, fontSize = 9.sp)
                            }
                            Text(if (isSelected) tx(fa, "SELECTED", "انتخاب‌شده") else tx(fa, "SELECT", "انتخاب"), color = if (isSelected) p.green else p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (target != null) {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.green.copy(alpha = .08f)).border(1.dp, p.green.copy(alpha = .40f), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(tx(fa, "VERIFIED TARGET", "شبکه هدف تأییدشده"), color = p.green, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(target.optString("ssid"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${target.optString("bssid")}  ·  Ch ${target.optInt("channel")}", color = p.muted, fontSize = 10.sp)
                        }
                        ActionButton(p, tx(fa, "Choose another AP", "انتخاب AP دیگر"), onChangeTarget, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            3 -> {
                SectionCard(p, title = tx(fa, "ADVANCED OPTIONS", "تنظیمات پیشرفته"), subtitle = tx(fa, "These switches map directly to the firmware's initial setup settings.", "این کلیدها مستقیماً به تنظیمات راه‌اندازی اولیه فریم‌ور متصل‌اند.")) {
                    SetupSwitchRow(p, fa, tx(fa, "Status LED", "LED وضعیت"), tx(fa, "Visual system and alert indication.", "نمایش وضعیت و هشدارهای سیستم."), led, onLed)
                    SetupSwitchRow(p, fa, tx(fa, "Sound Alerts", "هشدار صوتی"), tx(fa, "Play device sounds for important events.", "پخش صدای دستگاه برای رویدادهای مهم."), sound, onSound)
                    SetupSwitchRow(p, fa, tx(fa, "Auto Channel Tracking", "ردیابی خودکار کانال"), tx(fa, "Follow the target AP channel automatically.", "کانال AP هدف را به‌صورت خودکار دنبال کن."), autoChannel, onAutoChannel)
                    SetupSwitchRow(p, fa, tx(fa, "Self-Protect Mode", "حالت محافظت خودکار"), tx(fa, "Enable the firmware's self-protection response when configured detection conditions are met.", "پاسخ محافظت خودکار فریم‌ور را هنگام تحقق شرایط تشخیص فعال کن."), selfProtect, onSelfProtect)
                    SetupSwitchRow(p, fa, tx(fa, "Enable SoftAP", "فعال‌سازی SoftAP"), tx(fa, "Keep the WAPFire Wi-Fi access point available for mobile/WebUI access. Disable only when Ethernet access is ready.", "اکسس‌پوینت Wi-Fi دستگاه برای دسترسی موبایل و WebUI فعال می‌ماند. فقط با آماده بودن Ethernet خاموشش کن."), softAp, onSoftAp)
                    if (!softAp) Text(tx(fa, "Warning: disabling SoftAP removes Wi-Fi access to WAPFire. Continue only when Ethernet access has already been configured and tested.", "هشدار: با غیرفعال‌کردن SoftAP دسترسی Wi-Fi به WAPFire قطع می‌شود. فقط وقتی ادامه بده که Ethernet را قبلاً تنظیم و آزمایش کرده باشی."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            4 -> {
                SectionCard(p, title = tx(fa, "FINAL REVIEW", "بازبینی نهایی"), subtitle = tx(fa, "Review the values before committing them to WAPFire.", "پیش از ذخیره روی WAPFire مقادیر را بررسی کن.")) {
                    SetupReviewRow(p, fa, "AP SSID", "نام شبکه", apSsid)
                    SetupReviewRow(p, fa, "AP Security", "امنیت شبکه", "WPA2/WPA3 Transition")
                    SetupReviewRow(p, fa, "Administrator", "مدیر", tx(fa, "Password will be updated", "رمز مدیر تغییر می‌کند"))
                    SetupReviewRow(p, fa, "Target AP", "AP هدف", target?.optString("ssid", "—") ?: "—")
                    SetupReviewRow(p, fa, "Target BSSID", "BSSID هدف", target?.optString("bssid", "—") ?: "—")
                    SetupReviewRow(p, fa, "Target Channel", "کانال هدف", target?.optInt("channel", 0)?.toString() ?: "—")
                    SetupReviewRow(p, fa, "Status LED", "LED وضعیت", if (led) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Sound Alerts", "هشدار صوتی", if (sound) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Auto Channel", "کانال خودکار", if (autoChannel) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Self-Protect", "محافظت خودکار", if (selfProtect) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "SoftAP", "شبکه دسترسی", if (softAp) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                }
                Text(tx(fa, "Applying this configuration restarts the Wi-Fi service when the AP credentials or target settings change. Rejoin WAPFire using the new SSID/password after the restart.", "با اعمال تنظیمات، در صورت تغییر مشخصات AP یا شبکه هدف، سرویس Wi-Fi راه‌اندازی مجدد می‌شود. پس از آن با SSID و رمز جدید دوباره به WAPFire وصل شو."), color = p.orange, fontSize = 10.sp, lineHeight = 16.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) ActionButton(p, tx(fa, "Back", "قبلی"), { validationError = ""; onStep(step - 1) }, enabled = !saving, modifier = Modifier.weight(1f))
            if (step < 4) ActionButton(p, tx(fa, "Next", "بعدی"), { nextStep() }, enabled = !saving && !targetSelecting, primary = true, modifier = Modifier.weight(1f))
            else ActionButton(p, if (saving) tx(fa, "Applying…", "در حال اعمال…") else tx(fa, "Apply Configuration", "اعمال تنظیمات"), onFinish, enabled = !saving, primary = true, modifier = Modifier.weight(1f))
        }
        if (saving) CircularProgressIndicator(modifier = Modifier.size(22.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
internal fun SetupSwitchRow(p: Palette, fa: Boolean, title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panelAlt.copy(alpha = .55f)).border(1.dp, p.border.copy(alpha = .75f), RoundedCornerShape(14.dp)).padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
internal fun SetupReviewRow(p: Palette, fa: Boolean, label: String, labelFa: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text(if (fa) labelFa else label, color = p.muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.25f))
    }
}
