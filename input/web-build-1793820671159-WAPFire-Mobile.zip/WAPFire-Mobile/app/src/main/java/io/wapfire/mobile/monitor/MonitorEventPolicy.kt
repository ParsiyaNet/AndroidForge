package io.wapfire.mobile.monitor

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

/** Security-event policy shared by the background monitor and its tests. */
internal object MonitorEventPolicy {
    private val threatTokens = listOf(
        "deauth", "deauthentication", "auth_attack", "authentication", "evil_twin",
        "wps_pixie_reaver", "pixie_reaver", "reaver", "wps_pixie_bully", "pixie_bully", "bully",
        "wrong_password", "wrong password"
    )

    fun isSecurityEvent(event: JSONObject): Boolean {
        val type = normalize(event.optString("event_type"))
        if (type == "correct_password" || type == "wpa_correct_password") return false
        if (type == "attack") return true
        if (type in setOf("wrong_password", "wpa_wrong_password")) return true
        val searchable = normalize(
            listOf(event.optString("event_type"), event.optString("message"), event.optString("details"))
                .joinToString(" ")
        )
        return threatTokens.any { searchable.contains(normalize(it)) }
    }

    fun title(event: JSONObject): String {
        val raw = listOf(event.optString("event_type"), event.optString("message"), event.optString("details"))
            .joinToString(" ").lowercase(Locale.ROOT)
        return when {
            raw.contains("deauth_airplay") || raw.contains("deauthentication_airplay") -> "Deauth Airplay detected"
            raw.contains("deauth") || raw.contains("deauthentication") -> "Deauth Attack detected"
            raw.contains("evil_twin") || raw.contains("evil twin") -> "Evil Twin detected"
            raw.contains("wps_pixie_reaver") || raw.contains("pixie_reaver") || raw.contains("reaver") -> "WPS Pixie Reaver detected"
            raw.contains("wps_pixie_bully") || raw.contains("pixie_bully") || raw.contains("bully") -> "WPS Pixie Bully detected"
            raw.contains("wrong_password") || raw.contains("wrong password") -> "WPA Wrong Password"
            raw.contains("auth_attack") || raw.contains("authentication") -> "Auth Attack detected"
            else -> "WAPFire Security Alert"
        }
    }

    /** Prefer a firmware event ID; otherwise hash stable event fields in key order. */
    fun signature(event: JSONObject): String {
        val id = listOf("id", "event_id", "log_id", "sequence", "seq")
            .firstNotNullOfOrNull { key -> event.optString(key).takeIf { it.isNotBlank() && it != "null" } }
        val stableKeys = listOf(
            "timestamp", "time", "formatted_time", "event_type", "message", "details",
            "bssid", "mac", "client_mac", "target", "channel"
        )
        val populated = stableKeys.mapNotNull { key ->
            event.optString(key).takeIf { it.isNotBlank() }?.let { "$key=$it" }
        }
        // Firmware sequence IDs can restart after reboot, so combine an ID with
        // the event's stable context instead of treating the ID as globally unique.
        val source = if (id != null) {
            "id:$id|${populated.joinToString("|")}"
        } else {
            if (populated.isEmpty()) event.toString() else populated.joinToString("|")
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(source.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(Locale.ROOT, it) }
    }

    fun detail(event: JSONObject): String = sequenceOf(
        event.optString("details"), event.optString("message"), event.optString("bssid"), event.optString("mac")
    ).firstOrNull { it.isNotBlank() }?.take(180).orEmpty()

    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)
        .replace('-', '_').replace(Regex("\\s+"), "_")
}
