# WAPFire Mobile 4.1.53 – VRM Character Renderer

- Replaced the in-app 2D LivLiv character renderer with an offline Three.js / @pixiv/three-vrm WebGL renderer.
- Bundles the user-provided `AvatarSample_A.vrm` as Nara's 3D character; the four 4K texture images are downscaled to 2K for mobile GPU/memory use while preserving mesh, skeleton, expressions and VRM metadata.
- Preserves the existing Compose screens, WebView bridge, assistant status messages and WAPFire monitoring flow.
- Added automatic blink, gaze, subtle idle motion, and state-driven happy / relaxed / sad / angry expressions.
- Uses the VRM model's A/I/U/E/O mouth shapes for timed text-response mouth motion. This is not audio-synchronized lip sync; the current app does not expose an audio timing stream to the renderer.
- Three.js r180 and @pixiv/three-vrm 3.5.5 are fetched by Gradle and copied into APK assets. First build requires network access; the installed app does not make runtime network requests for the assistant.
- VRM model: `AvatarSample_A`, author metadata `VRoid Project`, VRM 0.x. The model metadata declares the Everyone permission profile; original metadata remains embedded in the VRM file.

## Validation status

The source, model metadata, package paths, and JavaScript syntax were checked in this environment. An Android APK build and on-device WebGL validation were not run here. The target phone should be used for final visual/performance verification because Android WebView/GPU behavior cannot be proven by static inspection alone.
