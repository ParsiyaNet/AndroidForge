# WAPFire Mobile 4.1.54 — VRM Texture & Pose Fix

- Fixed embedded VRM texture loading in Android WebView by explicitly allowing local `blob:` and `data:` URLs in `connect-src`. This does not permit external network hosts.
- Added a relaxed standing pose for AvatarSample_A by lowering both upper arms and subtly bending the forearms from their authored T-pose.
- Kept the existing VRM model, expressions, blink behavior, assistant state bridge, and WAPFire UI.
- Updated renderer/build identifiers to 4.1.54 (versionCode 100).
- Changed diagnostic asset probes from synthetic HEAD requests to small ranged GET requests for more reliable WebView diagnostics.

## Validation

- JavaScript syntax validation: see `VALIDATION-4.1.54.txt`.
- VRM GLB integrity and embedded image payloads retained.
- Android APK build and physical-device WebView/WebGL validation are not performed in this environment.
