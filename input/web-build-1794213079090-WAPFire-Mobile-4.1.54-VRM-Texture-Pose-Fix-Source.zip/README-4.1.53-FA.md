# WAPFire Mobile 4.1.53 — Nara 3D / VRM

## تغییر اصلی
رندرکنندهٔ دوبعدی قبلی از مسیر فعال Assistant برداشته شده و Nara با موتور WebGL مبتنی بر Three.js و `@pixiv/three-vrm` در همان WebView نمایش داده می‌شود. صفحه‌های Compose، داشبورد، وضعیت‌های WAPFire، مانیتورینگ و پل JavaScript/Android حفظ شده‌اند.

## مدل Nara
- فایل داخل برنامه: `app/src/main/assets/assistant/characters/nara.vrm`
- مدل اصلی: `AvatarSample_A` از VRoid Project، فرمت VRM 0.x
- ۵۴ استخوان humanoid و ۱۴ گروه Blend Shape
- چهار تکسچر ۴۰۹۶×۴۰۹۶ برای مصرف کمتر GPU/RAM به ۲۰۴۸×۲۰۴۸ کاهش داده شده‌اند؛ دادهٔ مش، اسکلت، حالات چهره و متادیتای مجوز حفظ شده‌اند.
- حالت‌های blink، نگاه، حرکت ظریف سر/بالا‌تنه، واکنش به وضعیت‌های شبکه و شکل‌های دهانی فعال‌اند. حرکت دهان فعلی با تغییر متن/وضعیت زمان‌بندی می‌شود و Lip Sync واقعیِ هماهنگ با صدای TTS نیست.

## وابستگی‌ها و آفلاین بودن
Gradle در اولین Build این نسخه‌ها را از jsDelivr می‌گیرد و داخل `app/src/main/assets/assistant/vendor/` قرار می‌دهد:
- Three.js r180
- `@pixiv/three-vrm` 3.5.5

بنابراین برای اولین Build، محیط ساخت به اینترنت نیاز دارد. پس از ساخته‌شدن APK، فایل مدل و کتابخانه‌ها داخل خود APK هستند و اجرای Assistant برای بارگذاری مدل و رندر سه‌بعدی به اینترنت نیاز ندارد.

## ساخت APK
در Android Studio پروژه را باز کن و `assembleDebug` را اجرا کن، یا در ترمینال:

```bash
./gradlew :app:assembleDebug
```

در ویندوز:

```bat
gradlew.bat :app:assembleDebug
```

## وضعیت اعتبارسنجی
- ساختار GLB/VRM، بافرها و ۱۳ تصویر داخلی بررسی شده‌اند.
- وجود ۵۴ استخوان و ۱۴ Blend Shape تأیید شده است.
- Syntax هر دو فایل JavaScript جدید با `node --check` بررسی شده است.
- APK در این محیط ساخته نشده است؛ Android SDK و Gradle distribution در دسترس نبودند. تست نهایی WebView/WebGL و مصرف GPU باید روی گوشی هدف (از جمله Galaxy A70) انجام شود.
