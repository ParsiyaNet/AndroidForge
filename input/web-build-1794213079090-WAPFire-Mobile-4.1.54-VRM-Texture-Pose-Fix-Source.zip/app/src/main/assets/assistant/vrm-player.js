import * as THREE from './vendor/three.module.js';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from './vendor/three-vrm.module.min.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const easeOut = (v) => 1 - Math.pow(1 - clamp(v, 0, 1), 2);

/**
 * Small WebView-friendly VRM player with a compatibility API for WAPFire's existing
 * assistant state bridge. The supplied AvatarSample_A is a VRM 0.x model and is
 * converted by @pixiv/three-vrm during GLTF loading.
 */
export class Player {
  constructor(canvas, options = {}) {
    if (!(canvas instanceof HTMLCanvasElement)) throw new TypeError('VRM Player needs a canvas element.');
    this.canvas = canvas;
    this.options = options;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'low-power',
      preserveDrawingBuffer: true,
      premultipliedAlpha: true,
      depth: true,
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setClearColor(0x000000, 0);
    this.pixelRatio = Math.min(options.maxPixelRatio || window.devicePixelRatio || 1, 1.35);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(28, 1, 0.01, 100);
    this.camera.position.set(0, 1, 3);

    this.scene.add(new THREE.HemisphereLight(0xc8e8ff, 0x1a2941, 1.65));
    const key = new THREE.DirectionalLight(0xfff5ed, 2.15);
    key.position.set(-2.6, 4.5, 4.0);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x75caff, 0.85);
    fill.position.set(3.2, 2.3, -2.0);
    this.scene.add(fill);

    this.model = { name: 'AvatarSample_A' };
    this.vrm = null;
    this.view = { x: 0, y: -0.025, zoom: 1 };
    this.puppet = { model: { canvas: [1024, 1536] }, zoom: 1, panY: 0 };
    this.bounds = new THREE.Box3();
    this.center = new THREE.Vector3(0, 0.8, 0);
    this.dimensions = new THREE.Vector3(0.6, 1.6, 0.4);
    this.lookTarget = new THREE.Object3D();
    this.scene.add(this.lookTarget);

    this.head = null;
    this.neck = null;
    this.spine = null;
    this.chest = null;
    this.hips = null;
    this.baseBones = [];
    this.emotion = null;
    this.look = { x: 0, y: 0 };
    this.motion = null;
    this.motionStart = 0;
    this.motionDuration = 0.9;
    this.away = false;
    this.clock = 0;
    this.nextBlinkAt = 2.7 + Math.random() * 2.0;
    this.blinkUntil = -1;
    this.talkUntil = -1;
    this.raf = 0;
    this.lastFrame = 0;
    this.disposed = false;
    this.visible = true;
    this.onContextLost = null;

    this._onContextLost = (event) => {
      event.preventDefault();
      this.pause();
      this.onContextLost?.();
    };
    this._onVisibility = () => {
      this.visible = document.visibilityState !== 'hidden';
      if (this.visible && options.autoplay !== false) this.play();
    };
    canvas.addEventListener('webglcontextlost', this._onContextLost, false);
    document.addEventListener('visibilitychange', this._onVisibility);
    this.resize();
    if (options.autoplay !== false) this.play();
  }

  async load(url, { onProgress } = {}) {
    if (this.disposed) throw new Error('VRM Player was disposed before loading.');
    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));
    const gltf = await new Promise((resolve, reject) => {
      loader.load(
        url,
        resolve,
        (event) => {
          if (typeof onProgress === 'function' && event.total > 0) {
            onProgress({ step: 'download', progress: clamp(event.loaded / event.total, 0, 1) });
          }
        },
        reject,
      );
    });

    const vrm = gltf?.userData?.vrm;
    if (!vrm?.scene || !vrm?.humanoid) throw new Error('The file loaded as glTF, but its VRM humanoid extension was not found.');
    this.vrm = vrm;

    // VRM 0.x avatars face -Z; the utility rotates only legacy VRM 0.0 models.
    VRMUtils.rotateVRM0(vrm);
    // Reduce duplicate skinning work for mobile WebGL renderers. Keep the original
    // morph/expression mapping intact; this avatar has a small, phone-safe blendshape set.
    try { VRMUtils.combineSkeletons(vrm.scene); } catch (error) { console.warn('VRM skeleton optimization skipped:', error); }

    this.scene.add(vrm.scene);
    vrm.scene.updateMatrixWorld(true);
    this.bounds.setFromObject(vrm.scene);
    if (this.bounds.isEmpty()) throw new Error('The VRM model contains no renderable geometry.');
    this.bounds.getCenter(this.center);
    this.bounds.getSize(this.dimensions);
    if (!Number.isFinite(this.dimensions.y) || this.dimensions.y < 0.2) {
      throw new Error('The VRM model has invalid dimensions.');
    }

    this.model = {
      name: vrm.meta?.name || vrm.meta?.title || 'AvatarSample_A',
      format: 'VRM 0.x',
      expressions: vrm.expressionManager?.expressions?.map((item) => item.expressionName) || [],
    };

    const humanoid = vrm.humanoid;
    const getBone = (name) => {
      try { return humanoid.getNormalizedBoneNode(name); } catch (_) { return null; }
    };
    this.head = getBone('head');
    this.neck = getBone('neck');
    this.spine = getBone('spine');
    this.chest = getBone('chest') || getBone('upperChest');
    this.hips = getBone('hips');
    for (const bone of [this.head, this.neck, this.spine, this.chest, this.hips]) {
      if (bone) this.baseBones.push({
        bone,
        rotation: bone.rotation.clone(),
        position: bone.position.clone(),
        zOffset: 0,
      });
    }

    // AvatarSample_A is authored in a strict T-pose. Give it a relaxed, anime-style
    // standing pose immediately, without requiring an external animation clip. In this
    // model's VRM rest axes the left arm extends toward -X and the right toward +X, so
    // mirrored Z offsets rotate both upper arms down. Forearms continue the natural fall.
    const relaxedArmOffsets = {
      leftUpperArm: 1.10,
      rightUpperArm: -1.10,
      leftLowerArm: 0.18,
      rightLowerArm: -0.18,
    };
    for (const [name, zOffset] of Object.entries(relaxedArmOffsets)) {
      const bone = getBone(name);
      if (bone) this.baseBones.push({
        bone,
        rotation: bone.rotation.clone(),
        position: bone.position.clone(),
        zOffset,
      });
    }

    if (vrm.lookAt) {
      vrm.lookAt.target = this.lookTarget;
      vrm.lookAt.autoUpdate = true;
    }
    this.lookAt(null, 0);
    this._updateCamera();
    this._applyExpression();
    this.resize();
    this._renderOnce();
    if (typeof onProgress === 'function') onProgress({ step: 'download', progress: 1 });
    return this;
  }

  _expressionExists(name) {
    return !!this.vrm?.expressionManager?.getExpression?.(name);
  }

  _setExpression(name, value) {
    const manager = this.vrm?.expressionManager;
    if (!manager || !this._expressionExists(name)) return;
    manager.setValue(name, clamp(value, 0, 1));
  }

  _applyExpression() {
    const manager = this.vrm?.expressionManager;
    if (!manager) return;
    manager.resetValues();
    const map = {
      smile: ['happy', 0.82],
      shy: ['relaxed', 0.58],
      sad: ['sad', 0.72],
      angry: ['angry', 0.82],
      surprised: ['Surprised', 0.88],
      happy: ['happy', 0.82],
    };
    const preset = map[this.emotion];
    if (preset) {
      // AvatarSample_A stores Surprised as a custom VRM 0.x blendshape, not a standard preset.
      if (preset[0] === 'Surprised' && !this._expressionExists('Surprised')) this._setExpression('surprised', preset[1]);
      else this._setExpression(preset[0], preset[1]);
    }
    else if (this.emotion && this._expressionExists(this.emotion)) this._setExpression(this.emotion, 0.8);
    else this._setExpression('neutral', 1.0);
  }

  setExpression(expression) {
    this.emotion = expression == null ? null : String(expression);
    this._applyExpression();
    // The existing assistant writes a text response at the same time as its state change.
    // A short vowel-shape sequence gives the avatar a speaking-like reaction; it is not
    // synchronized to an audio stream.
    if (this.emotion) this.talkUntil = this.clock + 1.65;
  }

  setAway(value) {
    this.away = !!value;
  }

  lookAt(x, y = 0) {
    if (x == null) {
      this.look = { x: 0, y: 0 };
    } else {
      this.look = { x: clamp(Number(x) || 0, -1, 1), y: clamp(Number(y) || 0, -1, 1) };
    }
    const headY = this.bounds.isEmpty() ? 1.35 : this.bounds.min.y + this.dimensions.y * 0.83;
    const headX = this.center.x + this.look.x * this.dimensions.x * 0.9;
    const headLookY = headY + this.look.y * this.dimensions.y * 0.22;
    this.lookTarget.position.set(headX, headLookY, this.center.z + Math.max(this.dimensions.y * 2.5, 2.5));
  }

  blink() {
    this.blinkUntil = this.clock + 0.17;
  }

  act(action) {
    const durations = { nod: 0.72, tilt: 0.92, hop: 0.7, shake: 0.86 };
    if (!durations[action]) return false;
    this.motion = action;
    this.motionStart = this.clock;
    this.motionDuration = durations[action];
    return true;
  }

  _updateCamera() {
    if (!this.vrm || this.bounds.isEmpty()) return;
    const aspect = Math.max(0.25, this.canvas.clientWidth / Math.max(1, this.canvas.clientHeight));
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov / 2);
    const heightDistance = this.dimensions.y / (2 * Math.tan(halfFov));
    const widthDistance = this.dimensions.x / (2 * Math.tan(halfFov) * aspect);
    const baseDistance = Math.max(heightDistance, widthDistance, 1.0) * 1.10;
    const zoom = clamp(this.view.zoom || 1, 0.75, 1.25);
    const targetY = this.center.y - (this.view.y || 0) * this.dimensions.y;
    const targetX = this.center.x + (this.view.x || 0) * this.dimensions.x;
    const distance = baseDistance / zoom;
    this.camera.position.set(targetX, targetY, this.center.z + distance);
    this.camera.lookAt(targetX, targetY, this.center.z);
    this.camera.near = Math.max(0.01, distance / 100);
    this.camera.far = distance + this.dimensions.y * 5 + 10;
    this.camera.updateProjectionMatrix();
  }

  resize() {
    if (this.disposed) return;
    const width = Math.max(1, this.canvas.clientWidth || this.canvas.getBoundingClientRect().width || 1);
    const height = Math.max(1, this.canvas.clientHeight || this.canvas.getBoundingClientRect().height || 1);
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(width, height, false);
    this._updateCamera();
    this._renderOnce();
  }

  _update(delta) {
    if (!this.vrm) return;
    this.clock += delta;
    const t = this.clock;
    const moodTalk = t < this.talkUntil && !this.away;

    // Natural eye blinks with occasional small timing variation.
    if (t >= this.nextBlinkAt) {
      this.blinkUntil = t + 0.14;
      this.nextBlinkAt = t + 3.0 + Math.random() * 2.4;
    }
    let blinkWeight = 0;
    const blinkAge = this.blinkUntil - t;
    if (blinkAge > 0) blinkWeight = Math.sin(clamp(1 - blinkAge / 0.17, 0, 1) * Math.PI);
    if (this.away) blinkWeight = Math.max(blinkWeight, 0.72);
    this._setExpression('blink', blinkWeight);

    // Light mouth-shape motion while the matching text bubble is being presented.
    // It intentionally does not claim real audio lip-sync; the app does not pass PCM/audio
    // timing to this renderer at present.
    const vowelNames = ['aa', 'ih', 'ou', 'ee', 'oh'];
    for (const name of vowelNames) this._setExpression(name, 0);
    if (moodTalk) {
      const phase = t * 11.5;
      const vowel = vowelNames[Math.floor((phase / (Math.PI * 2)) * vowelNames.length) % vowelNames.length];
      const envelope = 0.16 + 0.23 * Math.max(0, Math.sin(phase));
      this._setExpression(vowel, envelope);
    }

    const motionAge = this.motion ? (t - this.motionStart) / this.motionDuration : 1;
    const motionWeight = this.motion ? 1 - easeOut(motionAge) : 0;
    const wave = this.away ? 0 : Math.sin(t * 1.25);
    for (const item of this.baseBones) {
      item.bone.rotation.copy(item.rotation);
      item.bone.position.copy(item.position);
      if (item.zOffset) item.bone.rotation.z += item.zOffset;
    }
    if (this.head) {
      this.head.rotation.x += wave * 0.012;
      this.head.rotation.z += Math.sin(t * 0.58) * 0.009;
      const action = this.motion;
      if (action === 'nod') this.head.rotation.x += Math.sin(motionAge * Math.PI * 2) * 0.12 * motionWeight;
      if (action === 'tilt') this.head.rotation.z += 0.16 * motionWeight;
      if (action === 'shake') this.head.rotation.y += Math.sin(motionAge * Math.PI * 8) * 0.13 * motionWeight;
    }
    if (this.neck) this.neck.rotation.x += wave * 0.006;
    if (this.chest) this.chest.rotation.x += Math.sin(t * 1.4) * 0.008;
    if (this.hips && this.motion === 'hop') {
      this.hips.position.y += Math.sin(clamp(motionAge, 0, 1) * Math.PI) * 0.055 * motionWeight;
    }

    if (this.motion && motionAge >= 1) this.motion = null;
    this.vrm.update(delta);
  }

  _renderOnce() {
    if (this.disposed || !this.renderer || !this.visible) return;
    this.renderer.render(this.scene, this.camera);
  }

  _frame = (timestamp) => {
    if (!this.raf || this.disposed) return;
    const rawDelta = this.lastFrame ? (timestamp - this.lastFrame) / 1000 : 1 / 30;
    this.lastFrame = timestamp;
    const delta = clamp(rawDelta, 0, 1 / 20);
    if (this.visible) {
      this._update(delta);
      this.renderer.render(this.scene, this.camera);
    }
    this.raf = requestAnimationFrame(this._frame);
  };

  play() {
    if (this.disposed || this.raf) return;
    this.lastFrame = 0;
    this.raf = requestAnimationFrame(this._frame);
  }

  pause() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.lastFrame = 0;
  }

  dispose() {
    if (this.disposed) return;
    this.pause();
    this.disposed = true;
    this.canvas.removeEventListener('webglcontextlost', this._onContextLost, false);
    document.removeEventListener('visibilitychange', this._onVisibility);
    if (this.vrm?.scene) {
      this.scene.remove(this.vrm.scene);
      try { VRMUtils.deepDispose(this.vrm.scene); } catch (_) { /* best-effort GPU cleanup */ }
    }
    this.renderer.dispose();
    this.vrm = null;
  }
}
