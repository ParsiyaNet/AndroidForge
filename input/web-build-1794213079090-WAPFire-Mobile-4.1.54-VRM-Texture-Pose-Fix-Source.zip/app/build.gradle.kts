import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 100
        versionName = "4.1.54"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// WAPFire 4.1.54: vendor the 3D VRM renderer into APK assets at build time.
// Runtime uses only appassets.androidplatform.net; no external network access is required.
val vendorVrmRenderer by tasks.registering {
    val vendorDir = file("src/main/assets/assistant/vendor")
    val threeModule = File(vendorDir, "three.module.js")
    val threeCore = File(vendorDir, "three.core.js")
    val gltfLoader = File(vendorDir, "loaders/GLTFLoader.js")
    val geometryUtils = File(vendorDir, "utils/BufferGeometryUtils.js")
    val vrmModule = File(vendorDir, "three-vrm.module.min.js")
    val threeLicense = File(vendorDir, "THREE-LICENSE.txt")
    val vrmLicense = File(vendorDir, "THREE-VRM-LICENSE.txt")

    outputs.files(threeModule, threeCore, gltfLoader, geometryUtils, vrmModule, threeLicense, vrmLicense)

    doLast {
        fun fetch(url: String, destination: File, minimumBytes: Int, marker: String? = null) {
            if (destination.exists() && destination.length() >= minimumBytes) {
                val existing = destination.readText(Charsets.UTF_8)
                if (marker == null || existing.contains(marker)) return
            }
            destination.parentFile.mkdirs()
            val temporary = File(destination.parentFile, destination.name + ".download")
            var connection: HttpURLConnection? = null
            try {
                val active = URL(url).openConnection() as HttpURLConnection
                connection = active
                active.connectTimeout = 30000
                active.readTimeout = 120000
                active.instanceFollowRedirects = true
                active.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.54")
                active.setRequestProperty("Accept", "application/javascript,text/plain,*/*")
                val status = active.responseCode
                if (status != HttpURLConnection.HTTP_OK) throw IOException("HTTP $status from $url")
                active.inputStream.use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
                if (temporary.length() < minimumBytes) throw IOException("Downloaded file is unexpectedly small: ${temporary.length()} bytes from $url")
                if (marker != null && !temporary.readText(Charsets.UTF_8).contains(marker)) {
                    throw IOException("Downloaded file did not contain expected marker '$marker': $url")
                }
                Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                logger.lifecycle("Vendored ${destination.relativeTo(projectDir)} (${destination.length()} bytes)")
            } finally {
                temporary.delete()
                connection?.disconnect()
            }
        }

        // Pin the versions together: three-vrm 3.5.5 documents compatibility with Three.js r180.
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js", threeModule, 1000, "three.core.js")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.core.js", threeCore, 100000, "REVISION = '180'")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/loaders/GLTFLoader.js", gltfLoader, 10000, "class GLTFLoader")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/utils/BufferGeometryUtils.js", geometryUtils, 10000, "toTrianglesDrawMode")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.5.5/lib/three-vrm.module.min.js", vrmModule, 50000, "VRMLoaderPlugin")
        fetch("https://cdn.jsdelivr.net/npm/three@0.180.0/LICENSE", threeLicense, 200, "MIT License")
        fetch("https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.5.5/LICENSE", vrmLicense, 200, "MIT License")

        fun rewriteThreeImport(file: File, replacement: String) {
            val source = file.readText(Charsets.UTF_8)
            val rewritten = Regex("""from\s*(['"])three\1""").replace(source) { match ->
                "from${match.groupValues[1]}$replacement${match.groupValues[1]}"
            }
            if (Regex("""from\s*(['"])three\1""").containsMatchIn(rewritten)) {
                throw GradleException("Could not rewrite bare Three.js import in ${file.name}")
            }
            file.writeText(rewritten, Charsets.UTF_8)
        }

        rewriteThreeImport(gltfLoader, "../three.module.js")
        rewriteThreeImport(geometryUtils, "../three.module.js")
        rewriteThreeImport(vrmModule, "./three.module.js")
        logger.lifecycle("Three.js r180 and @pixiv/three-vrm 3.5.5 are ready as offline APK assets.")
    }
}

tasks.named("preBuild").configure {
    dependsOn(vendorVrmRenderer)
}
