# WAPFire Mobile 4.1.1 — Background Security Monitor

This source release adds a user-started Android foreground service for local VF38 security-event notifications. See `CHANGELOG-4.1.1.md`, `ARCHITECTURE-4.1.1.md`, and `VALIDATION-4.1.1.txt`. For reliable alerts while the screen is off, set WAPFire battery usage to **Unrestricted / Don't optimize** in Android settings; Doze can otherwise suspend background network access. The monitor uses an ongoing notification and can increase battery usage.

## 4.1.1 quick start

1. Install/build the app and connect to WAPFire as usual.
2. Open **Overview → Background Security Monitor** and switch monitoring on.
3. Grant notification permission. If secure password saving is not enabled, approve the Android Keystore credential-storage prompt.
4. Open **Battery optimization settings** from the same card and exempt WAPFire (wording differs by Android/OEM).
5. Close the app. The ongoing notification shows monitor state; use its **Stop** action or the Overview switch to stop monitoring.

Attack events are read from the existing VF38 `/api/logs` endpoint; this release does not change firmware detection. Android Force stop, OEM task killers, Wi-Fi loss and reboot can interrupt monitoring. This release does not auto-start monitoring after phone reboot. See `VALIDATION-4.1.1.txt` for the exact checks performed and unperformed.

## 4.0.0 — Clean architecture and session reliability (base release)

This base release reorganized the mobile source into explicit application, UI, model, networking, and credential-storage areas while preserving the 3.2.13 user-facing workflows and the existing encrypted credential format. The 4.1.1 Android app package does not include or modify VF38 firmware source.

- `MainActivity.kt` is now only the Android activity entry point.
- `ui/WapFireApp.kt` owns the app composition and coordinates app-level navigation and operations.
- `ui/screens/` separates Discovery/Setup, Dashboard, and Settings screens.
- `ui/components/` contains shared visual components.
- `model/` contains app data types, snapshot parsing, and presentation helpers.
- `network/` separates the VF38 HTTP API, Wi-Fi discovery, Wi-Fi network binding/join lifecycle, and session recovery policy.
- `security/DeviceLoginVault.kt` isolates Android Keystore AES-GCM credential storage. The existing preference names, key alias, and ciphertext layout are retained so an in-place app update does not discard saved credentials.
- HTTP failures preserve their numeric status code and endpoint. Session recovery verifies the unauthenticated WAPFire root page before re-sending credentials, then retries only the safe status read. Non-idempotent settings, backup/restore, OTA, and device actions are never automatically replayed.
- When Android changes the phone's IP but the active WAPFire endpoint remains the same, the app can renew the IP-bound VF38 session and retain the active tab and cached dashboard. A changed endpoint is silently re-authenticated only when the exact selected AP BSSID has been confirmed.
- No BLE transport was introduced. Discovery continues to use the VF38 BSSID signature `02:57:41:xx:xx:xx` and native Android Wi-Fi APIs.

The app's package/application ID and minimum Android version remain unchanged. The current source release is 4.1.1; the 4.0.0 notes below describe the base architecture. Full device build and validation require Android Studio/JDK 17/SDK Platform 35. See `VALIDATION-4.1.1.txt` for checks actually performed and remaining device tests.

## 3.2.8 protection ring and API load stability
- Corrected the Threat Risk ring scale to match the VF38 firmware's 0.0–10.0 score, including one decimal place and status colors aligned with `OPTIMAL`, `MONITORING`, `WARNING` and `CRITICAL`.
- Overview now distinguishes configured setup, radio monitoring, armed Self-Protect and an active protection response using the live firmware fields.
- All native device API exchanges are serialized per session. The normal response timeout is 30 seconds, with longer operation-specific windows for scan, logs, backup and restore.
- Telemetry refreshes are coalesced to avoid duplicate polling. Firmware metadata is no longer fetched every telemetry cycle, chart data is fetched only on Overview, and advanced settings loading stops at the first failed endpoint.


## 3.2.7 Compose build compatibility fix
- Added the required `ExperimentalFoundationApi` opt-in to `DiscoveryScreen`, which owns the selected-network `BringIntoViewRequester` and calls `bringIntoView()` / `bringIntoViewRequester()`.
- This resolves the Kotlin compiler errors reported by AndroidForge for `MainActivity.kt` lines 1189, 1196 and 1263. No runtime behavior was changed by this annotation.

## 3.2.6 Settings target rescan fix
- Settings target scanning now always displays the complete AP list returned by `/api/scan`, even when a target is already configured. The user can select a replacement AP without clearing the current target first.
- After a target is successfully verified and saved, the Settings list collapses to that one selected AP. A subsequent scan repopulates the full list.
- Periodic status refreshes no longer prune active scan results back to the old configured BSSID. Clearing the target still clears stale target rows.
- During a scan, AP rows are disabled to prevent a selection racing against the scan response.

## 3.2.5 discovery flow and visual consistency
- Selecting a nearby Wi-Fi AP collapses the rest of the scan list, keeps only the selected network, and reveals the password card automatically. For secured APs, the password field is focused and the keyboard is opened; the card is scrolled into view. “Choose another network” resets the selection and returns to scanning.
- Toast-style notices now use a fully opaque theme surface with a stronger status border for readable text in both Dark and Light modes.
- Added the FA / EN language toggle to the Initial Setup header so Persian can be enabled from Setup itself.
- Resized the language toggle to exactly 36 × 36 dp, matching the Dark / Light control.

## 3.2.4 stability and UX refinement
- Schedule Start / End controls use equal-width native 24-hour Android time pickers. Invalid schedule combinations (no selected days or identical Start / End) cannot be saved while scheduling is enabled.
- Target AP results are retained and displayed by exact BSSID after selection. Same-SSID sibling radios and stale scan results remain hidden until the user explicitly clears / changes the target and scans again.
- Global notifications use a detached top popup with bounded width and a three-line limit, so notification presentation cannot participate in the page's scroll measurement.
- Settings target selection validates BSSID format and the VF38-supported channel range before calling the device API, and locks out duplicate selection requests while a target is being verified.
- Overnight Schedule intervals show the VF38 weekday-rollover limitation and the practical next-day selection workaround.
- Failed / lost Android Wi-Fi joins release their pending network callback and IP-readiness poll before a retry.

# WAPFire Mobile 3.2.3 — Native Glass Control Center

## 3.2.3 UI fixes
- Schedule Start / End use native Android 24-hour time pickers and equal-width controls.
- Target AP lists in Setup and Settings are filtered by the selected BSSID. Setup offers an explicit option to choose another AP.
- Global success/error notices are displayed in a bounded-width overlay.

# WAPFire Mobile 3.2.2 — Native Glass Control Center

## 3.2.2 VF38 API and Wi-Fi readiness fixes
- Added the missing authenticated `/api/mobile_settings` route to the matching VF38 source; the mobile-only response does not disclose the SoftAP passphrase.
- Current Wi-Fi state is now derived from `ConnectivityManager` transport and IPv4 `LinkProperties`, with DHCP fallback, so Android no longer reports “No Wi-Fi connection” when it already has an IPv4 lease but hides the SSID.
- Wi-Fi joining now waits up to 10 seconds for an IPv4 address and default gateway before attempting WebUI verification. A DHCP address without a route uses the documented WAPFire AP address only as a verification fallback; no false success is shown.

## 3.2.1 Setup and Wi-Fi join compatibility
- Rebuilt the native initial Setup as five WebUI-matching stages, including backup restore, AP/admin credentials, exact target BSSID selection, advanced switches and final review.
- Matched Android Wi-Fi network requests to the firmware WPA2/WPA3 Transition SoftAP security mode, pins the selected BSSID, reads the IPv4 gateway from the selected Network, verifies the actual WAPFire login page, and provides a dedicated Connect action after selecting a network.
- Improved join failure messages and reconnect flow; no firmware detection logic was changed.


## Language toggle alignment
- The `FA` / `EN` labels render centered in both LTR and RTL layouts. The language and theme actions are both 36 × 36dp; two-character labels remain centered and LTR in either interface direction.

## Theme control
- The compact single-button theme action uses the same half-filled contrast-circle glyph shown in the original Welcome Back header reference. The glyph remains fixed in both themes; tapping it toggles Dark/Light.

## 3.0.4 visual telemetry refinement
- The first screen title is **WAPFire**; the same compact contrast theme control is available on Discovery, Login, Setup and Control pages.
- Sign in includes an optional **Remember password** checkbox. A saved password is AES-GCM encrypted with an Android Keystore key and is bound to the device host. Unchecking it deletes the saved credential. Android backup is disabled for the app.
- Detection Breakdown always renders all eight VF38 detection categories, including zero-count rows.
- Network Telemetry shows traffic frames, packets, Target AP RX, and filtered frames. Free heap remains in Device Status, not Network Telemetry.
- WS2812 custom color controls are shown only for effects that actually consume them. Secondary color is only shown for Alternate.

Standalone native Android companion for the modular WAPFire VF38 firmware. The interface is Kotlin + Jetpack Compose. It does not embed the firmware WebUI and does not use a WebView.

## App structure

The main navigation has four destinations: **Overview**, **Clients**, **Events**, and **Settings**. Target selection and clearing are grouped at the top of Settings under **Monitoring & Target**. Device settings are organized into expandable functional groups instead of separate tabs.

The visual system uses layered translucent surfaces, softly lit ambient background elements, glass-like borders, restrained gradients, consistent spacing, and both light and dark themes. A single compact half-filled contrast-circle action button matching the original 3.0.3 Welcome Back control is shared across all main screens. English and Persian RTL layouts are supported.

## Exact event labels

The app displays these exact names as the primary event titles:

- Auth Attack
- Deauth Attack
- Deauth Airplay
- WPS Pixie Reaver
- WPS Pixie Bully
- Evil Twin
- WPA Correct Password
- WPA Wrong Password

Raw firmware identifiers are not used as primary titles. Correct/wrong password entries are driven by the firmware's actual `correct_password` and `wrong_password` event types. RF detections are resolved from the actual event label/message/details.

## Firmware capabilities exposed by the native app

| Capability | Firmware API / action | App location |
|---|---|---|
| Discovery, login, initial setup, logout | `/login`, `/logout`, `/api/status`, setup reads via `/api/mobile_settings`, writes via `/api/settings` | Connection / Setup / Session |
| Live status and RF telemetry | `/api/status`, `/api/chart_data` | Overview |
| Tracked clients | `/api/tracked_clients` | Clients |
| Event timeline and clearing | `/api/logs`, `/api/clear_logs` | Events |
| Target scan, exact selection, persistent save, clear | `/api/scan`, `/api/select_target`, `/api/save_target` | Settings → Monitoring & Target |
| Self-protect, automatic channel tracking | `/api/settings` | Settings → Protection |
| Status LED, smart LED, sound, SoftAP | `/api/settings` | Settings → Device Feedback / Connectivity |
| Beacon mode, AP SSID/password, admin password | `/api/settings` | Settings → Device security |
| Ethernet DHCP/static IP/DNS/gateway/subnet/hostname and diagnostics | `/api/ethernet_settings` | Settings → Network · Ethernet |
| HTTP event forwarding and test event | `/api/http_api_settings`, `/api/test_http_api` | Settings → Network · HTTP event API |
| NTP server, interval, timezone list, sync now, phone-time sync | `/api/ntp_settings`, `/api/ntp_sync_now`, `/api/ntp_sync_browser` | Settings → Time |
| MikroTik RouterOS integration and connection test | `/api/mikrotik_settings`, `/api/test_mikrotik` | Settings → MikroTik |
| WS2812 effect, colors, speed and brightness | `/api/led_settings` | Settings → Lighting |
| Client-initiated disconnect LED alert | `/api/disconnect_led_settings` | Settings → Lighting |
| Weekly scheduler and quiet-hours action | `/api/schedule_settings` | Settings → Automation |
| Deauth whitelist, up to 32 MAC entries | `/api/whitelist` | Settings → Access control |
| Device language | `/api/language` | Settings → App experience |
| Backup, restore and backup metadata | `/api/backup_settings`, `/api/restore_settings`, `/api/backup_info` | Settings → Firmware / Maintenance |
| Device, chip, memory, PSRAM and build information | `/api/firmware_info` | Settings → Firmware / Maintenance |
| Manual ESP32 OTA | `/update` multipart upload, form field `firmware` | Settings → Firmware / Maintenance |
| Update capability status | `/api/check_update` | Settings → Firmware / Maintenance |
| Reboot, Wi-Fi restart, factory reset, return to setup | `/reboot`, `/wifi_restart`, `/factory_reset`, `/force_setup` | Settings → Firmware / Maintenance |

The app loads advanced configuration modules sequentially to avoid opening many simultaneous HTTP connections to the ESP32 WebServer. The advanced settings forms are not overwritten by the regular telemetry polling while the user is editing them. A failed module load is reported rather than silently replacing values with defaults.

## Firmware compatibility and security changes

The matching source is in the sibling `WAPFireVF38/` folder of the full compatibility package.

- The app uploads OTA images with the exact `firmware` multipart field expected by VF38.
- The MikroTik settings read API no longer returns the saved router password. It returns `password_set`; blank or omitted password updates preserve the stored credential.
- The supplied VF38 firmware exposes `/api/mobile_settings` as an authenticated, read-only snapshot for the native app. It includes `beacon_mode` and `ap_pass_set` without returning the SoftAP passphrase. The existing WebUI continues using `/api/settings`.
- Beacon response is managed by the firmware alongside Self-Protect; the supplied VF38 settings read response does not expose a separate `beacon_mode` field.
- The app includes the firmware's `/force_setup` operation.
- The supplied firmware baseline retains the verified WPA2 retry / WPA3 SAE Status Code 1 behavior and the client-originated-only disconnect LED behavior.
- The firmware build tag is exposed in `/api/firmware_info` so the installed build can be identified from the app.

## Update service note

This VF38 source has no configured online release manifest/provider. Its `/api/check_update` endpoint reports that automatic update checking is not configured. The native app states this explicitly. Manual OTA using a local ESP32 `.bin` image is implemented.

## Build requirements

- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 (wrapper)
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

Open this folder in Android Studio and run **app → Tasks → build → assembleDebug**. On Windows, run `build-apk.bat`.

Application ID: `io.wapfire.mobile`  
Version: `4.1.1` (versionCode 41)  
Minimum Android: 10 (API 29)

## Operational cautions

- Backup files contain administrator, WAPFire Wi-Fi, MikroTik and device settings. Store them privately.
- During OTA, keep the board powered. Use a firmware image built for the exact ESP32 target and matching partition layout.
- Factory reset erases saved configuration. Return to initial setup changes the configured/setup state while retaining the saved credentials and advanced settings.
- The Android app uses the device's authenticated local HTTP session. Do not expose the firmware web server to an untrusted network.


## 3.0.1 settings refinement

See `CHANGELOG-3.0.1.md` for the settings UX changes and the VF38 `WAPFIRE_BUILD_TAG` include-order correction. Beacon mode is shown as a Self-Protect-managed state, not an independent credential toggle.


## WAPFire device discovery (3.2.10)

WAPFire SoftAPs are identified by the BSSID signature `02:57:41:xx:xx:xx`; the firmware preserves the factory-derived final three octets for a per-device suffix. The Android app filters nearby Wi-Fi scan results by this BSSID signature instead of relying on the SSID text, so users can rename the SoftAP without breaking discovery. Both **Current Network → Use network** and **Device Discovery → Scan nearby devices** run the WAPFire-only discovery flow. Unrelated Wi-Fi networks are not shown. Android 10 (API 29) remains the minimum supported version; no Android 11-only Beacon Information Element API is used.
