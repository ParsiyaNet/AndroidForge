# WAPFire Mobile 4.1.50

- Renamed the assistant tab and setup presentation to Nara (نارا).
- Updated the live character title, speech label, and accessibility description to identify Nara as the WAPFire network guardian.
- Kept the AndroidForge `v06_clean.livliv` character model unchanged; its embedded model metadata already declares the name Nara.
- Updated the assistant bootstrap asset/build version and Android versionCode to 91 / versionName 4.1.50.
- Corrected the character notice to identify the v06_clean package.


## Character framing correction (4.1.50 fit update)

- Reduced the LivLiv character zoom in the Assistant view so the left/right edges and upper silhouette remain inside the frame.
- Added a small downward pan in both views; the Overview preview places Nara slightly lower to prevent the top of the head from being clipped.
- Added a small bottom inset to the full Assistant stage so the lower frame edge sits below the character with breathing room.
- Kept the selected 4.1.50 model, textures, labels, UI and runtime behavior unchanged.
- Increased Android versionCode to 92 for install-as-update compatibility while retaining versionName 4.1.50.

### Assistant layout refinement (build 93)
- Overview character framing is slightly more zoomed-in, with a small upward compensation to keep the lower silhouette visible.
- Full Assistant places the Monitoring pill centered at the top, aligned with the Close and theme controls.
- Full Assistant now renders the live speech text in its own native card below the character frame, matching the Overview speech-card treatment.
- The native state selector remains below the speech card.
