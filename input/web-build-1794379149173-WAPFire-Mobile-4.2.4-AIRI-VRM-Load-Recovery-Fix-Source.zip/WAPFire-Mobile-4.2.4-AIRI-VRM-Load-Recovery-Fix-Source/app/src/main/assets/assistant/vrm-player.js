import * as THREE from './vendor/three.module.js';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from './vendor/three-vrm.module.min.js';
import {
  createVRMAnimationClip,
  VRMAnimationLoaderPlugin,
  VRMLookAtQuaternionProxy,
} from './vendor/three-vrm-animation.module.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const EYE_SACCADE_STEP_MS = 400;
const EYE_SACCADE_CDF = [
  [0.075, 800], [0.110, 0], [0.125, 0], [0.140, 0], [0.125, 0],
  [0.050, 0], [0.040, 0], [0.030, 0], [0.020, 0], [1.000, 0],
];
for (let i = 1; i < EYE_SACCADE_CDF.length; i++) {
  EYE_SACCADE_CDF[i][0] += EYE_SACCADE_CDF[i - 1][0];
  EYE_SACCADE_CDF[i][1] = EYE_SACCADE_CDF[i - 1][1] + EYE_SACCADE_STEP_MS;
}
function randomSaccadeInterval() {
  const r = Math.random();
  for (const [probability, start] of EYE_SACCADE_CDF) {
    if (r <= probability) return start + Math.random() * EYE_SACCADE_STEP_MS;
  }
  const last = EYE_SACCADE_CDF.at(-1);
  return last[1] + Math.random() * EYE_SACCADE_STEP_MS;
}

const STATE_EMOTIONS = {
  idle: 'neutral', scanning: 'neutral', connecting: 'think',
  success: 'happy', password_success: 'happy',
  password_warning: 'surprised', warning: 'surprised',
  angry: 'angry', offline: 'sad', setup: 'think',
};
const EMOTION_PRESETS = {
  neutral: { expressions: [], blend: 0.60 },
  happy: { expressions: [['joy', 0.70], ['happy', 0.70]], blend: 0.40 },
  sad: { expressions: [['sorrow', 0.70], ['sad', 0.70]], blend: 0.40 },
  angry: { expressions: [['angry', 0.70]], blend: 0.30 },
  surprised: { expressions: [['surprised', 0.80]], blend: 0.15 },
  think: { expressions: [['fun', 0.42], ['relaxed', 0.42]], blend: 0.50 },
  relaxed: { expressions: [['fun', 0.70], ['relaxed', 0.70]], blend: 0.40 },
};
const EXPRESSION_ALIASES = {
  joy: ['joy', 'happy'], happy: ['happy', 'joy'],
  sorrow: ['sorrow', 'sad'], sad: ['sad', 'sorrow'],
  surprised: ['surprised', 'Surprised'],
  angry: ['angry', 'Angry'], fun: ['fun', 'relaxed'],
  relaxed: ['relaxed', 'fun'],
};

/** AIRI-derived VRM companion renderer. No audio, speech or remote runtime assets. */
export class Player {
  constructor(canvas, options = {}) {
    if (!(canvas instanceof HTMLCanvasElement)) throw new TypeError('AIRI VRM requires a canvas element.');
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({
      canvas, alpha: true, antialias: true, powerPreference: 'high-performance',
      preserveDrawingBuffer: true, premultipliedAlpha: true, depth: true, stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    // AvatarSample_A uses KHR_materials_unlit; keep its authored anime colors intact.
    this.renderer.toneMapping = THREE.NoToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.setClearColor(0x000000, 0);
    this.maxAnisotropy = Math.min(this.renderer.capabilities.getMaxAnisotropy(), 8);
    this.pixelRatio = Math.min(options.maxPixelRatio || window.devicePixelRatio || 1, 2.0);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.01, 100);
    this.scene.add(new THREE.HemisphereLight(0xe4f2ff, 0x29364a, 1.35));
    const key = new THREE.DirectionalLight(0xfff5ec, 2.0);
    key.position.set(-2.7, 4.5, -4.0);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x9bd7ff, 0.82);
    fill.position.set(3.0, 2.2, 3.0);
    this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xb4d7ff, 0.38);
    rim.position.set(-1.5, 2.6, 3.5);
    this.scene.add(rim);

    this.model = { name: 'AvatarSample_A', canvas: [1024, 1536] };
    this.puppet = { model: { canvas: [1024, 1536] }, zoom: 1, panY: 0 };
    this.view = { x: 0, y: -0.025, zoom: 1 };
    this.vrm = null;
    this.vrmGroup = null;
    this.mixer = null;
    this.idleAction = null;
    this.idleClip = null;
    this.idleFallbackActive = false;
    this.idleFallbackBones = null;
    this.bounds = new THREE.Box3();
    this.center = new THREE.Vector3(0, 0.9, 0);
    this.dimensions = new THREE.Vector3(0.7, 1.7, 0.4);

    this.lookTarget = new THREE.Object3D();
    this.scene.add(this.lookTarget);
    this.lookAtBase = new THREE.Vector3();
    this.fixationTarget = new THREE.Vector3();
    this.lookOffset = { x: 0, y: 0 };
    this.saccadeElapsed = 0;
    this.nextSaccadeAfter = -1;

    this.clock = 0;
    this.blinking = false;
    this.blinkProgress = 0;
    this.blinkSuppressed = false;
    this.blinkElapsed = 0;
    this.nextBlinkAfter = 1 + Math.random() * 5;
    this.emoteName = null;
    this.emoteProgress = 1;
    this.emoteBlendDuration = 0.6;
    this.emoteStartValues = new Map();
    this.emoteTargetValues = new Map();
    this.emoteOwnedNames = new Set();
    this.state = 'idle';
    this.transientExpressionUntil = -1;
    this.away = false;

    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.raf = 0;
    this.lastFrame = 0;
    this.disposed = false;
    this.visible = true;
    this.onContextLost = null;

    this._onContextLost = (event) => { event.preventDefault(); this.pause(); this.onContextLost?.(); };
    this._onVisibility = () => {
      this.visible = document.visibilityState !== 'hidden';
      if (this.visible && options.autoplay !== false) this.play();
    };
    this._onPointerDown = (event) => {
      if (!this.vrm || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return;
      const rect = this.canvas.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      this.pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1,
        -(((event.clientY - rect.top) / rect.height) * 2 - 1));
      this.raycaster.setFromCamera(this.pointer, this.camera);
      if (this.raycaster.intersectObject(this.vrmGroup || this.vrm.scene, true).length) this.triggerTouch();
    };
    canvas.addEventListener('webglcontextlost', this._onContextLost, false);
    canvas.addEventListener('pointerdown', this._onPointerDown, { passive: true });
    document.addEventListener('visibilitychange', this._onVisibility);
    this.resize();
    if (options.autoplay !== false) this.play();
  }

  _createLoader() {
    const loader = new GLTFLoader();
    loader.crossOrigin = 'anonymous';
    loader.register(parser => new VRMLoaderPlugin(parser));
    loader.register(parser => new VRMAnimationLoaderPlugin(parser));
    return loader;
  }

  async load(url, { onProgress } = {}) {
    if (this.disposed) throw new Error('Renderer was disposed before model load.');
    const gltf = await this._createLoader().loadAsync(url, event => {
      if (event.total > 0 && onProgress) onProgress({ step: 'model', progress: clamp(event.loaded / event.total, 0, 1) });
    });
    const vrm = gltf?.userData?.vrm;
    if (!vrm?.scene || !vrm?.humanoid) throw new Error('AvatarSample_A has no valid VRM humanoid rig.');
    this.vrm = vrm;

    // AvatarSample_A is VRM 0.x (it contains the legacy `VRM` glTF extension).
    // Normalize legacy forward to the -Z direction expected by AIRI's stage camera.
    // VRM 1.x continues to use AIRI's faceFront-vector alignment below.
    const legacyVrm0 = !!gltf?.parser?.json?.extensions?.VRM ||
      String(vrm.meta?.metaVersion || '').startsWith('0');
    if (legacyVrm0 && typeof VRMUtils.rotateVRM0 === 'function') {
      try { VRMUtils.rotateVRM0(vrm); }
      catch (error) { console.warn('VRM0 orientation normalization skipped; preserving the loaded avatar.', error); }
    }

    // Keep the supplied AvatarSample_A meshes and UV/material bindings intact. Only use
    // the conservative skeleton merge; skip vertex cleanup on this textured VRM 0.x model.
    try { VRMUtils.combineSkeletons(vrm.scene); } catch (e) { console.warn('AIRI skeleton optimization skipped', e); }
    let materialCount = 0;
    let mappedMaterialCount = 0;
    const colorTextures = new Set();
    vrm.scene.traverse(object => {
      object.frustumCulled = false;
      const materials = Array.isArray(object.material) ? object.material : (object.material ? [object.material] : []);
      for (const material of materials) {
        if (!material) continue;
        materialCount++;
        if (material.map?.isTexture) {
          mappedMaterialCount++;
          colorTextures.add(material.map);
          material.map.colorSpace = THREE.SRGBColorSpace;
          material.map.anisotropy = this.maxAnisotropy;
          material.map.needsUpdate = true;
        }
        if (material.emissiveMap?.isTexture) {
          material.emissiveMap.colorSpace = THREE.SRGBColorSpace;
          material.emissiveMap.anisotropy = this.maxAnisotropy;
          material.emissiveMap.needsUpdate = true;
          colorTextures.add(material.emissiveMap);
        }
        for (const value of Object.values(material)) {
          if (value?.isTexture) {
            value.anisotropy = this.maxAnisotropy;
            value.needsUpdate = true;
          }
        }
        if (material.isMeshBasicMaterial) material.toneMapped = false;
        material.needsUpdate = true;
      }
    });
    this.model.textureCount = colorTextures.size;
    this.model.texturedMaterials = mappedMaterialCount;
    const textureReport = {
      materials: materialCount, texturedMaterials: mappedMaterialCount, uniqueColorTextures: colorTextures.size,
      legacyVrm0
    };
    if (mappedMaterialCount === 0 || colorTextures.size === 0) {
      // Do not abort a valid VRM because a material extension exposes its texture differently.
      // Keep the original materials untouched and let WebGL render the model normally.
      console.warn('AvatarSample_A texture map diagnostic returned zero; continuing with loader materials.', textureReport);
    } else {
      console.info('AvatarSample_A texture verification:', JSON.stringify(textureReport));
    }

    if (vrm.lookAt) {
      const proxy = new VRMLookAtQuaternionProxy(vrm.lookAt);
      proxy.name = 'lookAtQuaternionProxy';
      vrm.scene.add(proxy);
    }
    this.vrmGroup = new THREE.Group();
    this.vrmGroup.add(vrm.scene);
    this.scene.add(this.vrmGroup);
    this.vrmGroup.updateMatrixWorld(true);

    if (!legacyVrm0 && vrm.lookAt?.faceFront) {
      const faceFront = vrm.lookAt.faceFront.clone().normalize();
      const airiForward = new THREE.Vector3(0, 0, -1);
      const facing = new THREE.Quaternion().setFromUnitVectors(faceFront, airiForward);
      this.vrmGroup.quaternion.premultiply(facing);
      this.vrmGroup.updateMatrixWorld(true);
    }
    vrm.springBoneManager?.reset();

    // AIRI excludes spring-bone collider helper meshes from camera bounds.
    this.bounds.makeEmpty();
    const childBounds = new THREE.Box3();
    vrm.scene.updateMatrixWorld(true);
    vrm.scene.traverse(object => {
      if (!object.visible || object.name?.startsWith('VRMC_springBone_collider')) return;
      const mesh = object;
      if (!mesh.isMesh || !mesh.geometry) return;
      if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
      if (mesh.geometry.boundingBox) {
        childBounds.copy(mesh.geometry.boundingBox).applyMatrix4(mesh.matrixWorld);
        this.bounds.union(childBounds);
      }
    });
    if (this.bounds.isEmpty()) throw new Error('AvatarSample_A contains no visible mesh geometry.');
    this.bounds.getCenter(this.center);
    this.bounds.getSize(this.dimensions);
    // Keep the model at its true geometric center; no extra vertical shift.
    if (!Number.isFinite(this.dimensions.y) || this.dimensions.y < 0.2) throw new Error('VRM model bounds are invalid.');

    this.model.name = vrm.meta?.title || vrm.meta?.name || 'AvatarSample_A';
    this.model.format = `VRM ${vrm.meta?.metaVersion || '0.x'}`;
    if (vrm.lookAt) {
      vrm.lookAt.target = this.lookTarget;
      this.lookAt(0, 0, true);
    }
    this._updateCamera();
    this.resize();
    if (onProgress) onProgress({ step: 'model', progress: 1 });
    return this;
  }

  // AIRI's loadVRMAnimation -> createVRMAnimationClip -> reAnchorRootPositionTrack pipeline.
  async loadIdleMotion(url, { onProgress } = {}) {
    if (!this.vrm) throw new Error('Load AvatarSample_A before its AIRI motion.');
    const gltf = await this._createLoader().loadAsync(url);
    const animation = gltf?.userData?.vrmAnimations?.[0];
    if (!animation) throw new Error('idle_loop.vrma has no VRMC_vrm_animation payload.');
    const clip = createVRMAnimationClip(animation, this.vrm);
    if (!clip || !clip.tracks?.length || !(clip.duration > 0)) throw new Error('AIRI idle_loop produced an empty animation clip.');
    this.reAnchorRootPositionTrack(clip, this.vrm);
    clip.name = 'AIRI_Idle_Loop';
    this.mixer = new THREE.AnimationMixer(this.vrm.scene);
    this.idleClip = clip;
    this.idleAction = this.mixer.clipAction(clip);
    this.idleAction.setLoop(THREE.LoopRepeat, Infinity);
    this.idleAction.clampWhenFinished = false;
    this.idleAction.enabled = true;
    this.idleAction.setEffectiveTimeScale(1.0);
    this.idleAction.setEffectiveWeight(1.0);
    this.idleAction.play();
    this.idleFallbackActive = false;
    if (onProgress) onProgress({ step: 'motion', progress: 1, name: 'idle_loop' });
    this._applyStateExpression();
    console.info('AIRI idle motion installed:', JSON.stringify({ duration: clip.duration, tracks: clip.tracks.length }));
    return clip;
  }

  // Keep a correctly loaded textured avatar if the optional VRMA clip is unavailable.
  // AIRI idle_loop is still the primary animation; this low-amplitude local fallback is
  // used only when the clip cannot be installed on this device/model combination.
  enableIdleFallback() {
    if (!this.vrm || this.idleAction) return false;
    const humanoid = this.vrm.humanoid;
    if (!humanoid?.getNormalizedBoneNode) return false;
    const specs = [
      ['hips', 0], ['spine', 0], ['chest', 0], ['neck', 0], ['head', 0],
      ['leftUpperArm', 1.02], ['rightUpperArm', -1.02],
      ['leftLowerArm', 0.14], ['rightLowerArm', -0.14],
    ];
    const pose = [];
    for (const [name, zOffset] of specs) {
      const bone = humanoid.getNormalizedBoneNode(name);
      if (!bone) continue;
      pose.push({ bone, rotation: bone.rotation.clone(), position: bone.position.clone(), zOffset });
    }
    if (!pose.length) return false;
    this.idleFallbackBones = pose;
    this.idleFallbackActive = true;
    console.warn('AIRI idle_loop unavailable; local low-amplitude idle fallback enabled.');
    return true;
  }

  _updateIdleFallback() {
    if (!this.idleFallbackActive || !this.idleFallbackBones) return;
    const t = this.clock;
    const wave = Math.sin(t * 1.05);
    for (const item of this.idleFallbackBones) {
      item.bone.rotation.copy(item.rotation);
      item.bone.position.copy(item.position);
      if (item.zOffset) item.bone.rotation.z += item.zOffset;
    }
    const bone = name => this.idleFallbackBones.find(item => item.bone.name.toLowerCase().includes(name));
    const hips = bone('hips');
    const spine = bone('spine');
    const chest = bone('chest');
    const neck = bone('neck');
    const head = bone('head');
    if (hips) hips.bone.position.y += 0.0035 * wave;
    if (spine) spine.bone.rotation.x += 0.0045 * wave;
    if (chest) chest.bone.rotation.x += 0.008 * wave;
    if (neck) neck.bone.rotation.x += 0.004 * Math.sin(t * 0.72 + 0.4);
    if (head) {
      head.bone.rotation.x += 0.010 * Math.sin(t * 0.58 + 0.7);
      head.bone.rotation.z += 0.008 * Math.sin(t * 0.43);
    }
  }

  reAnchorRootPositionTrack(clip, vrm) {
    const hips = vrm.humanoid?.getNormalizedBoneNode('hips');
    if (!hips) { console.warn('AIRI idle motion: normalized hips bone not found.'); return; }
    const track = clip.tracks.find(item => item instanceof THREE.VectorKeyframeTrack && item.name === `${hips.name}.position`);
    if (!(track instanceof THREE.VectorKeyframeTrack)) {
      console.warn('AIRI idle motion: Hips.position track is missing.'); return;
    }
    const defaultHipPosition = hips.position.clone();
    const animationHipPosition = new THREE.Vector3(track.values[0], track.values[1], track.values[2]);
    const delta = animationHipPosition.sub(defaultHipPosition);
    for (const positionTrack of clip.tracks) {
      if (!positionTrack.name.endsWith('.position') || !(positionTrack instanceof THREE.VectorKeyframeTrack)) continue;
      for (let i = 0; i < positionTrack.values.length; i += 3) {
        positionTrack.values[i] -= delta.x;
        positionTrack.values[i + 1] -= delta.y;
        positionTrack.values[i + 2] -= delta.z;
      }
    }
  }

  _expressionName(name) {
    const manager = this.vrm?.expressionManager;
    if (!manager) return null;
    for (const candidate of (EXPRESSION_ALIASES[name] || [name])) {
      if (manager.getExpression?.(candidate)) return candidate;
    }
    return null;
  }

  _setExpression(name, value) {
    const actual = this._expressionName(name);
    if (actual) this.vrm.expressionManager.setValue(actual, clamp(value, 0, 1));
  }

  _startEmotion(emotionName, intensity = 1) {
    const preset = EMOTION_PRESETS[emotionName] || EMOTION_PRESETS.neutral;
    const manager = this.vrm?.expressionManager;
    this.emoteName = emotionName;
    this.emoteProgress = 0;
    this.emoteBlendDuration = preset.blend || 0.4;
    this.emoteStartValues.clear();
    this.emoteTargetValues.clear();

    if (!manager) return;
    const targets = new Map();
    for (const [requested, value] of preset.expressions || []) {
      const actual = this._expressionName(requested);
      if (actual) targets.set(actual, clamp(value * intensity, 0, 1));
    }
    const owned = new Set(this.emoteOwnedNames);
    for (const name of targets.keys()) owned.add(name);
    for (const name of owned) {
      this.emoteStartValues.set(name, manager.getValue(name) || 0);
      this.emoteTargetValues.set(name, targets.get(name) || 0);
    }
    this.emoteOwnedNames = owned;
  }

  _applyStateExpression() {
    this.transientExpressionUntil = -1;
    this._startEmotion(STATE_EMOTIONS[this.state] || 'neutral');
  }

  _isEmoteActive() {
    const mouthOnly = name => ['aa', 'ee', 'ih', 'oh', 'ou'].includes(name.toLowerCase());
    for (const [name, value] of this.emoteTargetValues) {
      if (value > 0.001 && !mouthOnly(name)) return true;
    }
    if (this.emoteProgress < 1) {
      for (const [name, value] of this.emoteStartValues) {
        if (value > 0.001 && !mouthOnly(name)) return true;
      }
    }
    return false;
  }

  _updateEmote(delta) {
    const manager = this.vrm?.expressionManager;
    if (!manager || !this.emoteStartValues.size) return;
    this.emoteProgress = Math.min(1, this.emoteProgress + delta / Math.max(0.05, this.emoteBlendDuration));
    const t = this.emoteProgress;
    const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    for (const [name, target] of this.emoteTargetValues) {
      const start = this.emoteStartValues.get(name) || 0;
      manager.setValue(name, this.emoteProgress >= 1 ? target : start + (target - start) * eased);
    }
    if (this.emoteProgress >= 1 && this.emoteName === 'neutral') {
      this.emoteName = null;
      this.emoteStartValues.clear();
      this.emoteTargetValues.clear();
      this.emoteOwnedNames.clear();
    }
  }

  setState(value, force = false) {
    const next = Object.prototype.hasOwnProperty.call(STATE_EMOTIONS, String(value || '').toLowerCase())
      ? String(value).toLowerCase() : 'idle';
    if (!force && next === this.state) return;
    this.state = next;
    this._applyStateExpression();
    const gaze = next === 'scanning' ? -0.38 : (next === 'warning' || next === 'password_warning' || next === 'angry') ? 0.22 : 0;
    this.lookAt(gaze, next === 'scanning' ? 0.10 : 0);
    this.fixationTarget.copy(this.lookAtBase);
  }

  setExpression(expression) {
    if (!expression) { this._applyStateExpression(); return; }
    const aliases = { smile: 'happy', happy: 'happy', shy: 'relaxed', sad: 'sad', angry: 'angry', surprised: 'surprised' };
    this._startEmotion(aliases[expression] || expression, 0.65);
  }

  setAway(value) { this.away = !!value; }

  triggerTouch() {
    if (!this.vrm) return false;
    this.transientExpressionUntil = this.clock + 1.35;
    this._startEmotion('happy', 0.72);
    this.blinkElapsed = this.nextBlinkAfter;
    return true;
  }

  lookAt(x, y = 0, instant = false) {
    this.lookOffset = { x: clamp(Number(x) || 0, -1, 1), y: clamp(Number(y) || 0, -1, 1) };
    if (!this.vrm?.lookAt) return;
    const headY = this.bounds.isEmpty() ? 1.35 : this.bounds.min.y + this.dimensions.y * 0.84;
    const headX = this.center.x + this.lookOffset.x * this.dimensions.x * 0.9;
    const headZ = this.center.z - Math.max(this.dimensions.y * 2.6, 2.5);
    this.lookAtBase.set(headX, headY + this.lookOffset.y * this.dimensions.y * 0.22, headZ);
    if (instant) {
      this.fixationTarget.copy(this.lookAtBase);
      this.lookTarget.position.copy(this.lookAtBase);
      this.vrm.lookAt.target = this.lookTarget;
      this.vrm.lookAt.update(0.016);
    }
  }

  blink() { this.blinkElapsed = this.nextBlinkAfter; }

  // AIRI's 0.2s sine blink, random interval 1–6s, and safe suppression handling.
  _updateBlink(vrm, delta, suppress = false) {
    if (!vrm?.expressionManager) return;
    this.blinkElapsed += delta;
    if (!this.blinking && this.blinkElapsed >= this.nextBlinkAfter) {
      this.blinking = true;
      this.blinkProgress = 0;
      this.blinkSuppressed = false;
    }
    if (this.blinking) {
      this.blinkProgress += delta / 0.2;
      const suppressed = this.away || suppress;
      if (suppressed) this.blinkSuppressed = true;
      const value = this.blinkSuppressed ? 0 : Math.sin(Math.PI * this.blinkProgress);
      this._setExpression('blink', value);
      if (this.blinkProgress >= 1) {
        this.blinking = false;
        this.blinkSuppressed = false;
        this.blinkElapsed = 0;
        this._setExpression('blink', 0);
        this.nextBlinkAfter = 1 + Math.random() * 5;
      }
    } else if (this.away || suppress) {
      this._setExpression('blink', 0);
    }
  }

  // AIRI's probabilistic idle saccades: 0.8–4.4s interval, small fixation offsets.
  _updateIdleEyeSaccades(vrm, delta) {
    if (!vrm?.expressionManager || !vrm.lookAt) return;
    this.saccadeElapsed += delta;
    if (this.saccadeElapsed >= this.nextSaccadeAfter) {
      this.fixationTarget.set(
        this.lookAtBase.x + THREE.MathUtils.randFloat(-0.25, 0.25),
        this.lookAtBase.y + THREE.MathUtils.randFloat(-0.25, 0.25),
        this.lookAtBase.z,
      );
      this.saccadeElapsed = 0;
      this.nextSaccadeAfter = randomSaccadeInterval() / 1000;
    }
    if (!vrm.lookAt.target) vrm.lookAt.target = this.lookTarget;
    vrm.lookAt.target.position.lerp(this.fixationTarget, 1);
  }

  _updateExpressions(delta) {
    if (!this.vrm?.expressionManager) return;
    if (this.transientExpressionUntil > 0 && this.clock >= this.transientExpressionUntil) {
      this.transientExpressionUntil = -1;
      this._applyStateExpression();
    }
    this._updateEmote(delta);
  }

  _updateCamera() {
    if (!this.vrm || this.bounds.isEmpty()) return;
    const width = Math.max(1, this.canvas.clientWidth || this.canvas.getBoundingClientRect().width);
    const height = Math.max(1, this.canvas.clientHeight || this.canvas.getBoundingClientRect().height);
    const aspect = Math.max(0.25, width / height);
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov / 2);
    const heightDistance = this.dimensions.y / (2 * Math.tan(halfFov));
    const widthDistance = this.dimensions.x / (2 * Math.tan(halfFov) * aspect);
    const zoom = clamp(this.view.zoom || 1, 0.75, 1.25);
    // Match the conservative 1.10 camera-fit margin from the earlier WAPFire VRM renderer.
    const distance = Math.max(heightDistance, widthDistance, 1) * 1.04 / zoom;
    const targetY = this.center.y - (this.view.y || 0) * this.dimensions.y;
    const targetX = this.center.x + (this.view.x || 0) * this.dimensions.x;
    this.camera.position.set(targetX, targetY, this.center.z - distance);
    this.camera.lookAt(targetX, targetY, this.center.z);
    this.camera.near = Math.max(0.01, distance / 100);
    this.camera.far = distance + this.dimensions.y * 5 + 10;
    this.camera.updateProjectionMatrix();
    if (this.vrm.lookAt) this.lookAt(this.lookOffset.x, this.lookOffset.y, true);
  }

  resize() {
    if (this.disposed) return;
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.max(1, this.canvas.clientWidth || rect.width || 1);
    const height = Math.max(1, this.canvas.clientHeight || rect.height || 1);
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(width, height, false);
    this._updateCamera();
    this._renderOnce();
  }

  _update(delta) {
    if (!this.vrm) return;
    this.clock += delta;
    // Match AIRI's stage-ui-three frame pipeline; voice/lip-sync is intentionally omitted.
    this.mixer?.update(delta);
    this._updateIdleFallback();
    this.vrm.materials?.forEach(material => material.update?.(delta));
    this.vrm.humanoid?.update();
    this._updateIdleEyeSaccades(this.vrm, delta);
    this.vrm.lookAt?.update?.(delta);
    this._updateBlink(this.vrm, delta, this._isEmoteActive());
    this._updateExpressions(delta);
    this.vrm.expressionManager?.update?.();
    this.vrm.nodeConstraintManager?.update?.();
    this.vrm.springBoneManager?.update?.(delta);
  }

  _renderOnce() {
    if (!this.disposed && this.renderer && this.visible) this.renderer.render(this.scene, this.camera);
  }

  _frame = (timestamp) => {
    if (!this.raf || this.disposed) return;
    const raw = this.lastFrame ? (timestamp - this.lastFrame) / 1000 : 1 / 60;
    this.lastFrame = timestamp;
    const delta = clamp(raw, 0, 1 / 20);
    if (this.visible) { this._update(delta); this.renderer.render(this.scene, this.camera); }
    this.raf = requestAnimationFrame(this._frame);
  };

  play() { if (!this.disposed && !this.raf) { this.lastFrame = 0; this.raf = requestAnimationFrame(this._frame); } }
  pause() { if (this.raf) cancelAnimationFrame(this.raf); this.raf = 0; this.lastFrame = 0; }

  dispose() {
    if (this.disposed) return;
    this.pause(); this.disposed = true;
    this.canvas.removeEventListener('webglcontextlost', this._onContextLost, false);
    this.canvas.removeEventListener('pointerdown', this._onPointerDown, false);
    document.removeEventListener('visibilitychange', this._onVisibility);
    if (this.vrmGroup) { this.scene.remove(this.vrmGroup); try { VRMUtils.deepDispose(this.vrmGroup); } catch (_) {} }
    this.renderer.dispose();
    this.vrm = null; this.vrmGroup = null; this.mixer = null; this.idleAction = null; this.idleClip = null; this.idleFallbackBones = null;
  }
}
