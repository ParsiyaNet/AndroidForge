# WAPFire Mobile 4.2.4 — AIRI VRM load recovery

- Restored the renderer camera FOV and fit margin to the preceding WAPFire VRM framing values.
- Removed the fatal texture-map assertion; texture inspection is now diagnostic only.
- Made VRM 0.x orientation normalization fail-safe.
- Kept a loaded avatar alive when optional motion or first-frame diagnostics report a warning.
- Preserved the 4.2.0 native dashboard and Overview UI.
- No voice, TTS, or speech-recognition features.

This is a source package. APK compilation and on-device rendering still require an Android build and device test.
