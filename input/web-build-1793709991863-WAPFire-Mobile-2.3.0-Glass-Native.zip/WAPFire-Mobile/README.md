# WAPFire Mobile 2.3.0 — Native Glass Control Center

A standalone Android application for WAPFire VF38. The UI is implemented in native Kotlin + Jetpack Compose; it does not embed the firmware WebUI or use a WebView.

## Interface
- Unified four-area navigation: Overview, Clients, Events and Settings.
- Target access-point selection is grouped inside Settings under Monitoring & Target; it is no longer a separate bottom-navigation tab.
- Translucent layered surfaces, soft ambient lighting, subtle specular borders and a consistent glass-style card system across dashboard, clients, events and settings.
- English and Persian interface options, including RTL layout; dark and light appearance.
- Security events use the exact firmware-facing names: Auth Attack, Deauth Attack, Deauth Airplay, WPS Pixie Reaver, WPS Pixie Bully, Evil Twin, WPA Correct Password and WPA Wrong Password. Technical event IDs are translated for titles and visible detail text.
- Event messages auto-dismiss after a short interval and the close control clears the active message.

## Core workflows
- Nearby WAPFire discovery, local subnet discovery and manual device address entry.
- Sign-in using the firmware `wg_auth` session cookie.
- First-run setup for administrator password and WAPFire access-point credentials.
- Live status dashboard with threat assessment, target state, traffic telemetry, radio activity chart and firmware detection labels.
- Target scan, exact SSID/BSSID/channel selection and target clearing, all inside Settings.
- Tracked client list and device event timeline.
- Native controls for self-protect, automatic channel tracking, LED, smart LED, sound alerts and SoftAP.
- Explicit logout calls the firmware `/logout` route, clears the local session and transient device state, and releases the Wi-Fi network binding.

## Firmware API
The project is aligned to the supplied `WAPFireVF38.ino` source in the WAPFireVF38 VF38 archive. Core calls include `/login`, `/logout`, `/api/status`, `/api/settings`, `/api/chart_data`, `/api/firmware_info`, `/api/logs`, `/api/tracked_clients`, `/api/scan`, `/api/select_target`, `/api/save_target`, and `/api/clear_logs`.

The current native Settings view intentionally exposes only controls wired to the verified core settings API. Advanced modules such as Ethernet, NTP, schedules, MikroTik, whitelist management, backup/restore and OTA are not represented as pretend controls; those require their own fully wired native screens and are not claimed as part of this 2.3.0 pass.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK Platform 35, then build `app` → `assembleDebug`. On Windows, `build-apk.bat` runs the same task. The project uses Gradle 8.9, Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

Application ID: `io.wapfire.mobile`  
Version: `2.3.0`  
Minimum Android: 10 (API 29)
