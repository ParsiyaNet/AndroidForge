# 4.1.63 — Tile surface isolation + denser bottom navigation

## Tile rendering fix
- Metric tiles now use a nearly opaque rounded glass body. This prevents any underlying native view or
  composition artifact from showing as a separate hard-edged rectangle inside the tile.
- The shared liquid-glass modifier now supports a `surfaceOpacity` blend, while preserving the original
  translucent appearance for other components that do not opt in.

## Parked assistant WebViews
- Parked WebViews remain attached and measured during warm-up. Before their first rendered frame they stay
  alpha-zero so initialization can continue; after readiness they switch to `View.INVISIBLE`, which prevents
  the native hardware layer from drawing at all.
- When a screen adopts a WebView, visibility and alpha are restored before resuming it.

## Bottom navigation
- The floating navigation body now blends to a nearly opaque glass surface.
- The selected tab capsule and rim have stronger contrast for dark-mode labels.

## Version
- `versionName`: 4.1.63
- `versionCode`: 109
