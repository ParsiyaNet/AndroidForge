# Project Desktop — Prototype 1

A native Android desktop-like workspace prototype built with Kotlin and Jetpack Compose.

## Included in this source drop
- Desktop canvas with configurable background and accent colors
- App-owned floating Notes and Calculator windows
- Dragging, resizing, minimize/restore, maximize/restore, close, and z-order
- Configurable taskbar visibility and icon sizing
- Alternate window-management menu when the taskbar is hidden
- Two workspaces with independent window arrangements
- Persistent notes and basic settings using Android SharedPreferences
- Desktop Builder settings panel
- Installed-app discovery/launching through Android package APIs (best-effort; see limitations)

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Use JDK 17. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.
If Android Studio proposes a compatible Gradle wrapper, accept it. The wrapper is intentionally not bundled in this source archive.

## Important scope notes
This is a working prototype foundation, not a complete third-party window manager. Android apps normally cannot embed other apps as freely movable child windows inside this app. Launching an installed app hands control to Android's activity/task system. Behavior depends on Android version, app manifest declarations, manufacturer customization, and multi-window support.

The prototype uses SharedPreferences for compact local persistence to keep this initial source drop easy to build. For a production version, migrate settings to Preferences DataStore and workspace/window records to Room, then add automated UI/instrumentation coverage.
