package com.projectdesktop

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

private val Ink = Color(0xFF172033)
private val Panel = Color(0xFFF8FAFC)
private val Muted = Color(0xFF64748B)
private val DefaultAccent = Color(0xFF6D5DFB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DesktopApp() }
    }
}

private data class DeskWindow(
    val id: String,
    val title: String,
    var x: Float,
    var y: Float,
    var w: Float,
    var h: Float,
    var minimized: Boolean = false,
    var maximized: Boolean = false,
    var oldX: Float = x,
    var oldY: Float = y,
    var oldW: Float = w,
    var oldH: Float = h
)

@Composable
private fun DesktopApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("desktop", 0) }
    var backgroundHex by remember { mutableStateOf(prefs.getString("background", "#EAF0F8") ?: "#EAF0F8") }
    var accentHex by remember { mutableStateOf(prefs.getString("accent", "#6D5DFB") ?: "#6D5DFB") }
    var taskbarVisible by remember { mutableStateOf(prefs.getBoolean("taskbar", true)) }
    var taskbarHeight by remember { mutableFloatStateOf(prefs.getFloat("taskbarHeight", 56f)) }
    var showSettings by remember { mutableStateOf(false) }
    var showApps by remember { mutableStateOf(false) }
    var showWindowMenu by remember { mutableStateOf(false) }
    var activeWorkspace by remember { mutableIntStateOf(prefs.getInt("workspace", 0).coerceIn(0, 1)) }
    var notes by remember { mutableStateOf(prefs.getString("notes", "Welcome to Project Desktop.\\n\\nDrag this window by its title bar, resize from the bottom-right corner, and open Desktop Builder to customize your space.") ?: "") }
    var calculatorInput by remember { mutableStateOf("0") }
    var calcResult by remember { mutableStateOf("") }
    var windows by remember {
        mutableStateOf(loadWindows(prefs, 0).ifEmpty {
            listOf(
                DeskWindow("notes", "Notes", 18f, 28f, 300f, 280f),
                DeskWindow("calculator", "Calculator", 42f, 330f, 270f, 310f)
            )
        })
    }
    val accent = parseColor(accentHex, DefaultAccent)
    val bg = parseColor(backgroundHex, Color(0xFFEAF0F8))
    var screenSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }

    fun saveState() {
        prefs.edit()
            .putString("background", backgroundHex)
            .putString("accent", accentHex)
            .putBoolean("taskbar", taskbarVisible)
            .putFloat("taskbarHeight", taskbarHeight)
            .putString("notes", notes)
            .putInt("workspace", activeWorkspace)
            .putString("windows_$activeWorkspace", windowsToJson(windows))
            .apply()
    }
    fun openWindow(id: String) {
        val current = windows.toMutableList()
        val existing = current.indexOfFirst { it.id == id }
        if (existing >= 0) {
            current[existing] = current[existing].copy(minimized = false)
            val selected = current.removeAt(existing)
            current.add(selected)
        } else {
            current.add(if (id == "notes") DeskWindow("notes", "Notes", 22f, 30f, 300f, 280f)
            else DeskWindow("calculator", "Calculator", 38f, 54f, 270f, 310f))
        }
        windows = current
        saveState()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = accent, background = bg, surface = Panel)) {
        BoxWithConstraints(
            Modifier.fillMaxSize().background(bg)
                .onSizeChanged { screenSize = it }
        ) {
            // Desktop wallpaper and simple ambient marks
            Box(Modifier.fillMaxSize().background(bg))
            Box(Modifier.align(Alignment.TopEnd).padding(22.dp).size(160.dp).clip(CircleShape).background(accent.copy(alpha = 0.07f)))
            Column(Modifier.align(Alignment.TopStart).padding(18.dp)) {
                Text("PROJECT", fontSize = 12.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Desktop", fontSize = 28.sp, color = Ink, fontWeight = FontWeight.Bold)
                Text("Workspace ${activeWorkspace + 1}", fontSize = 13.sp, color = Muted)
            }
            Row(
                Modifier.align(Alignment.TopEnd).padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmallAction(Icons.Default.Apps, "Applications") { showApps = true }
                SmallAction(Icons.Default.Tune, "Desktop Builder") { showSettings = true }
                SmallAction(Icons.Default.MoreVert, "Window controls") { showWindowMenu = true }
            }

            // Windows are drawn in z-order, with the final element on top.
            windows.forEachIndexed { index, win ->
                if (!win.minimized) {
                    DesktopWindowFrame(
                        win = win,
                        accent = accent,
                        notes = notes,
                        onNotes = { notes = it; prefs.edit().putString("notes", it).apply() },
                        calcInput = calculatorInput,
                        onCalcInput = { calculatorInput = it },
                        calcResult = calcResult,
                        onCalc = {
                            calcResult = evaluateSimple(calculatorInput)
                        },
                        onFocus = {
                            val list = windows.toMutableList()
                            val i = list.indexOfFirst { it.id == win.id }
                            if (i >= 0 && i != list.lastIndex) {
                                val item = list.removeAt(i)
                                list.add(item)
                                windows = list
                            }
                        },
                        onMove = { dx, dy ->
                            windows = windows.map { if (it.id == win.id) it.copy(
                                x = (it.x + dx).coerceAtLeast(0f),
                                y = (it.y + dy).coerceAtLeast(0f)
                            ) else it }
                        },
                        onResize = { dx, dy ->
                            windows = windows.map { if (it.id == win.id) it.copy(
                                w = (it.w + dx).coerceIn(210f, 520f),
                                h = (it.h + dy).coerceIn(180f, 620f)
                            ) else it }
                        },
                        onMinimize = { windows = windows.map { if (it.id == win.id) it.copy(minimized = true) else it }; saveState() },
                        onMaximize = {
                            windows = windows.map {
                                if (it.id == win.id) {
                                    if (!it.maximized) it.copy(oldX=it.x, oldY=it.y, oldW=it.w, oldH=it.h, x=0f, y=60f, w=(maxWidth.value-8).coerceAtLeast(220f), h=(maxHeight.value-taskbarHeight-80).coerceAtLeast(220f), maximized=true)
                                    else it.copy(x=it.oldX, y=it.oldY, w=it.oldW, h=it.oldH, maximized=false)
                                } else it
                            }
                        },
                        onClose = { windows = windows.filterNot { it.id == win.id }; saveState() },
                        onSave = ::saveState
                    )
                }
            }

            if (taskbarVisible) {
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                        .height(taskbarHeight.dp).clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(1.dp, Color.White, RoundedCornerShape(20.dp)).padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Icon(Icons.Default.Widgets, null, tint = accent, modifier = Modifier.size(23.dp))
                    windows.forEach { win ->
                        if (win.minimized) {
                            Button(onClick = { openWindow(win.id) }, contentPadding = PaddingValues(horizontal=12.dp, vertical=7.dp)) {
                                Text(win.title, fontSize=12.sp)
                            }
                        } else {
                            OutlinedButton(onClick = {
                                val list = windows.toMutableList()
                                val i = list.indexOfFirst { it.id == win.id }
                                if (i >= 0) { val w = list.removeAt(i); list.add(w); windows = list }
                            }, contentPadding = PaddingValues(horizontal=10.dp, vertical=7.dp)) {
                                Text(win.title, fontSize=12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { val target = 1 - activeWorkspace; prefs.edit().putString("windows_$activeWorkspace", windowsToJson(windows)).apply(); activeWorkspace = target; windows = loadWindows(prefs, target).ifEmpty { emptyList() }; saveState() }) {
                        Text("WS ${activeWorkspace + 1}", color=Ink)
                    }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, "Desktop Builder", tint=accent) }
                }
            }

            if (showWindowMenu) {
                AlertDialog(
                    onDismissRequest = { showWindowMenu = false },
                    title = { Text("Window controls") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { openWindow("notes"); showWindowMenu=false }, modifier=Modifier.fillMaxWidth()) { Text("Open Notes") }
                            Button(onClick = { openWindow("calculator"); showWindowMenu=false }, modifier=Modifier.fillMaxWidth()) { Text("Open Calculator") }
                            Button(onClick = { showSettings=true; showWindowMenu=false }, modifier=Modifier.fillMaxWidth()) { Text("Desktop Builder") }
                            Button(onClick = { showApps=true; showWindowMenu=false }, modifier=Modifier.fillMaxWidth()) { Text("Installed applications") }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showWindowMenu=false }) { Text("Done") } }
                )
            }

            if (showSettings) {
                DesktopBuilder(
                    backgroundHex = backgroundHex, accentHex = accentHex,
                    taskbarVisible = taskbarVisible, taskbarHeight = taskbarHeight,
                    onBackground = { backgroundHex=it; saveState() },
                    onAccent = { accentHex=it; saveState() },
                    onTaskbar = { taskbarVisible=it; saveState() },
                    onTaskbarHeight = { taskbarHeight=it; saveState() },
                    onReset = {
                        backgroundHex="#EAF0F8"; accentHex="#6D5DFB"; taskbarVisible=true; taskbarHeight=56f
                        windows = listOf(DeskWindow("notes","Notes",18f,28f,300f,280f), DeskWindow("calculator","Calculator",42f,330f,270f,310f))
                        saveState()
                    },
                    onDismiss = { showSettings=false }
                )
            }
            if (showApps) {
                InstalledAppsDialog(onDismiss={showApps=false})
            }
        }
    }
}

@Composable
private fun DesktopWindowFrame(
    win: DeskWindow,
    accent: Color,
    notes: String,
    onNotes: (String) -> Unit,
    calcInput: String,
    onCalcInput: (String) -> Unit,
    calcResult: String,
    onCalc: () -> Unit,
    onFocus: () -> Unit,
    onMove: (Float, Float) -> Unit,
    onResize: (Float, Float) -> Unit,
    onMinimize: () -> Unit,
    onMaximize: () -> Unit,
    onClose: () -> Unit,
    onSave: () -> Unit
) {
    var previousResize by remember(win.id) { mutableStateOf(Offset.Zero) }
    val safeX = win.x.coerceAtLeast(0f)
    val safeY = win.y.coerceAtLeast(0f)
    Column(
        Modifier.offset { IntOffset(safeX.roundToInt(), safeY.roundToInt()) }
            .width(win.w.dp).height(win.h.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFD8DFEA), RoundedCornerShape(16.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().height(42.dp).background(Color(0xFFF7F8FC))
                .pointerInput(win.id) {
                    detectDragGestures(onDragStart={onFocus()}) { change, drag ->
                        change.consume()
                        onMove(drag.x, drag.y)
                    }
                }.padding(start=12.dp, end=5.dp),
            verticalAlignment=Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
            Spacer(Modifier.width(8.dp))
            Text(win.title, modifier=Modifier.weight(1f), color=Ink, fontWeight=FontWeight.SemiBold, fontSize=13.sp)
            IconButton(onClick=onMinimize, modifier=Modifier.size(30.dp)) { Icon(Icons.Default.Remove, "Minimize", tint=Muted, modifier=Modifier.size(17.dp)) }
            IconButton(onClick=onMaximize, modifier=Modifier.size(30.dp)) { Icon(Icons.Default.OpenInFull, "Maximize or restore", tint=Muted, modifier=Modifier.size(15.dp)) }
            IconButton(onClick=onClose, modifier=Modifier.size(30.dp)) { Icon(Icons.Default.Close, "Close", tint=Muted, modifier=Modifier.size(17.dp)) }
        }
        if (win.id == "notes") {
            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Text("QUICK NOTE", color=accent, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.3.sp)
                Spacer(Modifier.height(8.dp))
                BasicTextField(
                    value=notes, onValueChange=onNotes,
                    modifier=Modifier.fillMaxSize().background(Color(0xFFFCFCFE), RoundedCornerShape(8.dp)).padding(8.dp),
                    textStyle=androidx.compose.ui.text.TextStyle(color=Ink, fontSize=14.sp, lineHeight=20.sp),
                    decorationBox = { inner -> Box { if (notes.isEmpty()) Text("Write something...", color=Muted); inner() } }
                )
            }
        } else {
            Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("CALCULATOR", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.2.sp)
                Spacer(Modifier.height(8.dp))
                Text(calcInput, color=Ink, fontSize=23.sp, fontWeight=FontWeight.SemiBold, maxLines=1)
                Text(calcResult.ifEmpty { " " }, color=accent, fontSize=15.sp)
                Spacer(Modifier.height(8.dp))
                val keys = listOf("7","8","9","÷","4","5","6","×","1","2","3","−","C","0",".","+","=")
                keys.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        row.forEach { key ->
                            Button(
                                onClick = {
                                    when (key) {
                                        "C" -> { onCalcInput("0") }
                                        "=" -> onCalc()
                                        else -> onCalcInput(if (calcInput=="0") key else calcInput+key)
                                    }
                                },
                                modifier=Modifier.weight(1f).height(39.dp),
                                contentPadding=PaddingValues(0.dp),
                                colors=ButtonDefaults.buttonColors(containerColor=if(key in listOf("÷","×","−","+","=")) accent else Color(0xFFF0F2F8), contentColor=if(key in listOf("÷","×","−","+","=")) Color.White else Ink)
                            ) { Text(key, fontSize=15.sp) }
                        }
                        repeat(4-row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(10.dp).pointerInput(win.id, win.w, win.h) {
            detectDragGestures(onDragStart={previousResize=Offset.Zero}) { change, drag ->
                change.consume()
                previousResize += drag
                onResize(drag.x, drag.y)
            }
        }.background(Color.Transparent), contentAlignment=Alignment.BottomEnd) {
            Box(Modifier.padding(end=4.dp, bottom=2.dp).size(8.dp).background(accent.copy(alpha=.65f), RoundedCornerShape(3.dp)))
        }
    }
}

@Composable
private fun DesktopBuilder(
    backgroundHex: String, accentHex: String, taskbarVisible: Boolean, taskbarHeight: Float,
    onBackground: (String)->Unit, onAccent: (String)->Unit, onTaskbar: (Boolean)->Unit,
    onTaskbarHeight: (Float)->Unit, onReset: ()->Unit, onDismiss: ()->Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={ Text("Desktop Builder", fontWeight=FontWeight.Bold) },
        text={
            LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.heightIn(max=520.dp)) {
                item { Text("COMPONENTS", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.2.sp) }
                item {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Taskbar", fontWeight=FontWeight.SemiBold); Text("Show app window switcher", color=Muted, fontSize=12.sp) }
                        Switch(checked=taskbarVisible, onCheckedChange=onTaskbar)
                    }
                }
                item { HorizontalDivider() }
                item { Text("APPEARANCE", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.2.sp) }
                item { ColorChoices("Background", backgroundHex, listOf("#EAF0F8","#F8F5EF","#182235","#E8F6F1"), onBackground) }
                item { ColorChoices("Accent", accentHex, listOf("#6D5DFB","#007F86","#D65A31","#B83B72"), onAccent) }
                item {
                    Column {
                        Text("Taskbar height · ${taskbarHeight.toInt()} dp")
                        Slider(value=taskbarHeight, onValueChange=onTaskbarHeight, valueRange=44f..76f)
                    }
                }
                item { Text("BEHAVIOR", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.2.sp) }
                item { Text("Windows can be moved by dragging their title bars and resized using the bottom-right grip.", color=Muted, fontSize=13.sp) }
                item { OutlinedButton(onClick={confirmReset=true}, modifier=Modifier.fillMaxWidth()) { Text("Reset to defaults") } }
            }
        },
        confirmButton={ TextButton(onClick=onDismiss) { Text("Done") } }
    )
    if (confirmReset) {
        AlertDialog(
            onDismissRequest={confirmReset=false},
            title={Text("Reset desktop?")},
            text={Text("This restores the default colors, taskbar, and starter window layout.")},
            confirmButton={TextButton(onClick={onReset(); confirmReset=false}) { Text("Reset") }},
            dismissButton={TextButton(onClick={confirmReset=false}) { Text("Cancel") }}
        )
    }
}

@Composable
private fun ColorChoices(label: String, selected: String, colors: List<String>, onSelect: (String)->Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Text(label, fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            colors.forEach { hex ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(parseColor(hex, Color.Gray))
                        .border(if(hex.equals(selected,true)) 3.dp else 1.dp, if(hex.equals(selected,true)) Ink else Color.LightGray, CircleShape)
                        .padding(4.dp),
                    contentAlignment=Alignment.Center
                ) {
                    if(hex.equals(selected,true)) Icon(Icons.Default.Check, null, tint=if(hex=="#182235") Color.White else Ink, modifier=Modifier.size(17.dp))
                }
                // Tap target layered over the swatch.
                Box(Modifier.offset(x=(-34).dp).size(34.dp).pointerInput(hex) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            if (event.changes.any { it.pressed }) onSelect(hex)
                        }
                    }
                })
            }
        }
    }
}

@Composable
private fun SmallAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: ()->Unit) {
    FilledTonalIconButton(onClick=onClick, modifier=Modifier.size(42.dp)) {
        Icon(icon, contentDescription=label)
    }
}

@Composable
private fun InstalledAppsDialog(onDismiss: ()->Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .map { it.activityInfo }
            .distinctBy { it.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
    }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Installed applications")},
        text={
            if (apps.isEmpty()) Text("No launchable applications were found.")
            else LazyColumn(Modifier.heightIn(max=440.dp)) {
                items(apps) { info ->
                    TextButton(
                        onClick={
                            val launch = pm.getLaunchIntentForPackage(info.packageName)
                            if (launch != null) {
                                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                runCatching { context.startActivity(launch) }
                            }
                            onDismiss()
                        },
                        modifier=Modifier.fillMaxWidth()
                    ) {
                        Text(info.loadLabel(pm).toString(), modifier=Modifier.weight(1f))
                        Icon(Icons.Default.Launch, null)
                    }
                }
            }
        },
        confirmButton={TextButton(onClick=onDismiss) { Text("Close")}}
    )
}

private fun parseColor(hex: String, fallback: Color): Color = runCatching {
    val clean = hex.removePrefix("#")
    Color(android.graphics.Color.parseColor("#$clean"))
}.getOrDefault(fallback)

private fun windowsToJson(windows: List<DeskWindow>): String {
    val array = JSONArray()
    windows.forEach {
        array.put(JSONObject().put("id",it.id).put("title",it.title).put("x",it.x).put("y",it.y)
            .put("w",it.w).put("h",it.h).put("minimized",it.minimized).put("maximized",it.maximized)
            .put("oldX",it.oldX).put("oldY",it.oldY).put("oldW",it.oldW).put("oldH",it.oldH))
    }
    return array.toString()
}

private fun loadWindows(prefs: android.content.SharedPreferences, workspace: Int): List<DeskWindow> {
    val raw = prefs.getString("windows_$workspace", null) ?: return emptyList()
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DeskWindow(
                id=o.optString("id"), title=o.optString("title"),
                x=o.optDouble("x",20.0).toFloat().coerceAtLeast(0f),
                y=o.optDouble("y",30.0).toFloat().coerceAtLeast(0f),
                w=o.optDouble("w",280.0).toFloat().coerceIn(210f,520f),
                h=o.optDouble("h",260.0).toFloat().coerceIn(180f,620f),
                minimized=o.optBoolean("minimized",false), maximized=o.optBoolean("maximized",false),
                oldX=o.optDouble("oldX",20.0).toFloat(), oldY=o.optDouble("oldY",30.0).toFloat(),
                oldW=o.optDouble("oldW",280.0).toFloat(), oldH=o.optDouble("oldH",260.0).toFloat()
            )
        }.filter { it.id in setOf("notes","calculator") }
    }.getOrDefault(emptyList())
}

private fun evaluateSimple(raw: String): String {
    return try {
        val normalized = raw.replace("×","*").replace("÷","/").replace("−","-").replace(" ","")
        val match = Regex("^(-?\\d+(?:\\.\\d+)?)([+*/-])(-?\\d+(?:\\.\\d+)?)$").matchEntire(normalized)
            ?: return "Enter: number operator number"
        val a = match.groupValues[1].toDouble()
        val op = match.groupValues[2]
        val b = match.groupValues[3].toDouble()
        val result = when(op) {
            "+" -> a+b
            "-" -> a-b
            "*" -> a*b
            "/" -> if (b == 0.0) return "Cannot divide by zero" else a/b
            else -> return "Invalid expression"
        }
        if (!result.isFinite()) "Invalid result" else result.toString().removeSuffix(".0")
    } catch (_: Exception) {
        "Invalid expression"
    }
}
