# Prototype feature status

## Implemented in source
- Kotlin + Jetpack Compose Android app
- App-owned Notes and Calculator windows
- Dragging by title bar; resizing from bottom grip
- Minimize, maximize/restore, close, focus ordering
- Taskbar toggle and window menu fallback
- Background/accent preset selection and taskbar height
- Two workspace slots with persisted window arrangement
- Persistent notes and compact preference persistence
- Best-effort launcher-app discovery and launch handoff
- Reset confirmation dialog

## Not yet implemented / needs hardening
- Room-backed workspace model and DataStore migration
- Robust arbitrary arithmetic expression parser (calculator currently accepts a simple binary expression)
- Full dynamic component registry/dependency system
- Rename/create arbitrary numbers of workspaces (two fixed slots in this prototype)
- Taskbar positioning and icon-size controls
- Window borders/transparency/title-bar component toggles
- Snapping, keyboard shortcuts, external display handling
- Automated unit/UI tests and device test report
- Release signing configuration

This status is intentionally conservative. A visible control is not counted as a feature unless it changes behavior.
