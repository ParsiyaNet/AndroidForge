# Android application integration limitations

- The prototype can query activities that advertise a launcher intent and request Android to launch them.
- Android package visibility rules apply. The manifest declares launcher-intent queries rather than requesting broad package visibility.
- Starting an external app transfers control to Android's activity/task manager. It does not embed the app as a child view inside this app's canvas.
- True movable external windows depend on Android's multi-window/freeform capabilities, app support, device manufacturer, and system privileges. This app does not request root, accessibility-based screen scraping, or privileged system permissions.
- The app does not replace Android's system status bar, navigation bar, or home screen.
