(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const language = fa ? 'fa' : 'en';
  const $ = (id) => document.getElementById(id);
  // WebView can dispatch late renderer callbacks while the page is being recreated.
  // Never assume optional UI nodes still exist when an async callback runs.
  const classAction = (element, action, ...args) => {
    const list = element && element.classList;
    if (list && typeof list[action] === 'function') list[action](...args);
  };
  const native = () => window.WapFireNative;
  const report = (message) => {
    try { native()?.reportStatus(message == null ? null : String(message).slice(0, 850)); }
    catch (e) { console.error('WAPFire native status bridge unavailable', e); }
  };
  const text = (faText, enText) => fa ? faText : enText;

  window.__wfPreflightStarted = true;
  document.documentElement.lang = language;
  document.documentElement.dir = fa ? 'rtl' : 'ltr';
  document.documentElement.style.direction = fa ? 'rtl' : 'ltr';
  if (document.body) { document.body.dir = fa ? 'rtl' : 'ltr'; document.body.style.direction = fa ? 'rtl' : 'ltr'; }
  classAction(document.body, 'toggle', 'compact', q.get('compact') !== '0');
  window.__wfInitialState = q.get('state') || 'idle';
  window.__wfPendingState = window.__wfInitialState;
  window.__wfLanguage = language;

  window.wapfireSetState = (state) => {
    window.__wfPendingState = String(state || 'idle');
    if (typeof window.__wfApplyState === 'function') window.__wfApplyState(window.__wfPendingState);
  };
  window.wapfireSetLanguage = (nextLanguage) => {
    const next = nextLanguage === 'en' ? 'en' : 'fa';
    if (next !== language) {
      const compact = !!document.body?.classList?.contains('compact');
      location.search = `?compact=${compact ? '1' : '0'}&lang=${next}&state=${encodeURIComponent(window.__wfPendingState || 'idle')}`;
    }
  };

  window.addEventListener('error', (event) => {
    const detail = event.message || event.target?.src || event.target?.href || 'Unknown script/resource error';
    // Browser favicon fetches are decorative metadata and must never be surfaced as an assistant failure.
    if (/favicon\.ico(?:$|[?#])/i.test(String(detail))) return;
    const stack = event.error?.stack ? ` | ${String(event.error.stack).slice(0, 500)}` : '';
    report(text('خطای JavaScript/Asset: ', 'JavaScript/asset error: ') + String(detail).slice(0, 160) + stack);
  }, true);
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const detail = reason?.stack || reason?.message || String(reason || 'Unhandled promise rejection');
    report(text('خطای اجرای دستیار: ', 'Assistant runtime error: ') + String(detail).slice(0, 600));
  });

  const controlLabels = {
    en: {idle:'Idle', scanning:'Scanning', connecting:'Connecting', success:'Connected', password_success:'Pass OK', password_warning:'Wrong pass', warning:'Warning', angry:'Attack', offline:'Offline', setup:'Setup'},
    fa: {idle:'آماده', scanning:'پایش', connecting:'اتصال', success:'متصل', password_success:'رمز صحیح', password_warning:'رمز اشتباه', warning:'هشدار', angry:'حمله', offline:'آفلاین', setup:'راه‌اندازی'}
  };
  for (const button of document.querySelectorAll('[data-state]')) {
    button.textContent = controlLabels[language][button.dataset.state] || button.textContent;
  }

  const labels = {
    idle: {en:['All clear. I am keeping an eye on your network.','Ready'],fa:['همه‌چیز مرتبه؛ دارم مراقب شبکه‌ات هستم.','آماده‌به‌کار'],expr:null,action:null},
    scanning:{en:['I am checking the radio activity around your network.','Monitoring'],fa:['دارم فعالیت‌های رادیویی اطراف شبکه را بررسی می‌کنم.','در حال پایش'],expr:null,action:'tilt'},
    connecting:{en:['One moment… I am reconnecting to your WAPFire device.','Connecting'],fa:['یک لحظه… دارم دوباره به دستگاه WAPFire وصل می‌شوم.','در حال اتصال'],expr:'shy',action:'nod'},
    success:{en:['Wonderful! The connection is back and everything is ready.','Connected'],fa:['عالی شد! اتصال برقرار است و همه‌چیز آماده است.','متصل شد'],expr:'smile',action:'hop'},
    password_success:{en:['The correct Wi-Fi password was confirmed. Nice work!','Password accepted'],fa:['رمز صحیح Wi‑Fi تأیید شد. عالیه!','رمز صحیح'],expr:'smile',action:'hop'},
    password_warning:{en:['That password was not accepted. Please check it before trying again.','Wrong password'],fa:['این رمز تأیید نشد؛ قبل از تلاش دوباره آن را بررسی کن.','رمز اشتباه'],expr:'shy',action:'tilt'},
    warning:{en:['Careful! I found suspicious activity that needs your attention.','Threat detected'],fa:['مراقب باش! فعالیت مشکوکی پیدا کردم که باید بررسی شود.','هشدار امنیتی'],expr:'shy',action:'nod'},
    angry:{en:['An attack has been detected. Stay alert!','Attack detected'],fa:['یک حمله شناسایی شد؛ هوشیار باش!','حمله شناسایی شد'],expr:'angry',action:'shake'},
    offline:{en:['I cannot reach your WAPFire device right now.','Device offline'],fa:['فعلاً نمی‌توانم به دستگاه WAPFire دسترسی پیدا کنم.','دستگاه در دسترس نیست'],expr:'sad',action:'tilt'},
    setup:{en:['Let us finish the first setup together.','Setup required'],fa:['بیا راه‌اندازی اولیه را با هم کامل کنیم.','نیازمند راه‌اندازی'],expr:'shy',action:'tilt'}
  };

  let player = null;
  let activeState = '';
  let ready = false;
  let pendingState = window.__wfPendingState;
  let stageObserver = null;
  let resizeRaf = 0;

  function showState(name, force=false) {
    const state = labels[name] ? name : 'idle';
    pendingState = state;
    window.__wfPendingState = state;
    if (!ready || !player || (!force && activeState === state)) return;

    const shell = $('shell');
    const speechText = $('speechText');
    const stateText = $('stateText');
    const dot = $('dot');
    if (!shell || !speechText || !stateText || !dot) {
      report(text('ساختار صفحه دستیار ناقص است؛ عناصر پیام یا وضعیت پیدا نشدند.', 'Assistant DOM is incomplete: one or more speech/state elements are missing.'));
      return;
    }

    activeState = state;
    const row = labels[state];
    const copy = fa ? row.fa : row.en;
    shell.dataset.state = state;
    speechText.textContent = copy[0];
    stateText.textContent = copy[1];
    // Enforce direction at the actual speech elements, not only at <html>.
    const direction = fa ? 'rtl' : 'ltr';
    for (const element of [speechText, speechText.parentElement]) {
      if (element) { element.dir = direction; element.style.direction = direction; element.style.textAlign = fa ? 'right' : 'left'; }
    }
    const isDanger = state === 'angry';
    const isWarning = state === 'warning' || state === 'password_warning';
    const isSuccess = state === 'success' || state === 'password_success';
    dot.style.color = isDanger ? 'var(--red)' : isWarning ? 'var(--amber)' : isSuccess ? 'var(--green)' : state === 'offline' ? 'var(--amber)' : 'var(--blue)';
    for (const button of document.querySelectorAll('[data-state]')) classAction(button, 'toggle', 'active', button.dataset.state === state);
    try {
      player.setAway(false);
      player.setExpression(row.expr);
      player.lookAt(state === 'scanning' ? -0.4 : (state === 'warning' || state === 'password_warning' || state === 'angry') ? 0.25 : null, state === 'scanning' ? 0.18 : 0);
      if (row.action) player.act(row.action);
      if (state === 'success' || state === 'password_success') player.blink();
    } catch (error) {
      console.error('LivLiv state reaction failed:', error);
      report(text('واکنش کاراکتر اجرا نشد: ', 'Character reaction failed: ') + String(error?.stack || error).slice(0, 420));
    }
  }
  window.__wfApplyState = (state) => { try { showState(String(state)); } catch (error) { console.error('Assistant state update failed:', error); report(String(error?.stack || error).slice(0, 600)); } };
  for (const button of document.querySelectorAll('[data-state]')) button.addEventListener('click', () => { try { showState(button.dataset.state, true); } catch (error) { console.error('Assistant control failed:', error); report(String(error?.stack || error).slice(0, 600)); } });

  async function probeAsset(path) {
    try {
      const response = await fetch(path, {cache:'no-store'});
      const type = response.headers.get('content-type') || '(no content-type)';
      const bytes = await response.arrayBuffer();
      return `${path}: HTTP ${response.status}, ${type}, ${bytes.byteLength} bytes`;
    } catch (error) {
      return `${path}: FETCH FAILED (${error?.message || error})`;
    }
  }

  async function diagnose(error, phase) {
    const probes = await Promise.all([
      probeAsset('./dist/index.js'),
      probeAsset('./dist/chunks/base-p0Sx5Qp5.js'),
      probeAsset('./characters/k01.livliv')
    ]);
    const detail = `${phase}: ${error?.message || error}; ${probes.join(' | ')}`;
    console.error('WAPFire LivLiv diagnostic:', detail);
    const loading = $('loading');
    if (loading) {
      classAction(loading, 'add', 'error');
      loading.textContent = text('خطای موتور: ', 'Renderer error: ') + detail.slice(0, 320);
    }
    report(detail);
  }

  const nextFrame = () => new Promise(resolve => requestAnimationFrame(() => resolve()));

  async function waitForCanvasLayout(canvas) {
    // Compose's WebView is hosted inside a LazyColumn item. Some Android WebView builds resolve
    // percentage heights to zero on the first layout pass even though the native View is measured.
    // Give the HTML stage its own minimum block size, then let the normal parent size take over.
    const compactMode = q.get('compact') !== '0';
    const fallbackHeight = compactMode ? 200 : Math.max(320, Math.min(window.innerHeight || 480, 1200));
    const shell = $('shell');
    const stage = canvas.parentElement;
    for (const element of [document.documentElement, document.body, shell, stage]) {
      if (element && element.getBoundingClientRect().height < 32) {
        element.style.minHeight = `${fallbackHeight}px`;
      }
    }
    // Keep the same safe minimum used by the previously working 4.1.28 renderer.
    // A definite canvas height is required before WebGL allocates its drawing buffer.
    canvas.style.minHeight = `${fallbackHeight}px`;
    canvas.style.width = '100%';
    canvas.style.height = '100%';

    // Allow Compose/WebView and Chromium to complete their layout before creating WebGL.
    for (let i = 0; i < 24; i++) {
      await nextFrame();
      const r = canvas.getBoundingClientRect();
      if (r.width >= 32 && r.height >= 32) return r;
    }
    const r = canvas.getBoundingClientRect();
    const shellRect = shell.getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    throw new Error(`Canvas layout failed (canvas ${Math.round(r.width)}x${Math.round(r.height)}, stage ${Math.round(stageRect.width)}x${Math.round(stageRect.height)}, shell ${Math.round(shellRect.width)}x${Math.round(shellRect.height)}).`);
  }

  function verifyFirstFrame(canvas, player) {
    const gl = canvas.getContext('webgl2');
    if (!gl || gl.isContextLost()) throw new Error('WebGL2 context is unavailable or was lost after model load.');
    const w = canvas.width, h = canvas.height;
    if (w < 32 || h < 32) throw new Error(`WebGL drawing buffer is too small (${w}x${h}).`);

    // Clear stale GL errors from texture upload/driver setup before checking the first frame.
    for (let i = 0; i < 8; i++) {
      if (gl.getError() === gl.NO_ERROR) break;
    }
    player.resize();
    gl.finish();
    if (gl.isContextLost()) throw new Error('WebGL2 context was lost while drawing the first frame.');

    // Read only a small central sample. Reading the entire full-screen buffer can allocate
    // tens of megabytes on high-DPI Android devices and can itself destabilize WebView.
    const sampleW = Math.min(96, w);
    const sampleH = Math.min(96, h);
    const sampleX = Math.max(0, Math.floor((w - sampleW) / 2));
    const sampleY = Math.max(0, Math.floor((h - sampleH) / 2));
    const pixels = new Uint8Array(sampleW * sampleH * 4);
    gl.readPixels(sampleX, sampleY, sampleW, sampleH, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const glError = gl.getError();
    let visiblePixels = 0;
    for (let i = 3; i < pixels.length; i += 4) if (pixels[i] > 12) visiblePixels++;
    const result = {width:w,height:h,sampleWidth:sampleW,sampleHeight:sampleH,visiblePixels,glError};
    console.info('WAPFire first-frame verification:', JSON.stringify(result));

    // This is diagnostic only. A transparent or delayed first sample must not dispose a
    // successfully loaded model; animation gets a chance to draw normally after play().
    if (glError !== gl.NO_ERROR || visiblePixels < 3) {
      report(`First-frame sample warning: ${sampleW}x${sampleH}, alpha=${visiblePixels}, GL=${glError}`);
      console.warn('LivLiv first-frame sample was inconclusive; continuing renderer startup.', result);
    }
    return result;
  }

  async function boot(Player) {
    window.__wfEngineBooted = true;
    report(text('ماژول LivLiv بارگذاری شد؛ در حال آماده‌سازی Canvas…', 'LivLiv module loaded; preparing canvas…'));
    const compactMode = q.get('compact') !== '0';
    classAction(document.body, 'toggle', 'compact', compactMode);
    classAction(document.body, 'toggle', 'full', !compactMode);
    const loading = $('loading');
    if (!loading) throw new Error('Assistant loading element #loading is missing from the page.');
    try {
      const canvas = $('stage');
      const rect = await waitForCanvasLayout(canvas);
      // Bound both pixel density and total buffer area. High-DPI full-screen WebViews
      // otherwise create very large WebGL buffers on devices with modest graphics memory.
      const pixelBudget = compactMode ? 900_000 : 1_800_000;
      const area = Math.max(1, rect.width * rect.height);
      const ratio = Math.max(1, Math.min(window.devicePixelRatio || 1, 1.5, Math.sqrt(pixelBudget / area)));
      canvas.width = Math.max(1, Math.round(rect.width * ratio));
      canvas.height = Math.max(1, Math.round(rect.height * ratio));
      report(text('Canvas آماده است؛ در حال ساخت موتور گرافیکی…', 'Canvas has a valid size; creating the graphics engine…'));
      // Do not start the animation loop until the canvas has its final WebView/Compose size.
      player = new Player(canvas, {idle:true,followPointer:'canvas',maxPixelRatio:ratio,lang:language,autoplay:false});
      // Keep the Overview framing compact. In the full portrait view, zoom out enough to
      // give the model breathing room above the dedicated status/control footer.
      const viewAspect = rect.width / rect.height;
      // The previous 0.76/0.82 values made Sena look undersized. Use a closer crop
      // while preserving the model's proportions; the framed stage and blurred poster fill
      // the remaining side/bottom space instead of stretching the character.
      const fullZoom = viewAspect < 0.55 ? 1.10 : viewAspect < 0.72 ? 1.06 : 1.00;
      player.view.x = 0;
      player.view.y = 0;
      player.view.zoom = compactMode ? 1.38 : fullZoom;
      player.onContextLost = () => {
        ready=false;
        if (loading.isConnected) {
          classAction(loading, 'remove', 'hide');
          classAction(loading, 'add', 'error');
          loading.textContent = text('شتاب‌دهندهٔ گرافیکی متوقف شد؛ صفحه را دوباره باز کن.', 'Graphics context lost. Reopen this screen.');
        }
        report(loading.textContent);
      };
      report(text('در حال دریافت مدل و تکسچرهای محلی…', 'Loading local character package and textures…'));
      await player.load('./characters/k01.livliv', {
        poster:'./characters/k01/cover.webp',
        onProgress:(progress) => {
          if (progress.step === 'download') {
            const message = text(`بارگذاری کاراکتر… ${Math.round(progress.progress*100)}٪`, `Loading character… ${Math.round(progress.progress*100)}%`);
            loading.textContent = message;
            report(message);
          }
        }
      });
      // The model's package carries a LivLiv corner watermark. Keep that mark in the
      // dedicated Assistant view, but suppress it in the compact Overview preview;
      // the required character credit is displayed separately in Settings > Credits.
      if (compactMode && player.mark && typeof player.mark.set === 'function') {
        try {
          player.mark.set('none', null, false);
          player.resize();
        } catch (markError) {
          // Attribution-mark styling is optional and must never prevent the character from starting.
          console.warn('LivLiv overview mark styling skipped:', markError);
        }
      }
      report(text('مدل بارگذاری شد؛ در حال رسم اولین فریم…', 'Model loaded; drawing the first frame…'));
      // The Compose-hosted WebView may finish loading before its final layout pass. Re-measure and
      // resize after load, then force one synchronous frame and inspect the real WebGL framebuffer.
      await nextFrame();
      await nextFrame();
      const finalRect = canvas.getBoundingClientRect();
      if (finalRect.width < 32 || finalRect.height < 32) throw new Error(`Canvas became unavailable after model load (${Math.round(finalRect.width)}x${Math.round(finalRect.height)}).`);
      canvas.width = Math.max(1, Math.round(finalRect.width * ratio));
      canvas.height = Math.max(1, Math.round(finalRect.height * ratio));
      try {
        verifyFirstFrame(canvas, player);
      } catch (frameError) {
        if (canvas.getContext('webgl2')?.isContextLost()) throw frameError;
        // Frame sampling is diagnostic only; it must not stop the live render loop on a healthy GL context.
        console.warn('LivLiv first-frame diagnostic skipped:', frameError);
        report(`First-frame diagnostic skipped: ${String(frameError?.message || frameError).slice(0, 180)}`);
      }
      // Keep the backing buffer in sync with the real Compose/WebView size (rotation, split-screen,
      // Overview card re-layout). Ignore transient zero-size callbacks while LazyColumn is moving.
      if (typeof ResizeObserver !== 'undefined') {
        stageObserver?.disconnect();
        stageObserver = new ResizeObserver(() => {
          if (!ready || !player) return;
          const r = canvas.getBoundingClientRect();
          if (r.width < 32 || r.height < 32) return;
          cancelAnimationFrame(resizeRaf);
          resizeRaf = requestAnimationFrame(() => { try { player?.resize(); } catch (e) { console.error('LivLiv resize failed', e); } });
        });
        stageObserver.observe(canvas.parentElement || canvas);
      }
      player.play();
      // Keep a low-opacity, blurred ambient layer behind the transparent model canvas.
      const poster = $('poster');
      if (poster) poster.style.opacity = compactMode ? '.34' : '.28';
      if (loading.isConnected) loading.remove();
      ready=true;
      activeState='';
      showState(pendingState,true);
      window.__wfRendererReady=true;
      native()?.reportReady();
      console.info('WAPFire LivLiv renderer ready:', player.model?.name);
    } catch (error) {
      const failure = text(`کاراکتر بارگذاری نشد: ${error?.message || error}`, `Character could not load: ${error?.message || error}`);
      if (loading) {
        classAction(loading, 'add', 'error');
        loading.textContent = failure;
      }
      report(`${failure}${error?.stack ? ` | ${String(error.stack).slice(0, 420)}` : ''}`);
      console.error('WAPFire LivLiv assistant:', error);
      // Leave the cover visible as a useful fallback rather than removing it over a blank canvas.
      const poster = $('poster');
      if (poster) { poster.style.opacity = '.82'; poster.style.filter = 'none'; poster.style.transform = 'none'; }
      try { player?.dispose(); } catch (_) {}
      player = null;
    }
  }

  async function verifyLocalAssets() {
    const assets = [
      ['./dist/index.js', 'JavaScript engine'],
      ['./dist/chunks/base-p0Sx5Qp5.js', 'Engine core'],
      ['./dist/chunks/params-BCSFSCtz.js', 'Engine parameters'],
      ['./dist/chunks/errors-ohqiRK3N.js', 'Engine errors'],
      ['./characters/k01.livliv', 'Sena model package'],
      ['./characters/k01/cover.webp', 'Sena cover image']
    ];
    const results = await Promise.all(assets.map(async ([path, label]) => {
      const response = await fetch(path, {cache:'no-store'});
      if (!response.ok) throw new Error(`${label} failed: ${path} returned HTTP ${response.status}.`);
      const bytes = await response.arrayBuffer();
      if (!bytes.byteLength) throw new Error(`${label} is empty: ${path}.`);
      const type = response.headers.get('content-type') || '(unknown MIME)';
      if (path.endsWith('.js') && !/javascript|ecmascript/i.test(type)) {
        throw new Error(`${label} has an invalid MIME type (${type}): ${path}.`);
      }
      return `${label} OK (${bytes.byteLength} bytes, ${type})`;
    }));
    console.info('WAPFire local asset preflight:', results.join(' | '));
    report(text('فایل‌های محلی آماده‌اند؛ موتور سه‌بعدی در حال بارگذاری است…', 'Local assets verified; importing renderer…'));
    return results;
  }

  async function startEngine() {
    window.__wfPreflightStartedAt = Date.now();
    window.__wfEngineBooted = false;
    await verifyLocalAssets();
    report(text('در حال واردکردن موتور LivLiv…', 'Importing LivLiv engine…'));
    const module = await Promise.race([
      import('./dist/index.js'),
      new Promise((_, reject) => setTimeout(() => reject(new Error('LivLiv module import timed out after 20 seconds.')), 20000))
    ]);
    if (!module?.Player) throw new Error('dist/index.js loaded but did not export Player.');
    window.__wfEngineBooted = true;
    if (typeof module.Player.isSupported === 'function' && !module.Player.isSupported()) {
      throw new Error('This Android WebView does not provide a usable WebGL2 context. Update Android System WebView/Chrome and enable hardware acceleration.');
    }
    await boot(module.Player);
  }

  report(text('JavaScript فعال است؛ در حال بررسی فایل‌های محلی…', 'JavaScript is active; checking local renderer assets…'));
  startEngine().catch((error) => diagnose(error, 'LivLiv startup failed'));

  window.addEventListener('pagehide', () => { stageObserver?.disconnect(); cancelAnimationFrame(resizeRaf); try { player?.dispose(); } catch (_) {} });
})();
