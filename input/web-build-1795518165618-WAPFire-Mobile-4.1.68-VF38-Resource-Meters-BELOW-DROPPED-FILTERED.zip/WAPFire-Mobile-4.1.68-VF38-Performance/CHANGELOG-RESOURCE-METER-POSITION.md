# Resource Meter Placement Update

- Moved CPU Core 0, CPU Core 1, Internal RAM, and PSRAM meters in Settings > DEVICE STATUS to appear directly below the `Dropped / filtered` row.
- Preserved the existing meter rendering, colors, responsive layout, and telemetry bindings. No firmware or API behavior changed.
