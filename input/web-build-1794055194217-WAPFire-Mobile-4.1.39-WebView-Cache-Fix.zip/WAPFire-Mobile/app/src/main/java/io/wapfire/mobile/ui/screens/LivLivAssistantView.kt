package io.wapfire.mobile.ui.screens

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import java.io.FileNotFoundException
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalLayoutDirection
import io.wapfire.mobile.BuildConfig
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx
import androidx.webkit.WebViewAssetLoader

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ASSET_PREFIX = "/assets/"
private const val ASSISTANT_URL = "https://appassets.androidplatform.net/assets/assistant/assistant-live.html"
private const val ASSISTANT_BUILD = "4.1.39"
private const val TAG = "WapFireAssistant"

/**
 * Uses AndroidX WebViewAssetLoader for a real HTTPS origin backed only by APK assets.
 * The asset handler serves ES modules, the LivLiv package and textures without network access.
 * All non-local requests are explicitly rejected by the WebViewClient.
 */
private class AssistantJsBridge(
    private val webView: WebView,
    private val onStatus: (String?) -> Unit,
    private val onReady: () -> Unit
) {
    @JavascriptInterface
    fun reportStatus(message: String?) {
        webView.post { onStatus(message?.take(900)?.ifBlank { null }) }
    }

    @JavascriptInterface
    fun reportReady() {
        webView.post { onReady() }
    }
}

private class LivLivWebView(
    context: Context,
    private val fa: Boolean,
    private val compact: Boolean,
    initialState: String,
    private val onNativeStatus: (String?) -> Unit
) : WebView(context) {
    private var pageReady = false
    private var rendererReady = false
    private var mainFrameFailed = false
    private var navigationGeneration = 0
    private var pendingState: String = initialState
    private val assetLoader = WebViewAssetLoader.Builder()
        .setDomain(ASSET_HOST)
        .addPathHandler(ASSET_PREFIX, object : WebViewAssetLoader.PathHandler {
            override fun handle(path: String): WebResourceResponse? {
                // Serve APK assets with explicit MIME types. ES modules require a JavaScript MIME type.
                val clean = Uri.decode(path).removePrefix("/")
                if (clean.isBlank() || clean.startsWith("/") || clean.contains('\\') ||
                    clean.split('/').any { it == ".." || it == "." }) return null
                val extension = clean.substringAfterLast('.', "").lowercase()
                val mime = when (extension) {
                    "html", "htm" -> "text/html"
                    "js", "mjs" -> "text/javascript"
                    "css" -> "text/css"
                    "json" -> "application/json"
                    "webp" -> "image/webp"
                    "png" -> "image/png"
                    "jpg", "jpeg" -> "image/jpeg"
                    "svg" -> "image/svg+xml"
                    "ico" -> "image/x-icon"
                    "livliv", "zip", "bin" -> "application/octet-stream"
                    else -> "application/octet-stream"
                }
                val encoding = if (mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("svg")) "UTF-8" else null
                return try {
                    val stream = context.assets.open(clean)
                    WebResourceResponse(
                        mime, encoding, 200, "OK",
                        mapOf(
                            "Cache-Control" to "no-store",
                            "X-Content-Type-Options" to "nosniff",
                            "Access-Control-Allow-Origin" to "https://$ASSET_HOST"
                        ),
                        stream
                    )
                } catch (_: FileNotFoundException) {
                    null
                } catch (error: Exception) {
                    Log.e(TAG, "Asset open failed: $clean", error)
                    null
                }
            }
        })
        .build()

    init {
        // Clear stale bootstrap/module responses from older APK versions before loading the assistant.
        clearCache(true)
        setBackgroundColor(AndroidColor.rgb(7, 22, 41))
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            databaseEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // The document is loaded from APK assets with loadDataWithBaseURL. AssetLoader
            // serves every ES module/model/texture request from the same virtual HTTPS origin.
            // Other hosts are rejected by shouldInterceptRequest below.
            blockNetworkLoads = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
        }
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        addJavascriptInterface(
            AssistantJsBridge(
                this,
                onStatus = { message -> onNativeStatus(message) },
                onReady = {
                    rendererReady = true
                    onNativeStatus(null)
                    Log.i(TAG, "LivLiv renderer reported READY")
                }
            ),
            "WapFireNative"
        )

        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = when (message.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> Log.ERROR
                    ConsoleMessage.MessageLevel.WARNING -> Log.WARN
                    else -> Log.DEBUG
                }
                val details = "JS ${message.message()} (${message.sourceId()}:${message.lineNumber()})"
                Log.println(level, TAG, details)
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR && !rendererReady) {
                    post { onNativeStatus(if (fa) "خطای موتور دستیار: ${message.message().take(220)} (${message.sourceId()}:${message.lineNumber()})" else "Assistant engine error: ${message.message().take(220)} (${message.sourceId()}:${message.lineNumber()})") }
                }
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!rendererReady && newProgress in 1..99) {
                    onNativeStatus(if (fa) "در حال بازکردن دستیار آفلاین… $newProgress٪" else "Opening offline assistant… $newProgress%")
                }
            }
        }

        webViewClient = object : WebViewClient() {
            private fun isLocal(uri: Uri): Boolean =
                uri.scheme == "https" && uri.host == ASSET_HOST && (uri.port == -1 || uri.port == 443)

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (!isLocal(uri)) {
                    Log.w(TAG, "Blocked non-local request: $uri")
                    return blockedResponse(403, "External resource blocked")
                }
                // Some WebView/Chromium builds still probe the origin-root favicon even
                // when the document declares a local icon. Serve it from packaged assets.
                if (uri.path.equals("/favicon.ico", ignoreCase = true)) {
                    return try {
                        WebResourceResponse(
                            "image/x-icon", null, 200, "OK",
                            mapOf("Cache-Control" to "no-store"),
                            context.assets.open("favicon.ico")
                        )
                    } catch (_: FileNotFoundException) {
                        blockedResponse(204, "No favicon")
                    }
                }
                if (uri.path?.startsWith(ASSET_PREFIX) != true) {
                    Log.w(TAG, "Blocked path outside packaged assets: $uri")
                    return blockedResponse(404, "Asset path not found")
                }
                val response = assetLoader.shouldInterceptRequest(uri)
                if (response == null) {
                    val path = uri.path ?: "(unknown)"
                    Log.e(TAG, "APK asset missing: $path")
                    post { if (!rendererReady) onNativeStatus(if (fa) "فایل دستیار داخل APK پیدا نشد: $path" else "Assistant APK asset missing: $path") }
                    return blockedResponse(404, "Packaged asset not found: $path")
                }
                Log.d(TAG, "Served local asset: ${uri.path} (${response.mimeType})")
                return response
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !isLocal(uri) || uri.path?.startsWith(ASSET_PREFIX) != true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                navigationGeneration++
                pageReady = false
                rendererReady = false
                mainFrameFailed = false
                onNativeStatus(if (fa) "در حال بازکردن صفحهٔ دستیار…" else "Opening assistant document…")
                Log.d(TAG, "Main page started: $url")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                Log.d(TAG, "Main page committed: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                Log.d(TAG, "Main page finished: $url rendererReady=$rendererReady mainFrameFailed=$mainFrameFailed")
                if (!rendererReady && !mainFrameFailed) {
                    onNativeStatus(if (fa) "صفحه باز شد؛ موتور سه‌بعدی در حال راه‌اندازی است…" else "Page loaded; initializing 2.5D renderer…")
                    val generation = navigationGeneration
                    postDelayed({
                        if (generation == navigationGeneration && pageReady && !rendererReady && !mainFrameFailed) {
                            evaluateJavascript("""(function(){
                                var c=document.getElementById('stage'),r=c&&c.getBoundingClientRect();
                                return {build:window.__wfAssistantBuildVersion||null,preflight:!!window.__wfPreflightStarted,engine:!!window.__wfEngineBooted,renderer:!!window.__wfRendererReady,
                                  canvas:r?{width:Math.round(r.width),height:Math.round(r.height)}:null,
                                  loading:document.getElementById('loading')?.textContent||null,
                                  url:location.href,origin:location.origin};
                            })()""".trimIndent()) { raw ->
                                val diagnostic = runCatching { org.json.JSONObject(raw ?: "{}") }.getOrElse { org.json.JSONObject() }
                                val detail = diagnostic.toString().take(550)
                                Log.e(TAG, "Renderer startup diagnostic: $detail")
                                val loadingValue = diagnostic.opt("loading")
                                val loadingMessage = if (loadingValue == null || loadingValue == org.json.JSONObject.NULL) "" else loadingValue.toString()
                                val canvasValue = diagnostic.opt("canvas")
                                val canvasMessage = when {
                                    canvasValue == null || canvasValue == org.json.JSONObject.NULL -> "canvas element missing"
                                    canvasValue is org.json.JSONObject -> "canvas ${canvasValue.optInt("width")}x${canvasValue.optInt("height")}"
                                    else -> canvasValue.toString()
                                }
                                val actualBuild = diagnostic.optString("build", "unknown")
                                val message = when {
                                    actualBuild != ASSISTANT_BUILD -> if (fa) "نسخهٔ قدیمی اسکریپت دستیار اجرا شده است ($actualBuild؛ انتظار $ASSISTANT_BUILD)." else "A stale assistant script is running ($actualBuild; expected $ASSISTANT_BUILD)."
                                    !diagnostic.optBoolean("preflight", false) -> if (fa) "اسکریپت راه‌اندازی اجرا نشده است؛ فایل محلی و کنسول را بررسی کن." else "Assistant bootstrap script did not execute; inspect local assets and console."
                                    !diagnostic.optBoolean("engine", false) -> if (fa) "ماژول موتور LivLiv بارگذاری نشده است." else "LivLiv engine module did not load."
                                    canvasValue == null || canvasValue == org.json.JSONObject.NULL -> if (fa) "عنصر Canvas در صفحه پیدا نشد." else "Canvas element is missing from the page."
                                    else -> if (fa) "موتور شروع شد اما هنوز آماده نیست؛ وضعیت WebGL را بررسی کن." else "Engine started but is not ready yet; inspect WebGL state."
                                }
                                val extra = listOf(canvasMessage, loadingMessage).filter { it.isNotBlank() }.joinToString(" · ")
                                onNativeStatus((if (extra.isNotBlank()) "$message ($extra)" else message) + " $detail")
                            }
                        }
                    }, 22000L)
                }
                if (rendererReady) applyPendingState()
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                val requestUrl = request?.url
                val isFavicon = requestUrl?.lastPathSegment.equals("favicon.ico", ignoreCase = true)
                val details = "WebView error mainFrame=${request?.isForMainFrame} url=$requestUrl code=${error?.errorCode} description=${error?.description}"
                Log.e(TAG, details)
                if (isFavicon) return
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    onNativeStatus(if (fa) "صفحهٔ دستیار باز نشد (${error?.errorCode}): ${error?.description}" else "Assistant page failed (${error?.errorCode}): ${error?.description}")
                } else if (!rendererReady) {
                    onNativeStatus(if (fa) "خطای فایل محلی: ${error?.description}" else "Local resource error: ${error?.description}")
                }
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, response)
                val requestUrl = request?.url
                val isFavicon = requestUrl?.lastPathSegment.equals("favicon.ico", ignoreCase = true)
                val details = "WebView HTTP error mainFrame=${request?.isForMainFrame} url=$requestUrl status=${response?.statusCode} reason=${response?.reasonPhrase}"
                Log.e(TAG, details)
                if (isFavicon) return
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    onNativeStatus(if (fa) "خطای صفحهٔ دستیار: HTTP ${response?.statusCode}" else "Assistant document error: HTTP ${response?.statusCode}")
                } else if (!rendererReady && response?.statusCode in 400..599) {
                    onNativeStatus(if (fa) "فایل دستیار پیدا نشد: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})" else "Assistant file missing: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})")
                }
            }
        }

        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        val pageUrl = "$ASSISTANT_URL?build=$ASSISTANT_BUILD&lang=$language&compact=$compactFlag&state=${Uri.encode(initialState)}"
        // Load the document through the same HTTPS AssetLoader origin as its ES modules and model.
        // This preserves a real same-origin context for JavaScript modules and fetch().
        Log.i(TAG, "Loading offline assistant build $ASSISTANT_BUILD from AssetLoader: $pageUrl")
        loadUrl(pageUrl)
        postDelayed({
            if (!rendererReady && pageReady) {
                evaluateJavascript("""(function(){return JSON.stringify({build:window.__wfAssistantBuildVersion||null,readyState:document.readyState,origin:location.origin,url:location.href,preflight:!!window.__wfPreflightStarted,engine:!!window.__wfEngineBooted,renderer:!!window.__wfRendererReady,userAgent:navigator.userAgent})})()""".trimIndent()) { result ->
                    Log.e(TAG, "Assistant boot probe: $result")
                    if (!rendererReady && !mainFrameFailed) {
                        val detail = if (result == null || result == "null") "JavaScript did not answer the native probe." else result.take(240)
                        onNativeStatus(if (fa) "تشخیص WebView: $detail" else "WebView diagnostic: $detail")
                    }
                }
            }
        }, 6000L)
    }

    fun setAssistantState(state: String) {
        if (pendingState == state) return
        pendingState = state
        if (pageReady && rendererReady) applyPendingState()
    }

    private fun applyPendingState() {
        val jsonState = org.json.JSONObject.quote(pendingState)
        evaluateJavascript("window.wapfireSetState && window.wapfireSetState($jsonState);", null)
    }

    private fun blockedResponse(code: Int, reason: String) = WebResourceResponse(
        "text/plain", "UTF-8", code, reason,
        mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )
}

@Composable
internal fun LivLivAssistantWebView(
    fa: Boolean,
    state: String,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val nativeStatus = androidx.compose.runtime.remember(context, fa, compact) {
        androidx.compose.runtime.mutableStateOf<String?>(if (fa) "در حال آماده‌سازی دستیار…" else "Preparing assistant…")
    }
    val view = remember(context, fa, compact) {
        LivLivWebView(context, fa, compact, state) { message -> nativeStatus.value = message }
    }

    DisposableEffect(view) {
        onDispose {
            runCatching {
                view.stopLoading()
                view.onPause()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { view },
            update = { it.setAssistantState(state) },
            modifier = Modifier.fillMaxSize()
        )
        // Status/diagnostic text must never cover the whole WebView: the old full-size opaque
        // overlay hid the character and could obstruct touches while the assistant was starting.
        nativeStatus.value?.let { message ->
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xE6071629))
                    .border(1.dp, Color(0x6636BAFF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 9.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    message,
                    color = Color(0xFFB8D2E8),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2
                )
            }
        }
    }
}

private fun overviewAssistantMessage(fa: Boolean, state: String): String = when (state) {
    // tx() always takes English first and Persian second. Keeping that order here
    // prevents the Overview speech text from switching to the opposite language.
    "scanning" -> tx(fa, "I am checking the radio activity around your network.", "دارم فعالیت‌های رادیویی اطراف شبکه را بررسی می‌کنم.")
    "connecting" -> tx(fa, "One moment… I am reconnecting to your WAPFire device.", "یک لحظه… دارم دوباره به دستگاه WAPFire وصل می‌شوم.")
    "success" -> tx(fa, "Wonderful! The connection is back and everything is ready.", "عالی شد! اتصال برقرار است و همه‌چیز آماده است.")
    "password_success" -> tx(fa, "The correct Wi-Fi password was confirmed. Nice work!", "رمز صحیح Wi‑Fi تأیید شد. عالیه!")
    "password_warning" -> tx(fa, "That password was not accepted. Please check it before trying again.", "این رمز تأیید نشد؛ قبل از تلاش دوباره آن را بررسی کن.")
    "warning" -> tx(fa, "Careful! I found suspicious activity that needs your attention.", "مراقب باش! فعالیت مشکوکی پیدا کردم که باید بررسی شود.")
    "angry" -> tx(fa, "An attack has been detected. Stay alert!", "یک حمله شناسایی شد؛ هوشیار باش!")
    "offline" -> tx(fa, "I cannot reach your WAPFire device right now.", "فعلاً نمی‌توانم به دستگاه WAPFire دسترسی پیدا کنم.")
    "setup" -> tx(fa, "Let us finish the first setup together.", "بیا راه‌اندازی اولیه را با هم کامل کنیم.")
    else -> tx(fa, "All clear. I am keeping an eye on your network.", "همه‌چیز مرتبه؛ دارم مراقب شبکه‌ات هستم.")
}

@Composable
internal fun LivLivAssistantOverviewCard(
    p: Palette,
    fa: Boolean,
    state: String,
    onOpenAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("WAPFIRE · LIVE ASSISTANT", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(tx(fa, "Sena is watching your network", "سنا مراقب شبکه‌ات است"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                tx(fa, "OPEN ↗", "نمایش ↗"),
                color = p.blue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(p.accentSoft.copy(alpha = .7f))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .clickable(onClick = onOpenAssistant)
            )
        }

        // Keep the preview and the speech card as separate native Compose siblings.
        // This prevents WebView's viewport/footer sizing from leaving a dead band below the bubble.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF071629))
                .border(1.dp, Color(0xFF23608D), RoundedCornerShape(22.dp))
                .padding(8.dp),
            // Keep only a small visual separation between the character frame and speech panel.
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(218.dp)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                LivLivAssistantWebView(
                    fa = fa,
                    state = state,
                    compact = true,
                    modifier = Modifier.fillMaxSize()
                )
            }
            CompositionLocalProvider(
                LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xF2061B31))
                        .border(1.dp, Color(0x884BBFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        if (fa) "گفت‌وگو با سنا" else "SENA · WAPFIRE ASSISTANT",
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF72E8FF),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = if (fa) 0.sp else 0.8.sp,
                        textAlign = if (fa) TextAlign.End else TextAlign.Start,
                        style = TextStyle(textDirection = if (fa) TextDirection.Rtl else TextDirection.Ltr)
                    )
                    Text(
                        overviewAssistantMessage(fa, state),
                        color = Color(0xFFECF7FF),
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 2,
                        textAlign = if (fa) TextAlign.End else TextAlign.Start,
                        style = TextStyle(textDirection = if (fa) TextDirection.Rtl else TextDirection.Ltr)
                    )
                }
            }
        }
    }
}

