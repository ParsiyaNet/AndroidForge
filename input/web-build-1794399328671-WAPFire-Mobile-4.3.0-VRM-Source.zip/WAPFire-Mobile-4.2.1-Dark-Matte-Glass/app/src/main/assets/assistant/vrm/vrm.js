/* WAPFire 4.3.0 - VRM (VRoid) assistant renderer: three.js + @pixiv/three-vrm.
 * Same native contract as the Hiyori and Nara pages:
 *   window.wapfireSetState(state)  /  WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg)
 * Emotions, gestures and idle motion live in vrm-pose.js (pure logic). This file loads the model, frames the camera
 * like the Nara screenshots, fixes left/right and pitch signs at runtime, and maps pose frames onto expressions and bones.
 * URL parameters: lang=fa|en, compact=1|0, state=<state>, zoom=<n>, dy=<n>  (zoom/dy are fine-tuning aids). */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { create as createPose } from './vrm-pose.js';

const BUILD = '4.3.0';
window.__wfPreflightStarted = true;
window.__wfAssistantBuildVersion = BUILD;
window.__wfAssistantDocumentExpected = true;
window.__wfEngineBooted = true;

const q = new URLSearchParams(location.search);
const fa = q.get('lang') !== 'en';
const compact = q.get('compact') !== '0';
const $ = (id) => document.getElementById(id);
const bridge = window.WapFireNative;
document.documentElement.lang = fa ? 'fa' : 'en';
document.body.className = compact ? 'compact' : 'full';

const D = Math.PI / 180;
const userZoom = parseFloat(q.get('zoom') || '1') || 1;
const userDy = parseFloat(q.get('dy') || '0') || 0;
let pendingState = q.get('state') || 'idle';
let ready = false;

function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
function fatal(message) {
  const text = String(message).slice(0, 400);
  console.error(text);
  const box = $('loading');
  if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
  report(text);
  try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
}
window.addEventListener('error', (e) => { if (!ready) fatal('VRM error: ' + (e.message || e)); });
window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('VRM error: ' + ((e.reason && e.reason.message) || e.reason)); });

/* ---------- states (labels identical to the Hiyori page) ---------- */
const PILL = {
  idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
  success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
  warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
  setup: ['Setup required', 'نیازمند راه‌اندازی']
};
const poseEngine = createPose();
const nowSec = () => performance.now() / 1000;

function showState(name) {
  const state = PILL[name] ? name : 'idle';
  pendingState = state;
  $('shell').dataset.state = state;
  $('stateText').textContent = PILL[state][fa ? 1 : 0];
  poseEngine.setState(state, nowSec());
}
window.wapfireSetState = (state) => { try { showState(String(state)); } catch (e) { report(String(e)); } };

/* ---------- three.js scene ---------- */
const canvas = $('stage');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setClearColor(0x000000, 0);
canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (!ready) fatal('WebGL context lost while starting.'); });

const scene = new THREE.Scene();
const FOV = 20;
const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 30);
const key = new THREE.DirectionalLight(0xffffff, Math.PI);
key.position.set(0.5, 0.9, 1.2).normalize();
scene.add(key);
scene.add(new THREE.AmbientLight(0xffffff, 0.45));

let vrm = null;
let facing = 1;               // +1 when the character looks toward +Z (the expected case after rotateVRM0)
let hipsRestY = 0;
const SIGN = { L: { down: 1, fwd: 1 }, R: { down: 1, fwd: 1 }, pitch: 1 };

/* ---------- framing (measured from the VRM mesh: hair/ear top 1.495 m, chin 1.23 m, hair half-width 0.207 m) ---------- */
const M = { top: 1.495, chin: 1.23, halfW: 0.207 };
// Targets taken from the Nara screenshots, as a fraction of the stage height: where the head starts and how tall it is.
const FRAME = {
  full: { top: 0.188, head: 0.32, maxW: 0.92 },
  compact: { top: 0.022, head: 0.41, maxW: 0.92 }
};
function fit() {
  const box = $('stageBox');
  const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
  renderer.setSize(W, H, false);
  camera.aspect = W / H;
  const cfg = compact ? FRAME.compact : FRAME.full;
  const headH = M.top - M.chin;
  let worldH = headH / cfg.head;                              // world height visible in the stage
  worldH = Math.max(worldH, (2 * M.halfW / cfg.maxW) / camera.aspect) / userZoom;   // never crop the hair width
  const topY = M.top + (cfg.top + userDy) * worldH;           // world y at the top edge of the stage
  const cy = topY - worldH / 2;
  const dist = (worldH / 2) / Math.tan(FOV * D / 2);
  camera.position.set(0, cy, facing * dist);
  camera.lookAt(0, cy, 0);
  camera.updateProjectionMatrix();
}
window.wapfireFrame = (zoom, dy) => { /* debugging aid */ fit(); return { zoom, dy }; };

/* ---------- humanoid helpers ---------- */
const nb = (name) => vrm.humanoid.getNormalizedBoneNode(name);
const rawBone = (name) => vrm.humanoid.getRawBoneNode(name);
const tmpV = new THREE.Vector3();
const posOf = (obj) => obj.getWorldPosition(tmpV.set(0, 0, 0)).clone();
function settle() { vrm.humanoid.update(); vrm.scene.updateMatrixWorld(true); }

/* The VRM may mirror left/right or pitch depending on how the normalized rig was built. Rather than assume, measure:
 * lower the arm with +angle and see whether the hand goes down; swing it with +angle and see whether it moves forward;
 * pitch the head with +angle and see whether the eye drops. */
function calibrate() {
  const head = rawBone('head'), eyeL = rawBone('leftEye') || head;
  const hp = posOf(head), ep = posOf(eyeL);
  facing = (ep.z - hp.z) >= 0 ? 1 : -1;
  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const ua = nb(name + 'UpperArm'), hand = rawBone(name + 'Hand');
    if (!ua || !hand) continue;
    ua.rotation.order = 'ZYX';
    ua.rotation.set(0, 0, 0.9); settle(); const yP = posOf(hand).y;
    ua.rotation.set(0, 0, -0.9); settle(); const yM = posOf(hand).y;
    SIGN[side].down = yP < yM ? 1 : -1;
    ua.rotation.set(0, 0.6, 0); settle(); const zP = posOf(hand).z;
    ua.rotation.set(0, -0.6, 0); settle(); const zM = posOf(hand).z;
    SIGN[side].fwd = (zP - zM) * facing > 0 ? 1 : -1;
    ua.rotation.set(0, 0, 0);
  }
  const hd = nb('head');
  if (hd) {
    hd.rotation.set(0.5, 0, 0); settle(); const yP = posOf(eyeL).y;
    hd.rotation.set(-0.5, 0, 0); settle(); const yM = posOf(eyeL).y;
    SIGN.pitch = yP < yM ? 1 : -1;
    hd.rotation.set(0, 0, 0);
  }
  settle();
}

/* ---------- expressions ---------- */
let exprNames = new Set();
let surprisedName = null;
function setExpr(name, v) { if (name && exprNames.has(name)) vrm.expressionManager.setValue(name, v); }

/* ---------- applying a pose frame ---------- */
const FINGERS = ['Index', 'Middle', 'Ring', 'Little'];
const CURL = [1.25, 1.35, 0.8];     // proximal, intermediate, distal (radians at curl = 1)
function setBone(name, x, y, z) { const n = nb(name); if (n) n.rotation.set(x, y, z); }

function applyFrame(f) {
  const E = f.expr;
  setExpr('happy', E.happy); setExpr('sad', E.sad); setExpr('angry', E.angry); setExpr('relaxed', E.relaxed);
  setExpr(surprisedName, E.surprised); setExpr('blink', E.blink);

  const p = SIGN.pitch;
  setBone('head', f.rot.head.x * p, f.rot.head.y, f.rot.head.z);
  setBone('neck', f.rot.neck.x * p, f.rot.neck.y, f.rot.neck.z);
  setBone('chest', f.rot.chest.x * p, f.rot.chest.y, f.rot.chest.z);
  setBone('spine', f.rot.spine.x * p, f.rot.spine.y, f.rot.spine.z);
  const hips = nb('hips'); if (hips) hips.position.y = hipsRestY + f.hipsY;

  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const s = SIGN[side], a = f.arm[side];
    const ua = nb(name + 'UpperArm'), la = nb(name + 'LowerArm'), sh = nb(name + 'Shoulder');
    if (ua) { ua.rotation.order = 'ZYX'; ua.rotation.set(0, s.fwd * a.fwd, s.down * a.down); }
    if (la) { la.rotation.order = 'ZYX'; la.rotation.set(0, s.fwd * a.elbowF, -s.down * a.elbowU); }
    if (sh) sh.rotation.set(0, 0, -s.down * f.shoulders);
    for (const finger of FINGERS) {
      ['Proximal', 'Intermediate', 'Distal'].forEach((seg, i) => {
        const bone = nb(name + finger + seg);
        if (bone) bone.rotation.set(0, 0, s.down * a.curl * CURL[i]);
      });
    }
  }
  if (vrm.lookAt) { vrm.lookAt.yaw = f.gaze.yaw; vrm.lookAt.pitch = f.gaze.pitch; }
}

/* ---------- main loop ---------- */
let last = performance.now();
function tick() {
  const nowMs = performance.now();
  const dt = Math.min(0.1, Math.max(0.001, (nowMs - last) / 1000));
  last = nowMs;
  if (vrm) {
    applyFrame(poseEngine.update(nowMs / 1000, dt));
    vrm.update(dt);
  }
  renderer.render(scene, camera);
}

window.wapfireVrmInfo = () => JSON.stringify({ build: BUILD, facing, sign: SIGN, expressions: Array.from(exprNames), surprised: surprisedName });

/* ---------- boot ---------- */
async function boot() {
  report(fa ? 'در حال بارگذاری مدل VRM…' : 'Loading VRM model…');
  const loader = new GLTFLoader();
  loader.register((parser) => new VRMLoaderPlugin(parser));
  let lastPct = -1;
  const gltf = await loader.loadAsync('./model/nara.vrm', (e) => {
    if (!e.lengthComputable) return;
    const pct = Math.floor((e.loaded / e.total) * 100);
    if (pct !== lastPct && pct % 10 === 0) { lastPct = pct; report((fa ? 'بارگذاری مدل VRM… ' : 'Loading VRM model… ') + pct + '%'); }
  });
  vrm = gltf.userData.vrm;
  if (!vrm) throw new Error('The file is not a VRM model.');
  if (VRMUtils.removeUnnecessaryVertices) VRMUtils.removeUnnecessaryVertices(gltf.scene);
  if (VRMUtils.combineSkeletons) VRMUtils.combineSkeletons(gltf.scene);
  else if (VRMUtils.removeUnnecessaryJoints) VRMUtils.removeUnnecessaryJoints(gltf.scene);
  VRMUtils.rotateVRM0(vrm);                       // VRM 0.x models face -Z; turn them toward the camera
  vrm.scene.traverse((o) => { o.frustumCulled = false; });
  scene.add(vrm.scene);

  const em = vrm.expressionManager;
  exprNames = new Set(em ? Object.keys(em.expressionMap || {}) : []);
  surprisedName = ['Surprised', 'surprised'].find((n) => exprNames.has(n)) || null;
  hipsRestY = nb('hips') ? nb('hips').position.y : 0;
  settle();
  calibrate();
  report('VRM ready: ' + window.wapfireVrmInfo());

  fit();
  if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
  window.addEventListener('resize', () => requestAnimationFrame(fit));
  showState(pendingState);
  renderer.setAnimationLoop(tick);
  // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  fit();
  ready = true;
  window.__wfRendererReady = true;
  $('loading').style.display = 'none';
  try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
}

showState(pendingState);
boot().catch((error) => fatal('VRM failed to start: ' + ((error && error.message) || error)));
