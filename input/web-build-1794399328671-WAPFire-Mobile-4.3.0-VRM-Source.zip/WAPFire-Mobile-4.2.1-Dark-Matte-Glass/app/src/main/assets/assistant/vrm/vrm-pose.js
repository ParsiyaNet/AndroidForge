/* WAPFire 4.3.0 - VRM pose / emotion engine (pure logic, no DOM, no three.js).
 *
 * create() returns { setState(name, now), update(now, dt) -> frame }.
 * The frame is a plain object of numbers; vrm.js maps it onto the VRM expression manager and humanoid bones.
 * All angles in a frame are RADIANS; arm angles are "semantic" so that vrm.js can fix left/right signs at runtime:
 *   down   = how far the upper arm hangs below horizontal (0 = T-pose, 1.22 = relaxed, negative = raised above horizontal)
 *   fwd    = swing of the whole arm toward the viewer
 *   elbowF = forearm bends forward (hand toward the chest)      elbowU = forearm bends upward (hand toward the head)
 *   curl   = 0..1 finger curl (fist)
 * Head/neck/chest/spine values are pitch (x, + = looks down), yaw (y) and roll (z).
 * Expression names follow three-vrm: happy (VRoid "Joy"), sad ("Sorrow"), angry, relaxed ("Fun"), surprised (custom "Surprised").
 */
const D = Math.PI / 180;

const EXPR = ['happy', 'sad', 'angry', 'relaxed', 'surprised'];
const BONES = ['head', 'neck', 'chest', 'spine'];
const ARM_KEYS = ['down', 'fwd', 'elbowF', 'elbowU', 'curl'];

const REST_ARM = { down: 70, fwd: 3, elbowF: 8, elbowU: 0, curl: 0.1 };
const arm = (o) => Object.assign({}, REST_ARM, o || {});

/* Degrees here (converted once). e = expression weights 0..1, blink = resting lid closure (narrowed / sleepy eyes). */
const POSES = {
  // calm, faintly smiling
  idle: { e: { happy: 0.14 }, blink: 0, head: { x: 0, y: 0, z: 0 }, L: arm(), R: arm() },

  // focused and watchful; head sweeps slowly left and right, hands held ready
  scanning: {
    e: { angry: 0.12 }, blink: 0.1, head: { x: 2, y: 0, z: 0 }, chest: { x: 1 },
    L: arm({ down: 66, fwd: 10, elbowF: 28 }), R: arm({ down: 66, fwd: 10, elbowF: 28 }), sweep: 1
  },

  // thinking: eyes up and to the side, head tilted, one hand raised toward the chin
  connecting: {
    e: { happy: 0.1, relaxed: 0.3 }, blink: 0, head: { x: -3, y: 8, z: 7 }, gaze: { yaw: -16, pitch: 8 },
    L: arm({ down: 68, elbowF: 14 }), R: arm({ down: 58, fwd: 22, elbowF: 84 })
  },

  // delighted: big joyful smile, a small hop, hands up in front
  success: {
    e: { happy: 1 }, blink: 0, head: { x: -4, y: 0, z: 4 }, chest: { x: -2 },
    L: arm({ down: 50, fwd: 16, elbowF: 62 }), R: arm({ down: 50, fwd: 16, elbowF: 62 }), gesture: 'hop'
  },

  // pleased: warm smile and a nod
  password_success: {
    e: { happy: 0.7, relaxed: 0.2 }, blink: 0, head: { x: 0, y: 0, z: 3 },
    L: arm({ down: 64, elbowF: 18 }), R: arm({ down: 64, elbowF: 18 }), gesture: 'nod'
  },

  // worried: sad brows, a soft "no", hands drawn to the chest
  password_warning: {
    e: { sad: 0.65, surprised: 0.12 }, blink: 0, head: { x: 4, y: 0, z: -7 }, gaze: { yaw: 0, pitch: -6 },
    L: arm({ down: 56, fwd: 24, elbowF: 78 }), R: arm({ down: 56, fwd: 24, elbowF: 78 }), gesture: 'no'
  },

  // alert: eyes wide, mouth rounded, a quick start backward, shoulders up
  warning: {
    e: { surprised: 0.9, sad: 0.12 }, blink: 0, head: { x: -5, y: 0, z: 0 }, chest: { x: -4 }, shoulders: 7,
    L: arm({ down: 58, fwd: 6, elbowF: 36 }), R: arm({ down: 58, fwd: 6, elbowF: 36 }), gesture: 'startle'
  },

  // angry: brows down, narrowed eyes, head lowered and leaning in, fists at the sides
  angry: {
    e: { angry: 1 }, blink: 0.2, head: { x: 11, y: 0, z: 0 }, neck: { x: 4 }, chest: { x: 7 }, spine: { x: 3 }, shoulders: 4,
    gaze: { yaw: 0, pitch: 4 },
    L: arm({ down: 62, fwd: 12, elbowF: 52, curl: 1 }), R: arm({ down: 62, fwd: 12, elbowF: 52, curl: 1 }), tremor: 1
  },

  // sad / tired: heavy eyelids, head drooping, slouched, arms hanging limp
  offline: {
    e: { sad: 0.95 }, blink: 0.32, head: { x: 15, y: 0, z: -5 }, neck: { x: 4 }, chest: { x: 8 }, spine: { x: 4 },
    gaze: { yaw: 0, pitch: -14 }, shoulders: -3, slowBreath: 1,
    L: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0 }), R: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0 })
  },

  // friendly: smile, head tilt, a small hello wave
  setup: {
    e: { happy: 0.5, relaxed: 0.2 }, blink: 0, head: { x: -2, y: 0, z: 6 },
    L: arm({ down: 68 }), R: arm({ down: 68 }), gesture: 'wave'
  }
};

const rad = (v) => (v || 0) * D;

function flatten(pose) {
  const t = {};
  for (const k of EXPR) t['e_' + k] = (pose.e && pose.e[k]) || 0;
  t.blink = pose.blink || 0;
  for (const b of BONES) for (const a of ['x', 'y', 'z']) t[b + '_' + a] = rad(pose[b] && pose[b][a]);
  t.shoulders = rad(pose.shoulders);
  t.gaze_yaw = (pose.gaze && pose.gaze.yaw) || 0;      // degrees (three-vrm lookAt API)
  t.gaze_pitch = (pose.gaze && pose.gaze.pitch) || 0;
  for (const side of ['L', 'R']) for (const k of ARM_KEYS) {
    const v = (pose[side] || REST_ARM)[k];
    t[side + '_' + k] = k === 'curl' ? v : rad(v);
  }
  return t;
}

const TAU = { e: 0.2, blink: 0.25, bone: 0.45, shoulders: 0.3, gaze: 0.28, arm: 0.4 };
function tauFor(key) {
  if (key.startsWith('e_')) return TAU.e;
  if (key === 'blink') return TAU.blink;
  if (key === 'shoulders') return TAU.shoulders;
  if (key.startsWith('gaze_')) return TAU.gaze;
  if (key[0] === 'L' || key[0] === 'R') return TAU.arm;
  return TAU.bone;
}

/* One-shot gestures. Each returns offsets that fade out; t = seconds since the state began. */
function gesture(name, t) {
  const g = { headX: 0, headY: 0, chestX: 0, hipsY: 0, wave: 0, waveT: 0 };
  if (name === 'nod') {
    if (t < 1.0) { const e = Math.sin(Math.PI * t / 1.0); g.headX = 11 * D * e; g.chestX = 2 * D * e; }
  } else if (name === 'no') {
    if (t < 2.0) g.headY = 15 * D * Math.exp(-t * 1.9) * Math.sin(2 * Math.PI * 1.55 * t);
  } else if (name === 'startle') {
    const e = Math.exp(-t * 4.2); g.headX = -7 * D * e; g.chestX = -5 * D * e; g.hipsY = 0.012 * e;
  } else if (name === 'hop') {
    // two small bounces with a nod
    if (t < 1.3) { const e = Math.abs(Math.sin(Math.PI * t / 0.65)) * Math.exp(-t * 1.2); g.hipsY = 0.035 * e; g.headX = 5 * D * e; }
  } else if (name === 'wave') {
    const dur = 2.6;
    if (t < dur) {
      const env = Math.min(1, t / 0.4) * Math.min(1, (dur - t) / 0.5);
      g.wave = Math.max(0, env); g.waveT = t;
    }
  }
  return g;
}

function create() {
  let pose = POSES.idle, t0 = 0, curState = 'idle';
  const cur = flatten(POSES.idle);
  let nextBlink = 2.5, blinkT = -1;
  let seed = 7;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };

  function setState(name, now) {
    curState = POSES[name] ? name : 'idle';
    pose = POSES[curState];
    t0 = now;
  }

  function update(now, dt) {
    const target = flatten(pose);
    for (const k in target) {
      const a = 1 - Math.exp(-dt / tauFor(k));
      cur[k] += (target[k] - cur[k]) * a;
    }
    const t = Math.max(0, now - t0);
    const g = gesture(pose.gesture, t);

    // ---- idle life: breathing, sway, micro head motion ---------------------------------------------------------
    const breathPeriod = pose.slowBreath ? 6.2 : 4.2;
    const breath = Math.sin(2 * Math.PI * now / breathPeriod);
    const sway = Math.sin(now * 0.52), sway2 = Math.sin(now * 0.83 + 1.7);
    const tremor = pose.tremor ? Math.sin(now * 38) * 0.0025 : 0;

    // ---- scanning: slow gaze sweep -----------------------------------------------------------------------------
    const sw = pose.sweep ? 1 : 0;
    const sweep = sw * Math.sin(now * 1.25);

    // ---- blinking ----------------------------------------------------------------------------------------------
    if (blinkT < 0 && now >= nextBlink) blinkT = 0;
    let blinkPulse = 0;
    if (blinkT >= 0) {
      blinkT += dt;
      const d = 0.2;
      blinkPulse = blinkT < d ? Math.sin(Math.PI * blinkT / d) : 0;
      if (blinkT >= d) { blinkT = -1; nextBlink = now + 2.2 + rnd() * 3.4; if (rnd() < 0.18) nextBlink = now + 0.28; }
    }

    // ---- build the frame ---------------------------------------------------------------------------------------
    const f = { expr: {}, rot: {}, arm: { L: {}, R: {} }, hipsY: 0, shoulders: 0, gaze: { yaw: 0, pitch: 0 }, state: curState };
    for (const k of EXPR) f.expr[k] = Math.max(0, Math.min(1, cur['e_' + k]));
    // VRoid "Joy" already closes the eyes; keep the blink out of it so the lids do not double-close.
    const eyesClosedByJoy = Math.min(1, f.expr.happy * 1.2);
    f.expr.blink = Math.max(cur.blink, blinkPulse) * (1 - eyesClosedByJoy);

    f.rot.head = { x: cur.head_x + g.headX + tremor * 4, y: cur.head_y + g.headY + sweep * 0.42 + 0.035 * sway, z: cur.head_z + 0.022 * sway2 };
    f.rot.neck = { x: cur.neck_x, y: cur.neck_y + sweep * 0.12, z: cur.neck_z };
    f.rot.chest = { x: cur.chest_x + g.chestX + 0.014 * breath, y: cur.chest_y + sweep * 0.06, z: cur.chest_z + 0.012 * sway };
    f.rot.spine = { x: cur.spine_x, y: cur.spine_y, z: cur.spine_z + 0.008 * sway2 };
    f.hipsY = g.hipsY;
    f.shoulders = cur.shoulders + 0.018 * Math.max(0, breath);

    f.gaze.yaw = cur.gaze_yaw + sweep * 14 + 2.2 * Math.sin(now * 0.9);
    f.gaze.pitch = cur.gaze_pitch + 1.6 * Math.sin(now * 0.71 + 0.8);

    for (const side of ['L', 'R']) {
      const a = f.arm[side];
      for (const k of ARM_KEYS) a[k] = cur[side + '_' + k];
      a.down += 0.01 * sway;                      // relaxed arm drift
    }
    // wave: right arm up, forearm oscillating; blended in/out by the gesture envelope
    if (g.wave > 0) {
      const w = g.wave, A = f.arm.R;
      const osc = Math.sin(g.waveT * 2 * Math.PI * 2.4);
      A.down += (rad(8) - A.down) * w;
      A.fwd += (rad(24) - A.fwd) * w;
      A.elbowF += (0 - A.elbowF) * w;
      A.elbowU += (rad(78) + 0.32 * osc - A.elbowU) * w;
      f.expr.happy = Math.max(f.expr.happy, 0.55 * w);
    }
    return f;
  }

  return { setState, update };
}

export { create, POSES, EXPR };
export default { create, POSES, EXPR };
