# WAPFire Mobile 4.3.0 — VRM (VRoid) character

- **New default character:** the VRoid model from the source zip (`Chiaki Katsumi [Miku Boxing]` by Yuuki, VRM 0.x) is now Nara.
  Rendered with three.js + @pixiv/three-vrm inside the existing WebView contract (`assets/assistant/vrm/`).
- **Same framing as the screenshots:** the Overview card and the Nara tab use the same head-top / head-height targets that 4.2.x
  derived from the Nara screenshots (Overview: head 41 % of the card, Nara tab: head 32 % starting at 18.8 %).
  The camera is computed from the model's measured head box (top 1.495 m, chin 1.23 m, hair half-width 0.207 m).
  Fine tuning: add `&zoom=1.1&dy=0.02` to the page URL (`VRM_URL` in `LivLivAssistantView.kt`) — `zoom > 1` zooms in, `dy > 0` moves the head down.
- **All ten WAPFire states have an emotion and a body pose** (`vrm/vrm-pose.js`, pure logic, unit-tested in node):
  idle (calm smile, breathing) · scanning (focused, slow head sweep) · connecting (thinking, head tilt, hand toward chin) ·
  success (big joy, small hop, hands up) · password_success (warm smile, nod) · password_warning (worried, soft "no", hands to chest) ·
  warning (surprised, startle, shoulders up) · angry (angry face, head lowered, leaning in, fists, faint tremor) ·
  offline (sad, drooping, slouched, slow breathing) · setup (friendly, hello wave).
  Blinking, breathing, sway, eye saccades and hair/clothes spring-bone physics run in every state.
  Expressions used: Joy→`happy`, Sorrow→`sad`, Angry→`angry`, Fun→`relaxed`, custom `Surprised`.
- **Arm / pitch signs are measured at runtime** (the page lowers each arm and checks where the hand goes), so the poses do not depend on
  how the normalized rig is mirrored. `window.wapfireVrmInfo()` prints the result and the expression names found in the model.
- **Fallback chain:** VRM → Hiyori (Live2D) → Nara (LivLiv). Triggered by missing assets/libs, a page-reported fatal error, a main-frame error,
  or no ready signal within 60 s (VRM) / 40 s (Hiyori).
- **Build:** new Gradle task `fetchVrmLibs` downloads pinned `three@0.170.0` and `@pixiv/three-vrm@3.3.3` into `assets/assistant/vrm/lib/`
  (jsDelivr, unpkg as mirror). A failed download is a warning, not a build failure — the app then starts with Hiyori.
  Offline builds: copy these files by hand:
  `three.module.js` (three/build), `addons/loaders/GLTFLoader.js` and `addons/utils/BufferGeometryUtils.js` (three/examples/jsm), `three-vrm.module.min.js` (@pixiv/three-vrm/lib).
- Settings → CHARACTER CREDITS now credits the VRoid model author (the model's license requires credit; redistribution of the model file itself is not allowed).
- `vrm/index.html` uses an import map, so its CSP allows inline scripts (`script-src 'self' 'unsafe-inline'`). Everything it loads is local; `connect-src` stays `'self'`.
- Android versionCode/versionName: 104 / 4.3.0.

Not verified in this package: a real Android build and on-device rendering (the packaging environment had no Android SDK, WebView or network).
Logic that was verified: pose engine in node for all ten states (no NaN, smooth blends, gesture timing), JS syntax, Kotlin/Gradle brace balance.
