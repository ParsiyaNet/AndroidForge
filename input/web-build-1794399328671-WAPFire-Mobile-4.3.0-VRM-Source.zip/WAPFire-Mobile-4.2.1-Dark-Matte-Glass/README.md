# WAPFire Mobile 4.3.0 — VRM (VRoid) character

Nara is now the VRoid model from the source package, with emotions and poses for every WAPFire state and the same zoom/framing as the Nara screenshots. Fallback order: VRM → Hiyori → Nara. See `CHANGELOG-4.3.0.md`.

---

# WAPFire Mobile 4.1.52 — Dark Bottom Navigation Matte Refinement

The dark-theme bottom navigation pill is slightly more opaque for improved label readability while retaining its frosted-glass appearance. The light theme and all other app behavior remain unchanged. See `CHANGELOG-4.1.52.md` and `VALIDATION-4.1.52.txt`.
