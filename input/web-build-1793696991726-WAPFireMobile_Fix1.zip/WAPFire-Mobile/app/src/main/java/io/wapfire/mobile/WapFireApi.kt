package io.wapfire.mobile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class WapFireApi(initialHost: String = "192.168.4.1") {
    @Volatile private var rootUrl: String = normalizeHost(initialHost)

    private val cookieStore = ConcurrentHashMap<String, List<Cookie>>()
    private val cookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            // Do not erase the active session on responses that simply contain no Set-Cookie header.
            if (cookies.isNotEmpty()) {
                cookieStore[url.host] = cookies.filter { it.expiresAt > System.currentTimeMillis() }
            }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> =
            cookieStore[url.host].orEmpty().filter { it.expiresAt > System.currentTimeMillis() }
    }

    private val http = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    fun setHost(value: String) {
        val normalized = normalizeHost(value)
        if (normalized != rootUrl) clearSession()
        rootUrl = normalized
    }

    fun getBaseUrl(): String = rootUrl

    fun clearSession() {
        cookieStore.clear()
    }

    suspend fun login(username: String, password: String) = withContext(Dispatchers.IO) {
        val body = FormBody.Builder()
            .add("user", username)
            .add("pass", password)
            .build()
        val request = Request.Builder().url(url("login")).post(body).build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, text.ifBlank { "Login failed" })
            if (cookieStore[urlHost()].isNullOrEmpty()) {
                // Firmware authenticates with a host/IP-bound wg_auth cookie.
                // OkHttp's CookieJar receives Set-Cookie before this response is returned.
                throw ApiException(401, "Device did not issue an authentication session")
            }
            text
        }
    }

    suspend fun getJson(path: String) = requestJson("GET", path, null)
    suspend fun getArray(path: String) = requestArray(path)
    suspend fun postJson(path: String, body: JSONObject) = requestJson("POST", path, body)
    suspend fun postEmpty(path: String) = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url(path)).post(ByteArray(0).toRequestBody(null)).build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, text.ifBlank { "HTTP ${response.code}" })
            text
        }
    }

    suspend fun postRaw(path: String, raw: String, contentType: String = "application/json") = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url(path))
            .post(raw.toRequestBody(contentType.toMediaType()))
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, text.ifBlank { "HTTP ${response.code}" })
            text
        }
    }

    private suspend fun requestJson(method: String, path: String, body: JSONObject?): JSONObject = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url(path))
        if (method == "POST") {
            val requestBody = (body?.toString() ?: "{}").toRequestBody("application/json; charset=utf-8".toMediaType())
            builder.post(requestBody)
        } else builder.get()

        http.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, extractMessage(text, response.code))
            try { JSONObject(text) } catch (e: Exception) { throw ApiException(response.code, "Invalid JSON from device: ${e.message}") }
        }
    }

    private suspend fun requestArray(path: String): JSONArray = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url(path)).get().build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw ApiException(response.code, extractMessage(text, response.code))
            try { JSONArray(text) } catch (e: Exception) { throw ApiException(response.code, "Invalid JSON from device: ${e.message}") }
        }
    }

    private fun url(path: String): String = rootUrl.trimEnd('/') + "/" + path.trimStart('/')
    private fun urlHost(): String = rootUrl.toHttpUrl().host

    private fun extractMessage(text: String, code: Int): String {
        return try {
            JSONObject(text).optString("message").ifBlank { text.ifBlank { "HTTP $code" } }
        } catch (_: Exception) { text.ifBlank { "HTTP $code" } }
    }

    companion object {
        fun normalizeHost(input: String): String {
            var host = input.trim().trimEnd('/')
            if (host.isBlank()) host = "192.168.4.1"
            if (!host.startsWith("http://") && !host.startsWith("https://")) host = "http://$host"
            return host
        }
    }
}

class ApiException(val code: Int, override val message: String) : IOException(message)
