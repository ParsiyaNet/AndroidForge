package io.wapfire.mobile.ui

import io.wapfire.mobile.model.*
import io.wapfire.mobile.network.*
import io.wapfire.mobile.security.*
import io.wapfire.mobile.monitor.BackgroundMonitorService
import io.wapfire.mobile.monitor.DetectionBreakdownNotificationCenter
import io.wapfire.mobile.ui.components.*
import io.wapfire.mobile.ui.screens.*

import android.Manifest
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

private fun Context.findLifecycleOwner(): LifecycleOwner? {
    var current: Context? = this
    while (current != null) {
        if (current is LifecycleOwner) return current
        current = (current as? ContextWrapper)?.baseContext
    }
    return null
}

@Composable
internal fun WapFireNativeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wapfire_native_v22", Context.MODE_PRIVATE) }
    var backgroundMonitoring by remember { mutableStateOf(BackgroundMonitorService.isRunning(context)) }
    val lifecycleOwner = remember(context) { context.findLifecycleOwner() }
    var appInForeground by remember {
        mutableStateOf(lifecycleOwner?.lifecycle?.currentState?.isAtLeast(Lifecycle.State.RESUMED) ?: true)
    }
    var showMonitorCredentialDialog by remember { mutableStateOf(false) }
    DisposableEffect(context, lifecycleOwner) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                backgroundMonitoring = intent?.getBooleanExtra("active", false) ?: false
            }
        }
        val filter = IntentFilter(BackgroundMonitorService.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    appInForeground = true
                    prefs.edit().putBoolean("monitor_app_foreground", true).apply()
                }
                Lifecycle.Event.ON_PAUSE -> {
                    appInForeground = false
                    prefs.edit().putBoolean("monitor_app_foreground", false).apply()
                }
                Lifecycle.Event.ON_DESTROY -> prefs.edit().putBoolean("monitor_app_foreground", false).apply()
                else -> Unit
            }
        }
        lifecycleOwner?.lifecycle?.addObserver(lifecycleObserver)
        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
            lifecycleOwner?.lifecycle?.removeObserver(lifecycleObserver)
        }
    }
    val scope = rememberCoroutineScope()
    val discovery = remember { WifiDiscovery(context) }
    val connector = remember { WifiConnector(context) }
    val sessionManager = remember { WapFireSessionManager() }
    var isDark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var isFa by remember { mutableStateOf(prefs.getBoolean("fa", false)) }
    var stage by remember { mutableStateOf(Stage.DISCOVERY) }
    var tab by remember { mutableStateOf(Tab.OVERVIEW) }
    var host by remember { mutableStateOf(prefs.getString("host", "192.168.4.1") ?: "192.168.4.1") }
    val savedLoginAtLaunch = remember { DeviceLoginVault.load(prefs, prefs.getString("host", "192.168.4.1") ?: "192.168.4.1") }
    var username by remember { mutableStateOf(savedLoginAtLaunch?.username ?: "admin") }
    var password by remember { mutableStateOf(savedLoginAtLaunch?.password ?: "") }
    var rememberPassword by remember {
        mutableStateOf(savedLoginAtLaunch != null || prefs.getBoolean("remember_password_preference", true))
    }
    var api by remember { mutableStateOf<WapFireApi?>(null) }
    // Device reachability is independent from the firmware's Promiscuous/LIVE state.
    // Keep the last snapshot and use this flag only for the app-to-device link indicator.
    var deviceOnline by remember { mutableStateOf(false) }
    var snapshot by remember { mutableStateOf(Snapshot()) }
    var logs by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var clients by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var networks by remember { mutableStateOf<List<WifiAccessPoint>>(emptyList()) }
    var lanDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedSsid by remember { mutableStateOf("") }
    var selectedBssid by remember { mutableStateOf("") }
    var wifiPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var setupAdminPass by remember { mutableStateOf("") }
    var setupApSsid by remember { mutableStateOf("WAPFire Network") }
    var setupApPass by remember { mutableStateOf("") }
    var setupStep by remember { mutableStateOf(0) }
    var setupLed by remember { mutableStateOf(true) }
    var setupSound by remember { mutableStateOf(true) }
    var setupAutoChannel by remember { mutableStateOf(true) }
    var setupSelfProtect by remember { mutableStateOf(false) }
    var setupSoftAp by remember { mutableStateOf(true) }
    var setupTarget by remember { mutableStateOf<JSONObject?>(null) }
    var targetSelecting by remember { mutableStateOf(false) }
    var targetNetworks by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var targetScanBusy by remember { mutableStateOf(false) }
    var advancedSettings by remember { mutableStateOf(AdvancedSettingsBundle()) }
    var advancedRefreshInProgress by remember { mutableStateOf(false) }
    var telemetryRefreshInProgress by remember { mutableStateOf(false) }
    var pendingBackupBytes by remember { mutableStateOf<ByteArray?>(null) }

    val backupDestinationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val bytes = pendingBackupBytes
        if (uri != null && bytes != null) {
            scope.launch {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Could not open destination file")
                }.onSuccess { notice = "WAPFire backup saved. This file contains device secrets; store it securely." }
                    .onFailure { error = it.message ?: "Could not save backup" }
                pendingBackupBytes = null
            }
        } else pendingBackupBytes = null
    }
    val restoreDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bytes = runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("Could not read backup") }
            if (bytes.isFailure) error = bytes.exceptionOrNull()?.message ?: "Could not read backup"
            else {
                val result = api?.restoreSettings(bytes.getOrThrow())
                if (result?.isSuccess == true) {
                    notice = "Settings restored. WAPFire is rebooting; reconnect and sign in again."
                    val client = api; client?.clearSession(); api = null
                    delay(3800)
                    connector.release(); stage = Stage.DISCOVERY
                } else error = result?.exceptionOrNull()?.message ?: "Restore failed"
            }
        }
    }
    val firmwareDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bytes = runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("Could not read firmware image") }
            if (bytes.isFailure) error = bytes.exceptionOrNull()?.message ?: "Could not read firmware image"
            else {
                val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "firmware.bin"
                val result = api?.uploadFirmware(name, bytes.getOrThrow())
                if (result?.isSuccess == true) {
                    notice = result.getOrThrow()
                    val client = api; client?.clearSession(); api = null
                    delay(2500)
                    connector.release(); stage = Stage.DISCOVERY
                } else error = result?.exceptionOrNull()?.message ?: "Firmware upload failed"
            }
        }
    }

    val p = colors(isDark)
    LaunchedEffect(error, notice) {
        val currentError = error
        val currentNotice = notice
        if (currentError.isNotBlank() || currentNotice.isNotBlank()) {
            delay(if (currentError.isNotBlank()) 4800 else 3200)
            if (error == currentError) error = ""
            if (notice == currentNotice) notice = ""
        }
    }
    LaunchedEffect(isDark) {
        (context as? ComponentActivity)?.window?.let { window ->
            window.statusBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            window.navigationBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
    }
    val scheme = if (isDark) darkColorScheme(
        primary = p.accent, onPrimary = Color(0xFF05201F), background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    ) else lightColorScheme(
        primary = p.accent, onPrimary = Color.White, background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    )

    fun applySnapshot(status: JSONObject, settings: JSONObject? = null, chart: JSONObject? = null, firmwareInfo: JSONObject? = null) {
        val previousHadTarget = snapshot.target.isNotBlank() || snapshot.targetMac.isNotBlank()
        val updated = Snapshot.from(status, settings, chart, firmwareInfo)
        val updatedHasTarget = updated.target.isNotBlank() || updated.targetMac.isNotBlank()
        // Scan results are intentionally independent from the currently configured target.
        // This lets the user scan and choose a replacement target without clearing the old one.
        // The selection callback collapses this list to the single verified AP; a real target
        // clear still resets it so stale scan rows are not shown as the active target.
        if (previousHadTarget && !updatedHasTarget) {
            targetNetworks = emptyList()
        }
        snapshot = updated.copy(
            // Firmware version is static between logins/updates; do not replace it with a
            // placeholder when regular telemetry refreshes intentionally skip that endpoint.
            firmware = updated.firmware.takeIf { it.isNotBlank() && it != "—" } ?: snapshot.firmware,
            // Keep the last chart snapshot on tabs that do not need chart traffic, or when
            // a chart request briefly fails under load.
            targetApRx = if (chart != null) updated.targetApRx else snapshot.targetApRx,
            radioRates = if (chart != null) updated.radioRates else snapshot.radioRates,
            targetRates = if (chart != null) updated.targetRates else snapshot.targetRates
        )
        if (!status.optBoolean("configured", false) && stage == Stage.CONTROL) stage = Stage.SETUP
    }

    suspend fun refreshAdvanced() {
        if (advancedRefreshInProgress) return
        val client = api ?: return
        advancedRefreshInProgress = true
        try {
            // Keep the ESP32 WebServer request load predictable: requests are sequential,
            // and stop at the first failure instead of wasting a full timeout on every
            // remaining settings endpoint when the device is already unreachable.
            val fetchers: List<suspend () -> Result<JSONObject>> = listOf(
                { client.mobileSettings() }, { client.ethernetSettings() }, { client.httpApiSettings() },
                { client.ntpSettings() }, { client.mikrotikSettings() }, { client.ledSettings() },
                { client.disconnectLedSettings() }, { client.scheduleSettings() }, { client.whitelist() },
                { client.firmwareInfo() }, { client.backupInfo() }
            )
            val loaded = ArrayList<JSONObject>(fetchers.size)
            for (fetch in fetchers) {
                val result = fetch()
                if (result.isFailure) {
                    error = result.exceptionOrNull()?.message ?: "Could not load all device settings"
                    return
                }
                loaded += result.getOrThrow()
            }
            advancedSettings = AdvancedSettingsBundle(
                general = loaded[0], ethernet = loaded[1], httpApi = loaded[2],
                ntp = loaded[3], mikrotik = loaded[4], led = loaded[5],
                disconnectLed = loaded[6], schedule = loaded[7], whitelist = loaded[8],
                firmware = loaded[9], backupInfo = loaded[10]
            )
        } finally {
            advancedRefreshInProgress = false
        }
    }

    suspend fun refreshAll(activeTab: Tab = tab) {
        // Manual refreshes and the periodic loop can coincide. Skip the duplicate instead
        // of queuing another complete telemetry cycle behind the first one.
        if (telemetryRefreshInProgress) return
        val client = api ?: return
        telemetryRefreshInProgress = true
        try {
            val sessionResult = sessionManager.statusWithRecovery(client, username, password)
            val status = when (sessionResult) {
                is WapFireSessionManager.StatusResult.Online -> {
                    if (sessionResult.recovered) {
                        notice = tx(isFa, "WAPFire session restored automatically.", "نشست WAPFire به‌صورت خودکار بازیابی شد.")
                    }
                    sessionResult.status
                }
                is WapFireSessionManager.StatusResult.Offline -> {
                    deviceOnline = false
                    // Link failures never erase a valid-looking session or cached screen.
                    // The next heartbeat will check again without discarding the UI state.
                    return
                }
                is WapFireSessionManager.StatusResult.LoginRequired -> {
                    client.clearSession()
                    api = null
                    deviceOnline = false
                    error = sessionResult.message
                    // Keep the active tab, last snapshot, events, and client rows intact.
                    stage = Stage.LOGIN
                    return
                }
            }
            deviceOnline = true
            // In-app notifications are always active while the Activity is visible, regardless
            // of the optional Background Alerts switch. The background service uses the same
            // persisted counter baseline so the two pollers cannot duplicate an alert.
            if (appInForeground) {
                DetectionBreakdownNotificationCenter.process(context.applicationContext, status)
            }
            // Chart data is only needed on Overview. The firmware version is read at login
            // and after setup, so fetching it on every 3-second telemetry cycle is redundant.
            val chartResult = if (activeTab == Tab.OVERVIEW) client.chart() else null
            if (chartResult?.exceptionOrNull() is IOException) deviceOnline = false
            applySnapshot(status, null, chartResult?.getOrNull(), null)

            if (activeTab == Tab.EVENTS) {
                val result = client.logs()
                result.getOrNull()?.let { arr -> logs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
                if (result.exceptionOrNull() is IOException) deviceOnline = false
            }
            if (activeTab == Tab.CLIENTS || activeTab == Tab.SETTINGS) {
                val result = client.clients()
                result.getOrNull()?.let { arr -> clients = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
                if (result.exceptionOrNull() is IOException) deviceOnline = false
            }
        } finally {
            telemetryRefreshInProgress = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            selectedSsid = ""; selectedBssid = ""; wifiPassword = ""
            scope.launch {
                scanning = true; error = ""; notice = ""
                connector.bindToCurrentWifi()
                val activeWifi = discovery.current()
                networks = discovery.scan()
                // When the phone is already on the WAPFire SoftAP, the BSSID
                // result is the same device; skip the extra subnet probe duplicate.
                lanDevices = if (WifiDiscovery.isWapFireBssid(activeWifi.bssid)) emptyList()
                    else discovery.findWapFireOnLan()
                scanning = false
                if (networks.isEmpty() && lanDevices.isEmpty()) error = tx(isFa, "No WAPFire devices found. Check that the SoftAP is enabled and try again, or enter its IP manually.", "دستگاه WAPFire پیدا نشد. روشن بودن SoftAP را بررسی کن یا IP را دستی وارد کن.")
            }
        } else error = tx(isFa, "Wi-Fi permission was not granted. Manual IP remains available.", "مجوز Wi-Fi داده نشد؛ ورود دستی IP همچنان فعال است.")
    }

    fun discoverNow() {
        selectedSsid = ""; selectedBssid = ""; wifiPassword = ""
        val permissions = WifiDiscovery.requiredPermissions()
        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            error = tx(isFa, "Allow nearby Wi-Fi access to scan automatically. You can still enter an IP below.", "برای جستجوی خودکار مجوز Wi-Fi را بده؛ ورود دستی IP هم فعال است.")
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        scope.launch {
            scanning = true; error = ""; notice = ""
            connector.bindToCurrentWifi()
            val activeWifi = discovery.current()
            val wifi = discovery.scan()
            // Avoid listing the currently connected SoftAP a second time by its IP.
            val lan = if (WifiDiscovery.isWapFireBssid(activeWifi.bssid)) emptyList()
                else discovery.findWapFireOnLan()
            networks = wifi
            lanDevices = lan
            scanning = false
            if (wifi.isEmpty() && lan.isEmpty()) error = tx(isFa, "No WAPFire devices found. Check that the SoftAP is enabled and try again, or enter its IP manually.", "دستگاه WAPFire پیدا نشد. روشن بودن SoftAP را بررسی کن یا IP را دستی وارد کن.")
        }
    }

    fun restoreRememberedLogin(targetHost: String) {
        val saved = DeviceLoginVault.load(prefs, targetHost)
        if (saved != null) {
            username = saved.username
            password = saved.password
            rememberPassword = true
        } else {
            username = "admin"
            password = ""
            rememberPassword = false
        }
    }

    fun useHost(value: String, expectedBssid: String? = null) {
        host = value.trim().removePrefix("http://").removePrefix("https://").substringBefore('/')
        prefs.edit().putString("host", host).putString("known_ap_bssid", expectedBssid.orEmpty()).apply()
        restoreRememberedLogin(host)
        // Replace any prior join callback with the BSSID-specific watcher for the
        // currently connected AP; never leave two callbacks competing for process binding.
        connector.release()
        connector.bindToCurrentWifi(
            expectedBssid = expectedBssid,
            onRestored = { restoredNetwork ->
                scope.launch {
                    val verifiedHost = discovery.findWapFireHost(restoredNetwork, host)
                    if (verifiedHost == null) {
                        deviceOnline = false
                        return@launch
                    }
                    host = verifiedHost
                    prefs.edit().putString("host", host).apply()
                    val activeApi = api
                    if (activeApi != null && (stage == Stage.CONTROL || stage == Stage.SETUP)) {
                        val activeHost = activeApi.baseUrl
                            .removePrefix("http://").removePrefix("https://").substringBefore('/')
                        if (activeHost.equals(verifiedHost, ignoreCase = true)) {
                            if (stage == Stage.CONTROL) {
                                refreshAll(tab)
                            } else {
                                when (val restored = sessionManager.statusWithRecovery(activeApi, username, password)) {
                                    is WapFireSessionManager.StatusResult.Online -> {
                                        deviceOnline = true
                                        applySnapshot(restored.status)
                                        if (restored.recovered) notice = tx(isFa, "WAPFire session restored automatically.", "نشست WAPFire به‌صورت خودکار بازیابی شد.")
                                    }
                                    is WapFireSessionManager.StatusResult.Offline -> deviceOnline = false
                                    is WapFireSessionManager.StatusResult.LoginRequired -> {
                                        activeApi.clearSession(); api = null; deviceOnline = false
                                        error = restored.message; stage = Stage.LOGIN
                                    }
                                }
                            }
                            if (deviceOnline) notice = tx(isFa, "WAPFire connection restored.", "اتصال WAPFire دوباره برقرار شد.")
                        } else {
                            // A changed IP is trusted for silent re-authentication only when
                            // the exact AP BSSID was supplied by the discovery/join flow.
                            val sameKnownAp = !expectedBssid.isNullOrBlank() &&
                                expectedBssid.equals(selectedBssid, ignoreCase = true)
                            if (sameKnownAp) {
                                val fresh = sessionManager.connectToVerifiedHost(verifiedHost, username, password)
                                if (fresh.isSuccess) {
                                    activeApi.clearSession()
                                    val connected = fresh.getOrThrow()
                                    api = connected.api
                                    deviceOnline = true
                                    applySnapshot(connected.status)
                                    notice = tx(isFa, "WAPFire connection and session restored.", "اتصال و نشست WAPFire بازیابی شد.")
                                    if (stage == Stage.CONTROL) refreshAll(tab)
                                } else {
                                    activeApi.clearSession(); api = null; deviceOnline = false
                                    error = fresh.exceptionOrNull()?.message ?: "Please sign in again."
                                    stage = Stage.LOGIN
                                }
                            } else {
                                activeApi.clearSession(); api = null; deviceOnline = false
                                error = tx(isFa, "WAPFire address changed. Verify the device and sign in again.", "آدرس WAPFire تغییر کرده است؛ دستگاه را بررسی کن و دوباره وارد شو.")
                                stage = Stage.LOGIN
                            }
                        }
                    }
                }
            },
            onLost = {
                if (stage == Stage.CONTROL || stage == Stage.SETUP) {
                    deviceOnline = false
                    error = ""
                }
            }
        )
        error = ""; notice = ""
        stage = Stage.LOGIN
    }

    fun selectWifiAccessPoint(ap: WifiAccessPoint) {
        if (selectedBssid != ap.bssid) wifiPassword = ""
        selectedSsid = ap.ssid
        selectedBssid = ap.bssid
        error = ""
        notice = tx(isFa, "${ap.ssid} selected. Enter its Wi-Fi password and press Connect below.", "${ap.ssid} انتخاب شد. رمز Wi-Fi را وارد کن و دکمه اتصال پایین را بزن.")
    }

    fun startWifiConnect(ap: WifiAccessPoint) {
        // If the selected WAPFire is already the active Wi-Fi connection, use its
        // current gateway directly instead of asking Android to join the same AP again.
        val currentWifi = discovery.current()
        if (ap.isCurrentConnection || currentWifi.bssid.equals(ap.bssid, ignoreCase = true)) {
            useHost(currentWifi.gateway.ifBlank { "192.168.4.1" }, ap.bssid)
            return
        }
        if (selectedBssid != ap.bssid) {
            selectWifiAccessPoint(ap)
            return
        }
        if (ap.securityMode == "WEP") {
            error = tx(isFa, "WEP networks are not supported by Android's secure local-network join API.", "اتصال امن اندروید از شبکه‌های WEP پشتیبانی نمی‌کند.")
            return
        }
        if (ap.secured && wifiPassword.isBlank()) {
            error = tx(isFa, "Enter the Wi-Fi password for the selected access point.", "رمز Wi-Fi شبکه انتخاب‌شده را وارد کن.")
            return
        }
        if (ap.secured && wifiPassword.length !in 8..63) {
            error = tx(isFa, "WAPFire WPA2/WPA3 passphrases must contain 8–63 characters.", "رمز WPA2/WPA3 دستگاه باید ۸ تا ۶۳ نویسه باشد.")
            return
        }
        if (ap.secured && wifiPassword.any { it.code !in 0x20..0x7E }) {
            error = tx(isFa, "Android requires an ASCII Wi-Fi passphrase for WPA2/WPA3 network requests.", "برای اتصال WPA2/WPA3 از طریق Android، رمز Wi-Fi باید از نویسه‌های ASCII باشد.")
            return
        }
        busy = true; error = ""; notice = ""
        connector.connect(ap.ssid, ap.bssid, wifiPassword, ap.securityMode,
            onAvailable = { network, gateway ->
                scope.launch {
                    val actualHost = gateway.ifBlank { "192.168.4.1" }
                    val verifiedHost = discovery.findWapFireHost(network, actualHost)
                    busy = false

                    // This callback can fire again after Android restores the requested
                    // Wi-Fi network. Keep the authenticated screen/session on recovery.
                    val activeApi = api
                    val hasEstablishedSession = activeApi != null &&
                        (stage == Stage.CONTROL || stage == Stage.SETUP)
                    if (hasEstablishedSession) {
                        if (verifiedHost == null) {
                            deviceOnline = false
                            return@launch
                        }

                        val activeHost = activeApi!!.baseUrl
                            .removePrefix("http://").removePrefix("https://").substringBefore('/')
                        host = verifiedHost
                        prefs.edit().putString("host", host).putString("known_ap_ssid", ap.ssid).putString("known_ap_bssid", ap.bssid).apply()
                        selectedSsid = ap.ssid
                        selectedBssid = ap.bssid
                        error = ""

                        if (activeHost.equals(verifiedHost, ignoreCase = true)) {
                            if (stage == Stage.CONTROL) {
                                // Preserve the authenticated cookie, current tab, and cached UI.
                                refreshAll(tab)
                            } else {
                                when (val restored = sessionManager.statusWithRecovery(activeApi!!, username, password)) {
                                    is WapFireSessionManager.StatusResult.Online -> {
                                        deviceOnline = true
                                        applySnapshot(restored.status)
                                        if (restored.recovered) notice = tx(isFa, "WAPFire session restored automatically.", "نشست WAPFire به‌صورت خودکار بازیابی شد.")
                                    }
                                    is WapFireSessionManager.StatusResult.Offline -> deviceOnline = false
                                    is WapFireSessionManager.StatusResult.LoginRequired -> {
                                        activeApi!!.clearSession(); api = null; deviceOnline = false
                                        error = restored.message; stage = Stage.LOGIN
                                    }
                                }
                            }
                            if (deviceOnline) notice = tx(isFa, "WAPFire connection restored.", "اتصال WAPFire دوباره برقرار شد.")
                        } else {
                            // The exact BSSID is confirmed by this Android Wi-Fi join callback.
                            val fresh = sessionManager.connectToVerifiedHost(verifiedHost, username, password)
                            if (fresh.isSuccess) {
                                activeApi!!.clearSession()
                                val connected = fresh.getOrThrow()
                                api = connected.api
                                deviceOnline = true
                                applySnapshot(connected.status)
                                notice = tx(isFa, "WAPFire connection and session restored.", "اتصال و نشست WAPFire بازیابی شد.")
                                if (stage == Stage.CONTROL) refreshAll(tab)
                            } else {
                                activeApi!!.clearSession(); api = null; deviceOnline = false
                                error = fresh.exceptionOrNull()?.message ?: "Please sign in again."
                                stage = Stage.LOGIN
                            }
                        }
                        return@launch
                    }

                    host = verifiedHost ?: actualHost
                    prefs.edit().putString("host", host).putString("known_ap_ssid", ap.ssid).putString("known_ap_bssid", ap.bssid).apply()
                    selectedSsid = ap.ssid
                    selectedBssid = ap.bssid
                    if (verifiedHost != null) {
                        restoreRememberedLogin(host)
                        wifiPassword = ""
                        notice = tx(isFa, "WAPFire joined over ${ap.securityMode}; device WebUI verified at $host.", "اتصال به WAPFire با ${ap.securityMode} برقرار شد و WebUI دستگاه در $host پاسخ داد.")
                        stage = Stage.LOGIN
                    } else {
                        error = tx(isFa, "Android joined ${ap.ssid}, but the WAPFire login page did not answer at $actualHost. You are still connected to this Wi-Fi. Check that this is the WAPFire BSSID and SoftAP is enabled; you can also try the manual IP below.", "اندروید به ${ap.ssid} وصل شد، اما صفحه ورود WAPFire در $actualHost پاسخ نداد. اتصال Wi-Fi برقرار است؛ بررسی کن BSSID متعلق به WAPFire باشد و SoftAP فعال باشد. همچنین می‌توانی IP را در بخش دستی امتحان کنی.")
                    }
                }
            },
            onFailure = { reason ->
                busy = false
                error = if (reason.isNotBlank())
                    tx(isFa, "WAPFire Wi-Fi join failed: $reason", "اتصال Wi-Fi به WAPFire ناموفق بود: $reason")
                else tx(isFa, "Android could not join this Wi-Fi network. Check its password and try again.", "اندروید نتوانست به این شبکه وصل شود؛ رمز را بررسی و دوباره تلاش کن.")
            },
            onLost = {
                busy = false
                if (stage == Stage.CONTROL || stage == Stage.SETUP) {
                    // Keep the authenticated session, current screen, and cached data.
                    // WifiConnector remains registered and rebinds when Wi-Fi returns.
                    deviceOnline = false
                    error = ""
                } else {
                    error = tx(isFa, "Wi-Fi link to the selected access point was lost. Turn Wi-Fi back on to reconnect automatically, or scan again.", "اتصال Wi-Fi قطع شد. برای اتصال خودکار Wi-Fi را دوباره روشن کن یا مجدداً اسکن کن.")
                }
            }
        )
    }

    fun signIn() {
        scope.launch {
            busy = true; error = ""; notice = ""
            deviceOnline = false
            val client = WapFireApi(host)
            val result = client.login(username, password)
            busy = false
            if (result.isSuccess) {
                api = client
                prefs.edit().putString("host", host).apply()
                val saved = if (rememberPassword) DeviceLoginVault.save(prefs, host, username, password) else {
                    DeviceLoginVault.clear(prefs); false
                }
                val status = client.status()
                if (status.isSuccess) {
                    deviceOnline = true
                    val value = status.getOrThrow()
                    applySnapshot(value, null, firmwareInfo = client.firmwareInfo().getOrNull())
                    if (!value.optBoolean("configured", false)) {
                        setupStep = 0
                        setupAdminPass = ""
                        setupApPass = ""
                        targetNetworks = emptyList()
                        targetSelecting = false
                        val initial = client.mobileSettings().getOrNull() ?: JSONObject()
                        setupApSsid = initial.optString("ap_ssid", value.optString("ap_ssid", "WAPFire")).ifBlank { "WAPFire" }
                        setupLed = initial.optBoolean("led", true)
                        setupSound = initial.optBoolean("sound", true)
                        setupAutoChannel = initial.optBoolean("auto_channel", true)
                        setupSelfProtect = initial.optBoolean("self_protect", false)
                        setupSoftAp = initial.optBoolean("softap_enabled", true)
                        val savedTargetSsid = initial.optString("target")
                        val savedTargetBssid = initial.optString("target_mac")
                        val savedTargetChannel = initial.optInt("target_ch")
                        setupTarget = if (savedTargetSsid.isNotBlank() && savedTargetBssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}")) && savedTargetChannel in 1..13) {
                            JSONObject().put("ssid", savedTargetSsid).put("bssid", savedTargetBssid).put("channel", savedTargetChannel).put("rssi", 0)
                        } else null
                    }
                    stage = if (value.optBoolean("configured", false)) Stage.CONTROL else Stage.SETUP
                    notice = if (rememberPassword && !saved)
                        tx(isFa, "Signed in, but this phone could not securely save the password.", "ورود موفق بود، اما ذخیره امن رمز روی گوشی انجام نشد.")
                    else tx(isFa, "Device session established.", "اتصال امن برقرار شد.")
                } else {
                    client.clearSession()
                    api = null
                    deviceOnline = false
                    error = status.exceptionOrNull()?.message ?: "Could not read device status"
                }
            } else {
                client.clearSession()
                api = null
                error = result.exceptionOrNull()?.message ?: tx(isFa, "Authentication failed.", "ورود ناموفق بود.")
            }
        }
    }

    fun openBatteryOptimizationSettings() {
        val settingsIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        runCatching { context.startActivity(settingsIntent) }
            .onFailure {
                val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                runCatching { context.startActivity(appDetails) }
            }
    }

    fun startBackgroundMonitorNow() {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            error = tx(isFa, "Notifications are disabled for WAPFire. Allow notifications in Android Settings first.", "اعلان‌های WAPFire در اندروید غیرفعال هستند؛ ابتدا مجوز اعلان را فعال کن.")
            return
        }
        try {
            BackgroundMonitorService.start(context)
            backgroundMonitoring = true
            error = ""
            notice = tx(isFa, "Background security monitoring started. You can close the app; the monitor notification will remain visible.", "پایش امنیتی پس‌زمینه شروع شد. می‌توانی اپ را ببندی؛ اعلان پایش فعال می‌ماند.")
        } catch (failure: Exception) {
            backgroundMonitoring = false
            error = failure.message ?: tx(isFa, "Android could not start background monitoring.", "اندروید نتوانست پایش پس‌زمینه را شروع کند.")
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startBackgroundMonitorNow()
        else error = tx(isFa, "Notification permission is required to receive attack alerts.", "برای دریافت هشدار حمله، مجوز اعلان الزامی است.")
    }

    val foregroundNotificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            notice = tx(isFa, "Android notifications are disabled. Enable WAPFire notifications to receive in-app detection alerts.", "اعلان‌های اندروید غیرفعال‌اند؛ برای دریافت هشدار هنگام استفاده از اپ، اعلان WAPFire را فعال کن.")
        }
    }

    fun requestBackgroundMonitorStart() {
        if (!deviceOnline || api == null) {
            error = tx(isFa, "Connect and sign in to WAPFire before starting background monitoring.", "قبل از شروع پایش پس‌زمینه به WAPFire وصل شو و وارد حساب شو.")
            return
        }
        if (DeviceLoginVault.load(prefs, host) == null) {
            showMonitorCredentialDialog = true
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startBackgroundMonitorNow()
        }
    }

    fun toggleBackgroundMonitor() {
        if (backgroundMonitoring || BackgroundMonitorService.isRunning(context)) {
            BackgroundMonitorService.stop(context)
            backgroundMonitoring = false
            notice = tx(isFa, "Background security monitoring stopped.", "پایش امنیتی پس‌زمینه متوقف شد.")
        } else {
            requestBackgroundMonitorStart()
        }
    }

    LaunchedEffect(stage) {
        if (stage == Stage.CONTROL && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("foreground_detection_permission_requested", false)
        ) {
            prefs.edit().putBoolean("foreground_detection_permission_requested", true).apply()
            foregroundNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(Unit) {
        val saved = savedLoginAtLaunch
        if (saved != null) {
            busy = true
            error = ""
            val currentWifi = discovery.current()
            val savedBssid = prefs.getString("known_ap_bssid", "").orEmpty()
            val bindBssid = when {
                WifiDiscovery.isWapFireBssid(currentWifi.bssid) -> currentWifi.bssid
                savedBssid.isNotBlank() && currentWifi.bssid.equals(savedBssid, ignoreCase = true) -> savedBssid
                else -> null
            }
            connector.bindToCurrentWifi(expectedBssid = bindBssid)
            val targetHost = if (WifiDiscovery.isWapFireBssid(currentWifi.bssid) && currentWifi.gateway.isNotBlank()) {
                currentWifi.gateway
            } else host
            host = targetHost
            prefs.edit().putString("host", targetHost).apply()
            username = saved.username
            password = saved.password
            rememberPassword = true

            val client = WapFireApi(targetHost)
            when (val restored = sessionManager.statusWithRecovery(client, saved.username, saved.password)) {
                is WapFireSessionManager.StatusResult.Online -> {
                    api = client
                    deviceOnline = true
                    applySnapshot(restored.status, null, firmwareInfo = client.firmwareInfo().getOrNull())
                    stage = if (restored.status.optBoolean("configured", false)) Stage.CONTROL else Stage.SETUP
                    tab = Tab.OVERVIEW
                    notice = tx(isFa, "WAPFire session restored.", "ورود قبلی به WAPFire بازیابی شد.")
                    if (stage == Stage.SETUP) {
                        val initial = client.mobileSettings().getOrNull() ?: JSONObject()
                        setupApSsid = initial.optString("ap_ssid", restored.status.optString("ap_ssid", "WAPFire")).ifBlank { "WAPFire" }
                        setupLed = initial.optBoolean("led", true)
                        setupSound = initial.optBoolean("sound", true)
                        setupAutoChannel = initial.optBoolean("auto_channel", true)
                        setupSelfProtect = initial.optBoolean("self_protect", false)
                        setupSoftAp = initial.optBoolean("softap_enabled", true)
                    }
                }
                is WapFireSessionManager.StatusResult.Offline -> {
                    deviceOnline = false
                    notice = tx(isFa, "Saved WAPFire login is ready. Reconnect to the device to continue.", "اطلاعات ورود ذخیره است؛ برای ادامه دوباره به WAPFire متصل شو.")
                }
                is WapFireSessionManager.StatusResult.LoginRequired -> {
                    deviceOnline = false
                    error = restored.message
                    stage = Stage.LOGIN
                }
            }
            busy = false
        }
    }

    LaunchedEffect(stage, tab, api, appInForeground) {
        if (stage == Stage.CONTROL && api != null && appInForeground) {
            // Settings forms are loaded once on entry, not on every telemetry poll.
            if (tab == Tab.SETTINGS) refreshAdvanced()
            while (stage == Stage.CONTROL && appInForeground) {
                refreshAll(tab)
                // Detection Breakdown is checked at least every 5 seconds on every app tab.
                delay(if (tab == Tab.OVERVIEW) 3000 else 5000)
            }
        }
    }

    BackHandler(enabled = stage != Stage.DISCOVERY) {
        when (stage) {
            Stage.LOGIN -> stage = Stage.DISCOVERY
            Stage.SETUP -> if (setupStep > 0) setupStep-- else stage = Stage.DISCOVERY
            Stage.CONTROL -> { tab = Tab.OVERVIEW }
            else -> Unit
        }
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg, p.bg2, p.bg)))) {
            Box(Modifier.align(Alignment.TopEnd).padding(top = 70.dp, end = 8.dp).size(230.dp).blur(48.dp)
                .background(Brush.radialGradient(listOf(p.accent.copy(alpha = if (isDark) .20f else .13f), Color.Transparent)), CircleShape))
            Box(Modifier.align(Alignment.BottomStart).padding(bottom = 100.dp, start = 0.dp).size(260.dp).blur(54.dp)
                .background(Brush.radialGradient(listOf(p.blue.copy(alpha = if (isDark) .17f else .11f), Color.Transparent)), CircleShape))
            when (stage) {
                Stage.DISCOVERY -> DiscoveryScreen(
                    p, isFa, isDark, host, { host = it }, discovery.current(), networks, lanDevices,
                    scanning, busy, selectedSsid, selectedBssid, wifiPassword, { wifiPassword = it }, error, notice,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    onScan = { discoverNow() }, onSelectWifi = { selectWifiAccessPoint(it) },
                    onConnect = { startWifiConnect(it) },
                    onUseLan = { useHost(it) }, onUseCurrent = { discoverNow() },
                    onManual = { useHost(host) },
                    onChangeWifiSelection = { selectedSsid = ""; selectedBssid = ""; wifiPassword = ""; error = ""; notice = "" }
                )
                Stage.LOGIN -> LoginScreen(
                    p, isFa, isDark, host, { host = it }, username, { username = it }, password, { password = it },
                    rememberPassword, { checked ->
                        rememberPassword = checked
                        prefs.edit().putBoolean("remember_password_preference", checked).apply()
                        if (!checked) {
                            DeviceLoginVault.clear(prefs)
                            BackgroundMonitorService.stop(context)
                            backgroundMonitoring = false
                        }
                    },
                    busy, error, notice, onBack = { stage = Stage.DISCOVERY }, onLogin = { signIn() },
                    onClear = { error = ""; notice = "" },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() }
                )
                Stage.SETUP -> FirstSetupScreen(
                    p = p, fa = isFa, dark = isDark,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    step = setupStep, onStep = { setupStep = it },
                    apSsid = setupApSsid, onApSsid = { setupApSsid = it },
                    apPass = setupApPass, onApPass = { setupApPass = it },
                    adminPass = setupAdminPass, onAdminPass = { setupAdminPass = it },
                    led = setupLed, onLed = { setupLed = it },
                    sound = setupSound, onSound = { setupSound = it },
                    autoChannel = setupAutoChannel, onAutoChannel = { setupAutoChannel = it },
                    selfProtect = setupSelfProtect, onSelfProtect = { setupSelfProtect = it },
                    softAp = setupSoftAp, onSoftAp = { setupSoftAp = it },
                    targetNetworks = targetNetworks, target = setupTarget,
                    targetScanning = targetScanBusy, targetSelecting = targetSelecting,
                    onTargetScan = {
                        scope.launch {
                            targetScanBusy = true; targetNetworks = emptyList(); error = ""; notice = ""
                            val result = api?.scan()
                            if (result?.isSuccess == true) {
                                val arr = result.getOrThrow()
                                val scanned = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                                val selectedBssid = setupTarget?.optString("bssid").orEmpty().trim()
                                targetNetworks = if (selectedBssid.isBlank()) scanned else
                                    scanned.filter { it.optString("bssid").trim().equals(selectedBssid, ignoreCase = true) }
                                if (targetNetworks.isEmpty()) notice = tx(isFa, "No matching access point was returned by the WAPFire radio scan.", "اکسس‌پوینت منطبق در اسکن رادیویی WAPFire پیدا نشد.")
                            } else error = result?.exceptionOrNull()?.message ?: "Target scan failed"
                            targetScanBusy = false
                        }
                    },
                    onTargetSelect = { network ->
                        scope.launch {
                            val ssid = network.optString("ssid")
                            val bssid = network.optString("bssid")
                            val channel = network.optInt("channel")
                            if (ssid.isBlank() || !isValidBssid(bssid) || channel !in 1..13) {
                                error = tx(isFa, "This access point has incomplete or invalid SSID/BSSID/channel data.", "اطلاعات SSID، BSSID یا کانال این شبکه ناقص یا نامعتبر است.")
                            } else {
                                targetSelecting = true; error = ""; notice = ""
                                val selected = api?.selectTarget(ssid, bssid, channel)
                                if (selected?.isSuccess == true) {
                                    val response = selected.getOrThrow()
                                    val verifiedBssid = response.optString("bssid", bssid).ifBlank { bssid }
                                    val verifiedChannel = response.optInt("channel", channel).takeIf { it in 1..13 } ?: channel
                                    val verifiedTarget = JSONObject()
                                        .put("ssid", response.optString("target", ssid).ifBlank { ssid })
                                        .put("bssid", verifiedBssid)
                                        .put("channel", verifiedChannel)
                                        .put("rssi", network.optInt("rssi"))
                                        .put("secured", network.optBoolean("secured"))
                                    if (isValidBssid(verifiedBssid)) {
                                        setupTarget = verifiedTarget
                                        targetNetworks = listOf(verifiedTarget)
                                        notice = tx(isFa, "Target verified by WAPFire: $ssid", "شبکه هدف توسط WAPFire تأیید شد: $ssid")
                                    } else {
                                        error = tx(isFa, "WAPFire returned an invalid target BSSID.", "فریم‌ور BSSID نامعتبر برای شبکه هدف برگرداند.")
                                    }
                                } else error = selected?.exceptionOrNull()?.message ?: "Target selection failed"
                                targetSelecting = false
                            }
                        }
                    },
                    onChangeTarget = { setupTarget = null; targetNetworks = emptyList() },
                    onRestore = { restoreDocumentLauncher.launch(arrayOf("application/json", "text/*")) },
                    saving = saving, snapshot = snapshot, error = error, notice = notice,
                    onFinish = {
                        val selected = setupTarget
                        if (selected == null) {
                            error = tx(isFa, "Select and verify a target access point before applying setup.", "قبل از اعمال Setup یک شبکه هدف انتخاب و تأیید کن.")
                        } else {
                            scope.launch {
                                saving = true; error = ""; notice = ""
                                val payload = JSONObject()
                                    .put("adminpass", setupAdminPass)
                                    .put("ap_ssid", setupApSsid)
                                    .put("ap_pass", setupApPass)
                                    .put("led", setupLed)
                                    .put("sound", setupSound)
                                    .put("auto_channel", setupAutoChannel)
                                    .put("self_protect", setupSelfProtect)
                                    .put("softap_enabled", setupSoftAp)
                                    .put("target", selected.optString("ssid"))
                                    .put("target_ch", selected.optInt("channel"))
                                    .put("target_mac", selected.optString("bssid"))
                                val client = api
                                val result = client?.updateSettings(payload)
                                saving = false
                                if (result?.isSuccess == true) {
                                    val response = result.getOrThrow()
                                    password = setupAdminPass
                                    val rememberedSetupSaved = if (rememberPassword)
                                        DeviceLoginVault.save(prefs, host, username, setupAdminPass) else true
                                    if (!rememberedSetupSaved) error = "Setup was applied, but the updated password could not be saved securely on this phone."
                                    if (response.optBoolean("wifi_restart_needed", false)) {
                                        notice = tx(isFa, "Setup saved. WAPFire is restarting its SoftAP with the new credentials. Rejoin it to continue.", "تنظیمات ذخیره شد. شبکه WAPFire با مشخصات جدید راه‌اندازی مجدد می‌شود؛ دوباره به آن وصل شو.")
                                        client?.clearSession(); api = null
                                        delay(3800)
                                        connector.release()
                                        host = "192.168.4.1"
                                        prefs.edit().putString("host", host).apply()
                                        stage = Stage.DISCOVERY
                                    } else {
                                        val status = client.status().getOrNull()
                                        if (status?.optBoolean("configured") == true) {
                                            deviceOnline = true
                                            applySnapshot(status, null, firmwareInfo = client.firmwareInfo().getOrNull())
                                            stage = Stage.CONTROL
                                            tab = Tab.OVERVIEW
                                            notice = tx(isFa, "Initial setup completed.", "راه‌اندازی اولیه کامل شد.")
                                        } else error = tx(isFa, "The device did not confirm setup completion.", "دستگاه تکمیل راه‌اندازی را تأیید نکرد.")
                                    }
                                } else error = result?.exceptionOrNull()?.message ?: "Setup could not be saved"
                            }
                        }
                    },
                    onClear = { error = ""; notice = "" },
                    onLogout = {
                        BackgroundMonitorService.stop(context)
                        backgroundMonitoring = false
                        DeviceLoginVault.clear(prefs)
                        scope.launch {
                            val client = api
                            runCatching { client?.logout() }
                            client?.clearSession(); api = null; deviceOnline = false; connector.release()
                            stage = Stage.DISCOVERY; error = ""; notice = ""
                        }
                    }
                )
                Stage.CONTROL -> ControlCenter(
                    p, isFa, isDark, tab, snapshot, deviceOnline, logs, clients, error, notice,
                    onTab = { tab = it; error = ""; notice = "" },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = {
                        val next = if (isFa) "en" else "fa"
                        scope.launch {
                            val result = api?.setLanguage(next)
                            if (result?.isSuccess == true) {
                                isFa = next == "fa"
                                prefs.edit().putBoolean("fa", isFa).apply()
                                notice = result.getOrThrow().optString("message").ifBlank { "Device language updated." }
                            } else error = result?.exceptionOrNull()?.message ?: "Could not update device language"
                        }
                    },
                    onRefresh = { scope.launch { refreshAll(tab); if (tab == Tab.SETTINGS) refreshAdvanced() } },
                    onToggle = { key, value ->
                        scope.launch {
                            val result = api?.updateSettings(JSONObject().put(key, value))
                            if (result?.isSuccess == true) {
                                val response = result.getOrThrow()
                                if (response.optBoolean("wifi_restart_needed")) {
                                    notice = tx(isFa, "Setting saved. WAPFire Wi-Fi is restarting; reconnect and sign in again.", "تنظیم ذخیره شد. Wi‑Fi دستگاه دوباره راه‌اندازی می‌شود؛ دوباره متصل شو و وارد شو.")
                                    api?.clearSession(); api = null
                                    delay(700)
                                    connector.release()
                                    stage = Stage.DISCOVERY
                                } else {
                                    notice = response.optString("message").ifBlank { tx(isFa, "${key.replace('_', ' ')} updated on WAPFire.", "تنظیم ${key.replace('_', ' ')} در WAPFire اعمال شد.") }
                                    refreshAll(tab)
                                }
                            } else error = result?.exceptionOrNull()?.message ?: "Setting was not applied"
                        }
                    },
                    targetNetworks = targetNetworks, targetScanBusy = targetScanBusy,
                    targetSelecting = targetSelecting,
                    onTargetScan = {
                        scope.launch {
                            targetScanBusy = true
                            error = ""; notice = ""
                            // Do not require clearing the current target. A scan always exposes
                            // every AP returned by the radio, regardless of the active BSSID.
                            val result = api?.scan()
                            targetScanBusy = false
                            if (result?.isSuccess == true) {
                                val found = result.getOrThrow()
                                targetNetworks = (0 until found.length()).mapNotNull { found.optJSONObject(it) }
                                if (targetNetworks.isEmpty()) notice = tx(
                                    isFa,
                                    "No access points were returned by the scan. Try scanning again.",
                                    "در این اسکن اکسس‌پوینتی برنگشت. دوباره اسکن کن."
                                )
                            } else {
                                error = result?.exceptionOrNull()?.message ?: tx(isFa, "Network scan failed.", "اسکن شبکه ناموفق بود.")
                            }
                        }
                    },
                    onSelectTarget = { network ->
                        scope.launch {
                            if (targetSelecting) return@launch
                            targetSelecting = true
                            error = ""; notice = ""
                            val ssid = network.optString("ssid")
                            val bssid = network.optString("bssid").trim()
                            val channel = network.optInt("channel")
                            if (ssid.isBlank() || !isValidBssid(bssid) || channel !in 1..13) {
                                error = tx(isFa, "This access point cannot be selected because its SSID, BSSID or channel is invalid.", "به دلیل نامعتبر بودن SSID، BSSID یا کانال، این اکسس‌پوینت قابل انتخاب نیست.")
                            } else {
                                val selected = api?.selectTarget(ssid, bssid, channel)
                                if (selected?.isSuccess == true) {
                                    val verified = selected.getOrThrow()
                                    val verifiedBssid = verified.optString("bssid", bssid).ifBlank { bssid }
                                    val verifiedChannel = verified.optInt("channel", channel).takeIf { it in 1..13 } ?: channel
                                    val selectedAp = JSONObject()
                                        .put("ssid", verified.optString("target", ssid).ifBlank { ssid })
                                        .put("bssid", verifiedBssid)
                                        .put("channel", verifiedChannel)
                                        .put("rssi", network.optInt("rssi"))
                                        .put("secured", network.optBoolean("secured"))
                                    if (!isValidBssid(verifiedBssid)) {
                                        error = tx(isFa, "WAPFire returned an invalid target BSSID.", "فریم‌ور BSSID نامعتبر برای شبکه هدف برگرداند.")
                                    } else {
                                        // Keep the verified radio as the only result even if persistence fails.
                                        targetNetworks = listOf(selectedAp)
                                        refreshAll(Tab.OVERVIEW)
                                        val saved = api?.saveTarget(ssid, verifiedBssid, verifiedChannel)
                                        if (saved?.isSuccess == true) notice = tx(isFa, "Target selected and saved.", "شبکه هدف انتخاب و ذخیره شد.")
                                        else error = saved?.exceptionOrNull()?.message ?: "Target is active but could not be saved"
                                    }
                                } else error = selected?.exceptionOrNull()?.message ?: "Target selection failed"
                            }
                            targetSelecting = false
                        }
                    },
                    onClearLogs = {
                        scope.launch {
                            val result = api?.clearLogs()
                            if (result?.isSuccess == true) { notice = tx(isFa, "Device event log cleared.", "گزارش رویدادهای دستگاه پاک شد."); refreshAll(Tab.EVENTS) }
                            else error = result?.exceptionOrNull()?.message ?: "Could not clear logs"
                        }
                    },
                    onClearTarget = {
                        scope.launch {
                            val result = api?.selectTarget("", "", 0)
                            if (result?.isSuccess == true) {
                                targetNetworks = emptyList()
                                notice = tx(isFa, "Target cleared.", "شبکه هدف پاک شد.")
                                refreshAll(Tab.OVERVIEW)
                            } else error = result?.exceptionOrNull()?.message ?: "Could not clear target"
                        }
                    },
                    onLogout = {
                        BackgroundMonitorService.stop(context)
                        backgroundMonitoring = false
                        DeviceLoginVault.clear(prefs)
                        scope.launch {
                            val client = api
                            runCatching { client?.logout() }
                            client?.clearSession(); api = null; connector.release()
                            password = ""; setupAdminPass = ""; setupApPass = ""; wifiPassword = ""
                            logs = emptyList(); clients = emptyList(); targetNetworks = emptyList()
                            snapshot = Snapshot(); error = ""; notice = ""; stage = Stage.DISCOVERY; tab = Tab.OVERVIEW
                        }
                    },
                    onClearMessage = { error = ""; notice = "" },
                    advanced = advancedSettings,
                    onAdvancedSave = { module, payload ->
                        scope.launch {
                            error = ""; notice = ""
                            val result = when (module) {
                                "general" -> api?.updateSettings(payload)
                                "ethernet" -> api?.saveEthernet(payload)
                                "http_api" -> api?.saveHttpApi(payload)
                                "ntp" -> api?.saveNtp(payload)
                                "mikrotik" -> api?.saveMikrotik(payload)
                                "led" -> api?.saveLed(payload)
                                "disconnect_led" -> api?.saveDisconnectLed(payload)
                                "schedule" -> api?.saveSchedule(payload)
                                "whitelist" -> api?.saveWhitelist(payload)
                                else -> null
                            }
                            if (result?.isSuccess == true) {
                                val response = result.getOrThrow()
                                notice = response.optString("message").ifBlank { "${module.replace('_', ' ')} settings saved." }
                                if (module == "general" && payload.has("adminpass")) {
                                    password = payload.optString("adminpass")
                                    if (rememberPassword && !DeviceLoginVault.save(prefs, host, username, password)) {
                                        error = "Password changed, but the updated login could not be saved securely on this phone."
                                    }
                                }
                                if (module == "general" && response.optBoolean("wifi_restart_needed")) {
                                    notice = "Credentials / target saved. WAPFire Wi-Fi is restarting; reconnect and sign in again."
                                    api?.clearSession(); api = null
                                    delay(3600)
                                    connector.release(); stage = Stage.DISCOVERY
                                } else {
                                    refreshAdvanced()
                                }
                            } else error = result?.exceptionOrNull()?.message ?: "Could not save ${module.replace('_', ' ')} settings"
                        }
                    },
                    onAdvancedAction = { action ->
                        scope.launch {
                            error = ""; notice = ""
                            val client = api
                            when (action) {
                                "test_http_api" -> { val r = client?.testHttpApi(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "Test event sent") else error = r?.exceptionOrNull()?.message ?: "HTTP API test failed" }
                                "test_mikrotik" -> { val r = client?.testMikrotik(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "MikroTik test queued") else error = r?.exceptionOrNull()?.message ?: "MikroTik test failed" }
                                "ntp_sync_now" -> { val r = client?.syncNtpNow(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "NTP sync initiated") else error = r?.exceptionOrNull()?.message ?: "NTP sync failed" }
                                "ntp_sync_browser" -> { val r = client?.syncNtpFromPhone(System.currentTimeMillis() / 1000L); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "Phone time sent to WAPFire") else error = r?.exceptionOrNull()?.message ?: "Phone time sync failed" }
                                "refresh_clients" -> { refreshAll(Tab.SETTINGS); notice = tx(isFa, "Tracked client list refreshed.", "فهرست کلاینت‌های ردیابی‌شده به‌روز شد.") }
                                "check_update" -> { val r = client?.checkUpdate(); if (r?.isSuccess == true) { val v = r.getOrThrow(); notice = when { v.optBoolean("update_available") -> "Update available: ${v.optString("latest_version")}"; !v.optBoolean("automatic_updates_supported", true) -> v.optString("message").ifBlank { "No online release feed is configured. Manual OTA remains available." }; else -> "WAPFire is up to date (${v.optString("current_version")})." } } else error = r?.exceptionOrNull()?.message ?: "Update check failed" }
                                "reboot", "wifi_restart", "factory_reset", "force_setup" -> {
                                    val path = when (action) {
                                        "reboot" -> "/reboot"
                                        "wifi_restart" -> "/wifi_restart"
                                        "factory_reset" -> "/factory_reset"
                                        else -> "/force_setup"
                                    }
                                    val r = client?.deviceAction(path)
                                    if (r?.isSuccess == true) {
                                        notice = when (action) {
                                            "factory_reset" -> "Factory reset accepted. Reconnect and run setup again."
                                            "force_setup" -> "Setup mode enabled. Reconnect to WAPFire and complete setup."
                                            "reboot" -> "WAPFire is rebooting. Reconnect when it is online."
                                            else -> "Wi-Fi services are restarting. Reconnect when the access point returns."
                                        }
                                        client?.clearSession(); api = null
                                        delay(700)
                                        connector.release()
                                        if (action == "factory_reset" || action == "force_setup") {
                                            snapshot = Snapshot(); logs = emptyList(); clients = emptyList(); advancedSettings = AdvancedSettingsBundle()
                                        }
                                        stage = Stage.DISCOVERY
                                    } else error = r?.exceptionOrNull()?.message ?: "Device action failed"
                                }
                            }
                        }
                    },
                    onBackup = {
                        scope.launch {
                            val r = api?.backupSettings()
                            if (r?.isSuccess == true) {
                                val bytes = r.getOrThrow()
                                val name = "WAPFire-backup-${System.currentTimeMillis()}.json"
                                pendingBackupBytes = bytes
                                backupDestinationLauncher.launch(name)
                            } else error = r?.exceptionOrNull()?.message ?: "Backup failed"
                        }
                    },
                    onRestore = { restoreDocumentLauncher.launch(arrayOf("application/json", "text/*")) },
                    onFirmwarePick = { firmwareDocumentLauncher.launch(arrayOf("application/octet-stream", "application/x-binary", "application/firmware")) },
                    backgroundMonitorActive = backgroundMonitoring,
                    onBackgroundMonitor = { toggleBackgroundMonitor() },
                    onBatterySettings = { openBatteryOptimizationSettings() }
                )
            }
            if (showMonitorCredentialDialog) {
                AlertDialog(
                    onDismissRequest = { showMonitorCredentialDialog = false },
                    title = { Text(tx(isFa, "Enable background monitoring?", "فعال‌سازی پایش پس‌زمینه؟"), color = p.text) },
                    text = {
                        Text(
                            tx(
                                isFa,
                                "To monitor while the app is closed, WAPFire needs to save this device password on your phone. It is encrypted with Android Keystore and is only sent after the VF38 login page is verified. Enable secure saving and continue?",
                                "برای ادامه پایش پس از بسته شدن اپ، رمز دستگاه باید روی گوشی ذخیره شود. رمز با Android Keystore رمزنگاری می‌شود و فقط پس از تأیید صفحه ورود فریمور VF38 ارسال خواهد شد. ذخیره امن رمز و ادامه فعال‌سازی؟"
                            ),
                            color = p.muted
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            showMonitorCredentialDialog = false
                            val saved = DeviceLoginVault.save(prefs, host, username, password)
                            if (saved) {
                                rememberPassword = true
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                                        context, Manifest.permission.POST_NOTIFICATIONS
                                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                                ) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else startBackgroundMonitorNow()
                            } else {
                                error = tx(isFa, "The password could not be encrypted and saved. Monitoring was not started.", "رمز عبور ذخیره امن نشد؛ پایش شروع نشد.")
                            }
                        }) { Text(tx(isFa, "Enable", "فعال‌سازی"), color = p.accent) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showMonitorCredentialDialog = false }) { Text(tx(isFa, "Cancel", "لغو"), color = p.muted) }
                    }
                )
            }
            // A separate popup window is fully detached from the scrollable page's
            // measurement and nested-scroll hierarchy.
            if (error.isNotBlank() || notice.isNotBlank()) {
                Popup(
                    alignment = Alignment.TopCenter,
                    properties = PopupProperties(
                        focusable = false,
                        dismissOnBackPress = false,
                        dismissOnClickOutside = false,
                        clippingEnabled = true
                    )
                ) {
                    Box(
                        Modifier.widthIn(max = 320.dp)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .shadow(16.dp, RoundedCornerShape(14.dp))
                    ) {
                        MessageCard(
                            p,
                            if (error.isNotBlank()) error else notice,
                            error.isNotBlank(),
                            onClose = { error = ""; notice = "" }
                        )
                    }
                }
            }
        }
        }
    }
}
