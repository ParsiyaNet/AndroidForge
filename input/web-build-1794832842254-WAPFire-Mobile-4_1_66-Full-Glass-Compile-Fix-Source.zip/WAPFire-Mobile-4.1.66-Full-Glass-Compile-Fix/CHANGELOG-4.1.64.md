# 4.1.64 — Full Glass GPU pass optimization

## Liquid Glass rendering
- Replaced the per-card Android `setShadowLayer` + `ClipOp.Difference` path with a single composed GPU shader for the body, light-bleed and specular layers.
- Preserved all original Full Glass color stops, alpha values, gradients, glint position/width and refracting rim.
- Removed the standalone shadow draw and merged the glass surface, glint and rim into one cached Compose draw node.
- Kept rounded clipping for card content. No device-tier quality scaling or pixel-ratio reduction.

## App backdrop
- Composed the opaque base gradient and three ambient radial lights into one cached shader draw. Their centers, radii, colors, opacity and stacking order are unchanged.

## Unchanged
- Nara / LivLiv / WebGL code, model assets, character animation, network polling, monitoring logic, navigation and application behavior.

## Validation
- Source-level change only. Gradle compilation and physical-device frame-time testing must be run before claiming runtime performance improvement.
