# WAPFire Mobile 4.1.65 — Full Glass build fix

- Restored `LocalContentInset` in `UiComponents.kt`. It is consumed by Dashboard and Settings screens and was accidentally removed while replacing the Liquid Glass drawing implementation in 4.1.64.
- Kept the 4.1.64 Full Glass shader and rendering changes unchanged.
- No WebGL, character, animation, pixel-ratio, or Full Glass quality changes.
- Increased Android `versionCode` to 111 and set `versionName` to `4.1.65`.
