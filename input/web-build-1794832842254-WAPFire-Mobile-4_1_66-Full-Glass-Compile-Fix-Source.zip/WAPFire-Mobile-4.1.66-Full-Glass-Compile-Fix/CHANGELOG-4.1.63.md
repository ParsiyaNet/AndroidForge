# 4.1.63 — Full Glass rendering optimization

## Liquid Glass performance
- Kept the Full Glass visual profile on every device; no device-tier quality reduction or adaptive downgrade.
- Preserved glass opacity, palette colors, gradient stops, top-edge glint, rim and card elevations.
- Kept the 4.1.62 outside-only shadow behavior (no shadow is painted underneath translucent glass), while merging the ambient and spot shadows into one cached `Paint.setShadowLayer` / `drawPath` pass, with a blended color and weighted blur/offset matching the original composite as closely as one pass allows.
- Combined the three glass surface gradients and top-edge glint into one size-cached drawing node per glass surface.
- Cached the three full-screen radial light brushes by backdrop size.

## Unchanged
- WebGL, Nara / LivLiv character rendering, character animations, WebView lifecycle, layout dimensions, networking and monitoring behavior.
