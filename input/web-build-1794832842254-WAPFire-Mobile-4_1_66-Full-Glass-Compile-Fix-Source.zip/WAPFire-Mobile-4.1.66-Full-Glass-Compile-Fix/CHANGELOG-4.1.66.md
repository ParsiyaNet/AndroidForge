# WAPFire Mobile 4.1.66 — Full Glass Kotlin compile fix

- Fixed the Kotlin `Unresolved reference: fillPaint` error in `UiComponents.kt`.
- Inside the `Paint.apply { ... }` initializer, assign the composed shader through the receiver property (`shader = ...`) instead of referring to `fillPaint` before its initializer has completed.
- Preserved the 4.1.65 Full Glass shader stops, alpha values, glint, rim, backdrop, and rendering quality.
- No WebGL, character, animation, pixel-ratio, or adaptive-quality changes.
- Android versionCode: 112; versionName: 4.1.66.
