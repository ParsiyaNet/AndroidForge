# WAPFire Mobile 4.1.44

## Overview assistant layout
- Increased the Overview assistant preview height from 218dp to 280dp.
- Removed the extra Compose spacing between the character frame and the native speech panel and slightly tightened the card padding.
- Explicitly sized the compact WebView shell and stage to the full measured viewport to eliminate unused space below the character frame.
- Kept the proven 1.18x compact camera zoom from 4.1.43 so Sena’s full hairline remains visible; the taller viewport increases her on-screen size without changing the crop or stretching the model.
- Left the full Assistant screen, monitoring logic, network behavior and other Overview cards unchanged.

## Version
- Version name: 4.1.44
- Version code: 85
