# WAPFire Mobile 4.2.1

- Replaced Android system TextToSpeech with bundled Sherpa-ONNX OfflineTts + Kokoro English `af_bella` (speaker ID 1).
- Speech output is English-only in both English and Persian UI modes; Persian on-screen strings are unchanged.
- Removed the dependency on installed phone TTS voices and all prompts to install voices from Android Settings.
- Added a build-time resource pipeline that downloads/verifies the Sherpa-ONNX Android AAR, Kokoro English model, English lexicon, and copies only the needed model files into APK assets.
- Added proper uncompressed APK asset packaging for ONNX and voice binary files.
- Improved Hiyori Live2D movement: explicit randomized `Idle` motion startup plus eased gaze drift, breathing, and restrained head/body sway, while retaining the existing state poses and speech lip-sync bridge.
- Android versionCode/versionName: 103 / 4.2.1.

## Build / size notes

The first build needs GitHub access and downloads the model resources. `model.onnx` alone is about 330 MB, so the resulting APK is substantially larger than 4.2.0. Once installed, Kokoro voice generation itself works offline and does not require Android system TTS data.
