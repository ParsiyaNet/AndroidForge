package io.wapfire.mobile.ui.screens

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.max

/**
 * WAPFire 4.2.1: fully bundled, offline English voice for Nara.
 * Kokoro English speaker af_bella (speaker ID 1) is packaged in the APK;
 * Android system TextToSpeech voices and the phone's TTS Settings are never used.
 */
internal class AssistantVoice(
    context: Context,
    private val onSpeaking: (Boolean) -> Unit
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val engineMutex = Mutex()

    @Volatile private var engine: OfflineTts? = null
    @Volatile private var activeTrack: AudioTrack? = null
    private var requestJob: Job? = null
    @Volatile private var requestId: Long = 0L
    private var hasShownError = false

    fun speak(text: String) {
        // A hard guard: never synthesize Persian/Arabic-script text, even if a future
        // caller accidentally passes the localized UI caption instead of English.
        if (text.isBlank() || containsNonEnglishScript(text)) return
        val cleanText = text.trim().take(MAX_TEXT_CHARS)
        if (cleanText.isBlank()) return

        val id = ++requestId
        requestJob?.cancel()
        stopAudioTrack()
        onSpeaking(false)
        requestJob = scope.launch {
            try {
                val generated = withContext(Dispatchers.Default) {
                    engineMutex.withLock {
                        val tts = engine ?: createEngine().also { engine = it }
                        tts.generate(cleanText, sid = BELLA_SPEAKER_ID, speed = SPEECH_SPEED)
                    }
                }
                if (id != requestId) return@launch
                onSpeaking(true)
                withContext(Dispatchers.IO) {
                    play(generated.samples, generated.sampleRate, id)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (id == requestId) showVoiceError(error)
            } finally {
                if (id == requestId) {
                    stopAudioTrack()
                    onSpeaking(false)
                }
            }
        }
    }

    private fun createEngine(): OfflineTts {
        val base = "assistant/tts/kokoro-en-v0_19"
        val model = OfflineTtsKokoroModelConfig(
            model = "$base/model.onnx",
            voices = "$base/voices.bin",
            tokens = "$base/tokens.txt",
            lexicon = "$base/lexicon-en-us.txt",
            lang = "eng"
        )
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                kokoro = model,
                numThreads = max(2, Runtime.getRuntime().availableProcessors().coerceAtMost(4)),
                debug = false,
                provider = "cpu"
            ),
            maxNumSentences = 2
        )
        return OfflineTts(assetManager = appContext.assets, config = config)
    }

    private suspend fun play(samples: FloatArray, sampleRate: Int, id: Long) {
        if (samples.isEmpty() || sampleRate <= 0) return
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        check(minBuffer > 0) { "Unsupported audio format ($sampleRate Hz)" }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuffer * 2, 16 * 1024))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        activeTrack = track
        try {
            track.play()
            val pcm = ShortArray(CHUNK_SAMPLES)
            var offset = 0
            while (offset < samples.size && id == requestId) {
                coroutineContext.ensureActive()
                val count = minOf(CHUNK_SAMPLES, samples.size - offset)
                for (i in 0 until count) {
                    val value = samples[offset + i].coerceIn(-1.0f, 1.0f)
                    pcm[i] = (value * 32767.0f).toInt().toShort()
                }
                val written = track.write(pcm, 0, count, AudioTrack.WRITE_BLOCKING)
                check(written >= 0) { "Audio playback failed ($written)" }
                offset += written
                if (written == 0) break
            }
        } finally {
            if (activeTrack === track) activeTrack = null
            runCatching { if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop() }
            runCatching { track.release() }
        }
    }

    fun stop() {
        ++requestId
        requestJob?.cancel()
        requestJob = null
        stopAudioTrack()
        onSpeaking(false)
    }

    fun shutdown() {
        stop()
        // Wait for any native generation call to leave the critical section before
        // releasing the ONNX engine. Native generation itself is not cancellable.
        scope.launch(Dispatchers.Default) {
            engineMutex.withLock {
                runCatching { engine?.free() }
                engine = null
            }
            scope.cancel()
        }
    }

    private fun stopAudioTrack() {
        val track = activeTrack ?: return
        runCatching { track.pause() }
        runCatching { track.flush() }
        runCatching { track.stop() }
    }

    private fun showVoiceError(error: Throwable) {
        if (hasShownError) return
        hasShownError = true
        val detail = error.message?.take(120).orEmpty()
        mainHandler.post {
            val message = if (detail.isBlank()) {
                "Nara's built-in English voice could not start. Reinstall the app if the problem continues."
            } else {
                "Nara's built-in English voice could not start: $detail"
            }
            Toast.makeText(appContext, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun containsNonEnglishScript(value: String): Boolean = value.any { ch ->
        val cp = ch.code
        cp in 0x0590..0x08FF || cp in 0xFB1D..0xFDFF || cp in 0xFE70..0xFEFF
    }

    private companion object {
        const val BELLA_SPEAKER_ID = 1
        const val SPEECH_SPEED = 1.02f
        const val MAX_TEXT_CHARS = 700
        const val CHUNK_SAMPLES = 4096
    }
}
