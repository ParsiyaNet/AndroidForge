import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 103
        versionName = "4.2.1"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
    androidResources {
        noCompress += listOf("onnx", "bin")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation(files("libs/sherpa-onnx-2.0.1.aar"))

    debugImplementation("androidx.compose.ui:ui-tooling")
}


// WAPFire 4.2.1: bundle Sherpa-ONNX + the English Kokoro model inside the APK.
// Runtime speech is fully offline and does not consult Android's installed TTS voices.
val sherpaOnnxAar = file("libs/sherpa-onnx-2.0.1.aar")
val sherpaAarSha256 = "a8d09d1d32f3eb8520482c6d3d43fae674681c5b050385967c70a3c2c9bf0ee7"
val kokoroArchive = layout.buildDirectory.file("downloads/kokoro-en-v0_19.tar.bz2").get().asFile
val kokoroLexiconDownload = layout.buildDirectory.file("downloads/lexicon-en-us.txt").get().asFile
val kokoroAssetDir = file("src/main/assets/assistant/tts/kokoro-en-v0_19")

val downloadBundledVoiceInputs by tasks.registering {
    outputs.files(sherpaOnnxAar, kokoroArchive, kokoroLexiconDownload)
    outputs.upToDateWhen { false } // Always verify the pinned AAR checksum before compilation.

    doLast {
        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(128 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
        }

        fun download(url: String, destination: File, minBytes: Long, expectedSha256: String? = null) {
            destination.parentFile.mkdirs()
            if (destination.isFile && destination.length() >= minBytes &&
                (expectedSha256 == null || sha256(destination) == expectedSha256)) return
            destination.delete()
            val partial = File(destination.parentFile, destination.name + ".part")
            partial.delete()
            var lastError: Exception? = null
            for (attempt in 1..3) {
                var connection: HttpURLConnection? = null
                try {
                    connection = URL(url).openConnection() as HttpURLConnection
                    connection.connectTimeout = 30000
                    connection.readTimeout = 600000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty("User-Agent", "WAPFire-Mobile/4.2.1")
                    connection.setRequestProperty("Accept", "application/octet-stream")
                    val code = connection.responseCode
                    if (code != HttpURLConnection.HTTP_OK) throw IOException("HTTP $code while downloading $url")
                    var lastProgressMb = 0L
                    connection.inputStream.use { input ->
                        partial.outputStream().buffered(1024 * 1024).use { output ->
                            val buffer = ByteArray(1024 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                val progressMb = partial.length() / (16L * 1024 * 1024)
                                if (progressMb > lastProgressMb) {
                                    lastProgressMb = progressMb
                                    logger.lifecycle("Downloading ${destination.name}: approximately ${progressMb * 16} MB received")
                                }
                            }
                        }
                    }
                    if (partial.length() < minBytes) throw IOException("Downloaded file is too small (${partial.length()} bytes): $url")
                    if (expectedSha256 != null && sha256(partial) != expectedSha256) {
                        throw IOException("SHA-256 verification failed for $url")
                    }
                    Files.move(partial.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    return
                } catch (error: Exception) {
                    lastError = error
                    partial.delete()
                    logger.warn("Download attempt $attempt/3 failed for $url: ${error.message}")
                } finally {
                    connection?.disconnect()
                }
            }
            throw GradleException("Unable to download required offline voice resource: $url", lastError)
        }

        download(
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.1/sherpa-onnx-2.0.1.aar",
            sherpaOnnxAar,
            20L * 1024 * 1024,
            sherpaAarSha256
        )
        download(
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2",
            kokoroArchive,
            50L * 1024 * 1024
        )
        download(
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/lexicon-en-us.txt",
            kokoroLexiconDownload,
            1024L * 1024
        )
    }
}

val prepareBundledKokoroAssets by tasks.registering {
    dependsOn(downloadBundledVoiceInputs)
    val modelFile = File(kokoroAssetDir, "model.onnx")
    val voicesFile = File(kokoroAssetDir, "voices.bin")
    val tokensFile = File(kokoroAssetDir, "tokens.txt")
    val lexiconFile = File(kokoroAssetDir, "lexicon-en-us.txt")
    val licenseFile = File(kokoroAssetDir, "LICENSE")
    outputs.files(modelFile, voicesFile, tokensFile, lexiconFile, licenseFile)

    doLast {
        val extractRoot = layout.buildDirectory.dir("tmp/kokoro-en-v0_19-extracted").get().asFile
        delete(extractRoot)
        extractRoot.mkdirs()
        copy {
            from(tarTree(resources.bzip2(kokoroArchive))) {
                include("kokoro-en-v0_19/model.onnx", "kokoro-en-v0_19/voices.bin", "kokoro-en-v0_19/tokens.txt", "kokoro-en-v0_19/LICENSE")
            }
            into(extractRoot)
        }

        val sourceDir = File(extractRoot, "kokoro-en-v0_19")
        if (!File(sourceDir, "model.onnx").isFile || File(sourceDir, "model.onnx").length() < 250L * 1024 * 1024) {
            throw GradleException("Kokoro model archive is incomplete: model.onnx is missing or too small")
        }
        if (!File(sourceDir, "voices.bin").isFile || !File(sourceDir, "tokens.txt").isFile) {
            throw GradleException("Kokoro model archive is missing voices.bin or tokens.txt")
        }
        kokoroAssetDir.mkdirs()
        listOf("model.onnx", "voices.bin", "tokens.txt", "LICENSE").forEach { name ->
            val source = File(sourceDir, name)
            if (source.isFile) Files.copy(source.toPath(), File(kokoroAssetDir, name).toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        Files.copy(kokoroLexiconDownload.toPath(), lexiconFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
        logger.lifecycle("Bundled Kokoro English TTS assets prepared (speaker af_bella / ID 1). espeak-ng-data is intentionally omitted because the English lexicon is bundled instead.")
    }
}

// WAPFire 4.1.50: fetch the selected AndroidForge character package at build time.
// Source: https://github.com/ParsiyaNet/AndroidForge/blob/main/v06_clean.livliv
// The .livliv archive is embedded in the APK; runtime remains offline.
val downloadV06CleanCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val previewDir = file("src/main/assets/assistant/characters/v03")
    val expectedGitBlobSha1 = "112bbede0967362103ec297a368b881531bf00c5"
    val sourceUrl = "https://raw.githubusercontent.com/ParsiyaNet/AndroidForge/main/v06_clean.livliv"

    outputs.files(modelAsset, File(previewDir, "cover.webp"), File(previewDir, "avatar.webp"))
    outputs.upToDateWhen { false }

    doLast {
        fun gitBlobSha1(file: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
        }

        modelAsset.parentFile.mkdirs()
        previewDir.mkdirs()
        val tempModel = File(modelAsset.parentFile, "v06-clean.download.livliv")
        var lastFailure: Exception? = null
        var downloaded = false

        for (attempt in 1..3) {
            var activeConnection: HttpURLConnection? = null
            try {
                val connection = URL(sourceUrl).openConnection() as HttpURLConnection
                activeConnection = connection
                connection.connectTimeout = 30000
                connection.readTimeout = 120000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.50")
                connection.setRequestProperty("Accept", "application/octet-stream")
                val status = connection.responseCode
                if (status != HttpURLConnection.HTTP_OK) {
                    throw IOException("HTTP $status from $sourceUrl")
                }
                connection.inputStream.use { input ->
                    tempModel.outputStream().use { output -> input.copyTo(output) }
                }

                val actualSha = gitBlobSha1(tempModel)
                if (actualSha != expectedGitBlobSha1) {
                    throw GradleException("AndroidForge v06_clean.livliv changed: expected $expectedGitBlobSha1, received $actualSha")
                }

                val entries = linkedSetOf<String>()
                ZipFile(tempModel).use { archive ->
                    archive.entries().asSequence().filterNot { it.isDirectory }.forEach { entry ->
                        val name = entry.name.replace('\\', '/')
                        if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) {
                            throw GradleException("Unsafe path in v06_clean.livliv: ${entry.name}")
                        }
                        entries.add(name)
                    }
                    if (entries.none { it.substringAfterLast('/') == "model.json" }) {
                        throw GradleException("v06_clean.livliv does not contain model.json")
                    }
                    if (entries.none { it.substringAfterLast('/') == "avatar.webp" }) {
                        throw GradleException("v06_clean.livliv does not contain avatar.webp")
                    }
                    val imageCount = entries.count { it.substringAfterLast('.').lowercase() in setOf("webp", "png", "jpg", "jpeg") }
                    if (imageCount < 10) throw GradleException("v06_clean.livliv image set looks incomplete ($imageCount image files)")

                    listOf("cover.webp", "avatar.webp").forEach { wanted ->
                        val entry = archive.entries().asSequence().firstOrNull { !it.isDirectory && it.name.substringAfterLast('/') == wanted }
                        if (entry != null) {
                            val destination = File(previewDir, wanted)
                            archive.getInputStream(entry).use { input ->
                                destination.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                    }
                }

                Files.move(tempModel.toPath(), modelAsset.toPath(), StandardCopyOption.REPLACE_EXISTING)
                downloaded = true
                logger.lifecycle("Downloaded and verified AndroidForge v06_clean.livliv (Git blob SHA-1 $actualSha). Character assets are embedded; runtime remains offline.")
                break
            } catch (error: Exception) {
                lastFailure = error
                tempModel.delete()
                logger.warn("AndroidForge v06_clean.livliv download attempt $attempt failed: ${error.message}")
            } finally {
                activeConnection?.disconnect()
            }
        }
        tempModel.delete()
        if (!downloaded) {
            throw GradleException("Could not download and package AndroidForge v06_clean.livliv. Check GitHub access from the build runner.", lastFailure)
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(downloadV06CleanCharacter, downloadBundledVoiceInputs, prepareBundledKokoroAssets)
}

