# WAPFire Mobile 4.2.1 — Built-in Nara voice

- Nara speaks **English only** using Kokoro `kokoro-en-v0_19`, speaker `af_bella` (speaker ID `1`).
- Text displayed in the UI remains localized (English/Persian); the voice uses a separate English-only message map.
- Runtime TTS uses Sherpa-ONNX and `AudioTrack`; it does not query Android Text-to-Speech services and never asks the user to install a system voice.
- The voice model and runtime are packaged into the APK. Internet is required only the first time the project is built, to download and verify the AAR, model archive and English lexicon. The installed application can synthesize speech offline.
- The model is large (about 330 MB for `model.onnx`, plus voices and lexicon). The APK will consequently be several hundred MB larger than the previous version and needs sufficient free storage/RAM.
- The build fetch task pins Sherpa-ONNX Android AAR v2.0.1 by SHA-256. Model files are checked for expected presence and minimum size, and Kokoro's upstream `LICENSE` is copied into app assets.
- Hiyori's existing Cubism Idle clips are explicitly started and remain randomized. A subtle AIRI-inspired idle layer adds eased gaze changes, breathing and head/body sway. Speaking remains connected to the existing mouth/lip-sync bridge.

Build from Windows with `build-apk.bat` or from the project root with `gradlew assembleDebug`. First build requires access to GitHub.
