# WAPFire Mobile 4.1.56 — LivLiv WAPFire reactions

This source package uses the bundled local `v03.livliv` model and connects the
character's expressions and movements to live WAPFire VF38 status telemetry. See
`CHANGELOG-4.1.56.md`, `VALIDATION-4.1.56.txt` and the firmware-side
`MOBILE-ASSISTANT-REACTION-CONTRACT.md`.
