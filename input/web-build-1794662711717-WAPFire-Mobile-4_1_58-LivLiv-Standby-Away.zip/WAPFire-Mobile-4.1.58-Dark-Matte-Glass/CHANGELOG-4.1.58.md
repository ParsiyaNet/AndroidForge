# 4.1.58

- Added an explicit `standby` character state driven by firmware `beacon_mode`.
- Standby now holds LivLiv `setAway(true)` until Beacon Response is enabled again.
- Separated ordinary `idle` (normal natural idle) from Standby/Away, so an ACTIVE promiscuous state cannot immediately cancel the Away pose.
- Added `beacon_mode` to the live firmware `/api/status` payload and parsed it into the Android snapshot.
- Preserved target-offline, attack, password and other event reactions; event reactions temporarily override the ambient state and then return to the active base state.
