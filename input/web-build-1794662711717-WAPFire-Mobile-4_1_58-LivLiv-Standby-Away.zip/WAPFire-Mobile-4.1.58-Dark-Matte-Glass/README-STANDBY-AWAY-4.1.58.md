# WAPFire Mobile 4.1.58 — Persistent Standby / Away

This release binds the character's Away pose to the firmware's actual Beacon Response Standby setting.

## Behavior

- `beacon_mode=false` in the live `/api/status` response selects the dedicated `standby` character state.
- `standby` calls LivLiv `setAway(true)` and holds that pose while Beacon Response remains in Standby.
- `beacon_mode=true` exits Standby and restores the regular scanning/idle state selected by `promiscuous`.
- Ordinary `idle` is now a normal, non-Away state. This prevents the initial or transient idle state from being mistaken for persistent Standby.
- Target AP offline, attack, wrong-password, correct-password and connection reactions remain higher-priority event overlays and return to the current ambient state afterward.

## Firmware requirement

Use the included WAPFire VF38 firmware source. Its `/api/status` response now includes the boolean `beacon_mode` field. Recompile and flash the firmware, then build/install the Android app so both sides use this contract.

## Validation

Run `WAPFIRE_FIRMWARE_DIR=/path/to/WAPFireVF38 python tools/validate_4_1_58.py` to run the source integration checks. The bundle is source-only; no APK or firmware binary is included.
