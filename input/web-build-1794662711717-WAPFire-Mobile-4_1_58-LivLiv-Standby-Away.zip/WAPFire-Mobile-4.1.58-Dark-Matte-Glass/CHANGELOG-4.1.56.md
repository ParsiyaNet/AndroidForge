# WAPFire Mobile 4.1.56 — WAPFire-aware LivLiv reactions

- Standby (`promiscuous` not ACTIVE) now uses LivLiv `setAway(true)`.
- Attack counter increases select the model's actual Angry expression ID and play a downward look.
- Wrong-password counter increases select the actual Sad expression ID and shake the head.
- Correct-password / connection recovery use Smile + hop + blink; monitoring, warning, setup and reconnect states have distinct subtle reactions.
- Repeated events of the same category replay their animation using a unique event sequence token.
- The Android app, HTML document and local LivLiv bootstrap are versioned 4.1.56; local model loading remains offline.
- Firmware detection algorithms and thresholds are unchanged. The existing VF38 cumulative `labels[]` contract is documented beside the firmware serializer.
- Android versionCode/versionName: 102 / 4.1.56.
