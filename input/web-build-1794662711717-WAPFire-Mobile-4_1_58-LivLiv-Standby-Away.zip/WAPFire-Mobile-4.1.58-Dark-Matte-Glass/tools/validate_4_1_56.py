#!/usr/bin/env python3
"""Source-level integration checks for the WAPFire 4.1.56 LivLiv reactions."""
from pathlib import Path
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets/assistant"
JS = ASSETS / "assistant-preflight-4.1.56.js"
MODEL = ASSETS / "characters/v03.livliv"
HTML = (ASSETS / "assistant-live.html").read_text(encoding="utf-8")
VIEW = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt").read_text(encoding="utf-8")
DASH = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
FW = ROOT.parent.parent / "wapfire firmware/WAPFireVF38/webui_api_handlers.h"
FW_TEXT = FW.read_text(encoding="utf-8")
RUNTIME = (ASSETS / "dist/chunks/base-p0Sx5Qp5.js").read_text(encoding="utf-8")
JS_TEXT = JS.read_text(encoding="utf-8")

with zipfile.ZipFile(MODEL) as archive:
    model = json.loads(archive.read("model.json"))
expressions = {entry["id"] for entry in model.get("expressions", [])}
for expression in ("smile", "x_expr_03637e", "x_expr_0cfa09", "x_expr_7d048e"):
    assert expression in expressions, f"Model is missing expression {expression}"

assert "away:true" in JS_TEXT and "player.setAway(row.away === true)" in JS_TEXT
assert "player.act('away')" not in JS_TEXT
assert "expr:'x_expr_0cfa09'" in JS_TEXT and "action:'shy'" in JS_TEXT
assert "lookAt:{x:0,y:-0.82}" in JS_TEXT
assert "expr:'x_expr_7d048e'" in JS_TEXT and "action:'shake'" in JS_TEXT
assert "expr:'x_expr_03637e'" in JS_TEXT
actions_block = re.search(r"var S=\{([^}]+)\}", RUNTIME)
assert actions_block, "LivLiv built-in action list was not found"
for action in ("nod", "shake", "tilt", "hop", "shy"):
    assert re.search(rf"\b{action}:", actions_block.group(1)), f"Runtime action {action} is unavailable"
assert "player.setExpression(row.expr ?? null)" in JS_TEXT
assert "rawState.indexOf('#')" in JS_TEXT
assert '"$it#$assistantEventSequence"' in DASH
assert "state.substringBefore('#')" in VIEW
assert "assistant-preflight-4.1.56.js" in HTML
assert "content=\"4.1.56\"" in HTML
assert '"assistant/assistant-preflight-4.1.56.js"' in VIEW
assert 'ASSISTANT_BUILD = "4.1.56"' in VIEW
assert 'versionCode = 102' in GRADLE and 'versionName = "4.1.56"' in GRADLE
assert 'labels' in FW_TEXT and 'Mobile assistant event contract' in FW_TEXT

print("PASS  model expression IDs match all configured face states")
print("PASS  all configured movements exist in the bundled LivLiv runtime")
print("PASS  standby uses setAway(true), not act('away')")
print("PASS  attack uses angry face + look-down movement/gaze")
print("PASS  wrong-password event uses sad face + shake-head movement and preserves probable classification")
print("PASS  repeated same-category events replay through sequence tokens")
print("PASS  HTML, WebView asset verification and app build versions are aligned")
print("PASS  firmware keeps the existing cumulative labels[] event contract")
