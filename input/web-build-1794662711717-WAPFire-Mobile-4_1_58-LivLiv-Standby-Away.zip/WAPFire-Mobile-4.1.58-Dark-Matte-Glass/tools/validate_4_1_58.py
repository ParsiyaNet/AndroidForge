#!/usr/bin/env python3
"""Source-level regression checks for persistent Beacon Standby/Away (4.1.58)."""
from pathlib import Path
import json
import re
import os

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets/assistant"
JS = ASSETS / "assistant-preflight-4.1.58.js"
HTML = (ASSETS / "assistant-live.html").read_text(encoding="utf-8")
VIEW = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt").read_text(encoding="utf-8")
DASH = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt").read_text(encoding="utf-8")
MODELS = (ROOT / "app/src/main/java/io/wapfire/mobile/model/AppModels.kt").read_text(encoding="utf-8")
APP = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt").read_text(encoding="utf-8")
PREVIEW = (ROOT / "app/src/main/java/io/wapfire/mobile/ui/screens/AssistantPreviewScreen.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
FW_DIR = Path(os.environ.get("WAPFIRE_FIRMWARE_DIR", str(ROOT.parent.parent / "wapfire firmware/WAPFireVF38")))
FW = FW_DIR / "webui_api_handlers.h"
FW_TEXT = FW.read_text(encoding="utf-8")
JS_TEXT = JS.read_text(encoding="utf-8")

assert 'beacon_mode' in FW_TEXT and 'statusJson += beaconModeEnabled ? "true" : "false";' in FW_TEXT
assert 'beaconMode: Boolean? = null' in MODELS
assert 'status.has("beacon_mode") -> status.optBoolean("beacon_mode")' in MODELS
assert 'settings?.has("beacon_mode") == true -> settings.optBoolean("beacon_mode")' in MODELS
assert 'beaconMode = updated.beaconMode ?: snapshot.beaconMode' in APP
assert 'snapshot.beaconMode' in DASH
assert re.search(r'snapshot\.beaconMode\s*==\s*false\s*->\s*\{\s*// Beacon Mode disabled', DASH)
assert 'assistantBaseState = "standby"' in DASH
assert 'snapshot.beaconMode == false -> "standby"' in DASH
assert '"standby" to tx(fa, "Standby / Away"' in PREVIEW

# The visual Away pose is explicit and independent from normal idle.
assert re.search(r'idle:\s*\{.*?expr:null,\s*away:false', JS_TEXT, re.S)
assert re.search(r'standby:\s*\{.*?expr:null,\s*away:true', JS_TEXT, re.S)
assert 'player.setAway(row.away === true);' in JS_TEXT
assert 'window.__wfAssistantBuildVersion = \'4.1.58\';' in JS_TEXT
assert "assistant-preflight-4.1.58.js?build=4.1.58" in HTML
assert 'content="4.1.58"' in HTML
assert 'assistant-preflight-4.1.58.js' in VIEW
assert 'ASSISTANT_BUILD = "4.1.58"' in VIEW
assert 'versionCode = 104' in GRADLE and 'versionName = "4.1.58"' in GRADLE

# Ensure existing higher-priority reactions remain present.
for state in ('target_offline', 'angry', 'password_warning', 'password_success', 'connecting', 'warning'):
    assert re.search(rf'{state}:\s*\{{', JS_TEXT), f'missing reaction state {state}'
assert 'assistantEventSequence++' in DASH
assert 'targetAvailabilityBaseline' in DASH

print('PASS: firmware publishes live beacon_mode in /api/status')
print('PASS: Android Snapshot parses beacon_mode and preserves cached value')
print('PASS: beacon_mode=false selects standby before transient connection/scan states')
print('PASS: standby uses persistent LivLiv setAway(true); ordinary idle uses setAway(false)')
print('PASS: enabling beacon_mode exits standby into scanning/idle')
print('PASS: manual assistant preview exposes Standby / Away')
print('PASS: existing Target AP offline and security-event reaction states remain wired')
print('PASS: Android / WebView / HTML / JS version markers are aligned at 4.1.58')
