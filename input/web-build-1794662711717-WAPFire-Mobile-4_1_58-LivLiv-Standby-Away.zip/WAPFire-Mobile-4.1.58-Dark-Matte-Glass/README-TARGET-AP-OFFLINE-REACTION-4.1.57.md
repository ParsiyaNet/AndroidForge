# WAPFire 4.1.57 — Target AP offline reaction

## Behavior

- When the selected Target AP transitions from available to unavailable, Nara switches to the Sad expression (`x_expr_7d048e`) with the built-in LivLiv `shy` / Look Down action and a sustained downward gaze.
- The reaction remains the ambient character state while that target stays unavailable. When the same BSSID becomes available again, the assistant returns to its normal monitoring/standby state.
- The app compares successive `target_available` samples for the same selected BSSID. The initial false value after app launch is only a baseline, not proof of a newly lost AP.
- The firmware already debounces target availability (three failed checks) before setting `target_available` false.
- While Self-Protect Beacon mode intentionally suspends target scans, firmware preserves the last confirmed availability instead of incorrectly publishing a loss. Fresh checks resume after the scan pause ends.

## Validation scope

Static checks cover the Kotlin transition logic, the exact `target_available` field mapping, the new LivLiv expression/action IDs, the versioned asset references, and the firmware SHA-256 entry. No Android APK or firmware binary is included; compilation and device/ESP flash testing remain to be run in a configured SDK/Arduino environment.
