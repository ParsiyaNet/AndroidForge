# 4.1.57

- Added a dedicated Target AP offline state, separate from the WAPFire device-offline state.
- On a confirmed target AP loss, the character uses Sad + Shy/Look Down and stays in that state until the selected BSSID returns.
- Added a manual Target AP offline preview state.
- Kept the initial `target_available=false` snapshot as a baseline instead of misreporting it as a newly lost AP.
- Firmware now preserves its last confirmed target availability while Beacon mode intentionally pauses scans; the unavailable debounce restarts after scanning resumes.
