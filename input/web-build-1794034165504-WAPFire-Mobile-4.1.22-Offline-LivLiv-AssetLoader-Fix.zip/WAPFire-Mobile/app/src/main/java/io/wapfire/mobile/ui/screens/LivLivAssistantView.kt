package io.wapfire.mobile.ui.screens

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.wapfire.mobile.BuildConfig
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx
import androidx.webkit.WebViewAssetLoader

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ASSET_PREFIX = "/assets/"
private const val ASSISTANT_URL = "https://appassets.androidplatform.net/assets/assistant/assistant-live.html"
private const val TAG = "WapFireAssistant"

/**
 * Uses AndroidX WebViewAssetLoader for a real HTTPS origin backed only by APK assets.
 * The asset handler serves ES modules, the LivLiv package and textures without network access.
 * All non-local requests are explicitly rejected by the WebViewClient.
 */
private class LivLivWebView(
    context: Context,
    private val fa: Boolean,
    private val compact: Boolean,
    initialState: String,
    private val onNativeStatus: (String?) -> Unit
) : WebView(context) {
    private var pageReady = false
    private var pendingState: String = initialState
    private val assetLoader = WebViewAssetLoader.Builder()
        .setDomain(ASSET_HOST)
        .addPathHandler(ASSET_PREFIX, WebViewAssetLoader.AssetsPathHandler(context))
        .build()

    init {
        setBackgroundColor(AndroidColor.rgb(7, 22, 41))
        // WebView is hardware accelerated by the Activity; do not force a separate layer here.
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            databaseEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // Network is kept enabled only so the virtual HTTPS origin can be served by
            // WebViewAssetLoader. Every request to another host is rejected below.
            blockNetworkLoads = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
        }
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = when (message.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> Log.ERROR
                    ConsoleMessage.MessageLevel.WARNING -> Log.WARN
                    else -> Log.DEBUG
                }
                Log.println(level, TAG, "JS ${message.message()} (${message.sourceId()}:${message.lineNumber()})")
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!pageReady && newProgress in 1..99) {
                    onNativeStatus(if (fa) "در حال بازکردن دستیار آفلاین… $newProgress٪" else "Opening offline assistant… $newProgress%")
                }
            }
        }

        webViewClient = object : WebViewClient() {
            private fun isLocal(uri: Uri): Boolean =
                uri.scheme == "https" && uri.host == ASSET_HOST && (uri.port == -1 || uri.port == 443)

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (!isLocal(uri)) {
                    Log.w(TAG, "Blocked non-local request: $uri")
                    return blockedResponse(403, "External resource blocked")
                }
                if (uri.path?.startsWith(ASSET_PREFIX) != true) {
                    Log.w(TAG, "Blocked path outside packaged assets: $uri")
                    return blockedResponse(404, "Asset path not found")
                }
                val response = assetLoader.shouldInterceptRequest(uri)
                if (response == null) {
                    Log.e(TAG, "AssetLoader returned no response: $uri")
                    return blockedResponse(404, "Packaged asset not found")
                }
                Log.v(TAG, "Served local asset: ${uri.path} (${response.mimeType})")
                return response
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !isLocal(uri) || uri.path?.startsWith(ASSET_PREFIX) != true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageReady = false
                onNativeStatus(if (fa) "در حال بارگذاری دستیار آفلاین…" else "Loading offline assistant…")
                Log.d(TAG, "Main page started: $url")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                Log.d(TAG, "Main page committed: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                onNativeStatus(null)
                Log.d(TAG, "Main page finished: $url")
                applyPendingState()
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.e(TAG, "WebView error mainFrame=${request?.isForMainFrame} url=${request?.url} code=${error?.errorCode} description=${error?.description}")
                if (request?.isForMainFrame == true) {
                    pageReady = false
                    onNativeStatus(if (fa) "صفحهٔ دستیار باز نشد (${error?.errorCode}): ${error?.description}" else "Assistant page failed (${error?.errorCode}): ${error?.description}")
                }
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, response)
                Log.e(TAG, "WebView HTTP error mainFrame=${request?.isForMainFrame} url=${request?.url} status=${response?.statusCode} reason=${response?.reasonPhrase}")
                if (request?.isForMainFrame == true) {
                    pageReady = false
                    onNativeStatus(if (fa) "خطای فایل دستیار: HTTP ${response?.statusCode}" else "Assistant asset error: HTTP ${response?.statusCode}")
                }
            }
        }

        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        loadUrl("$ASSISTANT_URL?lang=$language&compact=$compactFlag&state=${Uri.encode(initialState)}")
    }

    fun setAssistantState(state: String) {
        if (pendingState == state) return
        pendingState = state
        if (pageReady) applyPendingState()
    }

    private fun applyPendingState() {
        val jsonState = org.json.JSONObject.quote(pendingState)
        evaluateJavascript("window.wapfireSetState && window.wapfireSetState($jsonState);", null)
    }

    private fun blockedResponse(code: Int, reason: String) = WebResourceResponse(
        "text/plain", "UTF-8", code, reason,
        mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )
}

@Composable
internal fun LivLivAssistantWebView(
    fa: Boolean,
    state: String,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val nativeStatus = androidx.compose.runtime.remember(context, fa, compact) {
        androidx.compose.runtime.mutableStateOf<String?>(if (fa) "در حال آماده‌سازی دستیار…" else "Preparing assistant…")
    }
    val view = remember(context, fa, compact) {
        LivLivWebView(context, fa, compact, state) { message -> nativeStatus.value = message }
    }

    DisposableEffect(view) {
        onDispose {
            runCatching {
                view.stopLoading()
                view.onPause()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { view },
            update = { it.setAssistantState(state) },
            modifier = Modifier.fillMaxSize()
        )
        nativeStatus.value?.let { message ->
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xFF071629)),
                contentAlignment = Alignment.Center
            ) {
                Text(message, color = Color(0xFF9AB2CA), fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
internal fun LivLivAssistantOverviewCard(
    p: Palette,
    fa: Boolean,
    state: String,
    onOpenAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("WAPFIRE · LIVE ASSISTANT", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(tx(fa, "Sena is watching your network", "سنا مراقب شبکه‌ات است"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                tx(fa, "OPEN ↗", "نمایش ↗"),
                color = p.blue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(p.accentSoft.copy(alpha = .7f))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .then(Modifier)
                    .clickable(onClick = onOpenAssistant)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(218.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF071629))
                .border(1.dp, Color(0xFF23608D), RoundedCornerShape(22.dp))
                .padding(1.dp)
        ) {
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = true,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp))
            )
        }
        Text(
            tx(fa, "Character: Sena · LivLiv (livliv.ai)", "کاراکتر: Sena · LivLiv (livliv.ai)"),
            color = p.muted.copy(alpha = .75f), fontSize = 8.sp,
            modifier = Modifier.align(Alignment.End)
        )
    }
}

