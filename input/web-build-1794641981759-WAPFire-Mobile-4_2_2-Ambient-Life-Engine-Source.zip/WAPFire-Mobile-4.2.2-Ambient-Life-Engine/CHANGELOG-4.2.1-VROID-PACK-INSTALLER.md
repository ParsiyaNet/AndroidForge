# 4.2.1-vroid — Pack Installer & Credits

- Added a one-time `VRoid Pack +` ZIP installer for the user-provided VRM + seven VRMA pack.
- Validates GLB 2.0 headers, requires exactly one VRM and all seven numbered VRMA files, rejects duplicate/oversized entries, and avoids ZIP path extraction.
- Installs model and motions into app-private storage; a successful install automatically reloads the assistant WebView. Playback remains offline.
- Kept the individual VRM and VRMA import controls as fallback options.
- Added an in-app Credits & Licenses dialog and a full `CREDITS-VROID.txt` attribution notice.
- Raw character/motion assets are not embedded in the distributable APK/source because the embedded VRoid Hub model metadata prohibits redistribution and the VRMA pack prohibits extractable redistribution.
