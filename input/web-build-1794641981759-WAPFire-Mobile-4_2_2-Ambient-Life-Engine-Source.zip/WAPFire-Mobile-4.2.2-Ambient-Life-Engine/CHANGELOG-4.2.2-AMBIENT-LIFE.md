# WAPFire Mobile 4.2.2 — Ambient Life Engine

Based on `WAPFire-Mobile-4_2_1-Dark-Matte-Glass-Source`, retaining the 4.2.1 VRoid player and user-import workflow.

## Character behavior
- Added a continuous, subtle breathing layer driven by the selected VRM humanoid rig.
- Added a randomized ambient behavior scheduler with non-repeating recent actions and variable quiet intervals.
- Added restrained long-form behaviors: looking left/right, curious head tilt, thoughtful downward glance, gentle weight shift, shoulder relaxation and a brief hand-check gesture.
- Added occasional low-intensity facial reactions using expressions already embedded in the selected VRM.
- Kept explicit VRMA playback higher priority; ambient behaviors pause/fade while a deliberate motion or non-idle app state is active.
- Added direct eye-bone motion for models without a VRM LookAt extension. This matters for the supplied VRM, which contains left/right eye humanoid bones but no LookAt extension.
- Hair secondary motion continues to use the model's own VRM spring-bone setup.

## Source asset findings
- The supplied Chiaki Katsumi VRM includes `blink`, `blink_l`, `blink_r`, vowel shapes `A/I/U/E/O`, and facial presets `angry`, `fun`, `joy`, `sorrow`, and `Surprised`.
- The supplied seven pixiv/VRoid VRMA clips contain humanoid body animation tracks and no facial-expression tracks. They remain available as explicit showcase/greeting/pose actions, not as the ambient idle loop.

## Compatibility and limitations
- No additional GLB/VRMA download is required for the procedural idle behaviors.
- The model and third-party VRMA assets continue to be user-imported into app-private storage; this source package does not embed or redistribute those restricted raw assets.
- Android APK build and on-device behavior still require validation in AndroidForge / a device build.
