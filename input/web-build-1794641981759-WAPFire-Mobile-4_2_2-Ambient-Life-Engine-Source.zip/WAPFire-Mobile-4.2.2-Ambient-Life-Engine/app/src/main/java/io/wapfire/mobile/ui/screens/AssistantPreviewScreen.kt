package io.wapfire.mobile.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx


private fun pickedDocumentName(context: Context, uri: Uri): String? = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
}.getOrNull()?.substringAfterLast('/')

private fun copyPickedDocument(context: Context, uri: Uri, destination: File, maxBytes: Long): Boolean {
    val temporary = File(destination.parentFile, destination.name + ".importing")
    return try {
        destination.parentFile?.mkdirs()
        val input = context.contentResolver.openInputStream(uri) ?: return false
        input.use { source ->
            FileOutputStream(temporary).use { target ->
                val buffer = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val count = source.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= maxBytes) { "Selected file is too large" }
                    target.write(buffer, 0, count)
                }
                target.fd.sync()
            }
        }
        if (temporary.length() <= 0L) return false
        if (destination.exists() && !destination.delete()) return false
        temporary.renameTo(destination)
    } catch (_: Exception) {
        false
    } finally {
        temporary.delete()
    }
}

/**
 * Installs a user-selected VRoid resource ZIP into app-private storage.
 * The archive itself is never copied into the APK or exposed as a browsable app asset.
 */
private fun isValidGlb(file: File): Boolean = runCatching {
    if (file.length() < 20L) return@runCatching false
    FileInputStream(file).use { input ->
        val header = ByteArray(12)
        var offset = 0
        while (offset < header.size) {
            val read = input.read(header, offset, header.size - offset)
            if (read < 0) return@use false
            offset += read
        }
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val magic = ByteArray(4).also { buffer.get(it) }
        val version = buffer.int
        val declaredLength = buffer.int.toLong() and 0xFFFFFFFFL
        magic.contentEquals(byteArrayOf('g'.code.toByte(), 'l'.code.toByte(), 'T'.code.toByte(), 'F'.code.toByte())) &&
            version == 2 && declaredLength == file.length()
    }
}.getOrDefault(false)

private fun installStagedFiles(files: List<Pair<File, File>>) {
    val prepared = mutableListOf<Triple<File, File, File>>() // source, destination, temporary
    val backups = mutableListOf<Pair<File, File>>() // backup, destination
    val installed = mutableListOf<File>()
    try {
        files.forEach { (source, destination) ->
            val parent = destination.parentFile ?: throw IOException("Missing destination folder")
            if (!parent.exists() && !parent.mkdirs()) throw IOException("Could not create ${parent.name}")
            val temporary = File(parent, destination.name + ".installing")
            source.inputStream().use { input ->
                FileOutputStream(temporary).use { output ->
                    input.copyTo(output, 64 * 1024)
                    output.fd.sync()
                }
            }
            prepared += Triple(source, destination, temporary)
        }
        prepared.forEach { (_, destination, temporary) ->
            val backup = File(destination.parentFile, destination.name + ".previous")
            if (backup.exists() && !backup.delete()) throw IOException("Could not clear old backup ${backup.name}")
            if (destination.exists()) {
                if (!destination.renameTo(backup)) throw IOException("Could not preserve ${destination.name}")
                backups += backup to destination
            }
            if (!temporary.renameTo(destination)) {
                backups.lastOrNull()?.takeIf { it.second == destination }?.let { (old, target) -> old.renameTo(target); backups.remove(old to target) }
                throw IOException("Could not install ${destination.name}")
            }
            installed += destination
        }
        backups.forEach { (backup, _) -> backup.delete() }
    } catch (error: Exception) {
        installed.asReversed().forEach { it.delete() }
        backups.asReversed().forEach { (backup, destination) ->
            if (destination.exists()) destination.delete()
            backup.renameTo(destination)
        }
        throw error
    } finally {
        prepared.forEach { (_, _, temporary) -> temporary.delete() }
    }
}

/** Returns null on success, otherwise a user-readable failure reason. */
private fun importVroidPack(context: Context, uri: Uri): String? {
    val staging = File(context.cacheDir, "vroid-pack-${System.nanoTime()}")
    val stagedMotions = File(staging, "motions").apply { mkdirs() }
    var stagedModel: File? = null
    val stagedMotionFiles = arrayOfNulls<File>(7)
    var totalExpanded = 0L
    val maxArchiveExpanded = 400L * 1024L * 1024L
    val buffer = ByteArray(64 * 1024)

    return try {
        val raw = context.contentResolver.openInputStream(uri) ?: throw IOException("Could not open the selected ZIP")
        ZipInputStream(BufferedInputStream(raw)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) {
                    val baseName = entry.name.substringAfterLast('/').substringAfterLast('\\')
                    val motionMatch = Regex("^VRMA_0([1-7])\\.vrma$", RegexOption.IGNORE_CASE).matchEntire(baseName)
                    val target: File?
                    val limit: Long
                    if (baseName.endsWith(".vrm", ignoreCase = true)) {
                        if (stagedModel != null) throw IOException("The ZIP contains more than one VRM model")
                        target = File(staging, "current.vrm")
                        stagedModel = target
                        limit = 200L * 1024L * 1024L
                    } else if (motionMatch != null) {
                        val index = motionMatch.groupValues[1].toInt() - 1
                        if (stagedMotionFiles[index] != null) throw IOException("Duplicate VRMA_0${index + 1}.vrma in ZIP")
                        target = File(stagedMotions, "VRMA_0${index + 1}.vrma")
                        stagedMotionFiles[index] = target
                        limit = 50L * 1024L * 1024L
                    } else {
                        target = null
                        limit = 0L
                    }

                    var entryBytes = 0L
                    if (target != null) {
                        FileOutputStream(target).use { output ->
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                entryBytes += count
                                totalExpanded += count
                                if (entryBytes > limit || totalExpanded > maxArchiveExpanded) {
                                    throw IOException("The ZIP contains an oversized file")
                                }
                                output.write(buffer, 0, count)
                            }
                            output.fd.sync()
                        }
                    } else {
                        while (true) {
                            val count = zip.read(buffer)
                            if (count < 0) break
                            totalExpanded += count
                            if (totalExpanded > maxArchiveExpanded) throw IOException("The ZIP expands beyond the allowed size")
                        }
                    }
                }
                zip.closeEntry()
            }
        }

        val model = stagedModel ?: throw IOException("No .vrm character was found in the ZIP")
        if (!isValidGlb(model)) throw IOException("The VRM file is not a valid GLB 2.0 package")
        val missing = stagedMotionFiles.indices.filter { stagedMotionFiles[it] == null }
        if (missing.isNotEmpty()) throw IOException("Missing VRMA files: ${missing.joinToString { "VRMA_0${it + 1}" }}")
        stagedMotionFiles.forEachIndexed { index, file ->
            val motionFile = file ?: throw IOException("Missing VRMA_0${index + 1}.vrma")
            if (!isValidGlb(motionFile)) throw IOException("VRMA_0${index + 1}.vrma is not a valid GLB 2.0 file")
        }

        val installSet = mutableListOf<Pair<File, File>>()
        installSet.add(model to File(context.filesDir, "characters/user/current.vrm"))
        stagedMotionFiles.forEachIndexed { index, file ->
            val motionFile = file ?: throw IOException("Missing VRMA_0${index + 1}.vrma")
            installSet.add(motionFile to File(context.filesDir, "motions/user/VRMA_0${index + 1}.vrma"))
        }
        installStagedFiles(installSet)
        null
    } catch (error: Exception) {
        error.message?.take(180) ?: "Could not install the VRoid resource ZIP"
    } finally {
        staging.deleteRecursively()
    }
}

private data class VroidMotionButton(val key: String, val en: String, val fa: String)

private val vroidMotionButtons = listOf(
    VroidMotionButton("showcase", "Show", "نمایش"),
    VroidMotionButton("greeting", "Hello", "سلام"),
    VroidMotionButton("peace", "Peace", "صلح"),
    VroidMotionButton("shoot", "Shoot", "شلیک"),
    VroidMotionButton("spin", "Spin", "چرخش"),
    VroidMotionButton("pose", "Pose", "ژست"),
    VroidMotionButton("squat", "Squat", "اسکوات")
)

@Composable
private fun VroidMotionChip(label: String, onClick: () -> Unit, emphasized: Boolean = false) {
    Box(
        modifier = Modifier
            .height(32.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(if (emphasized) Color(0xFF125D86) else Color(0xFF0A2037))
            .border(1.dp, if (emphasized) Color(0xFF55C8F6) else Color(0xFF32658C), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (emphasized) Color.White else Color(0xFFCFE8F8), fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun VroidMotionControlBar(
    fa: Boolean,
    onPickPack: () -> Unit,
    onPickVrm: () -> Unit,
    onPickVrma: () -> Unit,
    onShowCredits: () -> Unit,
    onPlayMotion: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 2.dp)
                .height(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xF006182B))
                .border(1.dp, Color(0xAA3275A1), RoundedCornerShape(14.dp))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            VroidMotionChip(if (fa) "پک VRoid +" else "VRoid Pack +", onPickPack, true)
            VroidMotionChip(if (fa) "مدل +" else "VRM +", onPickVrm)
            VroidMotionChip(if (fa) "حرکت‌ها +" else "VRMA +", onPickVrma)
            vroidMotionButtons.forEach { motion ->
                VroidMotionChip(if (fa) motion.fa else motion.en, { onPlayMotion(motion.key) })
            }
            VroidMotionChip(if (fa) "اعتبارها" else "Credits", onShowCredits)
        }
    }
}

@Composable
private fun VroidCreditsDialog(fa: Boolean, onDismiss: () -> Unit) {
    val credits = if (fa) {
        "مدل سه‌بعدی\nChiaki Katsumi [Miku Boxing] — سازنده: Yuuki\nمنبع و اطلاعات سازنده: https://twitter.com/oh_nyoo\nمجوز VRoid Hub: استفادهٔ تجاری طبق دسته‌های مجاز و با درج اعتبار مجاز است؛ بازتوزیع، استفادهٔ جنسی و استفادهٔ خشونت‌آمیز ممنوع‌اند.\n\nانیمیشن‌ها\nهفت حرکت VRMA از pixiv Inc. / VRoid Project\nاعتبار الزامی: Animation credits to pixiv Inc.'s VRoid Project\nمنبع: https://booth.pm/ja/items/5512385\nفایل‌ها از ZIP انتخابی کاربر در حافظهٔ خصوصی اپ نصب می‌شوند و در APK بازتوزیع نمی‌شوند.\n\nموتور و کتابخانه‌ها\nThree.js r180 — MIT\n@pixiv/three-vrm 3.5.5 — MIT\n@pixiv/three-vrm-animation 3.5.5 — MIT\nبخش‌هایی از رندر و چرخهٔ VRM با اقتباس از Project AIRI (moeru-ai/airi)، commit 822243de34e8d1151202ac2f688f83d68d04289c.\nمجوزها و اعلان‌های کامل در فایل‌های NOTICE و LICENSE همراه سورس قرار دارند."
    } else {
        "3D character\nChiaki Katsumi [Miku Boxing] — Creator: Yuuki\nCreator source/contact: https://twitter.com/oh_nyoo\nVRoid Hub license: the listed commercial-use categories are permitted with credit; redistribution, sexual use and violent use are disallowed.\n\nAnimations\nSeven VRMA motions by pixiv Inc. / VRoid Project\nRequired credit: Animation credits to pixiv Inc.'s VRoid Project\nSource: https://booth.pm/ja/items/5512385\nThe user-selected ZIP is installed into app-private storage; the raw files are not redistributed inside the APK.\n\nEngine and libraries\nThree.js r180 — MIT\n@pixiv/three-vrm 3.5.5 — MIT\n@pixiv/three-vrm-animation 3.5.5 — MIT\nParts of the VRM renderer and update loop are adapted from Project AIRI (moeru-ai/airi), commit 822243de34e8d1151202ac2f688f83d68d04289c.\nFull notices and license texts are included in the source package."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF071629),
        titleContentColor = Color(0xFF72E8FF),
        textContentColor = Color(0xFFDCEBFA),
        title = { Text(if (fa) "اعتبارها و مجوزها" else "Credits & Licenses", fontWeight = FontWeight.Bold) },
        text = { Text(credits, modifier = Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), fontSize = 12.sp, lineHeight = 17.sp) },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (fa) "بستن" else "Close", color = Color(0xFF72E8FF))
            }
        }
    )
}

@Composable
internal fun AssistantPreviewScreen(
    p: Palette,
    fa: Boolean,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    embedded: Boolean = false,
    state: String = "idle"
) {
    var motionRequest by remember { mutableStateOf<String?>(null) }
    var avatarReloadToken by remember { mutableStateOf(0) }
    var showVroidCredits by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val packPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val error = withContext(Dispatchers.IO) { importVroidPack(context, uri) }
            if (error == null) {
                avatarReloadToken += 1
                Toast.makeText(
                    context,
                    if (fa) "مدل و هر ۷ حرکت VRoid نصب شدند؛ از این به بعد آفلاین هستند."
                    else "VRM character and all 7 VRoid motions installed for offline use.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(context, if (fa) "نصب پک ناموفق بود: $error" else "VRoid pack install failed: $error", Toast.LENGTH_LONG).show()
            }
        }
    }
    val vrmPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = pickedDocumentName(context, uri).orEmpty()
            if (!name.endsWith(".vrm", ignoreCase = true)) {
                Toast.makeText(context, if (fa) "فقط فایل VRM انتخاب کن." else "Please select a .vrm file.", Toast.LENGTH_LONG).show()
            } else {
                val target = File(context.filesDir, "characters/user/current.vrm")
                if (copyPickedDocument(context, uri, target, 200L * 1024L * 1024L)) {
                    avatarReloadToken += 1
                    Toast.makeText(context, if (fa) "مدل VRM وارد شد." else "VRM character imported.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, if (fa) "واردکردن مدل ناموفق بود." else "Could not import the VRM file.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    val motionPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val candidates = uris.mapNotNull { uri ->
                val name = pickedDocumentName(context, uri) ?: return@mapNotNull null
                if (name.endsWith(".vrma", ignoreCase = true)) uri to name else null
            }.sortedBy { it.second.lowercase() }.take(7)
            if (candidates.isEmpty()) {
                Toast.makeText(context, if (fa) "فایل VRMA پیدا نشد؛ ZIP را استخراج و فایل‌ها را انتخاب کن." else "No .vrma files found. Extract the ZIP and select the VRMA files.", Toast.LENGTH_LONG).show()
            } else {
                val folder = File(context.filesDir, "motions/user")
                folder.mkdirs()
                (1..7).forEach { index -> File(folder, "VRMA_%02d.vrma".format(index)).delete() }
                var imported = 0
                candidates.forEachIndexed { index, item ->
                    val destination = File(folder, "VRMA_%02d.vrma".format(index + 1))
                    if (copyPickedDocument(context, item.first, destination, 50L * 1024L * 1024L)) imported++
                }
                Toast.makeText(context,
                    if (fa) "$imported حرکت VRoid وارد شد. از دکمه‌های پایین اجرا کن."
                    else "$imported VRoid motion file(s) imported. Use the buttons below to play them.",
                    Toast.LENGTH_LONG).show()
            }
        }
    }
    val pickPack = { packPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*")) }
    val pickVrm = { vrmPicker.launch(arrayOf("model/gltf-binary", "application/octet-stream", "*/*")) }
    val pickVrma = { motionPicker.launch(arrayOf("application/octet-stream", "*/*")) }
    val playMotion: (String) -> Unit = { key -> motionRequest = "$key:${System.nanoTime()}" }
    val showCredits = { showVroidCredits = true }

    if (embedded) {
        // Android-native controls sit outside the WebView. This avoids WebView/Canvas
        // hit-testing conflicts and guarantees taps reach the state controller.
        var selectedState by remember(state) { mutableStateOf(state) }
        val assistantStates: List<Pair<String, String>> = listOf(
            "idle" to tx(fa, "Idle", "آماده"),
            "scanning" to tx(fa, "Scanning", "پایش"),
            "connecting" to tx(fa, "Connecting", "اتصال"),
            "success" to tx(fa, "Connected", "متصل"),
            "password_success" to tx(fa, "Pass OK", "رمز صحیح"),
            "password_warning" to tx(fa, "Wrong pass", "رمز اشتباه"),
            "warning" to tx(fa, "Warning", "هشدار"),
            "angry" to tx(fa, "Attack", "حمله"),
            "offline" to tx(fa, "Offline", "آفلاین"),
            "setup" to tx(fa, "Setup", "راه‌اندازی")
        )
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF071629))
        ) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                LivLivAssistantWebView(
                    fa = fa,
                    state = selectedState,
                    compact = false,
                    modifier = Modifier.fillMaxSize(),
                    motionRequest = motionRequest,
                    avatarReloadToken = avatarReloadToken
                )
                // Keep a clear exit affordance after hiding the normal app toolbar/tab bar.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(18.dp)
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xB80A1E33))
                        .border(1.dp, Color(0x8836BAFF), CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("×", color = Color(0xFFEAF7FF), fontSize = 25.sp, lineHeight = 26.sp, fontWeight = FontWeight.Light)
                }
            }
            CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xF2061B31))
                        .border(1.dp, Color(0x884BBFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        if (fa) "دستیار سه‌بعدی VRoid" else "VROID · WAPFIRE ASSISTANT",
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF72E8FF),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = if (fa) 0.sp else 0.8.sp,
                        maxLines = 1
                    )
                    Text(
                        overviewAssistantMessage(fa, selectedState),
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFECF7FF),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 2
                    )
                }
            }
            CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xF006182B))
                        .border(1.dp, Color(0xAA3275A1), RoundedCornerShape(14.dp))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    assistantStates.forEach { (key, label) ->
                        val selected = selectedState == key
                        Box(
                            modifier = Modifier
                                .height(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Color(0xFF125D86) else Color(0xFF0A2037))
                                .border(
                                    1.dp,
                                    if (selected) Color(0xFF55C8F6) else Color(0xFF32658C),
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedState = key }
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (selected) Color.White else Color(0xFFCFE8F8),
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            VroidMotionControlBar(fa, pickPack, pickVrm, pickVrma, showCredits, playMotion)
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .then(Modifier.windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)))
                .background(Color.Transparent)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(p.panelAlt)
                        .border(1.dp, p.border, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("‹", color = p.text, fontSize = 27.sp, lineHeight = 28.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("WAPFIRE · VRoid 3D CHARACTER", color = p.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Animated assistant", "دستیار متحرک"), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = false,
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp)),
                motionRequest = motionRequest,
                avatarReloadToken = avatarReloadToken
            )
            VroidMotionControlBar(fa, pickPack, pickVrm, pickVrma, showCredits, playMotion)
        }
    }
    if (showVroidCredits) VroidCreditsDialog(fa, onDismiss = { showVroidCredits = false })
}
