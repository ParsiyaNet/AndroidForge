# WAPFire Mobile 4.1.49

- Replaced the packaged character model at build time with `v05_clean.livliv` from the user's AndroidForge repository.
- Verified the downloaded model against its Git blob SHA-1 before packaging; model, cover and avatar are embedded in APK assets.
- Runtime character loading remains fully offline; no model/texture download occurs on the device.
- Removed the 54px bottom reserve from the Assistant character stage because native Compose controls already live outside the WebView.
- Preserved the 4.1.48 Renderer and native Assistant controls.
