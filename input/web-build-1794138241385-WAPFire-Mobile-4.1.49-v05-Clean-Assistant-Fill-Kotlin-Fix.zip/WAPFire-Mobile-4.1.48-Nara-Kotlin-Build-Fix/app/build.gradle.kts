import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 90
        versionName = "4.1.49"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

// WAPFire 4.1.49: retrieve the user's clean LivLiv package at build time.
// The model, avatar and cover are copied into APK assets before asset merging;
// the installed app never fetches character files over the network.
val downloadV05CleanCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val previewDir = file("src/main/assets/assistant/characters/v03")
    val coverAsset = File(previewDir, "cover.webp")
    val avatarAsset = File(previewDir, "avatar.webp")
    val expectedGitBlobSha1 = "3737bf81f0550ff25b0cb91f5f16aafe9c1e4bea"
    val modelUrls = listOf(
        "https://raw.githubusercontent.com/ParsiyaNet/AndroidForge/main/v05_clean.livliv",
        "https://github.com/ParsiyaNet/AndroidForge/raw/refs/heads/main/v05_clean.livliv"
    )

    outputs.files(modelAsset, coverAsset, avatarAsset)
    // Always verify the on-disk model. If it already matches the approved Git blob,
    // no network request is needed (subsequent local builds can run offline).
    outputs.upToDateWhen { false }

    doLast {
        fun gitBlobSha1(file: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
        }

        fun validateAndExtract(file: File) {
            ZipFile(file).use { archive ->
                listOf("model.json", "cover.webp", "avatar.webp").forEach { required ->
                    if (archive.getEntry(required) == null) {
                        throw GradleException("v05_clean.livliv is missing required entry: $required")
                    }
                }
                val textureCount = archive.entries().asSequence().count { it.name.startsWith("textures/") }
                if (textureCount < 5) {
                    throw GradleException("v05_clean.livliv has an incomplete texture set ($textureCount textures)")
                }
                fun extract(entryName: String, destination: File) {
                    destination.parentFile.mkdirs()
                    val temp = File(destination.parentFile, destination.name + ".part")
                    archive.getInputStream(archive.getEntry(entryName)).use { input ->
                        temp.outputStream().use { output -> input.copyTo(output) }
                    }
                    Files.move(
                        temp.toPath(), destination.toPath(),
                        StandardCopyOption.REPLACE_EXISTING
                    )
                }
                extract("cover.webp", coverAsset)
                extract("avatar.webp", avatarAsset)
            }
        }

        modelAsset.parentFile.mkdirs()
        previewDir.mkdirs()
        if (modelAsset.isFile && gitBlobSha1(modelAsset) == expectedGitBlobSha1) {
            validateAndExtract(modelAsset)
            logger.lifecycle("Verified v05_clean.livliv already present; previews refreshed. Runtime remains offline.")
            return@doLast
        }

        val tempModel = File(modelAsset.parentFile, "v05_clean.livliv.download")
        var lastFailure: Exception? = null
        var downloaded = false
        for (endpoint in modelUrls) {
            for (attempt in 1..3) {
                var activeConnection: HttpURLConnection? = null
                try {
                    // Keep the connection used by this attempt immutable inside the try
                    // block so Kotlin can safely smart-cast it in stream operations.
                    val connection = URL(endpoint).openConnection() as HttpURLConnection
                    activeConnection = connection
                    connection.connectTimeout = 20000
                    connection.readTimeout = 60000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.49")
                    connection.setRequestProperty("Accept", "application/octet-stream")
                    val status = connection.responseCode
                    if (status != HttpURLConnection.HTTP_OK) {
                        throw IOException("HTTP $status from $endpoint")
                    }
                    connection.inputStream.use { input ->
                        tempModel.outputStream().use { output -> input.copyTo(output) }
                    }
                    val actualSha = gitBlobSha1(tempModel)
                    if (actualSha != expectedGitBlobSha1) {
                        throw GradleException("v05_clean.livliv integrity check failed: expected $expectedGitBlobSha1, received $actualSha")
                    }
                    validateAndExtract(tempModel)
                    Files.move(
                        tempModel.toPath(), modelAsset.toPath(),
                        StandardCopyOption.REPLACE_EXISTING
                    )
                    downloaded = true
                    logger.lifecycle("Downloaded and verified v05_clean.livliv ($actualSha); model and previews will be packaged into the APK.")
                    break
                } catch (error: Exception) {
                    lastFailure = error
                    tempModel.delete()
                    logger.warn("v05_clean.livliv fetch attempt $attempt failed from $endpoint: ${error.message}")
                } finally {
                    activeConnection?.disconnect()
                }
            }
            if (downloaded) break
        }
        if (!downloaded) {
            throw GradleException(
                "Could not fetch the verified v05_clean.livliv model. Check GitHub access from the build runner.",
                lastFailure
            )
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(downloadV05CleanCharacter)
}

