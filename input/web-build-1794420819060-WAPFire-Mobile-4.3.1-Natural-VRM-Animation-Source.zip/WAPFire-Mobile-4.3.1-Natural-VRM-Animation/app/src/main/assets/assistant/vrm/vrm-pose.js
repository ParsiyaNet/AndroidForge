/* WAPFire 4.3.1 - organic VRM pose / emotion engine.
 * Pure logic: no DOM, no three.js. The renderer maps the returned frame onto the VRM rig.
 *
 * Design goals:
 * - no endlessly repeating idle sway / gaze sine waves;
 * - breathing with gently changing cadence and depth;
 * - independent but correlated, slow posture and eye-attention shifts;
 * - brief, one-shot gestures with natural easing and pauses;
 * - duplicate state notifications never restart an in-progress gesture.
 *
 * Angles in frames are radians, except gaze (degrees for three-vrm lookAt).
 */
const D = Math.PI / 180;
const TAU = Math.PI * 2;

const EXPR = ['happy', 'sad', 'angry', 'relaxed', 'surprised'];
const BONES = ['head', 'neck', 'chest', 'spine'];
const ARM_KEYS = ['down', 'fwd', 'elbowF', 'elbowU', 'curl'];

const REST_ARM = { down: 70, fwd: 3, elbowF: 8, elbowU: 0, curl: 0.1 };
const arm = (o) => Object.assign({}, REST_ARM, o || {});

/* Degrees here (converted once). Expression weights and blink are 0..1. */
const POSES = {
  idle: { e: { happy: 0.14 }, blink: 0, head: { x: 0, y: 0, z: 0 }, L: arm(), R: arm() },

  scanning: {
    e: { angry: 0.10 }, blink: 0.06, head: { x: 1.5, y: 0, z: 0 }, chest: { x: 0.7 },
    L: arm({ down: 67, fwd: 8, elbowF: 22 }), R: arm({ down: 67, fwd: 8, elbowF: 22 }), sweep: 1
  },

  connecting: {
    e: { happy: 0.1, relaxed: 0.28 }, blink: 0, head: { x: -2.5, y: 5, z: 5 }, gaze: { yaw: -10, pitch: 5 },
    L: arm({ down: 68, elbowF: 14 }), R: arm({ down: 59, fwd: 20, elbowF: 78 })
  },

  success: {
    e: { happy: 1 }, blink: 0, head: { x: -3.5, y: 0, z: 3 }, chest: { x: -1.5 },
    L: arm({ down: 51, fwd: 14, elbowF: 58 }), R: arm({ down: 51, fwd: 14, elbowF: 58 }), gesture: 'hop'
  },

  password_success: {
    e: { happy: 0.68, relaxed: 0.18 }, blink: 0, head: { x: 0, y: 0, z: 2.5 },
    L: arm({ down: 65, elbowF: 16 }), R: arm({ down: 65, elbowF: 16 }), gesture: 'nod'
  },

  password_warning: {
    e: { sad: 0.62, surprised: 0.1 }, blink: 0, head: { x: 3.5, y: 0, z: -6 }, gaze: { yaw: 0, pitch: -5 },
    L: arm({ down: 57, fwd: 21, elbowF: 72 }), R: arm({ down: 57, fwd: 21, elbowF: 72 }), gesture: 'no'
  },

  warning: {
    e: { surprised: 0.86, sad: 0.1 }, blink: 0, head: { x: -4, y: 0, z: 0 }, chest: { x: -3 }, shoulders: 5.5,
    L: arm({ down: 59, fwd: 5, elbowF: 32 }), R: arm({ down: 59, fwd: 5, elbowF: 32 }), gesture: 'startle'
  },

  angry: {
    e: { angry: 1 }, blink: 0.18, head: { x: 9, y: 0, z: 0 }, neck: { x: 3 }, chest: { x: 6 }, spine: { x: 2.5 }, shoulders: 3.5,
    gaze: { yaw: 0, pitch: 3.5 },
    L: arm({ down: 63, fwd: 10, elbowF: 47, curl: 1 }), R: arm({ down: 63, fwd: 10, elbowF: 47, curl: 1 }), tremor: 1
  },

  offline: {
    e: { sad: 0.9 }, blink: 0.28, head: { x: 13, y: 0, z: -4 }, neck: { x: 3.5 }, chest: { x: 7 }, spine: { x: 3.5 },
    gaze: { yaw: 0, pitch: -12 }, shoulders: -2.5, slowBreath: 1,
    L: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0 }), R: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0 })
  },

  setup: {
    e: { happy: 0.46, relaxed: 0.18 }, blink: 0, head: { x: -1.5, y: 0, z: 5 },
    L: arm({ down: 68 }), R: arm({ down: 68 }), gesture: 'wave'
  }
};

const rad = (v) => (v || 0) * D;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const smooth = (t) => { const x = clamp(t, 0, 1); return x * x * (3 - 2 * x); };
const bell = (t, center, width) => Math.exp(-0.5 * Math.pow((t - center) / width, 2));

function flatten(pose) {
  const t = {};
  for (const k of EXPR) t['e_' + k] = (pose.e && pose.e[k]) || 0;
  t.blink = pose.blink || 0;
  for (const b of BONES) for (const a of ['x', 'y', 'z']) t[b + '_' + a] = rad(pose[b] && pose[b][a]);
  t.shoulders = rad(pose.shoulders);
  t.gaze_yaw = (pose.gaze && pose.gaze.yaw) || 0;
  t.gaze_pitch = (pose.gaze && pose.gaze.pitch) || 0;
  for (const side of ['L', 'R']) for (const k of ARM_KEYS) {
    const v = (pose[side] || REST_ARM)[k];
    t[side + '_' + k] = k === 'curl' ? v : rad(v);
  }
  return t;
}

const TAU_BLEND = { e: 0.24, blink: 0.22, bone: 0.62, shoulders: 0.52, gaze: 0.2, arm: 0.58 };
function tauFor(key) {
  if (key.startsWith('e_')) return TAU_BLEND.e;
  if (key === 'blink') return TAU_BLEND.blink;
  if (key === 'shoulders') return TAU_BLEND.shoulders;
  if (key.startsWith('gaze_')) return TAU_BLEND.gaze;
  if (key[0] === 'L' || key[0] === 'R') return TAU_BLEND.arm;
  return TAU_BLEND.bone;
}

/* One-shot gesture offsets. Gaussian-like pulses avoid mechanical back-and-forth loops. */
function gesture(name, t, style) {
  const g = { headX: 0, headY: 0, headZ: 0, chestX: 0, hipsY: 0, wave: 0, waveT: 0, waveDuration: 2.35, waveRate: 1.13 };
  if (name === 'nod') {
    // One clear, gentle nod followed by a small settling motion.
    g.headX = rad(6.2 * style.nodScale * bell(t, 0.28, 0.17) - 1.8 * style.nodScale * bell(t, 0.62, 0.2));
    g.chestX = rad(1.1 * style.nodScale * bell(t, 0.3, 0.22));
  } else if (name === 'no') {
    // One restrained left-right disagreement, with a pause rather than a repeated shake.
    g.headY = rad(style.noScale * (7.5 * bell(t, 0.38, 0.17) - 5.2 * bell(t, 0.82, 0.2)));
    g.headZ = rad(-1.8 * style.noScale * bell(t, 0.4, 0.2));
  } else if (name === 'startle') {
    const attack = smooth(t / 0.075);
    const settle = Math.exp(-Math.max(0, t - 0.075) * 3.2);
    const e = attack * settle;
    g.headX = -rad(5.5 * style.startleScale) * e;
    g.chestX = -rad(3.5 * style.startleScale) * e;
    g.hipsY = 0.009 * style.startleScale * e;
  } else if (name === 'hop') {
    // A light main bounce and a much smaller follow-through, not a repeated pogo motion.
    g.hipsY = style.hopScale * (0.031 * bell(t, 0.26, 0.13) + 0.010 * bell(t, 0.73, 0.11));
    g.headX = rad(style.hopScale * (4.2 * bell(t, 0.34, 0.18) - 1.4 * bell(t, 0.73, 0.15)));
  } else if (name === 'wave') {
    const duration = style.waveDuration;
    if (t < duration) {
      const fadeIn = Math.min(0.38, duration * 0.16);
      const fadeOut = Math.min(0.52, duration * 0.22);
      const inEnv = smooth(t / fadeIn);
      const outEnv = 1 - smooth((t - (duration - fadeOut)) / fadeOut);
      g.wave = clamp(inEnv * outEnv, 0, 1);
      g.waveT = t;
      g.waveDuration = duration;
      g.waveRate = style.waveRate;
    }
  }
  return g;
}

function create(seedValue) {
  let pose = POSES.idle, t0 = 0, curState = 'idle';
  const cur = flatten(POSES.idle);
  let seed = (Math.abs(Math.floor(Number.isFinite(seedValue) ? seedValue : 7)) % 2147483646) + 1;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const range = (a, b) => a + (b - a) * rnd();

  /* Smooth random waypoints with irregular durations: movement has pauses and never loops on a fixed period. */
  function makeLane(min, max, minTime, maxTime, chooser) {
    return { min, max, minTime, maxTime, chooser, from: 0, to: 0, start: 0, end: 0 };
  }
  function sampleLane(lane, now) {
    if (now >= lane.end) {
      lane.from = lane.to;
      lane.to = lane.chooser ? lane.chooser(rnd, range) : range(lane.min, lane.max);
      lane.start = now;
      lane.end = now + range(lane.minTime, lane.maxTime);
    }
    const u = smooth((now - lane.start) / Math.max(0.001, lane.end - lane.start));
    return lane.from + (lane.to - lane.from) * u;
  }

  const motion = {
    headPitch: makeLane(-0.85, 0.85, 3.1, 6.8),
    headYaw: makeLane(-1.65, 1.65, 2.8, 6.2),
    headRoll: makeLane(-0.8, 0.8, 3.0, 6.5),
    chestPitch: makeLane(-0.35, 0.42, 4.2, 8.2),
    chestYaw: makeLane(-0.55, 0.55, 4.0, 8.0),
    chestRoll: makeLane(-0.42, 0.42, 3.8, 7.5),
    spineRoll: makeLane(-0.28, 0.28, 4.5, 8.5),
    gazeYaw: makeLane(-4.8, 4.8, 1.8, 4.0),
    gazePitch: makeLane(-2.1, 2.1, 2.0, 4.3),
    shoulders: makeLane(-0.35, 0.35, 3.4, 7.2),
    weightShift: makeLane(-1, 1, 4.2, 8.8),
    scan: makeLane(-11.5, 11.5, 1.35, 2.8, (random, r) => random() < 0.24 ? 0 : r(-11.5, 11.5))
  };

  let gestureStyle = { nodScale: 1, noScale: 1, startleScale: 1, hopScale: 1, waveDuration: 2.35, waveRate: 1.13 };
  let breathPhase = 0;
  let breathPeriod = 4.25;
  let breathDepth = 1;
  let blinkReady = false, nextBlink = 0, blinkT = -1;
  let nextSaccade = 0, saccadeYaw = 0, saccadePitch = 0, saccadeT = -10;

  function setState(name, now) {
    const nextState = POSES[name] ? name : 'idle';
    // Some native/UI layers can report the same state more than once. Do not restart gestures.
    if (nextState === curState) return false;
    curState = nextState;
    pose = POSES[curState];
    t0 = now;
    // A new entrance gets slightly different timing/amplitude; repeated notifications do not.
    gestureStyle = {
      nodScale: range(0.88, 1.12),
      noScale: range(0.88, 1.12),
      startleScale: range(0.9, 1.1),
      hopScale: range(0.88, 1.12),
      waveDuration: range(2.15, 2.65),
      waveRate: range(0.98, 1.16)
    };
    return true;
  }

  function update(now, dt) {
    dt = clamp(Number.isFinite(dt) ? dt : 1 / 60, 0, 0.1);
    const target = flatten(pose);
    for (const k in target) {
      const a = 1 - Math.exp(-dt / tauFor(k));
      cur[k] += (target[k] - cur[k]) * a;
    }

    if (!blinkReady) {
      blinkReady = true;
      nextBlink = now + range(1.4, 3.0);
      nextSaccade = now + range(0.6, 1.4);
    }

    const t = Math.max(0, now - t0);
    const g = gesture(pose.gesture, t, gestureStyle);

    // Variable breathing cadence and depth. A new duration is chosen at each breath, so it never loops exactly.
    const desiredBreath = pose.slowBreath ? 5.8 : 4.15;
    breathPeriod += (desiredBreath - breathPeriod) * (1 - Math.exp(-dt * 0.16));
    breathPhase += (TAU / Math.max(3.2, breathPeriod)) * dt;
    if (breathPhase >= TAU) {
      breathPhase -= TAU;
      breathPeriod = pose.slowBreath ? range(5.2, 7.0) : range(3.55, 5.35);
      breathDepth = range(0.78, 1.14);
    }
    const breath = (Math.sin(breathPhase - 0.18) + 0.13 * Math.sin(2 * breathPhase - 0.8)) * breathDepth;

    // The body leads very slightly; the head and eyes make smaller, independent corrections.
    const headPitch = sampleLane(motion.headPitch, now);
    const headYaw = sampleLane(motion.headYaw, now);
    const headRoll = sampleLane(motion.headRoll, now);
    const chestPitch = sampleLane(motion.chestPitch, now);
    const chestYaw = sampleLane(motion.chestYaw, now);
    const chestRoll = sampleLane(motion.chestRoll, now);
    const spineRoll = sampleLane(motion.spineRoll, now);
    const gazeYaw = sampleLane(motion.gazeYaw, now);
    const gazePitch = sampleLane(motion.gazePitch, now);
    const shoulderDrift = sampleLane(motion.shoulders, now);
    const weightShift = sampleLane(motion.weightShift, now);
    const scan = pose.sweep ? sampleLane(motion.scan, now) : 0;

    // Tiny, quick eye saccades add attention without making the eyes buzz continuously.
    if (now >= nextSaccade) {
      saccadeYaw = range(-1.7, 1.7);
      saccadePitch = range(-0.9, 0.9);
      saccadeT = now;
      nextSaccade = now + range(1.0, 2.7);
    }
    const saccadeAge = Math.max(0, now - saccadeT);
    const saccadeFade = Math.exp(-saccadeAge * 10.5);

    // Blinks: varied intervals, with occasional natural double blinks.
    if (blinkT < 0 && now >= nextBlink) blinkT = 0;
    let blinkPulse = 0;
    if (blinkT >= 0) {
      blinkT += dt;
      const duration = 0.17;
      const phase = clamp(blinkT / duration, 0, 1);
      blinkPulse = Math.pow(Math.sin(Math.PI * phase), 1.25);
      if (blinkT >= duration) {
        blinkT = -1;
        const doubleBlink = rnd() < 0.14;
        nextBlink = now + (doubleBlink ? range(0.24, 0.42) : range(2.0, 5.1));
      }
    }

    let motionGain = 1;
    if (curState === 'scanning') motionGain = 0.72;
    else if (curState === 'connecting' || curState === 'setup') motionGain = 0.65;
    else if (curState === 'success') motionGain = 0.42;
    else if (curState === 'password_success' || curState === 'password_warning') motionGain = 0.5;
    else if (curState === 'warning' || curState === 'angry') motionGain = 0.32;
    else if (curState === 'offline') motionGain = 0.42;

    const microTremor = pose.tremor
      ? Math.sin(now * 12.7 + 0.22 * Math.sin(now * 1.35)) * 0.00065
      : 0;

    const f = { expr: {}, rot: {}, arm: { L: {}, R: {} }, hipsY: g.hipsY, shoulders: 0, gaze: { yaw: 0, pitch: 0 }, state: curState };
    for (const k of EXPR) f.expr[k] = clamp(cur['e_' + k], 0, 1);
    // VRoid Joy already closes the eyes; do not double-close its lids with the blink channel.
    const eyesClosedByJoy = Math.min(1, f.expr.happy * 1.2);
    f.expr.blink = Math.max(cur.blink, blinkPulse) * (1 - eyesClosedByJoy);

    f.rot.head = {
      x: cur.head_x + g.headX + rad(headPitch * motionGain * 0.55) + microTremor,
      y: cur.head_y + g.headY + rad(headYaw * motionGain * 0.72 + scan * 0.46),
      z: cur.head_z + g.headZ + rad((headRoll * 0.48 - weightShift * 0.24) * motionGain)
    };
    f.rot.neck = {
      x: cur.neck_x + rad(headPitch * motionGain * 0.12),
      y: cur.neck_y + rad(scan * 0.13),
      z: cur.neck_z + rad(headRoll * motionGain * 0.1)
    };
    f.rot.chest = {
      x: cur.chest_x + g.chestX + rad(chestPitch * motionGain * 0.42) + 0.009 * breath,
      y: cur.chest_y + rad(chestYaw * motionGain * 0.42 + scan * 0.055),
      z: cur.chest_z + rad((chestRoll * 0.34 + weightShift * 0.38) * motionGain)
    };
    f.rot.spine = {
      x: cur.spine_x + rad(chestPitch * motionGain * 0.1),
      y: cur.spine_y,
      z: cur.spine_z + rad((spineRoll * 0.3 + weightShift * 0.28) * motionGain)
    };
    f.shoulders = cur.shoulders + rad((shoulderDrift + weightShift * 0.2) * motionGain) + 0.012 * Math.max(0, breath);

    f.gaze.yaw = cur.gaze_yaw + gazeYaw * motionGain + scan * 1.18 + saccadeYaw * saccadeFade;
    f.gaze.pitch = cur.gaze_pitch + gazePitch * motionGain + 1.2 * Math.sin(breathPhase * 0.5) + saccadePitch * saccadeFade;

    for (const side of ['L', 'R']) {
      const a = f.arm[side];
      for (const k of ARM_KEYS) a[k] = cur[side + '_' + k];
      // A barely visible asymmetric settling motion, not a metronomic arm swing.
      a.down += rad((side === 'L' ? -0.65 : 0.55) * weightShift + (side === 'L' ? 0.16 : -0.14) * headRoll) * motionGain;
      a.fwd += rad((side === 'L' ? 0.22 : -0.18) * weightShift) * motionGain;
      a.elbowF += rad(0.08 * weightShift) * motionGain;
      if (pose.tremor) a.down += microTremor * (side === 'L' ? 0.8 : -0.65);
    }

    // A short, slow greeting: two relaxed, slightly uneven wrist/forearm movements.
    if (g.wave > 0) {
      const w = g.wave;
      const phase = TAU * (g.waveRate * g.waveT + 0.045 * Math.sin(TAU * 0.53 * g.waveT));
      const oscillation = Math.sin(phase + 0.25);
      const amplitude = 0.7 + 0.3 * Math.sin(Math.PI * clamp(g.waveT / g.waveDuration, 0, 1));
      const a = f.arm.R;
      a.down += (rad(8) - a.down) * w;
      a.fwd += (rad(21) - a.fwd) * w;
      a.elbowF += (rad(1.5) - a.elbowF) * w;
      a.elbowU += (rad(77) + rad(6.5) * oscillation * amplitude - a.elbowU) * w;
      f.expr.happy = Math.max(f.expr.happy, 0.52 * w);
    }

    return f;
  }

  return { setState, update };
}

export { create, POSES, EXPR };
export default { create, POSES, EXPR };
