package io.wapfire.mobile.ui.screens

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import java.io.FileNotFoundException
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import io.wapfire.mobile.BuildConfig
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx
import androidx.webkit.WebViewAssetLoader

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ASSET_PREFIX = "/assets/"
private const val NARA_URL = "https://appassets.androidplatform.net/assets/assistant/assistant-live.html"
private const val NARA_BUILD = "4.1.50"
private const val HIYORI_URL = "https://appassets.androidplatform.net/assets/assistant/hiyori/index.html"
private const val HIYORI_BUILD = "4.2.1"
private const val VRM_URL = "https://appassets.androidplatform.net/assets/assistant/vrm/index.html"
private const val VRM_BUILD = "4.3.1"
private const val VRM_STARTUP_TIMEOUT_MS = 60000L
private const val HIYORI_STARTUP_TIMEOUT_MS = 40000L

/** 4.3.1: the character engines in order of preference. If one cannot start, the next one is loaded. */
private enum class AssistantEngine { VRM, HIYORI, NARA }

private val VRM_ASSETS = listOf(
    "assistant/vrm/index.html",
    "assistant/vrm/vrm.js",
    "assistant/vrm/vrm-pose.js",
    "assistant/vrm/lib/three.module.js",
    "assistant/vrm/lib/three-vrm.module.min.js",
    "assistant/vrm/lib/addons/loaders/GLTFLoader.js",
    "assistant/vrm/lib/addons/utils/BufferGeometryUtils.js",
    "assistant/vrm/model/nara.vrm"
)

private val HIYORI_ASSETS = listOf(
    "assistant/hiyori/index.html",
    "assistant/hiyori/hiyori.js",
    "assistant/hiyori/pose.js",
    "assistant/hiyori/lib/live2dcubismcore.min.js",
    "assistant/hiyori/lib/pixi.min.js",
    "assistant/hiyori/lib/cubism4.min.js",
    "assistant/hiyori/model/Hiyori.model3.json",
    "assistant/hiyori/model/Hiyori.moc3"
)
private const val TAG = "WapFireAssistant"

/**
 * Uses AndroidX WebViewAssetLoader for a real HTTPS origin backed only by APK assets.
 * The asset handler serves ES modules, the LivLiv package and textures without network access.
 * All non-local requests are explicitly rejected by the WebViewClient.
 */
private class AssistantJsBridge(
    private val webView: WebView,
    private val onStatus: (String?) -> Unit,
    private val onReady: () -> Unit,
    private val onFatal: (String?) -> Unit
) {
    @JavascriptInterface
    fun reportStatus(message: String?) {
        webView.post { onStatus(message?.take(900)?.ifBlank { null }) }
    }

    @JavascriptInterface
    fun reportReady() {
        webView.post { onReady() }
    }

    /** The page could not start at all (for example Cubism Core or the model failed to load). */
    @JavascriptInterface
    fun reportFatal(message: String?) {
        webView.post { onFatal(message?.take(900)) }
    }
}

internal class LivLivWebView(
    context: Context,
    private val fa: Boolean,
    private val compact: Boolean,
    initialState: String,
    private val onNativeStatus: (String?) -> Unit
) : WebView(context) {
    private var pageReady = false
    private var rendererReady = false
    private var mainFrameFailed = false
    private var navigationGeneration = 0
    private var pendingState: String = initialState
    // 4.3.1: the VRM character is the default. Fallback chain: VRM -> Hiyori (Live2D) -> Nara (LivLiv).
    private var engine = AssistantEngine.VRM
    private val engineUrl: String get() = when (engine) {
        AssistantEngine.VRM -> VRM_URL
        AssistantEngine.HIYORI -> HIYORI_URL
        AssistantEngine.NARA -> NARA_URL
    }
    private val engineBuild: String get() = when (engine) {
        AssistantEngine.VRM -> VRM_BUILD
        AssistantEngine.HIYORI -> HIYORI_BUILD
        AssistantEngine.NARA -> NARA_BUILD
    }
    private fun assetsPresent(list: List<String>): Boolean =
        list.all { asset -> runCatching { context.assets.open(asset).use { true } }.getOrDefault(false) }
    private val assetLoader = WebViewAssetLoader.Builder()
        .setDomain(ASSET_HOST)
        .addPathHandler(ASSET_PREFIX, object : WebViewAssetLoader.PathHandler {
            override fun handle(path: String): WebResourceResponse? {
                // Serve APK assets with explicit MIME types. ES modules require a JavaScript MIME type.
                val clean = Uri.decode(path).removePrefix("/")
                if (clean.isBlank() || clean.startsWith("/") || clean.contains('\\') ||
                    clean.split('/').any { it == ".." || it == "." }) return null
                val extension = clean.substringAfterLast('.', "").lowercase()
                val mime = when (extension) {
                    "html", "htm" -> "text/html"
                    "js", "mjs" -> "text/javascript"
                    "css" -> "text/css"
                    "json" -> "application/json"
                    "webp" -> "image/webp"
                    "png" -> "image/png"
                    "jpg", "jpeg" -> "image/jpeg"
                    "svg" -> "image/svg+xml"
                    "ico" -> "image/x-icon"
                    "livliv", "zip", "bin" -> "application/octet-stream"
                    else -> "application/octet-stream"
                }
                val encoding = if (mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("svg")) "UTF-8" else null
                return try {
                    val stream = context.assets.open(clean)
                    WebResourceResponse(
                        mime, encoding, 200, "OK",
                        mapOf(
                            "Cache-Control" to "no-store",
                            "X-Content-Type-Options" to "nosniff",
                            "Access-Control-Allow-Origin" to "https://$ASSET_HOST"
                        ),
                        stream
                    )
                } catch (_: FileNotFoundException) {
                    null
                } catch (error: Exception) {
                    Log.e(TAG, "Asset open failed: $clean", error)
                    null
                }
            }
        })
        .build()

    init {
        setBackgroundColor(AndroidColor.rgb(7, 22, 41))
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            databaseEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // The main document and every ES module/model/texture are served from APK assets
            // through WebViewAssetLoader on one virtual HTTPS origin. Other hosts are rejected
            // by shouldInterceptRequest below.
            blockNetworkLoads = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
        }
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        addJavascriptInterface(
            AssistantJsBridge(
                this,
                onStatus = { message -> onNativeStatus(message) },
                onReady = {
                    rendererReady = true
                    onNativeStatus(null)
                    Log.i(TAG, "Assistant renderer reported READY (engine=${engine.name.lowercase()})")
                },
                onFatal = { message -> fallbackToNext("page reported: $message") }
            ),
            "WapFireNative"
        )

        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = when (message.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> Log.ERROR
                    ConsoleMessage.MessageLevel.WARNING -> Log.WARN
                    else -> Log.DEBUG
                }
                val details = "JS ${message.message()} (${message.sourceId()}:${message.lineNumber()})"
                Log.println(level, TAG, details)
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR && !rendererReady) {
                    post { onNativeStatus(if (fa) "خطای موتور دستیار: ${message.message().take(220)} (${message.sourceId()}:${message.lineNumber()})" else "Assistant engine error: ${message.message().take(220)} (${message.sourceId()}:${message.lineNumber()})") }
                }
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!rendererReady && newProgress in 1..99) {
                    onNativeStatus(if (fa) "در حال بازکردن دستیار آفلاین… $newProgress٪" else "Opening offline assistant… $newProgress%")
                }
            }
        }

        webViewClient = object : WebViewClient() {
            private fun isLocal(uri: Uri): Boolean =
                uri.scheme == "https" && uri.host == ASSET_HOST && (uri.port == -1 || uri.port == 443)

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (!isLocal(uri)) {
                    Log.w(TAG, "Blocked non-local request: $uri")
                    return blockedResponse(403, "External resource blocked")
                }
                // Some WebView/Chromium builds still probe the origin-root favicon even
                // when the document declares a local icon. Serve it from packaged assets.
                if (uri.path.equals("/favicon.ico", ignoreCase = true)) {
                    return try {
                        WebResourceResponse(
                            "image/x-icon", null, 200, "OK",
                            mapOf("Cache-Control" to "no-store"),
                            context.assets.open("favicon.ico")
                        )
                    } catch (_: FileNotFoundException) {
                        blockedResponse(204, "No favicon")
                    }
                }
                if (uri.path?.startsWith(ASSET_PREFIX) != true) {
                    Log.w(TAG, "Blocked path outside packaged assets: $uri")
                    return blockedResponse(404, "Asset path not found")
                }
                val response = assetLoader.shouldInterceptRequest(uri)
                if (response == null) {
                    val path = uri.path ?: "(unknown)"
                    Log.e(TAG, "APK asset missing: $path")
                    post { if (!rendererReady) onNativeStatus(if (fa) "فایل دستیار داخل APK پیدا نشد: $path" else "Assistant APK asset missing: $path") }
                    return blockedResponse(404, "Packaged asset not found: $path")
                }
                Log.d(TAG, "Served local asset: ${uri.path} (${response.mimeType})")
                return response
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !isLocal(uri) || uri.path?.startsWith(ASSET_PREFIX) != true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url?.substringBefore("?") != engineUrl) {
                    Log.d(TAG, "Ignoring non-assistant navigation start: $url")
                    return
                }
                navigationGeneration++
                pageReady = false
                rendererReady = false
                mainFrameFailed = false
                onNativeStatus(if (fa) "در حال بازکردن صفحهٔ دستیار…" else "Opening assistant document…")
                Log.d(TAG, "Main page started: $url")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                Log.d(TAG, "Main page committed: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.substringBefore("?") != engineUrl) {
                    Log.d(TAG, "Ignoring non-assistant navigation finish: $url")
                    return
                }
                pageReady = true
                Log.d(TAG, "Main page finished: $url rendererReady=$rendererReady mainFrameFailed=$mainFrameFailed")
                if (!rendererReady && !mainFrameFailed) {
                    onNativeStatus(if (fa) "صفحه باز شد؛ موتور سه‌بعدی در حال راه‌اندازی است…" else "Page loaded; initializing 2.5D renderer…")
                    val generation = navigationGeneration
                    postDelayed({
                        if (generation == navigationGeneration && pageReady && !rendererReady && !mainFrameFailed) {
                            evaluateJavascript("""(function(){
                                var c=document.getElementById('stage'),r=c&&c.getBoundingClientRect();
                                return {build:window.__wfAssistantBuildVersion||null,preflight:!!window.__wfPreflightStarted,engine:!!window.__wfEngineBooted,renderer:!!window.__wfRendererReady,
                                  canvas:r?{width:Math.round(r.width),height:Math.round(r.height)}:null,
                                  loading:document.getElementById('loading')?.textContent||null,
                                  bodyTag:!!document.body,bodyChildren:document.body?.children.length||0,
                                  shellChildren:document.getElementById('shell')?.children.length||0,
                                  stageChildren:document.querySelector('.stage')?.children.length||0,
                                  missing:['shell','stage','loading','poster'].filter(id=>!document.getElementById(id)),
                                  pathname:location.pathname,metaBuild:document.querySelector('meta[name="wapfire-assistant-build"]')?.content||null,
                                  url:location.href,origin:location.origin};
                            })()""".trimIndent()) { raw ->
                                val diagnostic = runCatching { org.json.JSONObject(raw ?: "{}") }.getOrElse { org.json.JSONObject() }
                                val detail = diagnostic.toString().take(550)
                                Log.e(TAG, "Renderer startup diagnostic: $detail")
                                val loadingValue = diagnostic.opt("loading")
                                val loadingMessage = if (loadingValue == null || loadingValue == org.json.JSONObject.NULL) "" else loadingValue.toString()
                                val canvasValue = diagnostic.opt("canvas")
                                val canvasMessage = when {
                                    canvasValue == null || canvasValue == org.json.JSONObject.NULL -> "canvas element missing"
                                    canvasValue is org.json.JSONObject -> "canvas ${canvasValue.optInt("width")}x${canvasValue.optInt("height")}"
                                    else -> canvasValue.toString()
                                }
                                val actualBuild = diagnostic.optString("build", "unknown")
                                val message = when {
                                    actualBuild != engineBuild -> if (fa) "نسخهٔ قدیمی اسکریپت دستیار اجرا شده است ($actualBuild؛ انتظار $engineBuild)." else "A stale assistant script is running ($actualBuild; expected $engineBuild)."
                                    !diagnostic.optBoolean("preflight", false) -> if (fa) "اسکریپت راه‌اندازی اجرا نشده است؛ فایل محلی و کنسول را بررسی کن." else "Assistant bootstrap script did not execute; inspect local assets and console."
                                    !diagnostic.optBoolean("engine", false) -> if (fa) "ماژول موتور LivLiv بارگذاری نشده است." else "LivLiv engine module did not load."
                                    canvasValue == null || canvasValue == org.json.JSONObject.NULL -> if (fa) "عنصر Canvas در صفحه پیدا نشد." else "Canvas element is missing from the page."
                                    else -> if (fa) "موتور شروع شد اما هنوز آماده نیست؛ وضعیت WebGL را بررسی کن." else "Engine started but is not ready yet; inspect WebGL state."
                                }
                                val extra = listOf(canvasMessage, loadingMessage).filter { it.isNotBlank() }.joinToString(" · ")
                                onNativeStatus((if (extra.isNotBlank()) "$message ($extra)" else message) + " $detail")
                            }
                        }
                    }, 22000L)
                }
                if (rendererReady) applyPendingState()
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                val requestUrl = request?.url
                val isFavicon = requestUrl?.lastPathSegment.equals("favicon.ico", ignoreCase = true)
                val details = "WebView error mainFrame=${request?.isForMainFrame} url=$requestUrl code=${error?.errorCode} description=${error?.description}"
                Log.e(TAG, details)
                if (isFavicon) return
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    if (engine != AssistantEngine.NARA) post { fallbackToNext("main frame error") }
                    onNativeStatus(if (fa) "صفحهٔ دستیار باز نشد (${error?.errorCode}): ${error?.description}" else "Assistant page failed (${error?.errorCode}): ${error?.description}")
                } else if (!rendererReady) {
                    onNativeStatus(if (fa) "خطای فایل محلی: ${error?.description}" else "Local resource error: ${error?.description}")
                }
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, response)
                val requestUrl = request?.url
                val isFavicon = requestUrl?.lastPathSegment.equals("favicon.ico", ignoreCase = true)
                val details = "WebView HTTP error mainFrame=${request?.isForMainFrame} url=$requestUrl status=${response?.statusCode} reason=${response?.reasonPhrase}"
                Log.e(TAG, details)
                if (isFavicon) return
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    if (engine != AssistantEngine.NARA) post { fallbackToNext("main frame error") }
                    onNativeStatus(if (fa) "خطای صفحهٔ دستیار: HTTP ${response?.statusCode}" else "Assistant document error: HTTP ${response?.statusCode}")
                } else if (!rendererReady && response?.statusCode in 400..599) {
                    onNativeStatus(if (fa) "فایل دستیار پیدا نشد: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})" else "Assistant file missing: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})")
                }
            }
        }

        if (engine == AssistantEngine.VRM && !assetsPresent(VRM_ASSETS)) {
            Log.e(TAG, "VRM assets or libraries missing from the APK (run the build with network access once so fetchVrmLibs can download them); trying Hiyori")
            engine = AssistantEngine.HIYORI
        }
        if (engine == AssistantEngine.HIYORI && !assetsPresent(HIYORI_ASSETS)) {
            Log.e(TAG, "Hiyori assets missing from the APK; using Nara")
            engine = AssistantEngine.NARA
        }
        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        val pageUrl = "$engineUrl?build=$engineBuild&lang=$language&compact=$compactFlag&state=${Uri.encode(initialState)}"
        // IMPORTANT: Load the main document through WebViewAssetLoader, exactly as in the
        // device-working 4.1.34 implementation. the previous inline-document API exposed the
        // document as a data:text/html URL on Android WebView. Our strict shouldInterceptRequest
        // policy correctly rejects every non-appassets URL, including that data: URL, so the
        // document itself was blocked before #stage/#loading could exist (4.1.40 regression).
        // All renderer scripts, model data and textures are bundled under app/src/main/assets
        // and are served locally by the HTTPS appassets origin; no Internet fetch is required.
        val requiredLocalAssets = listOf(
            "assistant/assistant-live.html",
            "assistant/assistant-preflight-4.1.50.js",
            "assistant/dist/index.js",
            "assistant/characters/v03.livliv",
            "assistant/characters/v03/cover.webp"
        )
        val missingAssets = requiredLocalAssets.filter { asset ->
            runCatching { context.assets.open(asset).use { true } }.getOrDefault(false).not()
        }
        if (engine == AssistantEngine.NARA && missingAssets.isNotEmpty()) {
            val missing = missingAssets.joinToString(", ")
            Log.e(TAG, "Required offline assistant assets missing from APK: $missing")
            onNativeStatus(if (fa) "فایل‌های آفلاین دستیار در APK ناقص‌اند: $missing" else "Offline assistant files are missing from APK: $missing")
        } else {
            Log.i(TAG, "Loading offline assistant from packaged APK assets via WebViewAssetLoader: $pageUrl")
            loadUrl(pageUrl)
        }
        postDelayed({
            if (!rendererReady && pageReady) {
                evaluateJavascript("""(function(){
                    var c=document.getElementById('stage'),r=c&&c.getBoundingClientRect();
                    return JSON.stringify({build:window.__wfAssistantBuildVersion||null,metaBuild:document.querySelector('meta[name="wapfire-assistant-build"]')?.content||null,
                      readyState:document.readyState,origin:location.origin,pathname:location.pathname,preflight:!!window.__wfPreflightStarted,
                      engine:!!window.__wfEngineBooted,renderer:!!window.__wfRendererReady,body:!!document.body,bodyChildren:document.body?.children.length||0,
                      canvas:r?{width:Math.round(r.width),height:Math.round(r.height)}:null,loading:!!document.getElementById('loading'),userAgent:navigator.userAgent});
                })()""".trimIndent()) { result ->
                    Log.e(TAG, "Assistant boot probe: $result")
                    if (!rendererReady && !mainFrameFailed) {
                        val detail = if (result == null || result == "null") "JavaScript did not answer the native probe." else result.take(240)
                        onNativeStatus(if (fa) "تشخیص WebView: $detail" else "WebView diagnostic: $detail")
                    }
                }
            }
        }, 6000L)
        armStartupTimeout()
    }

    /** The VRM model is ~18 MB and Hiyori ~5 MB of textures; give slow phones plenty of time before giving up. */
    private fun armStartupTimeout() {
        val armedFor = engine
        val timeout = when (armedFor) {
            AssistantEngine.VRM -> VRM_STARTUP_TIMEOUT_MS
            AssistantEngine.HIYORI -> HIYORI_STARTUP_TIMEOUT_MS
            AssistantEngine.NARA -> return
        }
        postDelayed({ if (engine == armedFor && !rendererReady) fallbackToNext("startup timeout") }, timeout)
    }

    private fun fallbackToNext(reason: String) {
        if (engine == AssistantEngine.NARA || rendererReady) return
        val failed = engine
        engine = when {
            failed == AssistantEngine.VRM && assetsPresent(HIYORI_ASSETS) -> AssistantEngine.HIYORI
            else -> AssistantEngine.NARA
        }
        Log.e(TAG, "$failed renderer failed ($reason); falling back to $engine")
        mainFrameFailed = false
        pageReady = false
        rendererReady = false
        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        loadUrl("$engineUrl?build=$engineBuild&lang=$language&compact=$compactFlag&state=${Uri.encode(pendingState)}")
        armStartupTimeout()
    }

    fun setAssistantState(state: String) {
        if (pendingState == state) return
        pendingState = state
        if (pageReady && rendererReady) applyPendingState()
    }

    private fun applyPendingState() {
        val jsonState = org.json.JSONObject.quote(pendingState)
        evaluateJavascript("window.wapfireSetState && window.wapfireSetState($jsonState);", null)
    }

    private fun blockedResponse(code: Int, reason: String) = WebResourceResponse(
        "text/plain", "UTF-8", code, reason,
        mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )
}

/** One live WebView (and its status text) for either the compact Overview card or the full Nara tab. */
internal class AssistantWebEntry(val view: LivLivWebView, val status: MutableState<String?>)

/**
 * 4.1.54: keeps the Nara WebViews alive while the user moves between tabs.
 * Before, every tab switch destroyed the WebView and the character reloaded from scratch.
 * The cache is owned by ControlCenter, so the views live exactly as long as the signed-in
 * control screens. Each entry is created lazily on its first visit (Overview = compact,
 * Nara tab = full) and is then only detached/attached, never recreated.
 */
internal class AssistantWebViewCache(private val context: Context, val fa: Boolean) {
    private val entries = HashMap<Boolean, AssistantWebEntry>()

    fun entry(compact: Boolean, initialState: String): AssistantWebEntry = entries.getOrPut(compact) {
        val status = mutableStateOf<String?>(if (fa) "در حال آماده‌سازی دستیار…" else "Preparing assistant…")
        AssistantWebEntry(LivLivWebView(context, fa, compact, initialState) { message -> status.value = message }, status)
    }

    fun destroyAll() {
        entries.values.forEach { entry ->
            runCatching {
                val view = entry.view
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.onPause()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        }
        entries.clear()
    }
}

internal val LocalAssistantWebViews = staticCompositionLocalOf<AssistantWebViewCache?> { null }

@Composable
internal fun LivLivAssistantWebView(
    fa: Boolean,
    state: String,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shared = LocalAssistantWebViews.current
    // Without a shared cache (legacy standalone preview) fall back to a private one that is
    // destroyed together with this composable, exactly like the old behaviour.
    val ownCache = remember(context, fa, shared == null) {
        if (shared == null) AssistantWebViewCache(context, fa) else null
    }
    DisposableEffect(ownCache) {
        onDispose { ownCache?.destroyAll() }
    }
    val cache = shared ?: ownCache!!
    val entry = remember(cache, compact) { cache.entry(compact, state) }
    val view = entry.view
    val container = remember(context) { FrameLayout(context) }

    // Attach the long-lived WebView to this screen's container; detach (not destroy) on leave.
    DisposableEffect(container, view) {
        (view.parent as? ViewGroup)?.removeView(view)
        container.addView(
            view,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        view.onResume()
        onDispose {
            // Another screen may already have taken the view over; only release it if it is still ours.
            if (view.parent === container) {
                container.removeView(view)
                view.onPause()
            }
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { container },
            update = { view.setAssistantState(state) },
            modifier = Modifier.fillMaxSize()
        )
        // Status/diagnostic text must never cover the whole WebView: the old full-size opaque
        // overlay hid the character and could obstruct touches while the assistant was starting.
        entry.status.value?.let { message ->
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xE6071629))
                    .border(1.dp, Color(0x6636BAFF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 9.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    message,
                    color = Color(0xFFB8D2E8),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2
                )
            }
        }
    }
}

internal fun overviewAssistantMessage(fa: Boolean, state: String): String = when (state) {
    // tx() always takes English first and Persian second. Keeping that order here
    // prevents the Overview speech text from switching to the opposite language.
    "scanning" -> tx(fa, "I am checking the radio activity around your network.", "دارم فعالیت‌های رادیویی اطراف شبکه را بررسی می‌کنم.")
    "connecting" -> tx(fa, "One moment… I am reconnecting to your WAPFire device.", "یک لحظه… دارم دوباره به دستگاه WAPFire وصل می‌شوم.")
    "success" -> tx(fa, "Wonderful! The connection is back and everything is ready.", "عالی شد! اتصال برقرار است و همه‌چیز آماده است.")
    "password_success" -> tx(fa, "The correct Wi-Fi password was confirmed. Nice work!", "رمز صحیح Wi‑Fi تأیید شد. عالیه!")
    "password_warning" -> tx(fa, "That password was not accepted. Please check it before trying again.", "این رمز تأیید نشد؛ قبل از تلاش دوباره آن را بررسی کن.")
    "warning" -> tx(fa, "Careful! I found suspicious activity that needs your attention.", "مراقب باش! فعالیت مشکوکی پیدا کردم که باید بررسی شود.")
    "angry" -> tx(fa, "An attack has been detected. Stay alert!", "یک حمله شناسایی شد؛ هوشیار باش!")
    "offline" -> tx(fa, "I cannot reach your WAPFire device right now.", "فعلاً نمی‌توانم به دستگاه WAPFire دسترسی پیدا کنم.")
    "setup" -> tx(fa, "Let us finish the first setup together.", "بیا راه‌اندازی اولیه را با هم کامل کنیم.")
    else -> tx(fa, "All clear. I am keeping an eye on your network.", "همه‌چیز مرتبه؛ دارم مراقب شبکه‌ات هستم.")
}

@Composable
internal fun LivLivAssistantOverviewCard(
    p: Palette,
    fa: Boolean,
    state: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("WAPFIRE · LIVE ASSISTANT", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
            Text(tx(fa, "Nara is watching your network", "نارا مراقب شبکه‌ات است"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }

        // Keep the preview and the speech card as separate native Compose siblings.
        // This prevents WebView's viewport/footer sizing from leaving a dead band below the bubble.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF071629))
                .border(1.dp, Color(0xFF23608D), RoundedCornerShape(22.dp))
                .padding(6.dp),
            // 4.1.44: tighter separation between the character frame and speech panel.
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    // 4.1.44: larger character frame (was 218dp) so Nara renders bigger.
                    .height(300.dp)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                LivLivAssistantWebView(
                    fa = fa,
                    state = state,
                    compact = true,
                    modifier = Modifier.fillMaxSize()
                )
            }
            CompositionLocalProvider(
                LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xF2061B31))
                        .border(1.dp, Color(0x884BBFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        if (fa) "گفت‌وگو با نارا" else "NARA · WAPFIRE ASSISTANT",
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF72E8FF),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = if (fa) 0.sp else 0.8.sp,
                        textAlign = if (fa) TextAlign.Right else TextAlign.Left,
                        style = TextStyle(textDirection = if (fa) TextDirection.Rtl else TextDirection.Ltr)
                    )
                    Text(
                        overviewAssistantMessage(fa, state),
                        color = Color(0xFFECF7FF),
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 2,
                        textAlign = if (fa) TextAlign.Right else TextAlign.Left,
                        style = TextStyle(textDirection = if (fa) TextDirection.Rtl else TextDirection.Ltr)
                    )
                }
            }
        }
    }
}

