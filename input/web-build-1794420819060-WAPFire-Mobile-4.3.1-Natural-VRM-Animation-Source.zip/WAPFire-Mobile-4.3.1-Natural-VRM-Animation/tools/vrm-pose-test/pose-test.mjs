import assert from 'node:assert/strict';
import { create, POSES, EXPR } from '../../app/src/main/assets/assistant/vrm/vrm-pose.js';

const finiteFrame = (frame) => {
  const values = [
    ...Object.values(frame.expr),
    ...Object.values(frame.rot).flatMap((v) => Object.values(v)),
    ...Object.values(frame.arm).flatMap((v) => Object.values(v)),
    frame.hipsY, frame.shoulders, frame.gaze.yaw, frame.gaze.pitch
  ];
  assert.ok(values.every(Number.isFinite), `non-finite frame in state ${frame.state}`);
  assert.deepEqual(Object.keys(frame.expr).sort(), [...EXPR, 'blink'].sort());
};

// Every state must remain finite through a long-running animation and a slow frame.
for (const state of Object.keys(POSES)) {
  const engine = create(20261111);
  assert.equal(engine.setState(state, 0), state !== 'idle');
  for (let i = 0; i < 60 * 45; i++) finiteFrame(engine.update(i / 60, 1 / 60));
  finiteFrame(engine.update(46, 0.1));
  console.log(`PASS finite output: ${state}`);
}

// Repeated state notifications must not replay the current one-shot gesture.
const first = create(12345);
const second = create(12345);
first.setState('setup', 0);
second.setState('setup', 0);
for (let i = 0; i < 180; i++) {
  const now = i / 60;
  if (i === 42) assert.equal(first.setState('setup', now), false);
  const a = first.update(now, 1 / 60);
  const b = second.update(now, 1 / 60);
  assert.ok(Math.abs(a.arm.R.elbowU - b.arm.R.elbowU) < 1e-12);
  assert.ok(Math.abs(a.rot.head.x - b.rot.head.x) < 1e-12);
}
console.log('PASS duplicate state does not restart gesture');

// Idle movement should have varied, non-identical samples, with no fixed short loop.
const idle = create(987654);
const signatures = new Set();
const samples = [];
const armSamples = [];
for (let i = 0; i < 60 * 40; i += 12) {
  const frame = idle.update(i / 60, 0.2);
  const signature = [frame.rot.head.x, frame.rot.head.y, frame.rot.head.z, frame.rot.chest.z, frame.gaze.yaw]
    .map((n) => n.toFixed(5)).join(',');
  signatures.add(signature);
  samples.push(signature);
  armSamples.push(frame.arm.L.down, frame.arm.R.down);
}
assert.ok(signatures.size > 130, `too few unique idle poses: ${signatures.size}`);
assert.ok(Math.max(...armSamples) - Math.min(...armSamples) > 0.005, 'arms should have subtle weight-shift movement');
for (let i = 0; i + 21 < samples.length; i++) {
  assert.notEqual(samples[i], samples[i + 21], `idle pattern repeated at sample ${i}`);
}
console.log(`PASS organic idle and arm variation: ${signatures.size} unique poses`);

// Gesture waves end, hops settle, and state-specific motion is only one-shot.
for (const [state, end] of [['setup', 3.4], ['password_success', 2], ['password_warning', 2.4], ['success', 2]]) {
  const engine = create(4567);
  engine.setState(state, 0);
  let frame;
  for (let i = 0; i <= end * 60; i++) frame = engine.update(i / 60, 1 / 60);
  if (state === 'setup') assert.ok(Math.abs(frame.arm.R.elbowU) < 0.15, 'wave should settle back to rest');
  if (state === 'success') assert.ok(Math.abs(frame.hipsY) < 0.002, 'hop should settle back to rest');
}
console.log('PASS one-shot gestures settle');

// Different sessions should not reproduce identical random micro-movement.
const x = create(111), y = create(222);
x.update(0, 1 / 60); y.update(0, 1 / 60);
const fx = x.update(1.1, 0.1), fy = y.update(1.1, 0.1);
assert.notEqual(fx.gaze.yaw, fy.gaze.yaw);
console.log('PASS per-session motion variation');
