# WAPFire Mobile 4.3.1 — Natural VRM animation

Nara is the VRoid character, rendered with the local three.js + three-vrm runtime. Version 4.3.1 replaces the fixed repeating idle movement with varied breathing, natural posture and gaze shifts, and short one-shot gestures. The assistant keeps the same framing and state contract. Fallback order: VRM → Hiyori → Nara. See `CHANGELOG-4.3.1.md` and `VALIDATION-4.3.1-ORGANIC-ANIMATION.txt`.
