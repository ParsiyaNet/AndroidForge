# WAPFire Mobile 4.3.1 — Natural VRM animation

- Replaced fixed, repeating head/body sway and eye drift with smooth random waypoints using varied timing, amplitude and natural pauses.
- Added variable breathing cadence and depth, correlated upper-body weight shifts with subtle arm settling, small attention changes and occasional quick eye saccades.
- Kept movement state-aware: idle remains calm; scanning uses irregular look directions; emotional states keep their distinct base poses with reduced ambient movement.
- Made nod, disagreement, startle, success bounce and greeting gestures short, eased one-shot actions rather than visibly repetitive loops.
- Added per-session animation seeds and small per-gesture timing/amplitude variations, so separate launches and greetings do not look identical.
- Duplicate notifications for the current state no longer reset its gesture timer.
- Reduced the high-frequency angry-state tremor to a subtle movement.
- Updated the VRM engine marker and Android app version to 4.3.1 (versionCode 105).

Validation: pure pose-engine tests pass under Node.js 22.16.0; see `VALIDATION-4.3.1-ORGANIC-ANIMATION.txt`.

Not verified: physical Android WebView rendering or a release APK build. The result is source-level animation work; final visual tuning should be checked on the target phone/model.
