package io.wapfire.mobile.ui.screens

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import java.io.FileNotFoundException
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.wapfire.mobile.BuildConfig
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx
import androidx.webkit.WebViewAssetLoader

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ASSET_PREFIX = "/assets/"
private const val ASSISTANT_URL = "https://appassets.androidplatform.net/assets/assistant/assistant-live.html"
private const val TAG = "WapFireAssistant"

/**
 * Uses AndroidX WebViewAssetLoader for a real HTTPS origin backed only by APK assets.
 * The asset handler serves ES modules, the LivLiv package and textures without network access.
 * All non-local requests are explicitly rejected by the WebViewClient.
 */
private class AssistantJsBridge(
    private val webView: WebView,
    private val onStatus: (String?) -> Unit,
    private val onReady: () -> Unit
) {
    @JavascriptInterface
    fun reportStatus(message: String?) {
        webView.post { onStatus(message?.take(240)?.ifBlank { null }) }
    }

    @JavascriptInterface
    fun reportReady() {
        webView.post { onReady() }
    }
}

private class LivLivWebView(
    context: Context,
    private val fa: Boolean,
    private val compact: Boolean,
    initialState: String,
    private val onNativeStatus: (String?) -> Unit
) : WebView(context) {
    private var pageReady = false
    private var rendererReady = false
    private var mainFrameFailed = false
    private var navigationGeneration = 0
    private var pendingState: String = initialState
    private val assetLoader = WebViewAssetLoader.Builder()
        .setDomain(ASSET_HOST)
        .addPathHandler(ASSET_PREFIX, object : WebViewAssetLoader.PathHandler {
            override fun handle(path: String): WebResourceResponse? {
                // Serve APK assets with explicit MIME types. ES modules require a JavaScript MIME type.
                val clean = Uri.decode(path).removePrefix("/")
                if (clean.isBlank() || clean.startsWith("/") || clean.contains('\\') ||
                    clean.split('/').any { it == ".." || it == "." }) return null
                val extension = clean.substringAfterLast('.', "").lowercase()
                val mime = when (extension) {
                    "html", "htm" -> "text/html"
                    "js", "mjs" -> "text/javascript"
                    "css" -> "text/css"
                    "json" -> "application/json"
                    "webp" -> "image/webp"
                    "png" -> "image/png"
                    "jpg", "jpeg" -> "image/jpeg"
                    "svg" -> "image/svg+xml"
                    "livliv", "zip", "bin" -> "application/octet-stream"
                    else -> "application/octet-stream"
                }
                val encoding = if (mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript") || mime.contains("svg")) "UTF-8" else null
                return try {
                    val stream = context.assets.open(clean)
                    WebResourceResponse(
                        mime, encoding, 200, "OK",
                        mapOf(
                            "Cache-Control" to "no-store",
                            "X-Content-Type-Options" to "nosniff",
                            "Access-Control-Allow-Origin" to "https://$ASSET_HOST"
                        ),
                        stream
                    )
                } catch (_: FileNotFoundException) {
                    null
                } catch (error: Exception) {
                    Log.e(TAG, "Asset open failed: $clean", error)
                    null
                }
            }
        })
        .build()

    init {
        setBackgroundColor(AndroidColor.rgb(7, 22, 41))
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            databaseEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // The document is loaded from APK assets with loadDataWithBaseURL. AssetLoader
            // serves every ES module/model/texture request from the same virtual HTTPS origin.
            // Other hosts are rejected by shouldInterceptRequest below.
            blockNetworkLoads = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
        }
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        addJavascriptInterface(
            AssistantJsBridge(
                this,
                onStatus = { message -> onNativeStatus(message) },
                onReady = {
                    rendererReady = true
                    onNativeStatus(null)
                    Log.i(TAG, "LivLiv renderer reported READY")
                }
            ),
            "WapFireNative"
        )

        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = when (message.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> Log.ERROR
                    ConsoleMessage.MessageLevel.WARNING -> Log.WARN
                    else -> Log.DEBUG
                }
                val details = "JS ${message.message()} (${message.sourceId()}:${message.lineNumber()})"
                Log.println(level, TAG, details)
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR && !rendererReady) {
                    post { onNativeStatus(if (fa) "خطای موتور دستیار: ${message.message().take(180)}" else "Assistant engine error: ${message.message().take(180)}") }
                }
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!rendererReady && newProgress in 1..99) {
                    onNativeStatus(if (fa) "در حال بازکردن دستیار آفلاین… $newProgress٪" else "Opening offline assistant… $newProgress%")
                }
            }
        }

        webViewClient = object : WebViewClient() {
            private fun isLocal(uri: Uri): Boolean =
                uri.scheme == "https" && uri.host == ASSET_HOST && (uri.port == -1 || uri.port == 443)

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (!isLocal(uri)) {
                    Log.w(TAG, "Blocked non-local request: $uri")
                    return blockedResponse(403, "External resource blocked")
                }
                if (uri.path?.startsWith(ASSET_PREFIX) != true) {
                    Log.w(TAG, "Blocked path outside packaged assets: $uri")
                    return blockedResponse(404, "Asset path not found")
                }
                val response = assetLoader.shouldInterceptRequest(uri)
                if (response == null) {
                    val path = uri.path ?: "(unknown)"
                    Log.e(TAG, "APK asset missing: $path")
                    post { if (!rendererReady) onNativeStatus(if (fa) "فایل دستیار داخل APK پیدا نشد: $path" else "Assistant APK asset missing: $path") }
                    return blockedResponse(404, "Packaged asset not found: $path")
                }
                Log.v(TAG, "Served local asset: ${uri.path} (${response.mimeType})")
                return response
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return !isLocal(uri) || uri.path?.startsWith(ASSET_PREFIX) != true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                navigationGeneration++
                pageReady = false
                rendererReady = false
                mainFrameFailed = false
                onNativeStatus(if (fa) "در حال بازکردن صفحهٔ دستیار…" else "Opening assistant document…")
                Log.d(TAG, "Main page started: $url")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                Log.d(TAG, "Main page committed: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                Log.d(TAG, "Main page finished: $url rendererReady=$rendererReady mainFrameFailed=$mainFrameFailed")
                if (!rendererReady && !mainFrameFailed) {
                    onNativeStatus(if (fa) "صفحه باز شد؛ موتور سه‌بعدی در حال راه‌اندازی است…" else "Page loaded; initializing 2.5D renderer…")
                    val generation = navigationGeneration
                    postDelayed({
                        if (generation == navigationGeneration && pageReady && !rendererReady && !mainFrameFailed) {
                            onNativeStatus(if (fa) "موتور اجرا نشد؛ خطای JavaScript یا بارگذاری فایل‌های محلی را بررسی کن." else "Renderer did not start. Check the JavaScript engine and local asset loading.")
                            Log.e(TAG, "Renderer startup timeout")
                        }
                    }, 18000L)
                }
                if (rendererReady) applyPendingState()
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                val details = "WebView error mainFrame=${request?.isForMainFrame} url=${request?.url} code=${error?.errorCode} description=${error?.description}"
                Log.e(TAG, details)
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    onNativeStatus(if (fa) "صفحهٔ دستیار باز نشد (${error?.errorCode}): ${error?.description}" else "Assistant page failed (${error?.errorCode}): ${error?.description}")
                } else if (!rendererReady) {
                    onNativeStatus(if (fa) "خطای فایل محلی: ${error?.description}" else "Local resource error: ${error?.description}")
                }
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, response)
                val details = "WebView HTTP error mainFrame=${request?.isForMainFrame} url=${request?.url} status=${response?.statusCode} reason=${response?.reasonPhrase}"
                Log.e(TAG, details)
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    pageReady = false
                    onNativeStatus(if (fa) "خطای صفحهٔ دستیار: HTTP ${response?.statusCode}" else "Assistant document error: HTTP ${response?.statusCode}")
                } else if (!rendererReady && response?.statusCode in 400..599) {
                    onNativeStatus(if (fa) "فایل دستیار پیدا نشد: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})" else "Assistant file missing: ${request?.url?.lastPathSegment} (HTTP ${response?.statusCode})")
                }
            }
        }

        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        val pageUrl = "$ASSISTANT_URL?lang=$language&compact=$compactFlag&state=${Uri.encode(initialState)}"
        // Load the document through the same HTTPS AssetLoader origin as its ES modules and model.
        // This preserves a real same-origin context for JavaScript modules and fetch().
        Log.i(TAG, "Loading offline assistant from AssetLoader: $pageUrl")
        loadUrl(pageUrl)
        postDelayed({
            if (!rendererReady && pageReady) {
                evaluateJavascript("""(function(){return JSON.stringify({readyState:document.readyState,origin:location.origin,url:location.href,preflight:!!window.__wfPreflightStarted,engine:!!window.__wfEngineBooted,renderer:!!window.__wfRendererReady,userAgent:navigator.userAgent})})()""".trimIndent()) { result ->
                    Log.e(TAG, "Assistant boot probe: $result")
                    if (!rendererReady && !mainFrameFailed) {
                        val detail = if (result == null || result == "null") "JavaScript did not answer the native probe." else result.take(240)
                        onNativeStatus(if (fa) "تشخیص WebView: $detail" else "WebView diagnostic: $detail")
                    }
                }
            }
        }, 6000L)
    }

    fun setAssistantState(state: String) {
        if (pendingState == state) return
        pendingState = state
        if (pageReady && rendererReady) applyPendingState()
    }

    private fun applyPendingState() {
        val jsonState = org.json.JSONObject.quote(pendingState)
        evaluateJavascript("window.wapfireSetState && window.wapfireSetState($jsonState);", null)
    }

    private fun blockedResponse(code: Int, reason: String) = WebResourceResponse(
        "text/plain", "UTF-8", code, reason,
        mapOf("Cache-Control" to "no-store"),
        java.io.ByteArrayInputStream(ByteArray(0))
    )
}

@Composable
internal fun LivLivAssistantWebView(
    fa: Boolean,
    state: String,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val nativeStatus = androidx.compose.runtime.remember(context, fa, compact) {
        androidx.compose.runtime.mutableStateOf<String?>(if (fa) "در حال آماده‌سازی دستیار…" else "Preparing assistant…")
    }
    val view = remember(context, fa, compact) {
        LivLivWebView(context, fa, compact, state) { message -> nativeStatus.value = message }
    }

    DisposableEffect(view) {
        onDispose {
            runCatching {
                view.stopLoading()
                view.onPause()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { view },
            update = { it.setAssistantState(state) },
            modifier = Modifier.fillMaxSize()
        )
        // Status/diagnostic text must never cover the whole WebView: the old full-size opaque
        // overlay hid the character and could obstruct touches while the assistant was starting.
        nativeStatus.value?.let { message ->
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xE6071629))
                    .border(1.dp, Color(0x6636BAFF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 9.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    message,
                    color = Color(0xFFB8D2E8),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
internal fun LivLivAssistantOverviewCard(
    p: Palette,
    fa: Boolean,
    state: String,
    onOpenAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("WAPFIRE · LIVE ASSISTANT", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(tx(fa, "Sena is watching your network", "سنا مراقب شبکه‌ات است"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                tx(fa, "OPEN ↗", "نمایش ↗"),
                color = p.blue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(p.accentSoft.copy(alpha = .7f))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .then(Modifier)
                    .clickable(onClick = onOpenAssistant)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(218.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF071629))
                .border(1.dp, Color(0xFF23608D), RoundedCornerShape(22.dp))
                .padding(1.dp)
        ) {
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = true,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp))
            )
        }
    }
}

