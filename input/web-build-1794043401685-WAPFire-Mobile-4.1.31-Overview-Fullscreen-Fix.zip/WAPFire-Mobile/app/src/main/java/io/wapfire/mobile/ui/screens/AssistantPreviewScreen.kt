package io.wapfire.mobile.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.ui.components.SmallAction
import io.wapfire.mobile.ui.components.ThemeAction
import io.wapfire.mobile.model.tx

@Composable
internal fun AssistantPreviewScreen(
    p: Palette,
    fa: Boolean,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    embedded: Boolean = false,
    state: String = "idle",
    dark: Boolean = true,
    onTheme: (() -> Unit)? = null,
    onLanguage: (() -> Unit)? = null
) {
    if (embedded) {
        // The dashboard Assistant tab is a canvas-first view. Do not wrap it in the
        // Overview card's compact spacing, rounded card, or a weighted content column.
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF071629))
        ) {
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = false,
                modifier = Modifier.fillMaxSize()
            )
            // Keep a clear exit affordance after hiding the normal app toolbar/tab bar.
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xB80A1E33))
                    .border(1.dp, Color(0x8836BAFF), CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Text("×", color = Color(0xFFEAF7FF), fontSize = 25.sp, lineHeight = 26.sp, fontWeight = FontWeight.Light)
            }
            Row(
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onLanguage != null) SmallAction(p, if (fa) "EN" else "FA", onLanguage)
                if (onTheme != null) ThemeAction(p, dark, onTheme)
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .then(Modifier.windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)))
                .background(Color.Transparent)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(p.panelAlt)
                        .border(1.dp, p.border, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("‹", color = p.text, fontSize = 27.sp, lineHeight = 28.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("WAPFIRE · LIVE 2.5D CHARACTER", color = p.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Animated assistant", "دستیار متحرک"), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = false,
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp))
            )
        }
    }
}
