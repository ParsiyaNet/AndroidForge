# نسخهٔ فعلی: WAPFire Mobile 4.3.2 — Nara 3D Offline

برای توضیحات و دستور ساخت نسخهٔ جدید، فایل `README-4.3.2-FA.md` را ببین.
این نسخه بر پایهٔ 4.2.0 Dark Matte Glass است و شخصیت AvatarSample_A را با Three.js و VRM، کاملاً آفلاین هنگام اجرا، مستقیماً در Android WebView نمایش می‌دهد. Unity و قابلیت صوتی شخصیت حذف شده‌اند.
