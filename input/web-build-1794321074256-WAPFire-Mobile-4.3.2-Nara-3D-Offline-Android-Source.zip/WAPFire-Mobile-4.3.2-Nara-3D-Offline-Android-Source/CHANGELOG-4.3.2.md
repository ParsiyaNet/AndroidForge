# WAPFire Mobile 4.3.2 — Nara 3D Offline (No Unity)

- Replaced the Live2D/Hiyori assistant renderer with the real AvatarSample_A VRM 3D character.
- Added Three.js r180, `@pixiv/three-vrm` 3.5.5 and `@pixiv/three-vrm-animation` 3.5.5; modules are vendored into APK assets by a Gradle task.
- Added eight real VRMA skeletal animations with immutable source pinning and Git blob SHA-1 verification.
- Added humanoid animation mixer, soft motion transitions, state-based expressions, natural blinking, touch blush reaction, and spring-bone simulation.
- Optimized large model textures to 2048 × 2048 while preserving the rig, meshes, expressions and spring bones.
- Kept WebView assets local-only and blocked external page requests; no runtime downloads are needed.
- Removed assistant TTS/voice implementation and speaker controls. No voice or audio subsystem is used by Nara.
- Preserved Android Compose state controls and retained WebView instances during tab switching.
- Updated character attribution and MIT license notices.
- Android versionCode/versionName: 105 / 4.3.2.
