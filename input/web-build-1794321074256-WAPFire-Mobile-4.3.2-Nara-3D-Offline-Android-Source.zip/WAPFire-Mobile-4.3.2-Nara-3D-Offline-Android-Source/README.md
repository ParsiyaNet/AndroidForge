# WAPFire Mobile 4.3.2 — Nara 3D Offline (Android, no Unity)

This build is based on **WAPFire Mobile 4.2.0 — Dark Matte Glass**. The assistant character is now a real 3D VRM avatar rendered directly inside the Android app with WebGL2. There is no Unity project, Unity runtime, separate Unity export, text-to-speech, speech recognition, voice playback, or in-app audio control.

## Character and renderer

- Character: **AvatarSample_A** (VRM 0.x), with its humanoid rig, facial expressions, and spring-bone setup retained.
- Mobile model: four large textures are downscaled to 2048 × 2048; the model still contains its meshes, humanoid bones, expressions, and spring bones.
- Renderer: Three.js r180 + `@pixiv/three-vrm` 3.5.5 + `@pixiv/three-vrm-animation` 3.5.5.
- Motion pack: eight real VRMA skeletal clips — Angry, Blush, Clapping, LookAround, Relax, Sad, Surprised, and Thinking.
- Character states: idle, scanning, connecting, success, password success/warning, warning, attack, offline, and setup.
- Motion blending, natural blink timing, state-based facial expressions, touch reaction, and VRM spring-bone updates are handled locally.
- The existing Assistant and Overview screens retain the native Compose integration. The WebView is cached during tab switches to avoid repeatedly loading the character.

## Offline behavior

The build task vendors the pinned Three.js/VRM modules and downloads the eight pinned VRMA files **while building**. Every VRMA file is checked against its expected Git blob SHA-1. These files are packaged into the app's `assets` directory. After installation, the character, textures, renderer, and animations are read from the APK through AndroidX WebViewAssetLoader. External WebView requests are blocked. No runtime model, script, animation, or voice download is performed.

The first build needs internet access to fetch the pinned renderer modules and motion clips. Once those files exist in `app/src/main/assets/assistant/vendor` and `app/src/main/assets/assistant/motions`, the same build can be repeated without re-fetching valid files.

## Build

1. Open this folder in Android Studio (or use the included `gradlew.bat` on Windows).
2. Allow the first build to download the pinned renderer libraries and VRMA motion pack.
3. Build the debug APK with:

   ```powershell
   .\gradlew.bat :app:assembleDebug
   ```

   On Linux/macOS:

   ```bash
   ./gradlew :app:assembleDebug
   ```

4. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The build uses Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.3.0, compile/target SDK 35, and minimum SDK 29. The character renderer needs an Android System WebView with WebGL2 support and hardware acceleration enabled.

## Verification status

Source-level checks are recorded in `VALIDATION-4.3.2.txt`. This source package was not compiled into an APK or tested on a physical phone in the preparation environment. A successful Gradle build and device-side visual/performance test are therefore still required before treating the release as device-verified.

## Licensing

See `app/src/main/assets/assistant/VRM-MODEL-ATTRIBUTION.txt`, `VRMA-LICENSE-MIT.txt`, and the generated vendor license files. The model's embedded VRoid Hub permission profile is preserved. The renderer libraries and motion pack carry MIT notices.
