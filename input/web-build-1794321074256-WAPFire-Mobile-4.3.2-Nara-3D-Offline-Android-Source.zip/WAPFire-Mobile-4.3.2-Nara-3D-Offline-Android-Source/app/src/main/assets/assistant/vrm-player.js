import * as THREE from './vendor/three.module.js';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from './vendor/three-vrm.module.min.js';
import {
  createVRMAnimationClip,
  VRMAnimationLoaderPlugin,
  VRMLookAtQuaternionProxy,
} from './vendor/three-vrm-animation.module.js';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const MOTIONS = ['Angry', 'Blush', 'Clapping', 'LookAround', 'Relax', 'Sad', 'Surprised', 'Thinking'];
const STATE_MOTION = {
  idle: ['Relax', true, -1, null],
  scanning: ['LookAround', true, -1, null],
  connecting: ['Thinking', true, -1, 'relaxed'],
  success: ['Clapping', false, 2.0, 'happy'],
  password_success: ['Clapping', false, 2.0, 'happy'],
  password_warning: ['Surprised', false, -1, 'surprised'],
  warning: ['Surprised', false, -1, 'surprised'],
  angry: ['Angry', false, 3.6, 'angry'],
  offline: ['Sad', true, -1, 'sad'],
  setup: ['Thinking', true, -1, 'relaxed'],
};

/** Offline VRM 0.x renderer with real VRMA skeletal animations (no audio subsystem). */
export class Player {
  constructor(canvas, options = {}) {
    if (!(canvas instanceof HTMLCanvasElement)) throw new TypeError('Nara 3D requires a canvas element.');
    this.canvas = canvas;
    this.options = options;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
      premultipliedAlpha: true,
      depth: true,
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setClearColor(0x000000, 0);
    this.maxAnisotropy = Math.min(this.renderer.capabilities.getMaxAnisotropy(), 8);
    this.pixelRatio = Math.min(options.maxPixelRatio || window.devicePixelRatio || 1, 1.5);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(28, 1, 0.01, 100);
    this.camera.position.set(0, 1, 3);
    this.scene.add(new THREE.HemisphereLight(0xd6eaff, 0x26364b, 1.7));
    const key = new THREE.DirectionalLight(0xfff4ea, 2.25);
    key.position.set(-2.6, 4.5, 4.0);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x83cfff, 0.88);
    fill.position.set(3.2, 2.3, -2.0);
    this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xa5caff, 0.48);
    rim.position.set(-1.5, 2.6, -3.5);
    this.scene.add(rim);

    this.model = { name: 'AvatarSample_A' };
    this.vrm = null;
    this.mixer = null;
    this.clips = new Map();
    this.actions = new Map();
    this.activeAction = null;
    this.touchAction = null;
    this.state = 'idle';
    this.stateBeforeTouch = 'idle';
    this.pendingReturnDelay = -1;
    this.returnAt = -1;
    this.touchReturnAt = -1;
    this.emotion = null;
    this.away = false;
    this.view = { x: 0, y: -0.025, zoom: 1 };
    this.puppet = { model: { canvas: [1024, 1536] }, zoom: 1, panY: 0 };
    this.bounds = new THREE.Box3();
    this.center = new THREE.Vector3(0, 0.8, 0);
    this.dimensions = new THREE.Vector3(0.6, 1.6, 0.4);
    this.lookTarget = new THREE.Object3D();
    this.scene.add(this.lookTarget);
    this.look = { x: 0, y: 0 };
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();

    this.clock = 0;
    this.nextBlinkAt = 2.4 + Math.random() * 2.5;
    this.blinkStarted = -10;
    this.raf = 0;
    this.lastFrame = 0;
    this.disposed = false;
    this.visible = true;
    this.onContextLost = null;
    this._onContextLost = (event) => {
      event.preventDefault();
      this.pause();
      this.onContextLost?.();
    };
    this._onVisibility = () => {
      this.visible = document.visibilityState !== 'hidden';
      if (this.visible && options.autoplay !== false) this.play();
    };
    this._onPointerDown = (event) => {
      if (!this.vrm || !event || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return;
      const rect = this.canvas.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      this.pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -(((event.clientY - rect.top) / rect.height) * 2 - 1));
      this.raycaster.setFromCamera(this.pointer, this.camera);
      const hits = this.raycaster.intersectObject(this.vrm.scene, true);
      if (hits.length) this.triggerTouch();
    };
    canvas.addEventListener('webglcontextlost', this._onContextLost, false);
    canvas.addEventListener('pointerdown', this._onPointerDown, { passive: true });
    document.addEventListener('visibilitychange', this._onVisibility);
    this.resize();
    if (options.autoplay !== false) this.play();
  }

  _createLoader() {
    const loader = new GLTFLoader();
    loader.crossOrigin = 'anonymous';
    loader.register((parser) => new VRMLoaderPlugin(parser));
    loader.register((parser) => new VRMAnimationLoaderPlugin(parser));
    return loader;
  }

  async load(url, { onProgress } = {}) {
    if (this.disposed) throw new Error('Renderer disposed before character load.');
    const loader = this._createLoader();
    const gltf = await loader.loadAsync(url, (event) => {
      if (typeof onProgress === 'function' && event.total > 0) {
        onProgress({ step: 'model', progress: clamp(event.loaded / event.total, 0, 1) });
      }
    });
    const vrm = gltf?.userData?.vrm;
    if (!vrm?.scene || !vrm?.humanoid) throw new Error('AvatarSample_A did not contain a valid VRM humanoid rig.');
    this.vrm = vrm;
    VRMUtils.rotateVRM0(vrm);
    try { VRMUtils.combineSkeletons(vrm.scene); }
    catch (error) { console.warn('Optional skeleton optimization skipped:', error); }
    vrm.scene.traverse((object) => {
      object.frustumCulled = false;
      const materials = Array.isArray(object.material) ? object.material : (object.material ? [object.material] : []);
      for (const material of materials) {
        for (const value of Object.values(material)) {
          if (value?.isTexture) {
            value.anisotropy = this.maxAnisotropy;
            value.needsUpdate = true;
          }
        }
      }
    });
    this.scene.add(vrm.scene);
    vrm.scene.updateMatrixWorld(true);
    this.bounds.setFromObject(vrm.scene);
    if (this.bounds.isEmpty()) throw new Error('AvatarSample_A contains no visible mesh geometry.');
    this.bounds.getCenter(this.center);
    this.bounds.getSize(this.dimensions);
    if (!Number.isFinite(this.dimensions.y) || this.dimensions.y < 0.2) throw new Error('Avatar model dimensions are invalid.');

    this.model = {
      name: vrm.meta?.name || vrm.meta?.title || 'AvatarSample_A',
      format: `VRM ${vrm.meta?.metaVersion || '0.x'}`,
      expressions: vrm.expressionManager?.expressions?.map((item) => item.expressionName) || [],
    };
    if (vrm.lookAt) {
      let proxy = vrm.scene.children.find((object) => object instanceof VRMLookAtQuaternionProxy);
      if (!proxy) {
        proxy = new VRMLookAtQuaternionProxy(vrm.lookAt);
        proxy.name = 'VRMLookAtQuaternionProxy';
        vrm.scene.add(proxy);
      } else if (!proxy.name) {
        proxy.name = 'VRMLookAtQuaternionProxy';
      }
      vrm.lookAt.target = this.lookTarget;
      vrm.lookAt.autoUpdate = true;
    }
    this.mixer = new THREE.AnimationMixer(vrm.scene);
    this.mixer.addEventListener('finished', (event) => this._onMotionFinished(event));
    this.lookAt(null, 0);
    this._updateCamera();
    this.resize();
    if (typeof onProgress === 'function') onProgress({ step: 'model', progress: 1 });
    return this;
  }

  async loadMotions(basePath = './motions/', { onProgress } = {}) {
    if (!this.vrm || !this.mixer) throw new Error('Load the VRM character before its motion pack.');
    const loader = this._createLoader();
    const loaded = await Promise.all(MOTIONS.map(async (name, index) => {
      const gltf = await loader.loadAsync(`${basePath}${name}.vrma`);
      const animation = gltf?.userData?.vrmAnimations?.[0];
      if (!animation) throw new Error(`${name}.vrma loaded but contains no VRM Animation extension.`);
      const clip = createVRMAnimationClip(animation, this.vrm);
      if (!clip || !clip.tracks?.length || !(clip.duration > 0)) throw new Error(`${name}.vrma produced an empty animation clip.`);
      clip.name = name;
      this.clips.set(name, clip);
      if (typeof onProgress === 'function') onProgress({ step: 'motions', progress: (index + 1) / MOTIONS.length, name });
      return name;
    }));
    if (loaded.length !== MOTIONS.length) throw new Error('VRMA motion pack is incomplete.');
    this.setState(this.state, true);
    return loaded;
  }

  _expressionExists(name) {
    return !!this.vrm?.expressionManager?.getExpression?.(name);
  }

  _setExpression(name, value) {
    const manager = this.vrm?.expressionManager;
    if (!manager || !this._expressionExists(name)) return;
    manager.setValue(name, clamp(value, 0, 1));
  }

  setExpression(expression) {
    this.emotion = expression == null ? null : String(expression);
    this._applyStateExpression();
  }

  setAway(value) { this.away = !!value; }

  _applyStateExpression() {
    if (!this.vrm?.expressionManager) return;
    const stateOverlay = {
      idle: ['relaxed', 0.16],
      scanning: ['relaxed', 0.16],
      connecting: ['relaxed', 0.12],
      success: ['happy', 0.55],
      password_success: ['happy', 0.55],
      password_warning: ['surprised', 0.30],
      warning: ['surprised', 0.30],
      angry: ['angry', 0.72],
      offline: ['sad', 0.38],
      setup: ['relaxed', 0.16],
    }[this.state];
    const overlayNames = ['happy', 'angry', 'sad', 'surprised', 'relaxed', 'Surprised', 'blink'];
    for (const name of overlayNames) this._setExpression(name, 0);
    if (stateOverlay) {
      const [name, weight] = stateOverlay;
      if (name === 'surprised' && !this._expressionExists('surprised') && this._expressionExists('Surprised')) {
        this._setExpression('Surprised', weight);
      } else this._setExpression(name, weight);
    }
    if (this.emotion && !stateOverlay) {
      const map = { smile: 'happy', shy: 'relaxed', happy: 'happy', sad: 'sad', angry: 'angry', surprised: 'surprised' };
      const name = map[this.emotion] || this.emotion;
      this._setExpression(name, 0.42);
    }
  }

  _playMotion(name, loop, returnDelay = -1, isTouch = false) {
    if (!this.mixer) return false;
    const clip = this.clips.get(name);
    if (!clip) throw new Error(`Required VRMA motion is missing: ${name}`);
    const next = this.mixer.clipAction(clip);
    const previous = this.activeAction;
    if (previous === next) previous.stop();
    next.reset();
    next.enabled = true;
    next.setEffectiveTimeScale(1);
    next.setEffectiveWeight(1);
    next.setLoop(loop ? THREE.LoopRepeat : THREE.LoopOnce, loop ? Infinity : 1);
    next.clampWhenFinished = !loop;
    if (previous && previous !== next) previous.crossFadeTo(next, 0.34, false);
    else next.fadeIn(0.34);
    next.play();
    this.activeAction = next;
    this.pendingReturnDelay = returnDelay;
    this.returnAt = -1;
    this.touchAction = isTouch ? next : null;
    return true;
  }

  _onMotionFinished(event) {
    if (event.action === this.touchAction) {
      this.touchAction = null;
      this.touchReturnAt = this.clock + 0.12;
      return;
    }
    if (event.action !== this.activeAction) return;
    if (this.pendingReturnDelay >= 0) this.returnAt = this.clock + this.pendingReturnDelay;
  }

  setState(value, force = false) {
    const nextState = Object.prototype.hasOwnProperty.call(STATE_MOTION, String(value || '').toLowerCase()) ? String(value).toLowerCase() : 'idle';
    if (!force && nextState === this.state && this.activeAction) return;
    this.state = nextState;
    this.touchAction = null;
    this.touchReturnAt = -1;
    this.returnAt = -1;
    const [motion, loop, returnDelay, emotion] = STATE_MOTION[nextState];
    this.emotion = emotion;
    this._playMotion(motion, loop, returnDelay, false);
    this._applyStateExpression();
  }

  triggerTouch() {
    if (!this.vrm || !this.clips.has('Blush') || this.touchAction) return false;
    this.stateBeforeTouch = this.state;
    this.touchReturnAt = -1;
    this._playMotion('Blush', false, -1, true);
    this._applyStateExpression();
    return true;
  }

  lookAt(x, y = 0) {
    this.look = x == null ? { x: 0, y: 0 } : { x: clamp(Number(x) || 0, -1, 1), y: clamp(Number(y) || 0, -1, 1) };
    const headY = this.bounds.isEmpty() ? 1.35 : this.bounds.min.y + this.dimensions.y * 0.83;
    const headX = this.center.x + this.look.x * this.dimensions.x * 0.9;
    this.lookTarget.position.set(headX, headY + this.look.y * this.dimensions.y * 0.22, this.center.z + Math.max(this.dimensions.y * 2.5, 2.5));
  }

  blink() { this.blinkStarted = this.clock; }

  _updateCamera() {
    if (!this.vrm || this.bounds.isEmpty()) return;
    const aspect = Math.max(0.25, this.canvas.clientWidth / Math.max(1, this.canvas.clientHeight));
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov / 2);
    const heightDistance = this.dimensions.y / (2 * Math.tan(halfFov));
    const widthDistance = this.dimensions.x / (2 * Math.tan(halfFov) * aspect);
    const distance = Math.max(heightDistance, widthDistance, 1.0) * 1.10 / clamp(this.view.zoom || 1, 0.75, 1.25);
    const targetY = this.center.y - (this.view.y || 0) * this.dimensions.y;
    const targetX = this.center.x + (this.view.x || 0) * this.dimensions.x;
    this.camera.position.set(targetX, targetY, this.center.z + distance);
    this.camera.lookAt(targetX, targetY, this.center.z);
    this.camera.near = Math.max(0.01, distance / 100);
    this.camera.far = distance + this.dimensions.y * 5 + 10;
    this.camera.updateProjectionMatrix();
  }

  resize() {
    if (this.disposed) return;
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.max(1, this.canvas.clientWidth || rect.width || 1);
    const height = Math.max(1, this.canvas.clientHeight || rect.height || 1);
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(width, height, false);
    this._updateCamera();
    this._renderOnce();
  }

  _update(delta) {
    if (!this.vrm) return;
    this.clock += delta;
    if (this.mixer) this.mixer.update(delta);
    if (this.clock >= this.nextBlinkAt) {
      this.blinkStarted = this.clock;
      this.nextBlinkAt = this.clock + 2.4 + Math.random() * 2.6;
    }
    const blinkAge = this.clock - this.blinkStarted;
    const blinkWeight = blinkAge >= 0 && blinkAge < 0.17 ? Math.sin((blinkAge / 0.17) * Math.PI) : 0;
    this._setExpression('blink', this.away ? Math.max(blinkWeight, 0.65) : blinkWeight);
    this.vrm.update(delta);
    if (this.touchReturnAt >= 0 && this.clock >= this.touchReturnAt) {
      this.touchReturnAt = -1;
      this.setState(this.stateBeforeTouch, true);
    }
    if (this.returnAt >= 0 && this.clock >= this.returnAt && this.state !== 'idle') {
      this.returnAt = -1;
      this.setState('idle', true);
    }
  }

  _renderOnce() {
    if (this.disposed || !this.renderer || !this.visible) return;
    this.renderer.render(this.scene, this.camera);
  }

  _frame = (timestamp) => {
    if (!this.raf || this.disposed) return;
    const rawDelta = this.lastFrame ? (timestamp - this.lastFrame) / 1000 : 1 / 30;
    this.lastFrame = timestamp;
    const delta = clamp(rawDelta, 0, 1 / 20);
    if (this.visible) {
      this._update(delta);
      this.renderer.render(this.scene, this.camera);
    }
    this.raf = requestAnimationFrame(this._frame);
  };

  play() {
    if (this.disposed || this.raf) return;
    this.lastFrame = 0;
    this.raf = requestAnimationFrame(this._frame);
  }

  pause() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.lastFrame = 0;
  }

  dispose() {
    if (this.disposed) return;
    this.pause();
    this.disposed = true;
    this.canvas.removeEventListener('webglcontextlost', this._onContextLost, false);
    this.canvas.removeEventListener('pointerdown', this._onPointerDown, false);
    document.removeEventListener('visibilitychange', this._onVisibility);
    if (this.vrm?.scene) {
      this.scene.remove(this.vrm.scene);
      try { VRMUtils.deepDispose(this.vrm.scene); } catch (_) { /* best effort GPU cleanup */ }
    }
    this.renderer.dispose();
    this.clips.clear();
    this.actions.clear();
    this.vrm = null;
    this.mixer = null;
  }
}
