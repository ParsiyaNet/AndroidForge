(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const language = fa ? 'fa' : 'en';
  const $ = (id) => document.getElementById(id);
  const native = () => window.WapFireNative;
  const report = (message) => {
    try { native()?.reportStatus(message == null ? null : String(message).slice(0, 220)); }
    catch (e) { console.error('WAPFire native status bridge unavailable', e); }
  };
  const text = (faText, enText) => fa ? faText : enText;

  window.__wfPreflightStarted = true;
  document.documentElement.lang = language;
  document.documentElement.dir = fa ? 'rtl' : 'ltr';
  document.body.classList.toggle('compact', q.get('compact') !== '0');
  window.__wfInitialState = q.get('state') || 'idle';
  window.__wfPendingState = window.__wfInitialState;
  window.__wfLanguage = language;

  window.wapfireSetState = (state) => {
    window.__wfPendingState = String(state || 'idle');
    if (typeof window.__wfApplyState === 'function') window.__wfApplyState(window.__wfPendingState);
  };
  window.wapfireSetLanguage = (nextLanguage) => {
    const next = nextLanguage === 'en' ? 'en' : 'fa';
    if (next !== language) {
      location.search = `?compact=${document.body.classList.contains('compact') ? '1' : '0'}&lang=${next}&state=${encodeURIComponent(window.__wfPendingState || 'idle')}`;
    }
  };

  window.addEventListener('error', (event) => {
    const detail = event.message || event.target?.src || event.target?.href || 'Unknown script/resource error';
    report(text('خطای JavaScript/Asset: ', 'JavaScript/asset error: ') + String(detail).slice(0, 180));
  }, true);
  window.addEventListener('unhandledrejection', (event) => {
    const detail = event.reason?.message || String(event.reason || 'Unhandled promise rejection');
    report(text('خطای اجرای دستیار: ', 'Assistant runtime error: ') + detail.slice(0, 180));
  });

  const labels = {
    idle: {en:['All clear. I am keeping an eye on your network.','Ready'],fa:['همه‌چیز مرتبه؛ دارم مراقب شبکه‌ات هستم.','آماده‌به‌کار'],expr:null,action:null},
    scanning:{en:['I am checking the radio activity around your network.','Monitoring'],fa:['دارم فعالیت‌های رادیویی اطراف شبکه را بررسی می‌کنم.','در حال پایش'],expr:null,action:'tilt'},
    connecting:{en:['One moment… I am reconnecting to your WAPFire device.','Connecting'],fa:['یک لحظه… دارم دوباره به دستگاه WAPFire وصل می‌شوم.','در حال اتصال'],expr:'shy',action:'nod'},
    success:{en:['Wonderful! The connection is back and everything is ready.','Connected'],fa:['عالی شد! اتصال برقرار است و همه‌چیز آماده است.','متصل شد'],expr:'smile',action:'hop'},
    warning:{en:['Careful! I found suspicious activity that needs your attention.','Threat detected'],fa:['مراقب باش! فعالیت مشکوکی پیدا کردم که باید بررسی شود.','تهدید شناسایی شد'],expr:'angry',action:'shake'},
    offline:{en:['I cannot reach your WAPFire device right now.','Device offline'],fa:['فعلاً نمی‌توانم به دستگاه WAPFire دسترسی پیدا کنم.','دستگاه در دسترس نیست'],expr:'sad',action:'tilt'},
    setup:{en:['Let us finish the first setup together.','Setup required'],fa:['بیا راه‌اندازی اولیه را با هم کامل کنیم.','نیازمند راه‌اندازی'],expr:'shy',action:'tilt'}
  };

  let player = null;
  let activeState = '';
  let ready = false;
  let pendingState = window.__wfPendingState;
  let stageObserver = null;
  let resizeRaf = 0;

  function showState(name, force=false) {
    const state = labels[name] ? name : 'idle';
    pendingState = state;
    window.__wfPendingState = state;
    if (!ready || !player || (!force && activeState === state)) return;
    activeState = state;
    const row = labels[state];
    const copy = fa ? row.fa : row.en;
    $('shell').dataset.state = state;
    $('speechText').textContent = copy[0];
    $('stateText').textContent = copy[1];
    $('dot').style.color = state === 'warning' ? 'var(--red)' : state === 'success' ? 'var(--green)' : state === 'offline' ? 'var(--amber)' : 'var(--blue)';
    for (const button of document.querySelectorAll('[data-state]')) button.classList.toggle('active',button.dataset.state === state);
    player.setAway(false);
    player.setExpression(row.expr);
    player.lookAt(state === 'scanning' ? -0.4 : state === 'warning' ? 0.25 : null, state === 'scanning' ? 0.18 : 0);
    if (row.action) player.act(row.action);
    if (state === 'success') player.blink();
  }
  window.__wfApplyState = (state) => showState(String(state));
  for (const button of document.querySelectorAll('[data-state]')) button.addEventListener('click', () => showState(button.dataset.state, true));

  async function probeAsset(path) {
    try {
      const response = await fetch(path, {cache:'no-store'});
      const type = response.headers.get('content-type') || '(no content-type)';
      const bytes = await response.arrayBuffer();
      return `${path}: HTTP ${response.status}, ${type}, ${bytes.byteLength} bytes`;
    } catch (error) {
      return `${path}: FETCH FAILED (${error?.message || error})`;
    }
  }

  async function diagnose(error, phase) {
    const probes = await Promise.all([
      probeAsset('./dist/index.js'),
      probeAsset('./dist/chunks/base-p0Sx5Qp5.js'),
      probeAsset('./characters/k01.livliv')
    ]);
    const detail = `${phase}: ${error?.message || error}; ${probes.join(' | ')}`;
    console.error('WAPFire LivLiv diagnostic:', detail);
    $('loading').classList.add('error');
    $('loading').textContent = text('خطای موتور: ', 'Renderer error: ') + detail.slice(0, 320);
    report(detail);
  }

  const nextFrame = () => new Promise(resolve => requestAnimationFrame(() => resolve()));

  async function waitForCanvasLayout(canvas) {
    // Compose's WebView is hosted inside a LazyColumn item. Some Android WebView builds resolve
    // percentage heights to zero on the first layout pass even though the native View is measured.
    // Give the HTML stage its own minimum block size, then let the normal parent size take over.
    const compactMode = q.get('compact') !== '0';
    const fallbackHeight = compactMode ? 200 : Math.max(320, Math.min(window.innerHeight || 480, 1200));
    const shell = $('shell');
    const stage = canvas.parentElement;
    for (const element of [document.documentElement, document.body, shell, stage]) {
      if (element && element.getBoundingClientRect().height < 32) {
        element.style.minHeight = `${fallbackHeight}px`;
      }
    }
    canvas.style.minHeight = `${fallbackHeight}px`;
    canvas.style.width = '100%';
    canvas.style.height = '100%';

    // Allow Compose/WebView and Chromium to complete their layout before creating WebGL.
    for (let i = 0; i < 24; i++) {
      await nextFrame();
      const r = canvas.getBoundingClientRect();
      if (r.width >= 32 && r.height >= 32) return r;
    }
    const r = canvas.getBoundingClientRect();
    const shellRect = shell.getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    throw new Error(`Canvas layout failed (canvas ${Math.round(r.width)}x${Math.round(r.height)}, stage ${Math.round(stageRect.width)}x${Math.round(stageRect.height)}, shell ${Math.round(shellRect.width)}x${Math.round(shellRect.height)}).`);
  }

  function verifyFirstFrame(canvas, player) {
    const gl = canvas.getContext('webgl2');
    if (!gl || gl.isContextLost()) throw new Error('WebGL2 context was lost before the first frame.');
    // Force the renderer to draw synchronously after the model is installed. LivLiv normally starts
    // requestAnimationFrame in its constructor; in WebView we deliberately start paused and draw once
    // with the final measured canvas dimensions.
    player.resize();
    gl.finish();
    const w = canvas.width, h = canvas.height;
    if (w < 32 || h < 32) throw new Error(`WebGL drawing buffer is too small (${w}x${h}).`);
    const pixels = new Uint8Array(w * h * 4);
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const glError = gl.getError();
    // Ignore the corner watermark: count only the central character area, so a lone logo
    // cannot be mistaken for a successfully rendered avatar.
    let visiblePixels = 0;
    const x0 = Math.floor(w * 0.10), x1 = Math.ceil(w * 0.90);
    const y0 = Math.floor(h * 0.08), y1 = Math.ceil(h * 0.92);
    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) if (pixels[(y * w + x) * 4 + 3] > 12) visiblePixels++;
    }
    const centralArea = (x1 - x0) * (y1 - y0);
    const threshold = Math.max(350, Math.floor(centralArea * 0.005));
    const result = {width:w,height:h,visiblePixels,threshold,glError};
    console.info('WAPFire first-frame verification:', JSON.stringify(result));
    report(`First frame check: ${w}x${h}, alpha pixels ${visiblePixels}/${threshold}, GL error ${glError}`);
    if (glError !== gl.NO_ERROR) throw new Error(`WebGL draw error 0x${glError.toString(16)} after first frame.`);
    if (visiblePixels < threshold) throw new Error(`Model loaded but first frame is blank (${visiblePixels} visible pixels at ${w}x${h}).`);
    return result;
  }

  async function boot(Player) {
    window.__wfEngineBooted = true;
    report(text('ماژول LivLiv بارگذاری شد؛ در حال آماده‌سازی Canvas…', 'LivLiv module loaded; preparing canvas…'));
    const compactMode = q.get('compact') !== '0';
    document.body.classList.toggle('compact', compactMode);
    document.body.classList.toggle('full', !compactMode);
    const loading = $('loading');
    try {
      const canvas = $('stage');
      const rect = await waitForCanvasLayout(canvas);
      const ratio = Math.min(window.devicePixelRatio || 1, 1.2);
      canvas.width = Math.max(1, Math.round(rect.width * ratio));
      canvas.height = Math.max(1, Math.round(rect.height * ratio));
      report(text('Canvas آماده است؛ در حال ساخت موتور گرافیکی…', 'Canvas has a valid size; creating the graphics engine…'));
      // Do not start the animation loop until the canvas has its final WebView/Compose size.
      player = new Player(canvas, {idle:true,followPointer:'canvas',maxPixelRatio:1.2,lang:language,autoplay:false});
      // The Overview card is short, so use a wider camera framing there.
      // The full Assistant keeps a nearly native scale but leaves a little breathing room.
      player.view.x = compactMode ? 0 : -0.04;
      player.view.zoom = compactMode ? 0.82 : 0.94;
      player.onContextLost = () => {
        ready=false;
        loading.classList.remove('hide');
        loading.textContent = text('شتاب‌دهندهٔ گرافیکی متوقف شد؛ صفحه را دوباره باز کن.', 'Graphics context lost. Reopen this screen.');
        report(loading.textContent);
      };
      report(text('در حال دریافت مدل و تکسچرهای محلی…', 'Loading local character package and textures…'));
      await player.load('./characters/k01.livliv', {
        poster:'./characters/k01/cover.webp',
        onProgress:(progress) => {
          if (progress.step === 'download') {
            const message = text(`بارگذاری کاراکتر… ${Math.round(progress.progress*100)}٪`, `Loading character… ${Math.round(progress.progress*100)}%`);
            loading.textContent = message;
            report(message);
          }
        }
      });
      report(text('مدل بارگذاری شد؛ در حال رسم اولین فریم…', 'Model loaded; drawing the first frame…'));
      // The Compose-hosted WebView may finish loading before its final layout pass. Re-measure and
      // resize after load, then force one synchronous frame and inspect the real WebGL framebuffer.
      await nextFrame();
      await nextFrame();
      const finalRect = canvas.getBoundingClientRect();
      if (finalRect.width < 32 || finalRect.height < 32) throw new Error(`Canvas became unavailable after model load (${Math.round(finalRect.width)}x${Math.round(finalRect.height)}).`);
      canvas.width = Math.max(1, Math.round(finalRect.width * ratio));
      canvas.height = Math.max(1, Math.round(finalRect.height * ratio));
      verifyFirstFrame(canvas, player);
      // Keep the backing buffer in sync with the real Compose/WebView size (rotation, split-screen,
      // Overview card re-layout). Ignore transient zero-size callbacks while LazyColumn is moving.
      if (typeof ResizeObserver !== 'undefined') {
        stageObserver?.disconnect();
        stageObserver = new ResizeObserver(() => {
          if (!ready || !player) return;
          const r = canvas.getBoundingClientRect();
          if (r.width < 32 || r.height < 32) return;
          cancelAnimationFrame(resizeRaf);
          resizeRaf = requestAnimationFrame(() => { try { player?.resize(); } catch (e) { console.error('LivLiv resize failed', e); } });
        });
        stageObserver.observe(canvas.parentElement || canvas);
      }
      player.play();
      $('poster').style.opacity = '0';
      loading.remove();
      ready=true;
      activeState='';
      showState(pendingState,true);
      window.__wfRendererReady=true;
      native()?.reportReady();
      console.info('WAPFire LivLiv renderer ready:', player.model?.name);
    } catch (error) {
      loading.classList.add('error');
      loading.textContent = text(`کاراکتر بارگذاری نشد: ${error?.message || error}`, `Character could not load: ${error?.message || error}`);
      report(loading.textContent);
      console.error('WAPFire LivLiv assistant:', error);
      // Leave the cover visible as a useful fallback rather than removing it over a blank canvas.
      $('poster').style.opacity = '.85';
      try { player?.dispose(); } catch (_) {}
      player = null;
    }
  }

  report(text('JavaScript فعال است؛ در حال واردکردن موتور LivLiv…', 'JavaScript is active; importing LivLiv engine…'));
  window.__wfPreflightStartedAt = Date.now();
  // Dynamic import lets us catch module URL, MIME-type, syntax, and dependency failures.
  import('./dist/index.js')
    .then((module) => {
      if (!module?.Player) throw new Error('dist/index.js loaded but did not export Player.');
      return boot(module.Player);
    })
    .catch((error) => diagnose(error, 'LivLiv ES module import failed'));

  window.addEventListener('pagehide', () => { stageObserver?.disconnect(); cancelAnimationFrame(resizeRaf); try { player?.dispose(); } catch (_) {} });
})();
