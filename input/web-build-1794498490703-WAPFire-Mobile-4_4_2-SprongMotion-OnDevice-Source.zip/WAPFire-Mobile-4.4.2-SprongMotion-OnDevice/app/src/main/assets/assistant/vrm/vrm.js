/* WAPFire 4.4.2 - VRM (VRoid) assistant renderer: three.js + @pixiv/three-vrm.
 * Same native contract as the Hiyori and Nara pages:
 *   window.wapfireSetState(state)  /  WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg)
 * Emotions, gestures and all natural motion live in vrm-pose.js (pure logic). This file loads the model, frames the camera
 * like the Nara screenshots, measures the rig's axis signs at runtime, and maps pose frames onto expressions, bones and eyes.
 * URL parameters: lang=fa|en, compact=1|0, state=<state>, zoom=<n>, dy=<n>  (zoom/dy are fine-tuning aids). */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { create as createPose } from './vrm-pose.js';

const BUILD = '4.4.2';
window.__wfPreflightStarted = true;
window.__wfAssistantBuildVersion = BUILD;
window.__wfAssistantDocumentExpected = true;
window.__wfEngineBooted = true;

const q = new URLSearchParams(location.search);
const fa = q.get('lang') !== 'en';
const compact = q.get('compact') !== '0';
const $ = (id) => document.getElementById(id);
const bridge = window.WapFireNative;
document.documentElement.lang = fa ? 'fa' : 'en';
document.body.className = compact ? 'compact' : 'full';

const D = Math.PI / 180;
const userZoom = parseFloat(q.get('zoom') || '1') || 1;
const userDy = parseFloat(q.get('dy') || '0') || 0;
let pendingState = q.get('state') || 'idle';
let pendingRevision = Number.parseInt(q.get('event') || '0', 10) || 0;
let ready = false;

function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
function fatal(message) {
  const text = String(message).slice(0, 400);
  console.error(text);
  const box = $('loading');
  if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
  report(text);
  try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
}
window.addEventListener('error', (e) => { if (!ready) fatal('VRM error: ' + (e.message || e)); });
window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('VRM error: ' + ((e.reason && e.reason.message) || e.reason)); });

/* ---------- states (labels identical to the Hiyori page) ---------- */
const PILL = {
  idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
  success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
  warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
  setup: ['Setup required', 'نیازمند راه‌اندازی']
};
const poseEngine = createPose();
const nowSec = () => performance.now() / 1000;

let shownState = null;
let shownRevision = -1;
function showState(name, revision = pendingRevision) {
  const state = PILL[name] ? name : 'idle';
  const nextRevision = Number.isFinite(Number(revision)) ? Number(revision) : 0;
  const changed = state !== shownState;
  const replay = !changed && nextRevision !== shownRevision;
  pendingState = state;
  pendingRevision = nextRevision;
  if (!changed && !replay) return;              // ignore ordinary recompositions, replay real repeated detections
  shownState = state;
  shownRevision = nextRevision;
  $('shell').dataset.state = state;
  $('stateText').textContent = PILL[state][fa ? 1 : 0];
  poseEngine.setState(state, nowSec(), replay);
  if (ready && (changed || replay)) requestMotionForState(state);
}
window.wapfireSetState = (state, revision) => {
  try { showState(String(state), revision === undefined ? pendingRevision : revision); }
  catch (e) { report(String(e)); }
};

/* ---------- three.js scene ---------- */
const canvas = $('stage');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setClearColor(0x000000, 0);
canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (!ready) fatal('WebGL context lost while starting.'); });

const scene = new THREE.Scene();
const FOV = 20;
const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 30);
const key = new THREE.DirectionalLight(0xffffff, Math.PI);
key.position.set(0.5, 0.9, 1.2).normalize();
scene.add(key);
scene.add(new THREE.AmbientLight(0xffffff, 0.45));

let vrm = null;
let facing = 1;               // +1 when the character looks toward +Z (the expected case after rotateVRM0)
let motionWideFrame = false;
let cameraGoal = null;
const hipsRest = { x: 0, y: 0, z: 0 };
// L/R: arm signs. pitch/yaw/roll: rig axis -> world semantics used by vrm-pose.js. lat/depth: hips x / z -> screen right / toward camera.
const SIGN = { L: { down: 1, fwd: 1 }, R: { down: 1, fwd: 1 }, pitch: 1, yaw: 1, roll: 1, lat: 1, depth: 1 };
const eyeRange = { yaw: 9, pitch: 9 };   // lookAt input degrees needed per degree of eye rotation (xRange / yRange of the model)

/* ---------- framing (measured from the VRM mesh: hair/ear top 1.495 m, chin 1.23 m, hair half-width 0.207 m) ---------- */
const M = { top: 1.495, chin: 1.23, halfW: 0.207 };
// Targets taken from the Nara screenshots, as a fraction of the stage height: where the head starts and how tall it is.
const FRAME = {
  full: { top: 0.188, head: 0.32, maxW: 0.92 },
  compact: { top: 0.022, head: 0.41, maxW: 0.92 }
};
function fit() {
  const box = $('stageBox');
  const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
  renderer.setSize(W, H, false);
  camera.aspect = W / H;
  // Full-body clips widen the camera; portrait idle returns to the original close framing.
  const cfg = motionWideFrame ? { top: 0.025, head: 0.15, maxW: 0.90 } : (compact ? FRAME.compact : FRAME.full);
  const headH = M.top - M.chin;
  let worldH = headH / cfg.head;
  worldH = Math.max(worldH, (2 * M.halfW / cfg.maxW) / camera.aspect) / userZoom;
  const topY = M.top + (cfg.top + userDy) * worldH;
  const cy = topY - worldH / 2;
  const dist = (worldH / 2) / Math.tan(FOV * D / 2);
  cameraGoal = { position: new THREE.Vector3(0, cy, facing * dist), lookY: cy };
  if (!ready || !camera.position.length()) {
    camera.position.copy(cameraGoal.position);
    camera.lookAt(0, cameraGoal.lookY, 0);
  }
  camera.updateProjectionMatrix();
}
window.wapfireFrame = (zoom, dy) => { /* debugging aid */ fit(); return { zoom, dy }; };

/* ---------- humanoid helpers ---------- */
const nb = (name) => vrm.humanoid.getNormalizedBoneNode(name);
const rawBone = (name) => vrm.humanoid.getRawBoneNode(name);
const tmpV = new THREE.Vector3();
const posOf = (obj) => obj.getWorldPosition(tmpV.set(0, 0, 0)).clone();
function settle() { vrm.humanoid.update(); vrm.scene.updateMatrixWorld(true); }

/* The VRM may mirror left/right, pitch, yaw or roll depending on how the normalized rig was built. Rather than assume, measure:
 * lower the arm with +angle and see whether the hand goes down; swing it with +angle and see whether it moves forward;
 * pitch / yaw / roll the head and see where the eyes go; move the hips and see where the head goes.
 * vrm-pose.js speaks WORLD semantics: pitch + = nose down, yaw + = toward screen right, roll + = top of head toward screen left. */
function calibrate() {
  const head = rawBone('head'), eyeL = rawBone('leftEye') || head, eyeR = rawBone('rightEye') || eyeL;
  const hp = posOf(head), ep = posOf(eyeL);
  facing = (ep.z - hp.z) >= 0 ? 1 : -1;
  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const ua = nb(name + 'UpperArm'), hand = rawBone(name + 'Hand');
    if (!ua || !hand) continue;
    ua.rotation.order = 'ZYX';
    ua.rotation.set(0, 0, 0.9); settle(); const yP = posOf(hand).y;
    ua.rotation.set(0, 0, -0.9); settle(); const yM = posOf(hand).y;
    SIGN[side].down = yP < yM ? 1 : -1;
    ua.rotation.set(0, 0.6, 0); settle(); const zP = posOf(hand).z;
    ua.rotation.set(0, -0.6, 0); settle(); const zM = posOf(hand).z;
    SIGN[side].fwd = (zP - zM) * facing > 0 ? 1 : -1;
    ua.rotation.set(0, 0, 0);
  }
  const hd = nb('head');
  if (hd) {
    const mid = () => posOf(eyeL).add(posOf(eyeR)).multiplyScalar(0.5);
    hd.rotation.set(0.5, 0, 0); settle(); const yP = posOf(eyeL).y;
    hd.rotation.set(-0.5, 0, 0); settle(); const yM = posOf(eyeL).y;
    SIGN.pitch = yP < yM ? 1 : -1;                       // + engine pitch = nose down
    // yaw: the eyes sit in front of the head pivot, so turning the head moves them sideways
    hd.rotation.set(0, 0.4, 0); settle(); const dxY = (mid().x - posOf(head).x) * facing;
    SIGN.yaw = dxY >= 0 ? 1 : -1;                        // + engine yaw = toward screen right
    // roll: the eyes sit above the pivot, so tilting the head moves them sideways
    hd.rotation.set(0, 0, 0.4); settle(); const dxZ = (mid().x - posOf(head).x) * facing;
    SIGN.roll = dxZ < 0 ? 1 : -1;                        // + engine roll = top of head toward screen left
    hd.rotation.set(0, 0, 0);
  }
  const hips = nb('hips');
  if (hips && hd) {
    const base = hips.position.clone(), h0 = posOf(head);
    hips.position.set(base.x + 0.05, base.y, base.z); settle(); const dx = (posOf(head).x - h0.x) * facing;
    SIGN.lat = dx >= 0 ? 1 : -1;
    hips.position.set(base.x, base.y, base.z + 0.05); settle(); const dz = (posOf(head).z - h0.z) * facing;
    SIGN.depth = dz >= 0 ? 1 : -1;
    hips.position.copy(base);
  }
  readEyeRanges();
  settle();
}

/* three-vrm maps lookAt degrees linearly: eye rotation = outputScale * (angle / inputMaxValue). VRoid models have a small output
 * scale (8-12 deg) over a 90 deg input, so the page has to ask for angle * (inputMax / outputScale) to get a visible eye movement. */
function readEyeRanges() {
  try {
    const ap = vrm.lookAt && vrm.lookAt.applier;
    if (ap && ap.rangeMapHorizontalOuter && ap.rangeMapVerticalUp) {
      const hy = (ap.rangeMapHorizontalOuter.outputScale + ap.rangeMapHorizontalInner.outputScale) / 2;
      const vy = (ap.rangeMapVerticalUp.outputScale + ap.rangeMapVerticalDown.outputScale) / 2;
      if (hy > 0.5) eyeRange.yaw = ap.rangeMapHorizontalOuter.inputMaxValue / hy;
      if (vy > 0.5) eyeRange.pitch = ap.rangeMapVerticalUp.inputMaxValue / vy;
    }
  } catch (e) { /* keep the defaults */ }
}

/* ---------- expressions ---------- */
let exprNames = new Set();
let surprisedName = null;
function setExpr(name, v) { if (name && exprNames.has(name)) vrm.expressionManager.setValue(name, v); }

/* ---------- applying a pose frame ---------- */
const FINGERS = [['Index', 0.75], ['Middle', 0.9], ['Ring', 1.0], ['Little', 1.1]];   // little fingers curl most
const CURL = [1.25, 1.35, 0.8];     // proximal, intermediate, distal (radians at curl = 1)
const THUMB = [[0, 0.8, 0], [0, 1.0, 0], [0, 0.7, 0]];   // thumb metacarpal, proximal, distal [x, y, z] at curl = 1: tucks the thumb into the fist (y mirrored per side)
const clampN = (v, a, b) => (v < a ? a : v > b ? b : v);
function setBone(name, x, y, z) { const n = nb(name); if (n) n.rotation.set(x, y, z); }

function applyFrame(f) {
  const E = f.expr;
  setExpr('happy', E.happy); setExpr('sad', E.sad); setExpr('angry', E.angry); setExpr('relaxed', E.relaxed);
  setExpr(surprisedName, E.surprised); setExpr('aa', E.aa); setExpr('blink', E.blink);

  const sp = SIGN.pitch, sy = SIGN.yaw, sr = SIGN.roll;
  const put = (name, v) => setBone(name, v.x * sp, v.y * sy, v.z * sr);
  const R = f.rot;
  put('head', R.head); put('neck', R.neck); put('chest', R.chest); put('upperChest', R.upperChest); put('spine', R.spine); put('hips', R.hips);
  const hips = nb('hips');
  if (hips) hips.position.set(hipsRest.x + f.hips.x * SIGN.lat, hipsRest.y + f.hips.y, hipsRest.z + f.hips.z * SIGN.depth);

  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const s = SIGN[side], a = f.arm[side];
    const ua = nb(name + 'UpperArm'), la = nb(name + 'LowerArm'), sh = nb(name + 'Shoulder'), hand = nb(name + 'Hand');
    if (ua) { ua.rotation.order = 'ZYX'; ua.rotation.set(0, s.fwd * a.fwd, s.down * a.down); }
    if (la) { la.rotation.order = 'ZYX'; la.rotation.set(a.twist, s.fwd * a.elbowF, -s.down * a.elbowU); }
    if (sh) sh.rotation.set(0, 0, -s.down * f.shoulders[side]);
    if (hand) hand.rotation.set(0, 0, s.down * a.wrist);
    FINGERS.forEach(([finger, weight], fi) => {
      const curl = clampN(a.curl + a.fing[fi], 0, 1) * weight;
      ['Proximal', 'Intermediate', 'Distal'].forEach((seg, i) => {
        const bone = nb(name + finger + seg);
        if (bone) bone.rotation.set(0, 0, s.down * curl * CURL[i]);
      });
    });
    const thumbCurl = clampN(a.curl, 0, 1);
    ['Metacarpal', 'Proximal', 'Distal'].forEach((seg, i) => {
      const bone = nb(name + 'Thumb' + seg);
      if (bone) bone.rotation.set(THUMB[i][0] * thumbCurl, THUMB[i][1] * thumbCurl * s.down, THUMB[i][2] * thumbCurl * s.down);
    });
    const ul = nb(name + 'UpperLeg'), ll = nb(name + 'LowerLeg');     // tiny knee give, only visible if the camera ever pulls back
    if (ul) ul.rotation.set(0, 0, 0);
    if (ll) ll.rotation.set(f.legs[side].knee * sp, 0, 0);
  }
  if (vrm.lookAt) {
    vrm.lookAt.yaw = clampN(f.eye.yaw * eyeRange.yaw, -90, 90);
    vrm.lookAt.pitch = clampN(f.eye.pitch * eyeRange.pitch, -90, 90);
  }
}

/* ---------- SprongMotion: text-to-motion -> VRM humanoid retarget ---------- */
const SOURCE_TO_VRM = {
  pelvis: 'hips', l_hip: 'leftUpperLeg', r_hip: 'rightUpperLeg', spine1: 'spine',
  l_knee: 'leftLowerLeg', r_knee: 'rightLowerLeg', spine2: 'chest',
  l_ankle: 'leftFoot', r_ankle: 'rightFoot', spine3: 'upperChest',
  l_foot: 'leftToes', r_foot: 'rightToes', neck: 'neck',
  l_collar: 'leftShoulder', r_collar: 'rightShoulder', head: 'head',
  l_shoulder: 'leftUpperArm', r_shoulder: 'rightUpperArm',
  l_elbow: 'leftLowerArm', r_elbow: 'rightLowerArm',
  l_wrist: 'leftHand', r_wrist: 'rightHand'
};
const qA = new THREE.Quaternion(), qB = new THREE.Quaternion(), qSource = new THREE.Quaternion();
const qSourceParent = new THREE.Quaternion(), qTargetParent = new THREE.Quaternion();
const qBasis = new THREE.Quaternion(), qBasisInv = new THREE.Quaternion();
const qDelta = new THREE.Quaternion(), qGenerated = new THREE.Quaternion(), qBase = new THREE.Quaternion();
let motionRig = [];
let activeMotion = null;
let motionTransition = null;
let motionRequestSerial = 0;
let motionPlanByRequest = new Map();
let activeMotionState = 'idle';
let currentMotionStatus = 'not-requested';

const MOTION_PLANS = {
  idle: { prompt: 'a person stands in a neutral relaxed pose, both upper arms close to the torso and both arms hanging naturally down by the sides, elbows softly bent, hands relaxed, makes a very small natural weight shift and a slow subtle head turn, no waving, no raised hands, no gestures', seconds: 6, loop: true, fullBody: false },
  scanning: { prompt: 'a person stands attentively in a neutral pose, both arms hanging naturally down by the sides with elbows softly bent, slowly looks left and right and makes a tiny weight shift, no hand gestures, no raised arms', seconds: 6, loop: true, fullBody: false },
  connecting: { prompt: 'a person looks thoughtful, slightly leans forward, makes a small welcoming hand gesture and settles into a relaxed standing posture', seconds: 4, loop: false, fullBody: false, follow: 'a person stands calmly with shoulders relaxed and both arms hanging naturally by the sides, gently shifts weight' },
  success: { prompt: 'a person happily celebrates a successful connection with a brief joyful open-arm gesture, then lowers both arms naturally', seconds: 4, loop: false, fullBody: false, follow: 'a person stands happily with shoulders relaxed and arms resting naturally by the sides, gently shifting weight' },
  password_success: { prompt: 'a person makes a small cheerful victory fist pump with the right hand, smiles and returns the arm to a relaxed position', seconds: 3.5, loop: false, fullBody: false, follow: 'a person stands happily with both arms relaxed at the sides and gently shifts weight' },
  password_warning: { prompt: 'a person looks disappointed, lowers the head and shoulders, gently shakes the head no and lets both arms rest by the sides', seconds: 3.5, loop: false, fullBody: false, follow: 'a person stands quietly with a slightly disappointed posture and both arms relaxed naturally down by the sides' },
  warning: { prompt: 'a person reacts with alert surprise, briefly recoils and raises a guarded defensive posture before settling', seconds: 3.5, loop: false, fullBody: false, follow: 'a person stands in a calm alert ready stance with both arms naturally lowered and shoulders relaxed' },
  angry: { prompt: 'a person takes a determined defensive stance, clenches the fists and makes one short controlled forward punch, then returns to guard', seconds: 4, loop: false, fullBody: false, follow: 'a person holds a calm defensive ready stance, arms lowered naturally and weight balanced' },
  offline: { prompt: 'a person looks worried, lowers the head, gives a small sigh and shifts weight with both arms relaxed by the sides', seconds: 6, loop: true, fullBody: false },
  setup: { prompt: 'a person gives one gentle friendly wave with the right hand, then lowers the arm and stands naturally', seconds: 3.5, loop: false, fullBody: false, follow: 'a person stands in a friendly relaxed posture with arms resting naturally down by the sides' }
};

function buildMotionRig(names, parents) {
  motionRig = names.map((sourceName, index) => {
    const boneName = SOURCE_TO_VRM[sourceName];
    const node = boneName ? nb(boneName) : null;
    return {
      sourceName, boneName, node, parentIndex: Number.isInteger(parents[index]) ? parents[index] : -1,
      rest: node ? node.quaternion.clone() : new THREE.Quaternion()
    };
  });
}
function motionWideForPrompt(prompt) {
  return /\b(walk|walking|run|running|jump|jumping|dance|dancing|sit|sitting|lie|lying|kneel|full body|kick|spin)\b/i.test(prompt || '');
}
function requestMotionPlan(plan, stateName = activeMotionState) {
  if (!plan || !vrm || !ready) return;
  const bridgeObject = window.WapFireNative;
  if (!bridgeObject || typeof bridgeObject.generateMotion !== 'function') {
    currentMotionStatus = 'native-bridge-missing';
    report('Native text-to-motion bridge is unavailable; using the safe relaxed pose.');
    return;
  }
  const id = ++motionRequestSerial;
  motionPlanByRequest.clear();
  motionPlanByRequest.set(id, { ...plan, stateName });
  currentMotionStatus = 'generating';
  try {
    bridgeObject.generateMotion(plan.prompt, plan.seconds || 4, ((Date.now() + id * 7919) >>> 0) & 0x7fffffff, id, !!plan.loop);
  } catch (error) {
    currentMotionStatus = 'request-failed';
    report('Motion request failed: ' + ((error && error.message) || error));
  }
}
function requestMotionForState(stateName) {
  activeMotionState = MOTION_PLANS[stateName] ? stateName : 'idle';
  requestMotionPlan(MOTION_PLANS[activeMotionState], activeMotionState);
}
function setMotionWide(enabled) {
  const next = !!enabled;
  if (next === motionWideFrame) return;
  motionWideFrame = next;
  fit();
}
function parseMotionPayload(payload) {
  const data = typeof payload === 'string' ? JSON.parse(payload) : payload;
  if (!data || data.error) throw new Error(data && data.error ? data.error : 'Invalid motion data');
  const count = Number(data.frameCount), joints = Number(data.jointCount), fps = Number(data.fps);
  if (!Number.isInteger(count) || count < 3 || count > 201 || joints !== 22 || fps !== 20) throw new Error('Unsupported motion dimensions');
  if (!Array.isArray(data.jointNames) || !Array.isArray(data.jointParents) || data.jointNames.length !== joints || data.jointParents.length !== joints) throw new Error('Motion skeleton metadata is incomplete');
  if (!Array.isArray(data.rotations) || data.rotations.length !== count * joints * 4) throw new Error('Motion quaternion data is incomplete');
  if (!Array.isArray(data.rootY) || data.rootY.length !== count) throw new Error('Motion root track is incomplete');
  const rotations = new Float32Array(data.rotations);
  const rootY = new Float32Array(data.rootY);
  for (let i = 0; i < rotations.length; i++) if (!Number.isFinite(rotations[i])) throw new Error('Motion contains invalid rotations');
  for (let i = 0; i < rootY.length; i++) if (!Number.isFinite(rootY[i])) throw new Error('Motion contains invalid root movement');
  return { fps, frameCount: count, jointCount: joints, jointNames: data.jointNames, jointParents: data.jointParents, rotations, rootY, duration: count / fps };
}
window.wapfireMotionProgress = (requestId, percent, message) => {
  if (requestId !== motionRequestSerial) return;
  currentMotionStatus = percent >= 100 ? 'generating' : 'downloading';
  if (percent === 100 && message) report(message);
};
window.wapfireMotionReady = (requestId, payload) => {
  if (requestId !== motionRequestSerial) return;
  try {
    const data = parseMotionPayload(payload);
    if (!motionRig.length) buildMotionRig(data.jointNames, data.jointParents);
    if (motionRig.length !== data.jointCount) throw new Error('Nara retarget skeleton mismatch');
    const plan = motionPlanByRequest.get(requestId) || MOTION_PLANS.idle;
    const next = { data, plan, startedAt: nowSec(), followTriggered: false };
    const previous = activeMotion;
    motionTransition = { from: previous, to: next, startedAt: nowSec(), duration: 0.55 };
    activeMotion = next;
    setMotionWide(!!plan.fullBody || motionWideForPrompt(plan.prompt));
    currentMotionStatus = 'ready';
    report('Nara text-to-motion ready (' + data.frameCount + ' frames, ' + data.fps + ' FPS).');
  } catch (error) {
    currentMotionStatus = 'invalid-motion';
    report('Nara motion retarget error: ' + ((error && error.message) || error));
  }
};
window.wapfireMotionFailed = (requestId, message) => {
  if (requestId !== motionRequestSerial) return;
  currentMotionStatus = 'download-or-generation-failed';
  // Never leave a stale gesture playing after a new event failed to generate.
  activeMotion = null; motionTransition = null;
  for (const entry of motionRig) if (entry.node) entry.node.quaternion.copy(entry.rest);
  const hips = nb('hips'); if (hips) hips.position.y = hipsRest.y;
  setMotionWide(false);
  report('Nara motion engine unavailable: ' + String(message || 'unknown error').slice(0, 220) + '. Connect to the internet once to download the 33 MB model.');
};
window.wapfireGenerateMotion = (prompt, seconds = 4, loop = false) => {
  const clean = String(prompt || '').trim().slice(0, 900);
  if (!clean) return false;
  const plan = { prompt: clean, seconds: Math.max(0.5, Math.min(10, Number(seconds) || 4)), loop: !!loop, fullBody: motionWideForPrompt(clean) };
  requestMotionPlan(plan, activeMotionState);
  return true;
};
window.wapfireMotionInfo = () => JSON.stringify({ engine: 'SprongMotion-14M 1.1.0', status: currentMotionStatus, state: activeMotionState, frameCount: activeMotion && activeMotion.data.frameCount, fps: activeMotion && activeMotion.data.fps, mappedJoints: motionRig.filter(x => x.node).length });

function sampleSourceRotation(clip, now, jointIndex, out) {
  if (!clip || !clip.data || jointIndex < 0 || jointIndex >= clip.data.jointCount) return out.identity();
  const data = clip.data, elapsed = Math.max(0, now - clip.startedAt);
  const framePosition = clip.plan.loop ? (elapsed * data.fps) % data.frameCount : Math.min(data.frameCount - 1, elapsed * data.fps);
  const f0 = Math.floor(framePosition), f1 = clip.plan.loop ? (f0 + 1) % data.frameCount : Math.min(data.frameCount - 1, f0 + 1);
  const alpha = framePosition - f0;
  const a = (f0 * data.jointCount + jointIndex) * 4, b = (f1 * data.jointCount + jointIndex) * 4;
  qA.set(data.rotations[a], data.rotations[a + 1], data.rotations[a + 2], data.rotations[a + 3]);
  qB.set(data.rotations[b], data.rotations[b + 1], data.rotations[b + 2], data.rotations[b + 3]);
  return out.copy(qA).slerp(qB, alpha).normalize();
}
function applyGeneratedMotion(now) {
  if (!activeMotion || !motionRig.length) return;
  if (!activeMotion.plan.loop && now - activeMotion.startedAt >= activeMotion.data.duration && !activeMotion.followTriggered) {
    activeMotion.followTriggered = true;
    const follow = activeMotion.plan.follow;
    if (follow) requestMotionPlan({ prompt: follow, seconds: 6, loop: true, fullBody: false }, activeMotionState);
    else requestMotionPlan(MOTION_PLANS.idle, 'idle');
  }
  const transition = motionTransition;
  let blend = 1;
  if (transition) blend = clampN((now - transition.startedAt) / transition.duration, 0, 1);
  for (let i = 0; i < motionRig.length; i++) {
    const entry = motionRig[i], node = entry.node;
    if (!node) continue;
    sampleSourceRotation(activeMotion, now, i, qSource);
    if (transition && transition.from) {
      sampleSourceRotation(transition.from, now, i, qB);
      qB.slerp(qSource, blend);
      qSource.copy(qB);
    }
    // Map the source joint's local axes through the source-parent and target-parent world frames.
    const sourceParent = entry.parentIndex >= 0 ? motionRig[entry.parentIndex]?.node : vrm.scene;
    if (sourceParent) sourceParent.getWorldQuaternion(qSourceParent);
    else qSourceParent.identity();
    if (node.parent) node.parent.getWorldQuaternion(qTargetParent); else qTargetParent.identity();
    qBasis.copy(qTargetParent).invert().multiply(qSourceParent).normalize();
    qBasisInv.copy(qBasis).invert();
    qDelta.copy(qBasis).multiply(qSource).multiply(qBasisInv).normalize();
    qGenerated.copy(qDelta).multiply(entry.rest).normalize();
    qBase.copy(node.quaternion);
    if (transition && !transition.from) qBase.slerp(qGenerated, blend);
    else qBase.copy(qGenerated);
    node.quaternion.copy(qBase);
  }
  const hipsMotion = motionRig.find(x => x.sourceName === 'pelvis');
  if (hipsMotion && hipsMotion.node) {
    const framePosition = activeMotion.plan.loop
      ? ((now - activeMotion.startedAt) * activeMotion.data.fps) % activeMotion.data.frameCount
      : Math.min(activeMotion.data.frameCount - 1, (now - activeMotion.startedAt) * activeMotion.data.fps);
    const f0 = Math.floor(framePosition), f1 = activeMotion.plan.loop ? (f0 + 1) % activeMotion.data.frameCount : Math.min(activeMotion.data.frameCount - 1, f0 + 1);
    const a = activeMotion.data.rootY[f0] - activeMotion.data.rootY[0];
    const b = activeMotion.data.rootY[f1] - activeMotion.data.rootY[0];
    const deltaY = (a + (b - a) * (framePosition - f0)) * 0.7;
    hipsMotion.node.position.y = hipsRest.y + clampN(deltaY, -0.45, 0.45);
  }
  if (transition && blend >= 1 && motionTransition === transition) motionTransition = null;
}

/* ---------- main loop ---------- */
let last = performance.now();
let lastRender = 0;
let pixelRatio = renderer.getPixelRatio();
const perf = { frames: 0, acc: 0, checked: 0 };
function tick() {
  const nowMs = performance.now();
  if (nowMs - lastRender < 14) return;                      // no point rendering faster than ~60 fps (saves battery on 90/120 Hz phones)
  lastRender = nowMs;
  const dt = Math.min(0.1, Math.max(0.001, (nowMs - last) / 1000));
  last = nowMs;
  if (vrm) {
    applyFrame(poseEngine.update(nowMs / 1000, dt));
    applyGeneratedMotion(nowMs / 1000);
    if (cameraGoal) {
      const blend = 1 - Math.exp(-5 * dt);
      camera.position.lerp(cameraGoal.position, blend);
      camera.lookAt(0, cameraGoal.lookY, 0);
    }
    vrm.update(Math.min(dt, 0.05));
    // Choppy animation never looks natural: if the phone cannot keep ~40 fps, lower the render resolution (never raised again).
    if (ready && perf.checked < 3 && pixelRatio > 1) {
      perf.frames++; perf.acc += dt;
      if (perf.frames >= 90) {
        perf.checked++;
        if (perf.acc / perf.frames > 0.026) {
          pixelRatio = Math.max(1, pixelRatio - 0.5); renderer.setPixelRatio(pixelRatio); fit();
          report('Resolution lowered to ' + pixelRatio + 'x for smoother motion.');
        }
        perf.frames = 0; perf.acc = 0;
      }
    }
  }
  renderer.render(scene, camera);
}

window.wapfireVrmInfo = () => JSON.stringify({ build: BUILD, facing, sign: SIGN, eyeRange, expressions: Array.from(exprNames), surprised: surprisedName });
window.wapfirePoseInfo = () => JSON.stringify(poseEngine.debug());
// Dev aid: where does the hand land on screen (normalised -1..1) for these arm angles (degrees)? Used to keep gestures inside the frame.
window.wapfireProbe = (side, down, fwd, elbowF, elbowU) => {
  const name = side === 'L' ? 'left' : 'right', s = SIGN[side];
  const ua = nb(name + 'UpperArm'), la = nb(name + 'LowerArm'), hand = rawBone(name + 'Hand');
  if (!ua || !la || !hand) return null;
  ua.rotation.order = 'ZYX'; ua.rotation.set(0, s.fwd * fwd * D, s.down * down * D);
  la.rotation.order = 'ZYX'; la.rotation.set(0, s.fwd * elbowF * D, -s.down * elbowU * D);
  settle(); camera.updateMatrixWorld(true);
  const v = posOf(hand).project(camera);
  return JSON.stringify([+v.x.toFixed(3), +v.y.toFixed(3)]);
};
window.wapfireTrigger = (slot, kind) => poseEngine.trigger(slot, kind, nowSec());   // e.g. wapfireTrigger('arm', 'wave') to preview a gesture   // which gesture / gaze target is running right now

/* ---------- boot ---------- */
async function boot() {
  report(fa ? 'در حال بارگذاری مدل VRM…' : 'Loading VRM model…');
  const loader = new GLTFLoader();
  loader.register((parser) => new VRMLoaderPlugin(parser));
  let lastPct = -1;
  const gltf = await loader.loadAsync('./model/nara.vrm', (e) => {
    if (!e.lengthComputable) return;
    const pct = Math.floor((e.loaded / e.total) * 100);
    if (pct !== lastPct && pct % 10 === 0) { lastPct = pct; report((fa ? 'بارگذاری مدل VRM… ' : 'Loading VRM model… ') + pct + '%'); }
  });
  vrm = gltf.userData.vrm;
  if (!vrm) throw new Error('The file is not a VRM model.');
  if (VRMUtils.removeUnnecessaryVertices) VRMUtils.removeUnnecessaryVertices(gltf.scene);
  if (VRMUtils.combineSkeletons) VRMUtils.combineSkeletons(gltf.scene);
  else if (VRMUtils.removeUnnecessaryJoints) VRMUtils.removeUnnecessaryJoints(gltf.scene);
  VRMUtils.rotateVRM0(vrm);                       // VRM 0.x models face -Z; turn them toward the camera
  vrm.scene.traverse((o) => { o.frustumCulled = false; });
  scene.add(vrm.scene);

  const em = vrm.expressionManager;
  exprNames = new Set(em ? Object.keys(em.expressionMap || {}) : []);
  surprisedName = ['Surprised', 'surprised'].find((n) => exprNames.has(n)) || null;
  if (nb('hips')) hipsRest.x = nb('hips').position.x, hipsRest.y = nb('hips').position.y, hipsRest.z = nb('hips').position.z;
  settle();
  calibrate();
  report('VRM ready: ' + window.wapfireVrmInfo());

  fit();
  if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
  window.addEventListener('resize', () => requestAnimationFrame(fit));
  showState(pendingState, pendingRevision);
  renderer.setAnimationLoop(tick);
  // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  fit();
  ready = true;
  window.__wfRendererReady = true;
  $('loading').style.display = 'none';
  try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
  requestMotionForState(shownState || pendingState || 'idle');
}

showState(pendingState, pendingRevision);
boot().catch((error) => fatal('VRM failed to start: ' + ((error && error.message) || error)));
