import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 104
        versionName = "4.2.2"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// WAPFire 4.2.2: stage a pinned Three.js + @pixiv/three-vrm runtime for offline WebView use.
// The model itself is the user-supplied VRM file under src/main/assets/assistant/vrm/model.vrm.
// Runtime requests are served only from APK assets; the downloads below happen at build time.
val vrmRuntimeFiles = listOf(
    Triple("vendor/three/build/three.module.js", "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js", 300_000L),
    Triple("vendor/three/examples/jsm/loaders/GLTFLoader.js", "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/loaders/GLTFLoader.js", 50_000L),
    Triple("vendor/three/examples/jsm/utils/BufferGeometryUtils.js", "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/utils/BufferGeometryUtils.js", 10_000L),
    Triple("vendor/@pixiv/three-vrm/lib/three-vrm.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@3.5.5/lib/three-vrm.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-core/lib/three-vrm-core.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-core@3.5.5/lib/three-vrm-core.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-materials-hdr-emissive-multiplier/lib/three-vrm-materials-hdr-emissive-multiplier.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-materials-hdr-emissive-multiplier@3.5.5/lib/three-vrm-materials-hdr-emissive-multiplier.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-materials-mtoon/lib/three-vrm-materials-mtoon.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-materials-mtoon@3.5.5/lib/three-vrm-materials-mtoon.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-materials-v0compat/lib/three-vrm-materials-v0compat.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-materials-v0compat@3.5.5/lib/three-vrm-materials-v0compat.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-node-constraint/lib/three-vrm-node-constraint.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-node-constraint@3.5.5/lib/three-vrm-node-constraint.module.min.js", 256L),
    Triple("vendor/@pixiv/three-vrm-springbone/lib/three-vrm-springbone.module.min.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm-springbone@3.5.5/lib/three-vrm-springbone.module.min.js", 256L)
)

val downloadVrmRuntime by tasks.registering {
    val runtimeRoot = file("src/main/assets/assistant/vrm")
    val destinations = vrmRuntimeFiles.map { (relative, _, _) -> File(runtimeRoot, relative) }
    outputs.files(destinations)
    outputs.upToDateWhen { destinations.all { it.isFile && it.length() > 256L } }

    doLast {
        vrmRuntimeFiles.forEach { (relative, sourceUrl, minimumBytes) ->
            val destination = File(runtimeRoot, relative)
            if (destination.isFile && destination.length() >= minimumBytes) {
                logger.lifecycle("VRM runtime already staged: ${destination.relativeTo(projectDir)}")
                return@forEach
            }
            destination.parentFile.mkdirs()
            val temporary = File(destination.parentFile, destination.name + ".download")
            val mirrors = listOf(
                sourceUrl,
                sourceUrl.replace("https://cdn.jsdelivr.net/npm/", "https://unpkg.com/")
            )
            var downloaded = false
            var lastFailure: Exception? = null
            for (attempt in 1..3) {
                for (mirror in mirrors) {
                    var connection: HttpURLConnection? = null
                    try {
                        connection = URL(mirror).openConnection() as HttpURLConnection
                        connection.connectTimeout = 30_000
                        connection.readTimeout = 120_000
                        connection.instanceFollowRedirects = true
                        connection.setRequestProperty("User-Agent", "WAPFire-Mobile-VRM/4.2.2")
                        connection.setRequestProperty("Accept", "application/javascript, text/javascript, */*")
                        val status = connection.responseCode
                        if (status != HttpURLConnection.HTTP_OK) throw IOException("HTTP $status from $mirror")
                        connection.inputStream.use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
                        if (!temporary.isFile || temporary.length() < minimumBytes) {
                            throw IOException("Downloaded asset is too small (${temporary.length()} bytes): $mirror")
                        }
                        Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                        downloaded = true
                        logger.lifecycle("Staged offline VRM dependency: ${destination.relativeTo(projectDir)} (${destination.length()} bytes)")
                        break
                    } catch (error: Exception) {
                        lastFailure = error
                        temporary.delete()
                        logger.warn("VRM dependency download failed (attempt $attempt): $mirror — ${error.message}")
                    } finally {
                        connection?.disconnect()
                    }
                }
                if (downloaded) break
            }
            temporary.delete()
            if (!downloaded) {
                throw GradleException("Could not stage VRM runtime asset $relative. Check CDN access from the build machine.", lastFailure)
            }
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(downloadVrmRuntime)
}

