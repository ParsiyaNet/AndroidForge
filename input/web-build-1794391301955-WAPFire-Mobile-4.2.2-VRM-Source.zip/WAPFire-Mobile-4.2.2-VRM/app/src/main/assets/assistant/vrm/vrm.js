import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';

(() => {
  'use strict';
  const BUILD = '4.2.2-vrm';
  window.__wfPreflightStarted = true;
  window.__wfAssistantBuildVersion = BUILD;
  window.__wfAssistantDocumentExpected = true;
  window.__wfEngineBooted = true;

  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') === 'fa';
  const compact = q.get('compact') !== '0';
  const $ = (id) => document.getElementById(id);
  const bridge = window.WapFireNative;
  document.documentElement.lang = fa ? 'fa' : 'en';
  document.body.className = compact ? 'compact' : 'full';

  const TEXT = {
    idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'],
    connecting: ['Connecting', 'در حال اتصال'], success: ['Connected', 'متصل شد'],
    password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
    warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'],
    offline: ['Device offline', 'دستگاه آفلاین'], setup: ['Setup required', 'نیازمند راه‌اندازی']
  };
  const report = (message) => { try { bridge?.reportStatus?.(String(message).slice(0, 800)); } catch (_) {} };
  function fatal(message) {
    const value = String(message || 'Unknown VRM error').slice(0, 400);
    console.error(value);
    const box = $('loading');
    if (box) { box.className = 'loading error'; box.textContent = value; box.style.display = 'block'; }
    report(value);
    try { bridge?.reportFatal?.(value); } catch (_) {}
  }
  window.addEventListener('error', (e) => { if (!window.__wfRendererReady) fatal(`Nara 3D error: ${e.message || e}`); });
  window.addEventListener('unhandledrejection', (e) => { if (!window.__wfRendererReady) fatal(`Nara 3D error: ${(e.reason && e.reason.message) || e.reason}`); });

  const FACE_NAMES = ['neutral', 'happy', 'relaxed', 'sad', 'angry', 'surprised', 'blink'];
  const FACE = Object.fromEntries(FACE_NAMES.map((name) => [name, 0]));
  let faceCurrent = { ...FACE };
  let faceTarget = { ...FACE, neutral: 1 };
  let blinkUntil = 0;
  let nextBlinkAt = 2.8;

  const STATE_POSES = {
    idle: { face: { neutral: 1, relaxed: 0.08 } },
    scanning: { face: { neutral: 0.5, relaxed: 0.28, surprised: 0.12 } },
    connecting: { face: { neutral: 0.2, relaxed: 0.65 } },
    success: { face: { neutral: 0, happy: 1 } },
    password_success: { face: { neutral: 0, happy: 0.8 } },
    password_warning: { face: { neutral: 0, sad: 0.7, surprised: 0.15 } },
    warning: { face: { neutral: 0, surprised: 0.95 } },
    // The model license forbids violent use. Threat detection therefore uses a non-contact alert pose.
    angry: { face: { neutral: 0, angry: 0.65, surprised: 0.25 } },
    offline: { face: { neutral: 0, sad: 0.68 } },
    setup: { face: { neutral: 0, happy: 0.5, relaxed: 0.3 } }
  };

  let renderer, scene, camera, currentVrm, clock;
  let currentState = q.get('state') || 'idle';
  let currentMotion = null;
  let motionStartedAt = 0;
  let motionFaceOverride = false;
  let compactFullBody = false;
  let frameBox = null;
  const bones = {};
  const restBones = {};
  const BONE_NAMES = [
    'hips', 'spine', 'chest', 'upperChest', 'neck', 'head',
    'leftShoulder', 'leftUpperArm', 'leftLowerArm', 'leftHand',
    'rightShoulder', 'rightUpperArm', 'rightLowerArm', 'rightHand',
    'leftUpperLeg', 'leftLowerLeg', 'leftFoot', 'rightUpperLeg', 'rightLowerLeg', 'rightFoot',
    'leftThumbProximal', 'leftIndexProximal', 'leftMiddleProximal', 'leftRingProximal', 'leftLittleProximal',
    'rightThumbProximal', 'rightIndexProximal', 'rightMiddleProximal', 'rightRingProximal', 'rightLittleProximal'
  ];
  const tempEuler = new THREE.Euler(0, 0, 0, 'XYZ');
  const tempQuaternion = new THREE.Quaternion();
  const offsets = {};
  let baseRootY = 0;
  let baseRootYPosition = 0;
  let elapsed = 0;
  let resizeObserver = null;
  let animationFrame = 0;

  function setFace(target) {
    faceTarget = { ...FACE };
    for (const [name, value] of Object.entries(target || {})) {
      if (name in faceTarget) faceTarget[name] = Math.max(0, Math.min(1, value));
    }
    if (!target || Object.keys(target).every((name) => name === 'neutral')) faceTarget.neutral = 1;
  }

  function statePose(name, t) {
    const pose = {};
    const put = (bone, x, y, z) => { pose[bone] = [x, y, z]; };
    switch (name) {
      case 'scanning':
        put('head', 0.015 * Math.sin(t * 1.8), 0.24 * Math.sin(t * 1.35), 0.012 * Math.sin(t * 0.7));
        put('neck', 0, 0.08 * Math.sin(t * 1.35), 0);
        break;
      case 'connecting':
        put('head', -0.035, 0.04 * Math.sin(t * 1.2), 0.07);
        put('rightUpperArm', 0.05, 0, -0.12);
        break;
      case 'success':
      case 'password_success':
        put('head', -0.08 * Math.sin(Math.min(t, 1.2) * 3), 0, 0.015);
        put('chest', -0.035, 0, 0);
        break;
      case 'password_warning':
        put('head', 0.035, 0.14 * Math.sin(Math.min(t, 1.7) * 5) * Math.exp(-t * 1.2), -0.09);
        break;
      case 'warning':
      case 'angry':
        put('head', -0.11 * Math.exp(-t * 3.4), 0.025 * Math.sin(t * 2), 0);
        put('chest', -0.035 * Math.exp(-t * 2.5), 0, 0);
        put('leftUpperArm', 0.12, 0, 0.22);
        put('rightUpperArm', 0.12, 0, -0.22);
        break;
      case 'offline':
        put('head', 0.17, 0, -0.045);
        put('neck', 0.07, 0, 0);
        put('chest', 0.025, 0, 0);
        break;
      case 'setup':
        put('head', -0.025, 0, 0.06);
        break;
      default:
        break;
    }
    // Gentle breathing and tiny idle sway remain active beneath every state.
    const breath = Math.sin(t * 1.65) * 0.012;
    const sway = Math.sin(t * 0.72) * 0.018;
    const chest = pose.chest || [0, 0, 0];
    pose.chest = [chest[0] + breath, chest[1] + sway, chest[2]];
    if (!pose.head) pose.head = [0, 0, 0];
    pose.head[2] += Math.sin(t * 0.6) * 0.012;
    return pose;
  }

  function motionPose(name, t) {
    const p = { bones: {}, rootY: 0, rootYPosition: 0 };
    const put = (bone, x, y, z) => { p.bones[bone] = [x, y, z]; };
    const fade = Math.min(1, Math.max(0, t / 0.28));
    if (name === 'wave') {
      const a = fade * (t < 2.4 ? 1 : Math.max(0, 1 - (t - 2.4) / 0.45));
      put('rightUpperArm', 0.12, 0, -1.15 * a);
      put('rightLowerArm', -0.35, 0, -0.48 * a);
      put('rightHand', 0, 0.45 * Math.sin(t * 9) * a, 0.05);
    } else if (name === 'peace') {
      const a = fade * (t < 2.3 ? 1 : Math.max(0, 1 - (t - 2.3) / 0.5));
      put('rightUpperArm', 0.05, 0, -1.18 * a);
      put('rightLowerArm', -0.42 * a, 0, -0.28 * a);
      put('rightIndexProximal', 0.02, 0, -0.05);
      put('rightMiddleProximal', 0.02, 0, 0.05);
      put('rightRingProximal', 0.85 * a, 0, 0.06);
      put('rightLittleProximal', 0.9 * a, 0, 0.08);
      put('head', -0.04, 0, 0.05);
    } else if (name === 'scratch') {
      const a = fade * (t < 3.0 ? 1 : Math.max(0, 1 - (t - 3.0) / 0.55));
      put('rightUpperArm', 0.35 * a, 0, -1.25 * a);
      put('rightLowerArm', -1.35 * a, 0.05, -0.2 * a);
      put('rightHand', 0.15 * a, 0, 0.18 * a);
      put('head', 0.035, 0, 0.12);
    } else if (name === 'stretch') {
      const a = fade * (t < 2.5 ? 1 : Math.max(0, 1 - (t - 2.5) / 0.6));
      put('leftUpperArm', -0.05, 0, 1.45 * a);
      put('rightUpperArm', -0.05, 0, -1.45 * a);
      put('leftLowerArm', 0.1 * a, 0, 0.16 * a);
      put('rightLowerArm', 0.1 * a, 0, -0.16 * a);
      put('chest', -0.11 * a, 0, 0);
      put('head', -0.055 * a, 0, 0);
    } else if (name === 'spin') {
      const u = Math.min(1, t / 2.8);
      const eased = 1 - Math.pow(1 - u, 2);
      p.rootY = Math.PI * 2 * eased;
      put('chest', 0, 0, 0.02 * Math.sin(t * 4));
    } else if (name === 'squat') {
      const a = fade * (t < 2.25 ? 1 : Math.max(0, 1 - (t - 2.25) / 0.65));
      put('hips', 0.04 * a, 0, 0);
      put('leftUpperLeg', 0.45 * a, 0, 0.02);
      put('rightUpperLeg', 0.45 * a, 0, -0.02);
      put('leftLowerLeg', -0.75 * a, 0, 0);
      put('rightLowerLeg', -0.75 * a, 0, 0);
      p.rootYPosition = -0.09 * a;
      put('head', 0.08 * a, 0, 0);
    } else if (name === 'pose') {
      const a = fade * (t < 3.0 ? 1 : Math.max(0, 1 - (t - 3.0) / 0.55));
      put('leftUpperArm', 0.12, 0, 0.72 * a);
      put('rightUpperArm', 0.12, 0, -0.72 * a);
      put('leftLowerArm', 0, 0, -0.78 * a);
      put('rightLowerArm', 0, 0, 0.78 * a);
      put('head', -0.02, 0, 0.035);
    } else if (name === 'cheer') {
      const a = fade * (t < 1.05 ? 1 : Math.max(0, 1 - (t - 1.05) / 0.5));
      put('leftUpperArm', 0, 0, 0.95 * a);
      put('rightUpperArm', 0, 0, -0.95 * a);
      put('leftLowerArm', -0.45 * a, 0, 0.15 * a);
      put('rightLowerArm', -0.45 * a, 0, -0.15 * a);
      put('head', -0.08 * Math.sin(t * 4) * a, 0, 0);
    } else if (name === 'nod') {
      const a = fade * Math.max(0, 1 - t / 1.2);
      put('head', -0.17 * Math.sin(Math.PI * Math.min(1, t / 1.2)) * a, 0, 0);
    } else if (name === 'no') {
      const a = Math.max(0, 1 - t / 1.8);
      put('head', 0, 0.18 * Math.sin(t * 9) * a, 0);
    } else if (name === 'startle' || name === 'alert') {
      const a = Math.max(0, 1 - t / (name === 'alert' ? 2.0 : 1.0));
      put('head', -0.1 * a, 0, 0);
      put('leftUpperArm', 0.08 * a, 0, 0.18 * a);
      put('rightUpperArm', 0.08 * a, 0, -0.18 * a);
    }
    return p;
  }

  const MOTION_DURATION = {
    wave: 2.9, peace: 3.0, scratch: 3.8, stretch: 3.2, spin: 3.0, squat: 3.2,
    pose: 4.0, cheer: 1.7, nod: 1.3, no: 1.9, startle: 1.15, alert: 2.2
  };

  function playMotion(name) {
    const allowed = new Set(['wave', 'peace', 'scratch', 'stretch', 'spin', 'squat', 'pose', 'cheer', 'nod', 'no', 'startle', 'alert', 'full_body']);
    if (!allowed.has(name)) return false;
    if (name === 'full_body') {
      compactFullBody = !compactFullBody;
      fitCamera();
      return true;
    }
    currentMotion = name;
    motionStartedAt = elapsed;
    if (name === 'peace' || name === 'wave' || name === 'cheer') {
      setFace({ neutral: 0, happy: 0.7 });
      motionFaceOverride = true;
    }
    report(`Motion preview: ${name}`);
    return true;
  }
  window.wapfirePlayMotion = playMotion;

  function stateChanged(name) {
    const next = Object.prototype.hasOwnProperty.call(TEXT, name) ? name : 'idle';
    if (next === currentState) return;
    currentState = next;
    // Drop any one-shot gesture from the previous WAPFire state before applying the new one.
    currentMotion = null;
    motionFaceOverride = false;
    $('shell').dataset.state = next;
    $('stateText').textContent = TEXT[next][fa ? 1 : 0];
    const target = STATE_POSES[next]?.face || STATE_POSES.idle.face;
    setFace(target);
    const autoMotion = {
      success: 'cheer', password_success: 'nod', password_warning: 'no',
      warning: 'startle', angry: 'alert', setup: 'wave'
    }[next];
    if (autoMotion) playMotion(autoMotion);
  }
  window.wapfireSetState = (name) => { try { stateChanged(String(name)); } catch (e) { report(e); } };

  function fitCamera() {
    if (!camera || !frameBox) return;
    const height = Math.max(frameBox.size.y, 1.4);
    const full = !compact || compactFullBody;
    const targetY = full ? height * 0.52 : height * 0.72;
    const distance = height * (full ? 2.18 : 1.38);
    camera.position.set(0, targetY + height * 0.015, distance);
    camera.lookAt(0, targetY, 0);
    camera.near = 0.01;
    camera.far = Math.max(50, distance * 8);
    camera.updateProjectionMatrix();
  }

  function captureBones(vrm) {
    for (const name of BONE_NAMES) {
      const node = vrm.humanoid?.getNormalizedBoneNode(name);
      if (!node) continue;
      bones[name] = node;
      restBones[name] = node.quaternion.clone();
    }
    baseRootY = vrm.scene.rotation.y;
    baseRootYPosition = vrm.scene.position.y;
  }

  function applyBones(dt) {
    if (!currentVrm) return;
    const t = elapsed;
    const stateOffsets = statePose(currentState, t);
    let gesture = { bones: {}, rootY: 0, rootYPosition: 0 };
    if (currentMotion) {
      const motionTime = Math.max(0, elapsed - motionStartedAt);
      gesture = motionPose(currentMotion, motionTime);
      if (motionTime >= (MOTION_DURATION[currentMotion] || 2.5)) {
        currentMotion = null;
        if (motionFaceOverride) {
          setFace(STATE_POSES[currentState]?.face || STATE_POSES.idle.face);
          motionFaceOverride = false;
        }
      }
    }
    const blend = 1 - Math.exp(-Math.max(0.001, dt) * 9.5);
    const allNames = new Set([...Object.keys(bones), ...Object.keys(stateOffsets), ...Object.keys(gesture.bones || {})]);
    for (const name of allNames) {
      const node = bones[name];
      const rest = restBones[name];
      if (!node || !rest) continue;
      const a = stateOffsets[name] || [0, 0, 0];
      const b = (gesture.bones && gesture.bones[name]) || [0, 0, 0];
      tempEuler.set(a[0] + b[0], a[1] + b[1], a[2] + b[2], 'XYZ');
      tempQuaternion.setFromEuler(tempEuler);
      node.quaternion.copy(rest).multiply(tempQuaternion);
      // A tiny slerp against the target quaternion filters abrupt state changes.
      const key = `q_${name}`;
      if (!offsets[key]) offsets[key] = node.quaternion.clone();
      offsets[key].slerp(node.quaternion, blend);
      node.quaternion.copy(offsets[key]);
    }
    currentVrm.scene.rotation.y = baseRootY + (gesture.rootY || 0);
    currentVrm.scene.position.y = baseRootYPosition + (gesture.rootYPosition || 0);
  }

  function updateFace(dt) {
    if (!currentVrm?.expressionManager) return;
    if (elapsed >= nextBlinkAt) {
      blinkUntil = elapsed + 0.13;
      nextBlinkAt = elapsed + 2.5 + Math.random() * 2.4;
    }
    const blink = elapsed < blinkUntil ? Math.sin(Math.PI * (elapsed - (blinkUntil - 0.13)) / 0.13) : 0;
    const a = 1 - Math.exp(-dt * 10);
    for (const name of FACE_NAMES) {
      let target = faceTarget[name] || 0;
      if (name === 'blink') target = Math.max(target, blink);
      faceCurrent[name] += (target - faceCurrent[name]) * a;
      try { currentVrm.expressionManager.setValue(name, faceCurrent[name]); } catch (_) {}
    }
  }

  function resize() {
    if (!renderer || !camera) return;
    const box = $('stageBox');
    const width = Math.max(40, box.clientWidth);
    const height = Math.max(40, box.clientHeight);
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    fitCamera();
  }

  function animate() {
    animationFrame = requestAnimationFrame(animate);
    if (!currentVrm || document.visibilityState === 'hidden') return;
    const dt = Math.min(0.05, Math.max(0.001, clock.getDelta()));
    elapsed += dt;
    applyBones(dt);
    updateFace(dt);
    currentVrm.update(dt);
    renderer.render(scene, camera);
  }

  async function boot() {
    const canvas = $('stage');
    const stage = $('stageBox');
    renderer = new THREE.WebGLRenderer({
      canvas, alpha: true, antialias: true, powerPreference: 'low-power',
      premultipliedAlpha: false, preserveDrawingBuffer: false
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, compact ? 1.2 : 1.55));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(29, Math.max(1, stage.clientWidth) / Math.max(1, stage.clientHeight), 0.01, 100);
    scene.add(new THREE.HemisphereLight(0xdff3ff, 0x263b5a, 1.55));
    const key = new THREE.DirectionalLight(0xffffff, 2.0);
    key.position.set(1.2, 2.8, 2.4);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x8acfff, 0.7);
    fill.position.set(-2.2, 1.4, -1.0);
    scene.add(fill);

    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));
    $('loading').textContent = fa ? 'در حال بارگذاری مدل سه‌بعدی نارا…' : 'Loading Nara 3D model…';
    const gltf = await loader.loadAsync('./model.vrm', (progress) => {
      if (progress.total > 0) {
        const percent = Math.round((progress.loaded / progress.total) * 100);
        $('loading').textContent = fa ? `بارگذاری مدل… ${percent}٪` : `Loading model… ${percent}%`;
      }
    });
    currentVrm = gltf.userData.vrm;
    if (!currentVrm) throw new Error('The selected file did not produce a valid VRM model.');
    VRMUtils.rotateVRM0(currentVrm);
    try { VRMUtils.removeUnnecessaryVertices(currentVrm.scene); } catch (e) { console.warn('VRM vertex optimization skipped:', e); }
    try { VRMUtils.combineSkeletons(currentVrm.scene); } catch (e) { console.warn('VRM skeleton optimization skipped:', e); }
    try { VRMUtils.combineMorphs(currentVrm); } catch (e) { console.warn('VRM morph optimization skipped:', e); }
    currentVrm.scene.traverse((object) => { if (object.isMesh) object.frustumCulled = false; });
    scene.add(currentVrm.scene);
    currentVrm.scene.updateMatrixWorld(true);
    const bounds = new THREE.Box3().setFromObject(currentVrm.scene);
    const size = bounds.getSize(new THREE.Vector3());
    if (!Number.isFinite(size.y) || size.y < 0.1) throw new Error('The VRM model has an invalid or empty bounding box.');
    const center = bounds.getCenter(new THREE.Vector3());
    currentVrm.scene.position.x -= center.x;
    currentVrm.scene.position.z -= center.z;
    currentVrm.scene.position.y -= bounds.min.y;
    frameBox = { size };
    captureBones(currentVrm);
    fitCamera();
    resize();

    const initialState = Object.prototype.hasOwnProperty.call(TEXT, currentState) ? currentState : 'idle';
    currentState = 'idle';
    setFace(STATE_POSES.idle.face);
    stateChanged(initialState);
    if (resizeObserver) resizeObserver.disconnect();
    if (window.ResizeObserver) {
      resizeObserver = new ResizeObserver(() => requestAnimationFrame(resize));
      resizeObserver.observe(stage);
    }
    window.addEventListener('resize', () => requestAnimationFrame(resize));
    document.querySelectorAll('[data-motion]').forEach((button) => {
      button.addEventListener('click', () => playMotion(button.dataset.motion));
    });
    clock = new THREE.Clock();
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    $('loading').style.display = 'none';
    window.__wfRendererReady = true;
    try { bridge?.reportReady?.(); } catch (_) {}
    animate();
  }

  stateChanged(currentState);
  boot().catch((error) => fatal(`Nara VRM failed to start: ${(error && error.message) || error}`));
})();
