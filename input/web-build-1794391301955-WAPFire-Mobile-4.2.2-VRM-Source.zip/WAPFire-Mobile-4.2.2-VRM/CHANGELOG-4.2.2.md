# WAPFire Mobile 4.2.2 — VRM Assistant

- Replaced the Hiyori Live2D/Nara fallback route with one Three.js + @pixiv/three-vrm renderer.
- Embedded the exact user-supplied `model.vrm` as Nara's 3D character. No AvatarSample_A/B assets are referenced.
- Added VRM 0.0 compatibility, MToon materials, spring-bone update, facial expression mapping and mobile-oriented mesh optimizations.
- Bound WAPFire states to facial/body reactions: idle, scanning, connecting, success, correct/wrong password, warning, attack alert, offline and setup.
- Added manual motion preview controls in the full Assistant view: Wave, Peace, Scratch, Stretch, Spin, Squat, Model Pose and Full Body. The model is centered using its measured bounds.
- Pinned renderer packages are staged during Gradle preBuild and then served from APK assets; runtime WebView requests remain local/offline.
- Removed the old Gradle preBuild dependency that downloaded the LivLiv model package, because the active renderer no longer uses it.
- Kept attack reactions non-contact and non-combat to respect the uploaded model's embedded license metadata.

## Build note

The VRM runtime package files are fetched from jsDelivr (with unpkg fallback) during `:app:preBuild`. A machine building the APK needs access to one of those CDNs once. The installed APK does not fetch the libraries or model from the Internet.

## Model license note

The selected model metadata requires credit to Yuuki and disallows redistribution of the model file. Keep the VRM for personal/local builds unless separate redistribution permission is obtained. See `app/src/main/assets/assistant/vrm/MODEL-LICENSE.txt`.
