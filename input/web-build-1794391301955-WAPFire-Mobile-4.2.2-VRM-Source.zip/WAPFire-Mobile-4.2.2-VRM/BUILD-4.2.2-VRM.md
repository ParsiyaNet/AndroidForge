# WAPFire Mobile 4.2.2 — VRM build notes

## Build

- Windows: `gradlew.bat :app:assembleDebug`
- macOS/Linux: `./gradlew :app:assembleDebug`

The `preBuild` task stages pinned Three.js 0.180.0 and @pixiv/three-vrm 3.5.5 ES modules under `app/src/main/assets/assistant/vrm/vendor/`. The build computer needs internet access to jsDelivr or unpkg for this first-time staging step. The resulting APK loads the model and JavaScript modules from packaged assets; the assistant renderer does not need internet access at runtime.

## Assistant motions

The full Assistant tab includes an in-app preview panel for Wave, Peace, Scratch, Stretch, Spin, Squat, Model Pose, and Full Body framing. WAPFire event states also drive facial and body reactions automatically. Attack alerts use non-contact gestures only.

## Model license

`app/src/main/assets/assistant/vrm/model.vrm` is the exact VRM file supplied for this local project. Its embedded metadata credits Yuuki, requires attribution, and disallows redistribution. Do not publish or share an APK containing this model unless the creator separately permits redistribution. See `app/src/main/assets/assistant/vrm/MODEL-LICENSE.txt`.
