package io.wapfire.mobile.ui.screens

import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.model.tx
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.FileNotFoundException
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ASSET_PREFIX = "/assets/assistant/"
private const val ASSISTANT_URL = "https://appassets.androidplatform.net/assets/assistant/assistant-live.html"
private const val TAG = "WapFireAssistant"

/**
 * A same-origin, appassets-style WebView loader. Every byte served to this WebView comes from
 * app/src/main/assets/assistant. The renderer, model, textures and HTML all work with networking
 * blocked, and ES-module imports keep a normal HTTPS origin instead of file://'s opaque origin.
 */
private class LivLivWebView(
    context: Context,
    private val fa: Boolean,
    private val compact: Boolean,
    initialState: String
) : WebView(context) {
    private var pageReady = false
    private var pendingState: String = initialState

    init {
        setBackgroundColor(AndroidColor.TRANSPARENT)
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            databaseEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            // Do not enable blockNetworkLoads here: appassets.androidplatform.net is a virtual
            // HTTPS origin whose requests are fulfilled locally by shouldInterceptRequest.
            // The request interceptor below rejects every non-local host, while the page CSP
            // also limits scripts, images, styles and fetch() to this same local origin.
            blockNetworkLoads = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = true
        }
        webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                val level = when (message.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> Log.ERROR
                    ConsoleMessage.MessageLevel.WARNING -> Log.WARN
                    else -> Log.DEBUG
                }
                Log.println(level, TAG, "${message.message()} (${message.sourceId()}:${message.lineNumber()})")
                return true
            }
        }
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return blockedResponse(400, "Bad Request")
                if (uri.host != ASSET_HOST || uri.scheme != "https") {
                    return blockedResponse(403, "External resource blocked")
                }
                val path = uri.path ?: return blockedResponse(404, "Not Found")
                if (!path.startsWith(ASSET_PREFIX)) return blockedResponse(404, "Not Found")
                val encoded = path.removePrefix(ASSET_PREFIX)
                val relative = runCatching { URLDecoder.decode(encoded, StandardCharsets.UTF_8.name()) }.getOrNull()
                    ?: return blockedResponse(400, "Bad Path")
                if (relative.isBlank() || relative.startsWith("/") || relative.split('/').any { it == ".." || it == "." }) {
                    return blockedResponse(403, "Invalid asset path")
                }
                val assetPath = "assistant/$relative"
                return try {
                    val mime = mimeType(relative)
                    val charset = if (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) "UTF-8" else null
                    val headers = mapOf(
                        "Access-Control-Allow-Origin" to "https://$ASSET_HOST",
                        "X-Content-Type-Options" to "nosniff",
                        "Cache-Control" to "no-store"
                    )
                    WebResourceResponse(mime, charset, 200, "OK", headers, context.assets.open(assetPath))
                } catch (_: FileNotFoundException) {
                    blockedResponse(404, "Asset not found")
                } catch (error: Exception) {
                    Log.w(TAG, "Could not serve $assetPath", error)
                    blockedResponse(500, "Asset error")
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // This WebView is a closed local viewer. Do not let taps navigate to the network.
                return request?.url?.host != ASSET_HOST
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                Log.d(TAG, "Loading local assistant page: $url")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                Log.d(TAG, "Assistant page committed: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageReady = true
                Log.d(TAG, "Assistant page finished: $url")
                applyPendingState()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.e(TAG, "WebView resource error mainFrame=${request?.isForMainFrame} url=${request?.url} code=${error?.errorCode} description=${error?.description}")
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                response: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, response)
                Log.e(TAG, "WebView HTTP error mainFrame=${request?.isForMainFrame} url=${request?.url} status=${response?.statusCode} reason=${response?.reasonPhrase}")
            }
        }
        val language = if (fa) "fa" else "en"
        val compactFlag = if (compact) "1" else "0"
        loadUrl("$ASSISTANT_URL?lang=$language&compact=$compactFlag&state=${Uri.encode(initialState)}")
    }

    fun setAssistantState(state: String) {
        if (pendingState == state) return
        pendingState = state
        if (pageReady) applyPendingState()
    }

    private fun applyPendingState() {
        val jsonState = JSONObject.quote(pendingState)
        evaluateJavascript("window.wapfireSetState && window.wapfireSetState($jsonState);", null)
    }

    private fun blockedResponse(code: Int, reason: String) = WebResourceResponse(
        "text/plain", "UTF-8", code, reason,
        mapOf("Cache-Control" to "no-store"),
        ByteArrayInputStream(ByteArray(0))
    )

    private fun mimeType(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html"
        "js", "mjs" -> "application/javascript"
        "json" -> "application/json"
        "webp" -> "image/webp"
        "png" -> "image/png"
        "svg" -> "image/svg+xml"
        "livliv", "zip" -> "application/vnd.livliv.model+zip"
        "txt", "md" -> "text/plain"
        else -> "application/octet-stream"
    }
}

@Composable
internal fun LivLivAssistantWebView(
    fa: Boolean,
    state: String,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val view = remember(context, fa, compact) { LivLivWebView(context, fa, compact, state) }

    DisposableEffect(view) {
        onDispose {
            runCatching {
                view.stopLoading()
                view.onPause()
                view.loadUrl("about:blank")
                view.removeAllViews()
                view.destroy()
            }
        }
    }

    AndroidView(
        factory = { view },
        update = { it.setAssistantState(state) },
        modifier = modifier
    )
}

@Composable
internal fun LivLivAssistantOverviewCard(
    p: Palette,
    fa: Boolean,
    state: String,
    onOpenAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("WAPFIRE · LIVE ASSISTANT", color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(tx(fa, "Sena is watching your network", "سنا مراقب شبکه‌ات است"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                tx(fa, "OPEN ↗", "نمایش ↗"),
                color = p.blue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(p.accentSoft.copy(alpha = .7f))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .then(Modifier)
                    .clickable(onClick = onOpenAssistant)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(218.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF071629))
                .border(1.dp, Color(0xFF23608D), RoundedCornerShape(22.dp))
                .padding(1.dp)
        ) {
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = true,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp))
            )
        }
        Text(
            tx(fa, "Character: Sena · LivLiv (livliv.ai)", "کاراکتر: Sena · LivLiv (livliv.ai)"),
            color = p.muted.copy(alpha = .75f), fontSize = 8.sp,
            modifier = Modifier.align(Alignment.End)
        )
    }
}

