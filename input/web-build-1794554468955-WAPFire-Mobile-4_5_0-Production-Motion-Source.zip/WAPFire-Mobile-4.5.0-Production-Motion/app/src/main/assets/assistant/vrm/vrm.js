/* WAPFire 4.5.0 - VRM (VRoid) assistant renderer: three.js + @pixiv/three-vrm.
 * Same native contract as the Hiyori and Nara pages:
 *   window.wapfireSetState(state)  /  WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg)
 * Emotions, gestures and all natural motion live in vrm-pose.js (pure logic). This file loads the model, frames the camera
 * like the Nara screenshots, measures the rig's axis signs at runtime, and maps pose frames onto expressions, bones and eyes.
 * URL parameters: lang=fa|en, compact=1|0, state=<state>, zoom=<n>, dy=<n>  (zoom/dy are fine-tuning aids). */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { create as createPose } from './vrm-pose.js';

const BUILD = '4.5.0';
window.__wfPreflightStarted = true;
window.__wfAssistantBuildVersion = BUILD;
window.__wfAssistantDocumentExpected = true;
window.__wfEngineBooted = true;

const q = new URLSearchParams(location.search);
const fa = q.get('lang') !== 'en';
const compact = q.get('compact') !== '0';
const $ = (id) => document.getElementById(id);
const bridge = window.WapFireNative;
document.documentElement.lang = fa ? 'fa' : 'en';
document.body.className = compact ? 'compact' : 'full';

const D = Math.PI / 180;
const userZoom = parseFloat(q.get('zoom') || '1') || 1;
const userDy = parseFloat(q.get('dy') || '0') || 0;
let pendingState = q.get('state') || 'idle';
let ready = false;

function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
function fatal(message) {
  const text = String(message).slice(0, 400);
  console.error(text);
  const box = $('loading');
  if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
  report(text);
  try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
}
window.addEventListener('error', (e) => { if (!ready) fatal('VRM error: ' + (e.message || e)); });
window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('VRM error: ' + ((e.reason && e.reason.message) || e.reason)); });

/* ---------- states (labels identical to the Hiyori page) ---------- */
const PILL = {
  idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
  success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
  warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
  setup: ['Setup required', 'نیازمند راه‌اندازی']
};
const poseEngine = createPose();
const nowSec = () => performance.now() / 1000;

let shownState = null;
function showState(name) {
  const state = PILL[name] ? name : 'idle';
  pendingState = state;
  if (state === shownState) return;            // the same state again must not restart its gestures
  shownState = state;
  $('shell').dataset.state = state;
  $('stateText').textContent = PILL[state][fa ? 1 : 0];
  poseEngine.setState(state, nowSec());
}
window.wapfireSetState = (state) => { try { showState(String(state)); } catch (e) { report(String(e)); } };

/* ---------- three.js scene ---------- */
const canvas = $('stage');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setClearColor(0x000000, 0);
canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (!ready) fatal('WebGL context lost while starting.'); });

const scene = new THREE.Scene();
const FOV = 20;
const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 30);
const key = new THREE.DirectionalLight(0xffffff, Math.PI);
key.position.set(0.5, 0.9, 1.2).normalize();
scene.add(key);
scene.add(new THREE.AmbientLight(0xffffff, 0.45));

let vrm = null;
let facing = 1;               // +1 when the character looks toward +Z (the expected case after rotateVRM0)
const hipsRest = { x: 0, y: 0, z: 0 };
// L/R: arm signs. pitch/yaw/roll: rig axis -> world semantics used by vrm-pose.js. lat/depth: hips x / z -> screen right / toward camera.
const SIGN = { L: { down: 1, fwd: 1 }, R: { down: 1, fwd: 1 }, pitch: 1, yaw: 1, roll: 1, lat: 1, depth: 1 };
const eyeRange = { yaw: 9, pitch: 9 };   // lookAt input degrees needed per degree of eye rotation (xRange / yRange of the model)

/* ---------- framing (measured from the VRM mesh: hair/ear top 1.495 m, chin 1.23 m, hair half-width 0.207 m) ---------- */
const M = { top: 1.495, chin: 1.23, halfW: 0.207 };
// Targets taken from the Nara screenshots, as a fraction of the stage height: where the head starts and how tall it is.
const FRAME = {
  full: { top: 0.188, head: 0.32, maxW: 0.92 },
  compact: { top: 0.022, head: 0.41, maxW: 0.92 }
};
function fit() {
  const box = $('stageBox');
  const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
  renderer.setSize(W, H, false);
  camera.aspect = W / H;
  const cfg = compact ? FRAME.compact : FRAME.full;
  const headH = M.top - M.chin;
  let worldH = headH / cfg.head;                              // world height visible in the stage
  worldH = Math.max(worldH, (2 * M.halfW / cfg.maxW) / camera.aspect) / userZoom;   // never crop the hair width
  const topY = M.top + (cfg.top + userDy) * worldH;           // world y at the top edge of the stage
  const cy = topY - worldH / 2;
  const dist = (worldH / 2) / Math.tan(FOV * D / 2);
  camera.position.set(0, cy, facing * dist);
  camera.lookAt(0, cy, 0);
  camera.updateProjectionMatrix();
}
window.wapfireFrame = (zoom, dy) => { /* debugging aid */ fit(); return { zoom, dy }; };

/* ---------- humanoid helpers ---------- */
const nb = (name) => vrm.humanoid.getNormalizedBoneNode(name);
const rawBone = (name) => vrm.humanoid.getRawBoneNode(name);
const tmpV = new THREE.Vector3();
const posOf = (obj) => obj.getWorldPosition(tmpV.set(0, 0, 0)).clone();
function settle() { vrm.humanoid.update(); vrm.scene.updateMatrixWorld(true); }

/* The VRM may mirror left/right, pitch, yaw or roll depending on how the normalized rig was built. Rather than assume, measure:
 * lower the arm with +angle and see whether the hand goes down; swing it with +angle and see whether it moves forward;
 * pitch / yaw / roll the head and see where the eyes go; move the hips and see where the head goes.
 * vrm-pose.js speaks WORLD semantics: pitch + = nose down, yaw + = toward screen right, roll + = top of head toward screen left. */
function calibrate() {
  const head = rawBone('head'), eyeL = rawBone('leftEye') || head, eyeR = rawBone('rightEye') || eyeL;
  const hp = posOf(head), ep = posOf(eyeL);
  facing = (ep.z - hp.z) >= 0 ? 1 : -1;
  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const ua = nb(name + 'UpperArm'), hand = rawBone(name + 'Hand');
    if (!ua || !hand) continue;
    ua.rotation.order = 'ZYX';
    ua.rotation.set(0, 0, 0.9); settle(); const yP = posOf(hand).y;
    ua.rotation.set(0, 0, -0.9); settle(); const yM = posOf(hand).y;
    SIGN[side].down = yP < yM ? 1 : -1;
    ua.rotation.set(0, 0.6, 0); settle(); const zP = posOf(hand).z;
    ua.rotation.set(0, -0.6, 0); settle(); const zM = posOf(hand).z;
    SIGN[side].fwd = (zP - zM) * facing > 0 ? 1 : -1;
    ua.rotation.set(0, 0, 0);
  }
  const hd = nb('head');
  if (hd) {
    const mid = () => posOf(eyeL).add(posOf(eyeR)).multiplyScalar(0.5);
    hd.rotation.set(0.5, 0, 0); settle(); const yP = posOf(eyeL).y;
    hd.rotation.set(-0.5, 0, 0); settle(); const yM = posOf(eyeL).y;
    SIGN.pitch = yP < yM ? 1 : -1;                       // + engine pitch = nose down
    // yaw: the eyes sit in front of the head pivot, so turning the head moves them sideways
    hd.rotation.set(0, 0.4, 0); settle(); const dxY = (mid().x - posOf(head).x) * facing;
    SIGN.yaw = dxY >= 0 ? 1 : -1;                        // + engine yaw = toward screen right
    // roll: the eyes sit above the pivot, so tilting the head moves them sideways
    hd.rotation.set(0, 0, 0.4); settle(); const dxZ = (mid().x - posOf(head).x) * facing;
    SIGN.roll = dxZ < 0 ? 1 : -1;                        // + engine roll = top of head toward screen left
    hd.rotation.set(0, 0, 0);
  }
  const hips = nb('hips');
  if (hips && hd) {
    const base = hips.position.clone(), h0 = posOf(head);
    hips.position.set(base.x + 0.05, base.y, base.z); settle(); const dx = (posOf(head).x - h0.x) * facing;
    SIGN.lat = dx >= 0 ? 1 : -1;
    hips.position.set(base.x, base.y, base.z + 0.05); settle(); const dz = (posOf(head).z - h0.z) * facing;
    SIGN.depth = dz >= 0 ? 1 : -1;
    hips.position.copy(base);
  }
  readEyeRanges();
  settle();
}

/* three-vrm maps lookAt degrees linearly: eye rotation = outputScale * (angle / inputMaxValue). VRoid models have a small output
 * scale (8-12 deg) over a 90 deg input, so the page has to ask for angle * (inputMax / outputScale) to get a visible eye movement. */
function readEyeRanges() {
  try {
    const ap = vrm.lookAt && vrm.lookAt.applier;
    if (ap && ap.rangeMapHorizontalOuter && ap.rangeMapVerticalUp) {
      const hy = (ap.rangeMapHorizontalOuter.outputScale + ap.rangeMapHorizontalInner.outputScale) / 2;
      const vy = (ap.rangeMapVerticalUp.outputScale + ap.rangeMapVerticalDown.outputScale) / 2;
      if (hy > 0.5) eyeRange.yaw = ap.rangeMapHorizontalOuter.inputMaxValue / hy;
      if (vy > 0.5) eyeRange.pitch = ap.rangeMapVerticalUp.inputMaxValue / vy;
    }
  } catch (e) { /* keep the defaults */ }
}

/* ---------- expressions ---------- */
let exprNames = new Set();
let surprisedName = null;
function setExpr(name, v) { if (name && exprNames.has(name)) vrm.expressionManager.setValue(name, v); }

/* ---------- applying a pose frame ---------- */
const FINGERS = [['Index', 0.75], ['Middle', 0.9], ['Ring', 1.0], ['Little', 1.1]];   // little fingers curl most
const CURL = [1.25, 1.35, 0.8];     // proximal, intermediate, distal (radians at curl = 1)
const THUMB = [[0, 0.8, 0], [0, 1.0, 0], [0, 0.7, 0]];   // thumb metacarpal, proximal, distal [x, y, z] at curl = 1: tucks the thumb into the fist (y mirrored per side)
const clampN = (v, a, b) => (v < a ? a : v > b ? b : v);
function setBone(name, x, y, z) { const n = nb(name); if (n) n.rotation.set(x, y, z); }

function applyFrame(f) {
  const E = f.expr;
  setExpr('happy', E.happy); setExpr('sad', E.sad); setExpr('angry', E.angry); setExpr('relaxed', E.relaxed);
  setExpr(surprisedName, E.surprised); setExpr('blink', E.blink);
  setExpr('aa', E.aa); setExpr('ih', E.ih); setExpr('ou', E.ou); setExpr('ee', E.ee); setExpr('oh', E.oh);

  const sp = SIGN.pitch, sy = SIGN.yaw, sr = SIGN.roll;
  const put = (name, v) => setBone(name, v.x * sp, v.y * sy, v.z * sr);
  const R = f.rot;
  put('head', R.head); put('neck', R.neck); put('chest', R.chest); put('upperChest', R.upperChest); put('spine', R.spine); put('hips', R.hips);
  const hips = nb('hips');
  if (hips) hips.position.set(hipsRest.x + f.hips.x * SIGN.lat, hipsRest.y + f.hips.y, hipsRest.z + f.hips.z * SIGN.depth);

  for (const [side, name] of [['L', 'left'], ['R', 'right']]) {
    const s = SIGN[side], a = f.arm[side];
    const ua = nb(name + 'UpperArm'), la = nb(name + 'LowerArm'), sh = nb(name + 'Shoulder'), hand = nb(name + 'Hand');
    if (ua) { ua.rotation.order = 'ZYX'; ua.rotation.set(0, s.fwd * a.fwd, s.down * a.down); }
    if (la) { la.rotation.order = 'ZYX'; la.rotation.set(a.twist, s.fwd * a.elbowF, -s.down * a.elbowU); }
    if (sh) sh.rotation.set(0, 0, -s.down * f.shoulders[side]);
    if (hand) hand.rotation.set(0, 0, s.down * a.wrist);
    FINGERS.forEach(([finger, weight], fi) => {
      const curl = clampN(a.curl + a.fing[fi], 0, 1) * weight;
      ['Proximal', 'Intermediate', 'Distal'].forEach((seg, i) => {
        const bone = nb(name + finger + seg);
        if (bone) bone.rotation.set(0, 0, s.down * curl * CURL[i]);
      });
    });
    const thumbCurl = clampN(a.curl, 0, 1);
    ['Metacarpal', 'Proximal', 'Distal'].forEach((seg, i) => {
      const bone = nb(name + 'Thumb' + seg);
      if (bone) bone.rotation.set(THUMB[i][0] * thumbCurl, THUMB[i][1] * thumbCurl * s.down, THUMB[i][2] * thumbCurl * s.down);
    });
    const ul = nb(name + 'UpperLeg'), ll = nb(name + 'LowerLeg');     // tiny knee give, only visible if the camera ever pulls back
    if (ul) ul.rotation.set(0, 0, 0);
    if (ll) ll.rotation.set(f.legs[side].knee * sp, 0, 0);
  }
  if (vrm.lookAt) {
    vrm.lookAt.yaw = clampN(f.eye.yaw * eyeRange.yaw, -90, 90);
    vrm.lookAt.pitch = clampN(f.eye.pitch * eyeRange.pitch, -90, 90);
  }
}

/* ---------- main loop ---------- */
let last = performance.now();
let lastRender = 0;
let lastFrame = null;
let pixelRatio = renderer.getPixelRatio();
const perf = { frames: 0, acc: 0, checked: 0 };
function tick() {
  const nowMs = performance.now();
  if (nowMs - lastRender < 14) return;                      // no point rendering faster than ~60 fps (saves battery on 90/120 Hz phones)
  lastRender = nowMs;
  const dt = Math.min(0.1, Math.max(0.001, (nowMs - last) / 1000));
  last = nowMs;
  if (vrm) {
    lastFrame = poseEngine.update(nowMs / 1000, dt);
    if (!window.__wfFreeze) applyFrame(lastFrame);
    vrm.update(Math.min(dt, 0.05));
    // Choppy animation never looks natural: if the phone cannot keep ~40 fps, lower the render resolution (never raised again).
    if (ready && perf.checked < 3 && pixelRatio > 1) {
      perf.frames++; perf.acc += dt;
      if (perf.frames >= 90) {
        perf.checked++;
        if (perf.acc / perf.frames > 0.026) {
          pixelRatio = Math.max(1, pixelRatio - 0.5); renderer.setPixelRatio(pixelRatio); fit();
          report('Resolution lowered to ' + pixelRatio + 'x for smoother motion.');
        }
        perf.frames = 0; perf.acc = 0;
      }
    }
  }
  if (!window.__wfSkipRender) renderer.render(scene, camera);
}

window.wapfireVrmInfo = () => JSON.stringify({ build: BUILD, facing, sign: SIGN, eyeRange, expressions: Array.from(exprNames), surprised: surprisedName });
window.wapfireMotionInfo = () => JSON.stringify(poseEngine.debug());
// Dev aid: where does the hand land on screen (normalised -1..1) for these arm angles (degrees)? Used to keep gestures inside the frame.
window.wapfireProbe = (side, down, fwd, elbowF, elbowU) => {
  const name = side === 'L' ? 'left' : 'right', s = SIGN[side];
  const ua = nb(name + 'UpperArm'), la = nb(name + 'LowerArm'), hand = rawBone(name + 'Hand');
  if (!ua || !la || !hand) return null;
  ua.rotation.order = 'ZYX'; ua.rotation.set(0, s.fwd * fwd * D, s.down * down * D);
  la.rotation.order = 'ZYX'; la.rotation.set(0, s.fwd * elbowF * D, -s.down * elbowU * D);
  settle(); camera.updateMatrixWorld(true);
  const v = posOf(hand).project(camera);
  return JSON.stringify([+v.x.toFixed(3), +v.y.toFixed(3)]);
};
// Dev aid: freeze the engine and show one static arm pose on both sides (degrees), e.g. wapfireFreezePose({down:70,fwd:60,elbowF:80,elbowU:0,curl:0.3})
window.wapfireFreezePose = (arm) => {
  window.__wfFreeze = true;
  const f = JSON.parse(JSON.stringify(lastFrame));
  const r = (v) => (v || 0) * D;
  for (const side of ['L', 'R']) Object.assign(f.arm[side], { down: r(arm.down), fwd: r(arm.fwd), elbowF: r(arm.elbowF), elbowU: r(arm.elbowU), twist: r(arm.twist), wrist: r(arm.wrist), curl: arm.curl || 0.28, fing: [0, 0, 0, 0] });
  applyFrame(f);
};
window.wapfireTrigger = (slot, kind) => poseEngine.trigger(slot, kind, nowSec());   // preview: wapfireTrigger('beat', 'clap'), ('event', 'laugh'), ('body', 'nod')

/* ---------- boot ---------- */
async function boot() {
  report(fa ? 'در حال بارگذاری مدل VRM…' : 'Loading VRM model…');
  const loader = new GLTFLoader();
  loader.register((parser) => new VRMLoaderPlugin(parser));
  let lastPct = -1;
  const gltf = await loader.loadAsync('./model/nara.vrm', (e) => {
    if (!e.lengthComputable) return;
    const pct = Math.floor((e.loaded / e.total) * 100);
    if (pct !== lastPct && pct % 10 === 0) { lastPct = pct; report((fa ? 'بارگذاری مدل VRM… ' : 'Loading VRM model… ') + pct + '%'); }
  });
  vrm = gltf.userData.vrm;
  if (!vrm) throw new Error('The file is not a VRM model.');
  if (VRMUtils.removeUnnecessaryVertices) VRMUtils.removeUnnecessaryVertices(gltf.scene);
  if (VRMUtils.combineSkeletons) VRMUtils.combineSkeletons(gltf.scene);
  else if (VRMUtils.removeUnnecessaryJoints) VRMUtils.removeUnnecessaryJoints(gltf.scene);
  VRMUtils.rotateVRM0(vrm);                       // VRM 0.x models face -Z; turn them toward the camera
  vrm.scene.traverse((o) => { o.frustumCulled = false; });
  scene.add(vrm.scene);

  const em = vrm.expressionManager;
  exprNames = new Set(em ? Object.keys(em.expressionMap || {}) : []);
  surprisedName = ['Surprised', 'surprised'].find((n) => exprNames.has(n)) || null;
  if (nb('hips')) hipsRest.x = nb('hips').position.x, hipsRest.y = nb('hips').position.y, hipsRest.z = nb('hips').position.z;
  settle();
  calibrate();
  report('VRM ready: ' + window.wapfireVrmInfo());

  fit();
  if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
  window.addEventListener('resize', () => requestAnimationFrame(fit));
  showState(pendingState);
  renderer.setAnimationLoop(tick);
  // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  fit();
  ready = true;
  window.__wfRendererReady = true;
  $('loading').style.display = 'none';
  try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
}

showState(pendingState);
boot().catch((error) => fatal('VRM failed to start: ' + ((error && error.message) || error)));
