/* WAPFire 4.5.0 - VRM character motion engine (pure logic, no DOM, no three.js).
 *
 * create(seed?) returns { setState(name, now), update(now, dt) -> frame, debug(), trigger(slot, kind, now) }.
 *
 * 4.4.0 fixed the "perfect loop" (layered breathing / weight shift / noise / gaze / blinking). The idle state became natural, but the
 * other states still looked like game-engine poses: one arm pose held rigidly for as long as the state lasted, both sides identical,
 * a frozen face, and a gesture every few seconds that had nothing to do with where the character looked.
 * 4.5.0 keeps the 4.4.0 base (the idle everybody liked) and adds what hand-keyed production animation has:
 *
 *   BEATS         a beat is a small choreography: gaze, head, torso, both arms and the face are timed together
 *                 (look -> head follows -> hand rises -> expression -> settle). Every state has its own menu of 6-10 beats and
 *                 picks them at random with random timing, amplitude and side, so the character is always "doing something"
 *                 that has intent, and never repeats the same thing twice in a row.
 *   ARM POSES     a library of real poses (hands clasped, chin, chest, mouth, fists, wave, cheer ...). Arms move pose-to-pose
 *                 with anticipation (a small move the other way first), overshoot and settle; left and right are scheduled
 *                 independently, so a gesture is never perfectly symmetrical. Between beats the arms return to the state's rest pose.
 *   FOLLOW-THROUGH  wrists lag the forearm, the head lags the torso, shoulders lag a hop, hanging arms swing with the body.
 *   MOTIFS        continuous rhythmic body language with jittered tempo (success: happy bounce, offline: slow sway ...).
 *   FACE ACTING   emotions breathe (+/-10 %), the mouth has its own small shapes (hum, gasp, giggle, tsk), brows flick.
 *
 * Frame conventions (all radians unless noted; WORLD semantics, vrm.js converts to the rig):
 *   pitch (x): + = nose/chest toward the floor      yaw (y): + = toward screen right      roll (z): + = top toward screen left
 *   hips.x: + = screen right, hips.z: + = toward the camera, hips.y: + = up (metres)
 *   shoulders.L/R: raise            eye.yaw/eye.pitch: DEGREES of eye rotation wanted (pitch + = down)
 *   arm: down (0 = T-pose, 1.22 = relaxed), fwd, elbowF, elbowU, twist, wrist, curl (0..1), fing[4] per-finger curl offsets
 * Expression names follow three-vrm: happy, sad, angry, relaxed, surprised (custom), blink and the mouth shapes aa ih ou ee oh.
 */
const D = Math.PI / 180;
const rad = (v) => (v || 0) * D;
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const smoother = (x) => { x = clamp(x, 0, 1); return x * x * x * (x * (x * 6 - 15) + 10); };
const bell = (u) => { const s = Math.sin(Math.PI * clamp(u, 0, 1)); return s * s; };
const trap = (u, a) => smoother(u / (a || 0.25)) * smoother((1 - u) / (a || 0.25));


/* ------------------------------------------------------------------------------------------------ random + noise */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeNoise(rnd) {
  const G = new Float32Array(256);
  for (let i = 0; i < 256; i++) G[i] = rnd() * 2 - 1;
  return (x) => {
    const i0 = Math.floor(x), f = x - i0;
    const a = G[i0 & 255], b = G[(i0 + 1) & 255];
    const u = f * f * f * (f * (f * 6 - 15) + 10);
    return clamp(2.4 * (a * f * (1 - u) + b * (f - 1) * u), -1, 1);
  };
}
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) % 997; }

const EXPR = ['happy', 'sad', 'angry', 'relaxed', 'surprised', 'aa', 'ih', 'ou', 'ee', 'oh'];
const STATE_NAMES = ['idle', 'scanning', 'connecting', 'success', 'password_success', 'password_warning', 'warning', 'angry', 'offline', 'setup'];
const ZERO2 = { yaw: 0, pitch: 0 };

/* ------------------------------------------------------------------------------------------------ arm pose library (degrees)
 * The right arm is the one on the left of the screen. The same numbers drive the left arm (mirrored by vrm.js), and every pose was
 * checked with window.wapfireProbe / wapfireFreezePose so the hands land inside the framed picture.
 * osc: [channel, amplitude (rad, or 0..1 for curl), Hz, ramp-in seconds, delay seconds]; live = how much the pose drifts while held. */
const ARM_CH = ['down', 'fwd', 'elbowF', 'elbowU', 'twist', 'wrist', 'curl'];
const mk = (down, fwd, elbowF, elbowU, o) => Object.assign({ down, fwd, elbowF, elbowU, twist: 0, wrist: 0, curl: 0.28, live: 1 }, o || {});
const ARMP = {
  hang: mk(70, 3, 8, 0),
  limp: mk(77, 0, 4, 0, { curl: 0.12 }),
  hangIn: mk(80, 20, 50, 0),
  belt: mk(80, 0, 100, 60),
  clasp: mk(80, 10, 130, 60, { live: 1.3 }),
  chest: mk(80, 20, 130, 40),
  chin: mk(60, 50, 90, 0, { live: 1.6 }),
  tapChin: mk(60, 50, 90, 0, { live: 1.6, osc: [['curl', 0.16, 3.1, 0.5, 0.5]] }),
  cheek: mk(62, 52, 100, 0, { live: 1.5 }),
  mouth: mk(60, 60, 120, 20, { live: 1.4 }),
  peek: mk(70, 60, 120, 0, { live: 1.3 }),
  present: mk(60, 40, 80, 0, { live: 1.6 }),
  pray: mk(50, 30, 130, 20, { live: 1.3 }),
  fist: mk(70, 60, 70, 0, { curl: 1, live: 1.3 }),
  fistShake: mk(70, 60, 70, 0, { curl: 1, live: 1, osc: [['elbowF', 0.2, 4.2, 0.2, 0]] }),
  fistLow: mk(78, 32, 58, 0, { curl: 1 }),
  wave: mk(25, 58, 35, 72, { osc: [['elbowU', 0.34, 2.4, 0.4, 0.15]] }),
  beckon: mk(60, 45, 60, 25, { live: 1.4, osc: [['elbowF', 0.42, 2.3, 0.3, 0.2]] }),
  cheerV: mk(20, 60, 40, 70, { live: 1.3, osc: [['elbowU', 0.1, 3.2, 0.5, 0.3]] }),
  cheer: mk(40, 60, 60, 40, { live: 1.3 }),
  back: mk(82, -30, 40, 0),
  wide: mk(48, 12, 34, 0, { live: 1.5 }),
  wring: mk(80, 10, 130, 60, { live: 1.3, osc: [['twist', 0.25, 1.3, 0.5, 0], ['wrist', 0.2, 1.7, 0.5, 0]] }),
  talk: mk(66, 40, 70, 0, { live: 1.4, osc: [['elbowF', 0.16, 1.1, 0.5, 0], ['fwd', 0.12, 0.8, 0.5, 0.2], ['wrist', 0.15, 1.5, 0.5, 0]] }),
  tap: mk(80, 0, 100, 60, { osc: [['curl', 0.2, 3.2, 0.4, 0.3]] })
};

/* ------------------------------------------------------------------------------------------------ base posture per state (degrees) */
const POSES = {
  idle: { e: { happy: 0.14 }, blink: 0, head: { x: 0, y: 0, z: 0 } },
  scanning: { e: { angry: 0.1 }, blink: 0.1, head: { x: 3, y: 0, z: 0 }, chest: { x: 1.5 } },
  connecting: { e: { happy: 0.1, relaxed: 0.3 }, blink: 0, head: { x: -2, y: 4, z: 6 }, gaze: { yaw: 0, pitch: -5 } },
  success: { e: { happy: 0.5, relaxed: 0.2 }, blink: 0, head: { x: -4, y: 0, z: 4 }, chest: { x: -2 } },
  password_success: { e: { happy: 0.6, relaxed: 0.2 }, blink: 0, head: { x: 0, y: 0, z: 3 } },
  password_warning: { e: { sad: 0.6, surprised: 0.1 }, blink: 0, head: { x: 4, y: 0, z: -6 }, gaze: { yaw: 0, pitch: 3 }, shoulders: 3 },
  warning: { e: { surprised: 0.8, sad: 0.1 }, blink: 0, head: { x: -5, y: 0, z: 0 }, chest: { x: -4 }, shoulders: 7 },
  angry: { e: { angry: 0.85 }, blink: 0.2, head: { x: 11, y: 0, z: 0 }, neck: { x: 4 }, chest: { x: 7 }, spine: { x: 3 }, shoulders: 4, gaze: { yaw: 0, pitch: -6 } },
  offline: { e: { sad: 0.9 }, blink: 0.3, head: { x: 11, y: 0, z: -5 }, neck: { x: 3 }, chest: { x: 7 }, spine: { x: 4 }, shoulders: -3, gaze: { yaw: 0, pitch: 5 } },
  setup: { e: { happy: 0.5, relaxed: 0.2 }, blink: 0, head: { x: -2, y: 0, z: 6 } }
};

/* Per-state behaviour: look mode, breathing [period s, depth], mean blink interval, noise strength, weight shift [min s, max s, amount],
 * spring speed, rest arm poses [left, right], the micro-event slots of 4.4.0 (body / arm / face), the beat menu, and an optional motif. */
const BEHAVIOUR = {
  idle: { look: 'viewer', breath: [4.4, 1], blink: 3.8, noise: 1, shift: [5, 10, 1], speed: 1, rest: ['hang', 'hang'],
    body: [['tilt', 3], ['nod', 1.2], ['shrug', 0.8], ['sigh', 0.9], ['lean', 1.2], ['neckroll', 1]], bodyGap: [2.8, 6.5],
    arm: [['fidget', 3], ['adjust', 1.2]], armGap: [3.5, 8],
    face: [['smile', 3], ['smirk', 1.5], ['curious', 0.8]], faceGap: [3, 8],
    beats: [['hairTuck', 1.5], ['lookHands', 1.2], ['stretch', 0.5], ['hum', 1.5], ['shyGlance', 1.5], ['noticing', 1.5], ['armsBack', 1.2], ['yawn', 0.35],
      ['thinkChin', 1], ['waveHello', 0.8], ['claspCalm', 1.8], ['leanSmile', 1.4]], beatGap: [4, 9], enter: [], motif: null },
  scanning: { look: 'sweep', breath: [4.0, 0.9], blink: 5.5, noise: 0.7, shift: [6, 12, 0.6], speed: 1.1, rest: ['hangIn', 'hangIn'],
    body: [['tilt', 2], ['nod', 0.8]], bodyGap: [3, 6],
    arm: [['fidget', 1.5]], armGap: [4, 9], face: [['curious', 1.5], ['smirk', 0.5]], faceGap: [4, 9],
    beats: [['sweepLook', 3], ['checkDevice', 2], ['ponderS', 1.5], ['leanIn', 1.5], ['nodApprove', 1], ['tapWait', 1.2], ['rapidGlance', 1.2]], beatGap: [1.2, 3],
    enter: ['leanIn'], motif: null },
  connecting: { look: 'think', breath: [4.2, 1], blink: 3.2, noise: 1.1, shift: [5, 9, 0.8], speed: 1, rest: ['hangIn', 'hangIn'],
    body: [['nod', 1], ['shrug', 0.8]], bodyGap: [3, 6], arm: [['fidget', 1.2]], armGap: [4, 8],
    face: [['curious', 2], ['smile', 1], ['smirk', 1]], faceGap: [2.5, 6],
    beats: [['thinkChinC', 3], ['lookAroundC', 2], ['hmm', 1.6], ['apologetic', 1.5], ['waitSway', 1.6], ['impatient', 1.4], ['thinkUp', 1.4]], beatGap: [0.8, 2.4],
    enter: ['hmm'], motif: null },
  success: { look: 'warm', breath: [3.6, 1.15], blink: 3.0, noise: 1.3, shift: [3, 6, 1.2], speed: 1.3, rest: ['hangIn', 'hangIn'],
    body: [['tilt', 2], ['nod', 1.5]], bodyGap: [2.5, 5], arm: [['fidget', 1]], armGap: [3, 6],
    face: [['grin', 3], ['smile', 2]], faceGap: [2.5, 5],
    beats: [['cheerV', 2], ['clap', 2.2], ['fistPump', 1.6], ['bounceSway', 2.4], ['giggleHands', 1.6], ['waveHappy', 1.2], ['proud', 1.4], ['twirlSway', 1.4]], beatGap: [0.6, 2],
    enter: ['cheerV'],
    motif: { f: [1.5, 2.1], on: [2.5, 5], off: [1.5, 3.5], map: [['hpy', 0.006, 'a', 0], ['hx', -0.018, 'a', 0.5], ['shL', -0.018, 'a', 0.6], ['shR', -0.018, 'a', 0.6], ['pz', 0.014, 'h', 0], ['sz', -0.012, 'h', 0]] } },
  password_success: { look: 'warm', breath: [4, 1], blink: 3.4, noise: 1, shift: [5, 9, 1], speed: 1.1, rest: ['clasp', 'clasp'],
    body: [['tilt', 2], ['nod', 1.5]], bodyGap: [3, 6], arm: [['fidget', 1]], armGap: [4, 8],
    face: [['smile', 3], ['grin', 1]], faceGap: [3, 7],
    beats: [['approveNod', 3], ['relief', 1.5], ['satisfied', 1.5], ['softClap', 1.2], ['happyHum', 1.4], ['giggleSmall', 1.2]], beatGap: [1.5, 3.8],
    enter: ['approveNod'], motif: null },
  password_warning: { look: 'worry', breath: [3.8, 1.05], blink: 2.8, noise: 1.1, shift: [4, 8, 1], speed: 0.95, rest: ['clasp', 'clasp'],
    body: [['tilt', 1.5], ['shrug', 1]], bodyGap: [3, 6], arm: [], armGap: [4, 8],
    face: [['worry', 3], ['curious', 1]], faceGap: [2.5, 6],
    beats: [['noNo', 3], ['wringHands', 3], ['peekWorry', 1.4], ['sighShake', 1.6], ['lookAwayThink', 1.4], ['apologize', 1.2], ['fidgetNervous', 1.8]], beatGap: [0.8, 2.2],
    enter: ['noNo'], motif: { f: [0.55, 0.8], on: [3, 6], off: [2, 4], map: [['sz', 0.012, 's', 0], ['hpx', 0.004, 's', 0.3]] } },
  warning: { look: 'dart', breath: [2.6, 0.9], blink: 4.8, noise: 1.1, shift: [3, 6, 0.8], speed: 1.3, rest: ['present', 'present'],
    body: [['tilt', 1], ['shrug', 1]], bodyGap: [3, 6], arm: [], armGap: [4, 8],
    face: [['curious', 2], ['worry', 1]], faceGap: [2, 5],
    beats: [['scanAlert', 3], ['startleBeat', 2], ['listen', 2.2], ['gulpGlance', 1.6], ['huddle', 1.4], ['stopGesture', 1.4]], beatGap: [0.7, 1.8],
    enter: ['startleBeat'], motif: null },
  angry: { look: 'lock', breath: [2.4, 1.35], blink: 6.5, noise: 0.6, shift: [4, 8, 0.7], speed: 1.25, rest: ['fistLow', 'fistLow'],
    body: [['tilt', 1], ['shrug', 0.5]], bodyGap: [3, 6], arm: [], armGap: [4, 8],
    face: [['glare', 3]], faceGap: [2.5, 5],
    beats: [['glareHold', 3], ['scoffSnap', 2.4], ['raiseFists', 2], ['fistShakeB', 1.2], ['headShakeSlow', 1.5], ['armsStiff', 1.5], ['stompBeat', 1.4]], beatGap: [1, 2.6],
    enter: ['stompBeat'], motif: null },
  offline: { look: 'down', breath: [6, 1.25], blink: 2.9, noise: 0.8, shift: [6, 12, 0.8], speed: 0.65, rest: ['limp', 'limp'],
    body: [['tilt', 1.5], ['shrug', 0.6]], bodyGap: [3, 7], arm: [['fidget', 1.5]], armGap: [4, 9],
    face: [['worry', 2]], faceGap: [3, 8],
    beats: [['bigSigh', 3], ['lookUpSad', 2], ['slowShake', 1.4], ['hugSelf', 1.6], ['rubFace', 1.2], ['weightSag', 1.5], ['shrugHelpless', 1.2]], beatGap: [1.8, 4.5],
    enter: ['bigSigh'], motif: { f: [0.3, 0.42], on: [4, 8], off: [2, 5], map: [['sz', 0.01, 's', 0], ['hpx', 0.004, 's', 0.4], ['cz', 0.008, 's', 0.8]] } },
  setup: { look: 'warm', breath: [4, 1], blink: 3.4, noise: 1.1, shift: [4, 8, 1], speed: 1.1, rest: ['hangIn', 'hangIn'],
    body: [['tilt', 2], ['nod', 1.5]], bodyGap: [3, 6], arm: [['fidget', 1]], armGap: [4, 8],
    face: [['smile', 3], ['curious', 1]], faceGap: [2.5, 6],
    beats: [['waveHello', 2], ['beckonCome', 2.4], ['presentOpen', 2.2], ['explain', 2.4], ['pointSide', 1.4], ['clapExcited', 1.2], ['cheerfulSway', 1.4]], beatGap: [0.8, 2.4],
    enter: ['waveHello'],
    motif: { f: [1.2, 1.6], on: [2, 4], off: [3, 6], map: [['hpy', 0.004, 'a', 0], ['hx', -0.012, 'a', 0.5]] } }
};

/* ------------------------------------------------------------------------------------------------ events */
/* Every event: dur(r) -> seconds, make(r) -> params, fx(p, u, t, add) adds offsets; u = 0..1 progress, t = seconds in.
 * add(key, value): hx/hy/hz head, nx.. neck, cx.. chest, ux.. upper chest, sx.. spine, px/py/pz hips rotation, hpx/hpy/hpz hips position,
 * shL/shR shoulders, L_xxx / R_xxx arm deltas, e_xxx expressions, blinkAdd eyelids. Beats start them with overrides (ev(t, kind, {a: ..})). */
const EV = {
  nod: { dur: (r) => r.range(0.9, 1.5), make: (r) => ({ a: r.range(4, 8) * D, n: r.chance(0.4) ? 2 : 1 }),
    fx(p, u, t, add) { const w = Math.pow(Math.sin(Math.PI * u * p.n), 2) * (1 - 0.3 * u); add('hx', p.a * w); add('nx', p.a * 0.3 * w); add('cx', p.a * 0.2 * w); } },
  tilt: { dur: (r) => r.range(2.4, 6), make: (r) => ({ roll: r.sign() * r.range(3, 8) * D, yaw: r.range(-4, 4) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add('hz', p.roll * w); add('hy', p.yaw * w); add('nz', p.roll * 0.3 * w); add('sz', -p.roll * 0.2 * w); } },
  shrug: { dur: (r) => r.range(0.9, 1.4), make: (r) => ({ a: r.range(0.07, 0.12) }),
    fx(p, u, t, add) { const w = bell(u); add('shL', p.a * w); add('shR', p.a * w); add('L_down', -0.05 * w); add('R_down', -0.05 * w); add('hx', -0.03 * w); } },
  sigh: { dur: (r) => r.range(3.6, 4.8), make: () => ({}),
    fx(p, u, t, add) {
      const ib = 0.35, b = u < ib ? smooth(u / ib) : 1 - smooth((u - ib) / (1 - ib));
      add('cx', -0.06 * b); add('ux', -0.04 * b); add('shL', 0.05 * b); add('shR', 0.05 * b); add('hx', -0.03 * b);
      const ex = bell(clamp((u - ib) / (1 - ib), 0, 1));
      add('hx', 0.06 * ex); add('shL', -0.03 * ex); add('shR', -0.03 * ex); add('e_aa', 0.1 * ex);
    } },
  lean: { dur: (r) => r.range(2, 5), make: (r) => ({ a: (r.chance(0.7) ? 1 : -1) * r.range(3, 6) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add('cx', p.a * w); add('ux', p.a * 0.5 * w); add('hx', -p.a * 0.6 * w); } },
  neckroll: { dur: () => 1.8, make: (r) => ({ s: r.sign(), a: r.range(4, 6) * D }),
    fx(p, u, t, add) { const w = Math.sin(2 * Math.PI * u) * bell(u); add('hz', p.s * p.a * w); add('ny', p.s * 0.03 * w); } },
  giggle: { dur: (r) => r.range(1, 1.6), make: () => ({}),
    fx(p, u, t, add) {
      const w = bell(u), osc = Math.sin(2 * Math.PI * 5.5 * t) * w;
      add('shL', 0.04 * osc); add('shR', 0.04 * osc); add('hpy', 0.004 * Math.abs(osc)); add('e_happy', 0.2 * w); add('hx', -0.02 * w); add('e_aa', 0.1 * w * (0.5 + 0.5 * osc));
    } },
  hop: { dur: () => 1.4, make: () => ({}),
    fx(p, u, t, add) { if (t < 1.3) { const e = Math.abs(Math.sin(Math.PI * t / 0.65)) * Math.exp(-t * 1.2); add('hpy', 0.035 * e); add('hx', 5 * D * e); } } },
  bounce: { dur: () => 1.0, make: () => ({}),
    fx(p, u, t, add) { const w = bell(u); add('hpy', 0.018 * w); add('hx', -0.02 * w); add('e_happy', 0.1 * w); } },
  startle: { dur: () => 1.8, make: () => ({}),
    fx(p, u, t, add) {
      const e = Math.exp(-t * 4.2);
      add('hx', -7 * D * e); add('cx', -5 * D * e); add('hpy', 0.012 * e); add('shL', 0.1 * e); add('shR', 0.1 * e); add('e_surprised', 0.5 * e);
    } },
  flinch: { dur: () => 0.9, make: (r) => ({ a: r.range(0.4, 0.8) }),
    fx(p, u, t, add) {
      const e = Math.exp(-t * 5) * p.a;
      add('hx', -5 * D * e); add('shL', 0.06 * e); add('shR', 0.06 * e); add('cx', -3 * D * e); add('e_surprised', 0.3 * e);
    } },
  shake: { dur: () => 2.0, make: (r) => ({ a: r.range(9, 15) * D, f: r.range(1.4, 1.8) }),
    fx(p, u, t, add) { const w = Math.exp(-t * 1.9) * Math.sin(2 * Math.PI * p.f * t); add('hy', p.a * w); add('ny', p.a * 0.3 * w); add('hx', 0.04 * bell(u)); } },
  scoff: { dur: () => 0.55, make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = bell(u); add('hx', 6 * D * w); add('hy', p.s * 5 * D * w); add('cx', 3 * D * w); add('shL', 0.04 * w); add('shR', 0.04 * w); add('e_angry', 0.1 * w); } },
  lunge: { dur: () => 1.3, make: () => ({}),
    fx(p, u, t, add) { const w = trap(u, 0.35); add('hx', 5 * D * w); add('cx', 6 * D * w); add('ux', 3 * D * w); add('shL', 0.07 * w); add('shR', 0.07 * w); add('hpz', 0.01 * w); } },
  collapse: { dur: () => 3.0, make: () => ({}),
    fx(p, u, t, add) {
      const d = smooth(u / 0.3) * (1 - 0.4 * smooth((u - 0.3) / 0.7));
      add('hx', 5 * D * d); add('shL', -0.05 * d); add('shR', -0.05 * d); add('cx', 5 * D * d); add('hpy', -0.012 * d);
    } },
  focus: { dur: () => 1.6, make: () => ({}),
    fx(p, u, t, add) { const w = trap(u, 0.4); add('hx', 3 * D * w); add('cx', 2 * D * w); add('e_angry', 0.08 * w); } },
  thinkIn: { dur: () => 2.0, make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = trap(u, 0.4); add('hz', p.s * 5 * D * w); add('hy', 4 * D * w); add('hx', -2 * D * w); } },
  fidget: { dur: (r) => r.range(1.5, 3), make: (r) => ({ s: r.chance(0.5) ? 'L' : 'R', a: r.range(8, 14) * D, c: r.range(0.08, 0.18) }),
    fx(p, u, t, add) {
      const w = bell(u);
      add(p.s + '_elbowF', p.a * w); add(p.s + '_curl', p.c * Math.sin(2 * Math.PI * 1.4 * t) * w); add(p.s + '_down', -0.03 * w); add(p.s + '_wrist', 0.1 * Math.sin(2 * Math.PI * 0.9 * t) * w);
    } },
  adjust: { dur: (r) => r.range(2, 4), make: (r) => ({ s: r.chance(0.5) ? 'L' : 'R', a: r.range(14, 22) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add(p.s + '_elbowF', p.a * w); add(p.s + '_down', -0.08 * w); add(p.s + '_fwd', 0.1 * w); add(p.s + '_curl', 0.1 * w); } },
  smile: { dur: (r) => r.range(2, 4), make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.35); add('e_happy', 0.28 * w); add('e_relaxed', 0.05 * w); } },
  smirk: { dur: (r) => r.range(2, 3.2), make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = trap(u, 0.35); add('e_relaxed', 0.35 * w); add('e_happy', 0.08 * w); add('hz', p.s * 2 * D * w); } },
  curious: { dur: (r) => r.range(1, 1.8), make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = bell(u); add('e_surprised', 0.16 * w); add('hx', -0.02 * w); add('hz', p.s * 2.5 * D * w); add('e_happy', 0.05 * w); } },
  grin: { dur: (r) => r.range(1.5, 3), make: () => ({}), fx(p, u, t, add) { add('e_happy', 0.18 * trap(u, 0.35)); } },
  worry: { dur: (r) => r.range(2, 4), make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.35); add('e_sad', 0.18 * w); add('e_surprised', 0.04 * w); } },
  glare: { dur: (r) => r.range(1.5, 3), make: () => ({}), fx(p, u, t, add) { add('e_angry', 0.25 * trap(u, 0.35)); } }
};

/* 4.5.0 additions: building blocks for beats */
Object.assign(EV, {
  expr: { dur: (r) => r.range(1, 2), make: () => ({ m: {}, sh: 'bell' }),
    fx(p, u, t, add) { const w = p.sh === 'trap' ? trap(u, 0.3) : bell(u); for (const k in p.m) add(k, p.m[k] * w); } },
  lids: { dur: (r) => r.range(1.2, 2.2), make: () => ({ a: 0.85 }), fx(p, u, t, add) { add('blinkAdd', p.a * trap(u, 0.3)); } },
  sway: { dur: (r) => r.range(3, 5.5), make: (r) => ({ f: r.range(0.45, 0.7), a: r.range(0.7, 1) }),
    fx(p, u, t, add) {
      const w = trap(u, 0.25) * p.a, ph = 2 * Math.PI * p.f * t, s = Math.sin(ph) * w;
      add('hpx', 0.012 * s); add('sz', -0.035 * s); add('cz', -0.03 * s); add('hz', 0.05 * s); add('pz', 0.03 * s); add('cy', 0.02 * Math.cos(ph) * w);
    } },
  bouncePulse: { dur: (r) => r.range(1.6, 3), make: (r) => ({ f: r.range(1.8, 2.4), a: r.range(0.7, 1.1) }),
    fx(p, u, t, add) {
      const e = Math.abs(Math.sin(Math.PI * p.f * t)) * trap(u, 0.2) * p.a;
      add('hpy', 0.014 * e); add('hx', -0.03 * e); add('shL', -0.03 * e); add('shR', -0.03 * e); add('L_down', -0.05 * e); add('R_down', -0.05 * e);
    } },
  laugh: { dur: (r) => r.range(1.4, 2.2), make: () => ({}),
    fx(p, u, t, add) {
      const w = bell(u), o = Math.sin(2 * Math.PI * 5.2 * t) * w;
      add('shL', 0.04 * o); add('shR', 0.04 * o); add('hx', -0.07 * w); add('cx', -0.04 * w); add('hpy', 0.005 * Math.abs(o));
      add('e_happy', 0.25 * w); add('e_aa', 0.35 * w * (0.55 + 0.45 * o)); add('hz', 0.03 * Math.sin(2 * Math.PI * 1.1 * t) * w);
    } },
  gulp: { dur: () => 0.7, make: () => ({}), fx(p, u, t, add) { const w = bell(u); add('nx', -0.04 * w); add('hx', -0.02 * w); add('shL', 0.03 * w); add('shR', 0.03 * w); add('e_aa', 0.05 * w); } },
  sniff: { dur: () => 0.9, make: () => ({}),
    fx(p, u, t, add) { const w = Math.pow(Math.sin(Math.PI * u * 2), 2) * (1 - u); add('hx', -0.05 * w); add('shL', 0.035 * w); add('shR', 0.035 * w); add('cx', -0.02 * w); } },
  snap: { dur: (r) => r.range(1, 1.8), make: (r) => ({ y: r.sign() * r.range(10, 22) * D, x: r.range(-3, 5) * D }),
    fx(p, u, t, add) {
      const e = u < 0.12 ? smooth(u / 0.12) : u < 0.6 ? 1 : 1 - smooth((u - 0.6) / 0.4);
      add('hy', p.y * e); add('hx', p.x * e); add('cy', p.y * 0.25 * e); add('ny', p.y * 0.25 * e);
    } },
  stomp: { dur: () => 0.6, make: () => ({}),
    fx(p, u, t, add) {
      const e = 0.25 * bell(clamp(u / 0.3, 0, 1)) - bell(clamp((u - 0.25) / 0.6, 0, 1)), hit = Math.max(0, -e);
      add('hpy', 0.014 * e); add('hx', 0.05 * hit); add('shL', 0.05 * hit); add('shR', 0.05 * hit); add('cx', 0.03 * hit);
    } },
  heave: { dur: (r) => r.range(1.6, 2.2), make: () => ({}),
    fx(p, u, t, add) {
      const ib = 0.4, b = u < ib ? smoother(u / ib) : 1 - smoother((u - ib) / (1 - ib));
      add('ux', -0.06 * b); add('cx', -0.04 * b); add('shL', 0.08 * b); add('shR', 0.08 * b); add('hx', -0.04 * b);
    } },
  bow: { dur: () => 1.7, make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.3); add('hx', 0.2 * w); add('cx', 0.12 * w); add('nx', 0.08 * w); add('shL', 0.04 * w); add('shR', 0.04 * w); } },
  headBack: { dur: (r) => r.range(1.6, 2.2), make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.3); add('hx', -0.12 * w); add('cx', -0.05 * w); add('ux', -0.04 * w); } },
  roll: { dur: () => 1.3, make: () => ({}), fx(p, u, t, add) { const w = bell(u), ph = 2 * Math.PI * u; add('shL', 0.07 * Math.sin(ph) * w); add('shR', -0.07 * Math.sin(ph) * w); add('hz', 0.02 * Math.sin(ph) * w); } }
});

/* ------------------------------------------------------------------------------------------------ beats */
/* A beat = { dur, acts[] }; every act has a start time t (seconds into the beat):
 *   ev(t, kind, overrides)        start an event (nod, tilt, lean, laugh ...)
 *   arms(t, rightPose, leftPose, hold, fast)   move the arm(s) to a pose from ARMP (null = leave that arm), back to rest after `hold`
 *   gz(t, yaw, pitch, hold, glide)   look somewhere (degrees; yaw + = screen right, pitch + = down); the gaze mode takes over afterwards
 *   shf(t, to)                    shift the weight (-1, 0, 1)
 *   xp(t, {e_happy: .3}, dur)     expression burst (the mouth shapes e_ou / e_aa / e_ih / e_ee / e_oh live here too)
 * The right arm is on the left of the screen, so "screen side" signs below are: right arm = -1, left arm = +1. */
const ev = (t, kind, ov) => ({ t, ev: kind, ov });
const arms = (t, R, L, hold, fast) => ({ t, arms: { R, L }, hold, fast });
const gz = (t, y, p, hold, glide) => ({ t, gaze: { y, p, hold, glide } });
const shf = (t, to) => ({ t, shift: to });
const xp = (t, m, dur, sh) => ev(t, 'expr', { m, dur, sh });
const both = (r, t, name, hold, fast) => { const f = r.chance(0.5); return [arms(t, f ? name : null, f ? null : name, hold, fast), arms(t + r.range(0.04, 0.12), f ? null : name, f ? name : null, hold, fast)]; };
const pulses = (r, t0, n, gap, m, dur) => { const o = []; for (let i = 0; i < n; i++) o.push(xp(t0 + i * gap + r.range(-0.1, 0.1), m, dur)); return o; };

const BEATS = {
  /* ---------------- idle ---------------- */
  hairTuck: (r) => { const left = r.chance(0.5), h = r.range(2, 3.2), scr = left ? -1 : 1;
    return { dur: h + 1, acts: [gz(0, scr * r.range(6, 12), 2, h * 0.8, 0.3), arms(0.15, left ? 'cheek' : null, left ? null : 'cheek', h), ev(0.3, 'tilt', { roll: -scr * r.range(4, 7) * D, dur: h }),
      xp(0.4, { e_happy: 0.18, e_relaxed: 0.1 }, h), ev(h * 0.75, 'nod', { a: 3 * D, n: 1 })] }; },
  lookHands: (r) => ({ dur: 3.8, acts: [gz(0, r.range(-8, 8), 16, 2.4, 0.35), ...both(r, 0.1, 'belt', 2.8), ev(0.2, 'lean', { a: 4 * D, dur: 2.4 }), xp(0.3, { e_happy: 0.2 }, 2.6),
    gz(2.6, 0, 0, 1.5, 0.25), ev(2.8, 'nod', { a: 3 * D, n: 1 })] }),
  stretch: (r) => ({ dur: 4.2, acts: [...both(r, 0, 'cheerV', 1.7), ev(0.1, 'headBack', { dur: 1.7 }), ev(0.1, 'heave', { dur: 2.2 }), gz(0, 0, -10, 1.6, 0.4), ev(1.7, 'sigh', {}), xp(1.8, { e_happy: 0.2 }, 1.6)] }),
  hum: (r) => ({ dur: 5, acts: [ev(0, 'sway', { dur: 4.6 }), xp(0.2, { e_happy: 0.25 }, 4.2, 'trap'), gz(0.3, r.range(-6, 6), -2, 3, 0.4), ...pulses(r, 0.5, 4, 1.0, { e_ou: r.range(0.18, 0.3) }, 0.55),
    ev(0.6, 'nod', { a: 2.5 * D, n: 2 })] }),
  shyGlance: (r) => { const scr = r.sign(); return { dur: 5, acts: [gz(0, scr * r.range(10, 20), 10, 2.8, 0.3), ...both(r, 0.2, 'clasp', 3.8), ev(0.2, 'tilt', { roll: scr * r.range(4, 7) * D, dur: 3 }),
    xp(0.3, { e_happy: 0.28 }, 3.4), ev(0.4, 'shrug', { a: 0.06 }), gz(3, 0, 1, 1.5, 0.3)] }; },
  noticing: (r) => { const scr = r.sign(); return { dur: 4.4, acts: [gz(0, scr * r.range(12, 24), -6, 1.8, 0.12), ev(0, 'curious', {}), ev(0.1, 'snap', { y: scr * r.range(8, 14) * D, x: -0.03, dur: 1.6 }),
    gz(1.9, 0, 0, 1.5, 0.25), ev(2.1, 'nod', { a: 4 * D, n: 1 }), xp(2.1, { e_happy: 0.3 }, 1.8)] }; },
  armsBack: (r) => { const h = r.range(4, 7); return { dur: h + 0.6, acts: [...both(r, 0, 'back', h), ev(0.2, 'lean', { a: -3 * D, dur: h - 0.5 }), xp(0.3, { e_happy: 0.12 }, h)] }; },
  yawn: () => ({ dur: 4.2, acts: [arms(0.2, 'mouth', null, 2.3), ev(0.3, 'headBack', { dur: 2 }), xp(0.4, { e_aa: 0.8, e_happy: 0.1 }, 1.7), ev(0.4, 'lids', { dur: 2 }), ev(0.3, 'heave', { dur: 2.2 }), xp(2.4, { e_sad: 0.1 }, 1.2)] }),
  thinkChin: (r) => { const h = r.range(3, 5), scr = r.sign(); return { dur: h + 1.2, acts: [arms(0.1, 'chin', 'belt', h), gz(0, scr * r.range(8, 16), -8, h * 0.5, 0.4), gz(h * 0.55, 0, 0, 1.2, 0.3),
    ev(0.2, 'tilt', { roll: r.sign() * r.range(4, 7) * D, dur: h }), ev(h * 0.5, 'nod', { a: 3 * D, n: 1 }), xp(0.5, { e_relaxed: 0.2, e_ou: 0.1 }, h)] }; },
  waveHello: (r) => ({ dur: 3.8, acts: [gz(0, 0, 0, 2.6, 0.2), arms(0, 'wave', null, 2.6), xp(0, { e_happy: 0.5 }, 2.8, 'trap'), ev(0.2, 'tilt', { roll: r.range(3, 6) * D, dur: 2.4 }), ev(2.4, 'nod', { a: 3 * D, n: 1 })] }),
  claspCalm: (r) => { const h = r.range(4, 7); return { dur: h, acts: [...both(r, 0, 'clasp', h - 0.5), xp(0.2, { e_happy: 0.12 }, h - 0.4)] }; },
  leanSmile: () => ({ dur: 3.8, acts: [ev(0, 'lean', { a: 5 * D, dur: 3.2 }), xp(0.2, { e_happy: 0.3 }, 3), gz(0, 0, -1, 3, 0.2), ev(1.5, 'nod', { a: 4 * D, n: 1 })] }),

  /* ---------------- scanning ---------------- */
  sweepLook: (r) => { const d = r.sign(), a = r.range(14, 28); return { dur: 4.6, acts: [gz(0, d * a, r.range(0, 6), r.range(0.8, 1.4), r.range(0.2, 0.4)), ev(0.05, 'focus', {}),
    gz(1.6, -d * r.range(10, 24), r.range(0, 6), r.range(0.8, 1.4), r.range(0.2, 0.4)), gz(3.3, r.range(-3, 3), r.range(1, 4), 1, 0.3), ev(1.7, 'tilt', { roll: r.sign() * 4 * D, dur: 2 })] }; },
  checkDevice: (r) => ({ dur: 4, acts: [gz(0, r.range(-10, 10), 15, 2.4, 0.3), ...both(r, 0.1, 'belt', 2.8), ev(0.1, 'lean', { a: 4 * D, dur: 2.5 }), gz(2.5, 0, 0, 1, 0.3), ev(2.7, 'nod', { a: 3 * D, n: 1 })] }),
  ponderS: (r) => { const h = r.range(2.5, 4); return { dur: h + 1, acts: [arms(0.1, 'chin', 'hangIn', h), gz(0, r.sign() * r.range(8, 16), -6, h * 0.6, 0.4), ev(0.2, 'tilt', { roll: r.sign() * 4 * D, dur: h }), ev(h * 0.6, 'nod', { a: 3 * D, n: 1 })] }; },
  leanIn: (r) => ({ dur: 3, acts: [ev(0, 'lean', { a: 5 * D, dur: 2.6 }), ev(0, 'focus', {}), gz(0, 0, 3, 2.4, 0.25), xp(0.2, { e_angry: 0.08 }, 2.4)] }),
  nodApprove: () => ({ dur: 2.4, acts: [ev(0, 'nod', { a: 5 * D, n: 2 }), xp(0.2, { e_happy: 0.18 }, 1.8), gz(0, 0, 0, 1.6, 0.2)] }),
  tapWait: (r) => ({ dur: 3.6, acts: [arms(0, r.chance(0.5) ? 'tap' : null, null, 3.2), arms(0, null, 'belt', 3.2), gz(0, r.sign() * r.range(10, 20), 4, 2, 0.4)] }),
  rapidGlance: (r) => { const d = r.sign(); return { dur: 2.8, acts: [gz(0, d * 22, 2, 0.5, 0.15), gz(0.7, -d * 22, 2, 0.5, 0.15), gz(1.4, d * 12, 4, 0.6, 0.15), gz(2.1, 0, 0, 0.7, 0.2), ev(0.1, 'focus', {})] }; },

  /* ---------------- connecting ---------------- */
  thinkChinC: (r) => { const h = r.range(4, 8), scr = r.sign(); return { dur: h + 1.2, acts: [arms(0.1, r.chance(0.5) ? 'tapChin' : 'chin', 'belt', h), gz(0, scr * r.range(8, 18), -9, 1.8, 0.35), gz(2, 0, 0, 0.9, 0.25),
    gz(3, -scr * r.range(6, 14), -7, 1.6, 0.35), ev(0.2, 'tilt', { roll: r.sign() * r.range(4, 8) * D, dur: h }), ev(h * 0.45, 'nod', { a: 3 * D, n: 1 }),
    xp(0.4, { e_relaxed: 0.2 }, h), ...pulses(r, 1.2, 2, 1.6, { e_ou: 0.18 }, 0.5)] }; },
  lookAroundC: (r) => { const d = r.sign(); return { dur: 5, acts: [gz(0, d * 18, -8, 1.3, 0.3), gz(1.6, -d * 18, -8, 1.3, 0.3), gz(3.2, 0, 0, 1, 0.3), ...both(r, 0.8, 'present', 2.8), ev(2.2, 'shrug', { a: 0.08 }), ev(0.4, 'curious', {})] }; },
  hmm: (r) => ({ dur: 3.4, acts: [ev(0, 'nod', { a: 5 * D, n: 2 }), ev(0.2, 'tilt', { roll: r.sign() * r.range(4, 7) * D, dur: 2.6 }), ...pulses(r, 0.2, 2, 1.2, { e_ou: 0.22 }, 0.6), ev(0.5, 'curious', {}), gz(0, r.sign() * 10, -5, 1.4, 0.3)] }),
  apologetic: (r) => ({ dur: 4, acts: [...both(r, 0, 'present', 3), ev(0.2, 'shrug', { a: 0.09 }), xp(0.2, { e_sad: 0.14, e_happy: 0.1 }, 3), gz(0, 0, 0, 3, 0.2), ev(1.8, 'bow', { dur: 1.3 }), ev(0.3, 'tilt', { roll: r.sign() * 5 * D, dur: 3 })] }),
  waitSway: (r) => ({ dur: 6, acts: [ev(0, 'sway', { dur: 5.2 }), ...both(r, 0, 'clasp', 5.2), gz(0, r.sign() * 10, 8, 2, 0.5), gz(2.4, 0, -4, 1.4, 0.4), gz(4, r.sign() * 8, 6, 1.6, 0.4), ev(3.4, 'sigh', {})] }),
  impatient: (r) => ({ dur: 4, acts: [arms(0, 'tap', 'belt', 3.6), gz(0, r.sign() * r.range(10, 20), 3, 1.6, 0.3), gz(2, 0, 0, 1.2, 0.3), xp(0.3, { e_sad: 0.1 }, 3), ev(2.4, 'shrug', { a: 0.06 })] }),
  thinkUp: (r) => ({ dur: 4.8, acts: [arms(0.1, 'cheek', 'belt', 4), gz(0, r.sign() * 14, -12, 2.2, 0.4), ev(0, 'sway', { dur: 4, a: 0.6 }), xp(0.3, { e_relaxed: 0.25, e_ou: 0.12 }, 3.6), gz(2.6, 0, 0, 1, 0.3)] }),

  /* ---------------- success ---------------- */
  cheerV: (r) => ({ dur: 2.6, acts: [...both(r, 0, 'cheerV', r.range(1.2, 1.8)), ev(0, 'hop', {}), ev(0.1, 'laugh', {}), xp(0.1, { e_happy: 0.3 }, 2), gz(0, 0, -6, 1.8, 0.2)] }),
  clap: (r) => { const n = Math.floor(r.range(3, 6)), t0 = 0.7, acts = [gz(0, 0, 0, 1.4, 0.2), ...both(r, 0, 'present', t0 + 0.1), ev(t0, 'bouncePulse', { dur: n * 0.3 + 0.4 }), xp(0, { e_happy: 0.25 }, n * 0.3 + t0 + 0.5)];
    for (let i = 0; i < n; i++) { acts.push(...both(r, t0 + i * 0.3, 'chest', 0.17, 1.7)); acts.push(...both(r, t0 + i * 0.3 + 0.15, 'present', 0.17, 1.7)); }
    return { dur: t0 + n * 0.3 + 0.9, acts }; },
  fistPump: (r) => { const left = r.chance(0.5); return { dur: 2.6, acts: [arms(0, left ? 'fistShake' : null, left ? null : 'fistShake', 1.3, 1.6), ev(0, 'hop', {}), ev(0.1, 'nod', { a: 6 * D, n: 2 }), xp(0, { e_happy: 0.3 }, 2), gz(0, 0, -3, 1.6, 0.2)] }; },
  bounceSway: (r) => ({ dur: 4.4, acts: [ev(0, 'bouncePulse', { dur: 3.6 }), ev(0.2, 'sway', { dur: 3.6, a: 0.5 }), xp(0, { e_happy: 0.25 }, 3.8), gz(0.3, r.sign() * 10, -3, 1.4, 0.3), gz(2.2, 0, -2, 1.5, 0.3)] }),
  giggleHands: (r) => ({ dur: 2.8, acts: [arms(0, 'mouth', null, 1.7), ev(0, 'laugh', {}), ev(0.2, 'tilt', { roll: r.sign() * 6 * D, dur: 2 }), gz(0, r.sign() * 10, 6, 1.6, 0.25)] }),
  waveHappy: (r) => ({ dur: 3.4, acts: [arms(0, 'wave', null, 2.4), xp(0, { e_happy: 0.3 }, 2.6), ev(0, 'bounce', {}), ev(0.2, 'tilt', { roll: r.range(3, 6) * D, dur: 2.4 }), gz(0, 0, 0, 2.4, 0.2)] }),
  proud: (r) => ({ dur: 4, acts: [...both(r, 0, 'belt', 3.4), ev(0, 'lean', { a: -3 * D, dur: 3.4 }), ev(0, 'headBack', { dur: 2 }), xp(0, { e_happy: 0.28 }, 3.4), ev(1.6, 'nod', { a: 4 * D, n: 1 })] }),
  twirlSway: (r) => ({ dur: 4.4, acts: [ev(0, 'sway', { dur: 4, a: 1 }), ...both(r, 0.3, 'present', 3), xp(0, { e_happy: 0.2 }, 4), gz(0.2, r.sign() * 14, -4, 1.4, 0.3), gz(2, 0, -2, 1.6, 0.3), ev(1.4, 'bouncePulse', { dur: 1.8 })] }),

  /* ---------------- password_success ---------------- */
  approveNod: () => ({ dur: 2.8, acts: [ev(0, 'nod', { a: 6 * D, n: 2 }), xp(0.1, { e_happy: 0.25 }, 2.2), gz(0, 0, 0, 2, 0.2)] }),
  relief: (r) => ({ dur: 5, acts: [ev(0, 'sigh', {}), gz(0, r.sign() * 6, 8, 1.8, 0.35), gz(2.2, 0, 0, 1.6, 0.3), xp(1.8, { e_happy: 0.25 }, 2.6), ev(2.4, 'nod', { a: 3 * D, n: 1 })] }),
  satisfied: (r) => ({ dur: 4, acts: [...both(r, 0, 'belt', 3.4), ev(0, 'lean', { a: -3 * D, dur: 3.4 }), ev(0.2, 'tilt', { roll: r.sign() * 5 * D, dur: 3 }), xp(0.2, { e_relaxed: 0.3, e_happy: 0.1 }, 3.2)] }),
  softClap: (r) => ({ dur: 3.2, acts: [...both(r, 0, 'chest', 0.6), ...both(r, 0.7, 'clasp', 0.25, 1.5), ...both(r, 1.0, 'chest', 0.25, 1.5), ...both(r, 1.3, 'clasp', 0.25, 1.5), xp(0, { e_happy: 0.25 }, 2.4), ev(0.7, 'bounce', {}), gz(0, 0, 0, 1.6, 0.2)] }),
  happyHum: (r) => ({ dur: 4.6, acts: [ev(0, 'sway', { dur: 4.2, a: 0.7 }), xp(0.2, { e_happy: 0.2 }, 4), ...pulses(r, 0.5, 4, 0.95, { e_ou: 0.2 }, 0.5), gz(0, r.sign() * 6, -2, 3, 0.4)] }),
  giggleSmall: (r) => ({ dur: 2.4, acts: [ev(0, 'giggle', {}), ev(0.1, 'tilt', { roll: r.sign() * 4 * D, dur: 1.8 }), gz(0, r.sign() * 8, 5, 1.2, 0.25)] }),

  /* ---------------- password_warning ---------------- */
  noNo: (r) => ({ dur: 4, acts: [ev(0, 'shake', { a: r.range(10, 16) * D, f: r.range(1.4, 1.7) }), ev(1.6, 'shake', { a: r.range(7, 11) * D, f: r.range(1.4, 1.7) }), ...both(r, 0.2, 'present', 3), xp(0, { e_sad: 0.2 }, 3.4), gz(0, r.sign() * 10, 8, 1.6, 0.3), gz(2, 0, 0, 1.6, 0.3)] }),
  wringHands: (r) => { const h = r.range(3, 5); return { dur: h + 0.6, acts: [...both(r, 0, 'wring', h), gz(0, r.sign() * 12, 10, h * 0.6, 0.4), ev(0.2, 'shrug', { a: 0.06 }), xp(0.2, { e_sad: 0.15 }, h), ...pulses(r, 0.8, 2, 1.4, { e_ou: 0.2, e_ih: 0.1 }, 0.5), shf(0.3, 'flip')] }; },
  peekWorry: (r) => ({ dur: 3.2, acts: [arms(0, 'mouth', null, 2.2), xp(0, { e_surprised: 0.22 }, 2.2), gz(0, r.sign() * 14, 4, 1.6, 0.15), ev(0, 'flinch', { a: 0.5 }), gz(1.8, 0, 2, 1, 0.3)] }),
  sighShake: (r) => ({ dur: 5, acts: [ev(0, 'sigh', {}), ev(1.2, 'shake', { a: 8 * D, f: 1.3 }), gz(0, 0, 12, 2.6, 0.4), ...both(r, 0.5, 'hangIn', 3), gz(3, 0, 2, 1.4, 0.3)] }),
  lookAwayThink: (r) => ({ dur: 4.6, acts: [gz(0, r.sign() * r.range(14, 24), 10, 2.4, 0.35), arms(0.2, 'chin', 'belt', 3.8), ev(0.2, 'tilt', { roll: r.sign() * 6 * D, dur: 3.6 }), xp(0.4, { e_sad: 0.14 }, 3.4), gz(2.8, 0, 0, 1.4, 0.3)] }),
  apologize: (r) => ({ dur: 3.8, acts: [...both(r, 0, 'pray', 2.8), ev(0.3, 'bow', {}), xp(0, { e_sad: 0.2 }, 3), gz(0, 0, 4, 2.2, 0.25), gz(2.2, 0, -2, 1.2, 0.3)] }),
  fidgetNervous: (r) => ({ dur: 4.6, acts: [shf(0, 'flip'), arms(0, 'tap', 'clasp', 4), gz(0, r.sign() * 12, 6, 1.4, 0.3), gz(1.8, r.sign() * 10, 4, 1.4, 0.3), ev(0.4, 'shrug', { a: 0.06 }), ev(2.4, 'sniff', {})] }),

  /* ---------------- warning ---------------- */
  scanAlert: (r) => { const d = r.sign(); return { dur: 3.2, acts: [gz(0, d * r.range(16, 28), r.range(-6, 6), 0.6, 0.2), ev(0, 'snap', { y: d * 0.2, x: -0.03, dur: 1.2 }), gz(0.85, -d * r.range(16, 26), r.range(-6, 6), 0.55, 0.2),
    ev(0.8, 'snap', { y: -d * 0.2, x: -0.02, dur: 1.2 }), gz(1.8, 0, 0, 0.8, 0.2), ev(1.9, 'flinch', { a: 0.5 })] }; },
  startleBeat: (r) => ({ dur: 3, acts: [ev(0, 'startle', {}), ...both(r, 0, 'pray', 1.6, 1.8), gz(0, r.sign() * 12, -2, 1.2, 0.14), gz(1.4, r.sign() * 18, 0, 1, 0.2)] }),
  listen: (r) => { const d = r.sign(); return { dur: 3.4, acts: [gz(0, d * r.range(18, 28), -3, 2.6, 0.2), ev(0, 'lean', { a: -3 * D, dur: 3 }), ev(0.2, 'tilt', { roll: -d * 6 * D, dur: 3 }), xp(0, { e_surprised: 0.12 }, 3), gz(2.8, 0, 0, 0.8, 0.15)] }; },
  gulpGlance: (r) => ({ dur: 2.6, acts: [ev(0.3, 'gulp', {}), gz(0, r.sign() * 14, 4, 0.8, 0.15), gz(0.9, 0, 0, 1.2, 0.2), ev(0, 'shrug', { a: 0.07 }), xp(0, { e_sad: 0.15 }, 2)] }),
  huddle: (r) => ({ dur: 3.6, acts: [...both(r, 0, 'pray', 3), ev(0, 'bow', { dur: 1.4 }), ev(0.1, 'shrug', { a: 0.1 }), gz(0, r.sign() * 16, 4, 1.2, 0.15), gz(1.4, r.sign() * 20, 0, 1.2, 0.15), xp(0, { e_sad: 0.18 }, 3)] }),
  stopGesture: (r) => { const left = r.chance(0.5); return { dur: 2.8, acts: [arms(0, left ? 'present' : null, left ? null : 'present', 1.8, 1.8), ev(0, 'flinch', { a: 0.6 }), gz(0, 0, 0, 1.8, 0.15), ev(0.5, 'nod', { a: 4 * D, n: 2 }), xp(0, { e_surprised: 0.15 }, 1.8)] }; },

  /* ---------------- angry ---------------- */
  glareHold: (r) => { const h = r.range(2.5, 4); return { dur: h + 0.4, acts: [gz(0, r.range(-1, 1), 0, h, 0.2), ev(0, 'lunge', { dur: 1.4 }), ev(0.1, 'heave', { dur: 2 }), xp(0, { e_angry: 0.15 }, h), ev(h * 0.5, 'heave', { dur: 1.8 }), ...pulses(r, 0.6, 2, h * 0.5, { e_ee: 0.2 }, 0.6)] }; },
  scoffSnap: (r) => { const d = r.sign(); return { dur: 3, acts: [ev(0, 'scoff', {}), gz(0.1, d * r.range(18, 30), 3, 0.9, 0.1), ev(0.15, 'snap', { y: d * 0.3, x: 0.05, dur: 1.2 }), gz(1.2, 0, 0, 1.4, 0.15), xp(0.1, { e_ee: 0.3 }, 0.7), xp(0.3, { e_angry: 0.15 }, 1.6)] }; },
  raiseFists: (r) => { const h = r.range(2.5, 4); return { dur: h + 0.5, acts: [...both(r, 0, 'fist', h, 1.5), ev(0, 'lunge', {}), ev(0.1, 'stomp', {}), xp(0, { e_angry: 0.15 }, h), gz(0, 0, 0, h, 0.15), ev(h * 0.5, 'heave', { dur: 1.6 })] }; },
  fistShakeB: (r) => { const left = r.chance(0.5); return { dur: 2.8, acts: [arms(0, left ? 'fistShake' : null, left ? null : 'fistShake', 1.8, 1.4), ev(0, 'lunge', {}), ev(0.2, 'shake', { a: 6 * D, f: 2.2 }), gz(0, 0, 0, 1.8, 0.15), xp(0, { e_angry: 0.15 }, 2)] }; },
  headShakeSlow: (r) => ({ dur: 3.6, acts: [ev(0, 'shake', { a: 8 * D, f: 1.0 }), ev(0, 'heave', { dur: 2.2 }), gz(0, r.sign() * 8, 5, 1.8, 0.3), gz(2, 0, -1, 1.2, 0.2), ev(2.2, 'sigh', {})] }),
  armsStiff: (r) => ({ dur: 3.6, acts: [...both(r, 0, 'fistLow', 3.2), ev(0, 'heave', { dur: 1.6 }), ev(1.6, 'heave', { dur: 1.6 }), xp(0, { e_ee: 0.15, e_angry: 0.1 }, 3.2)] }),
  stompBeat: (r) => ({ dur: 2.4, acts: [ev(0, 'stomp', {}), ev(0.1, 'scoff', {}), arms(0, 'fist', 'fist', 1.4, 1.6), gz(0, 0, 0, 1.6, 0.15), xp(0, { e_angry: 0.15 }, 1.6)] }),

  /* ---------------- offline ---------------- */
  bigSigh: (r) => ({ dur: 5.2, acts: [ev(0, 'sigh', {}), ev(0, 'collapse', { dur: 3.4 }), gz(0, r.sign() * 10, 14, 3, 0.5), xp(1.6, { e_sad: 0.1, e_ou: 0.1 }, 2)] }),
  lookUpSad: (r) => ({ dur: 4.4, acts: [gz(0, 0, -3, 1.2, 0.35), ev(0.2, 'tilt', { roll: r.sign() * 5 * D, dur: 2 }), xp(0.2, { e_sad: 0.1, e_surprised: 0.08 }, 1.6), gz(1.7, r.sign() * 14, 14, 2.4, 0.6), ev(1.8, 'sniff', {})] }),
  slowShake: (r) => ({ dur: 4, acts: [ev(0, 'shake', { a: 6 * D, f: 0.9 }), gz(0, r.sign() * 8, 14, 2.4, 0.5), ...pulses(r, 0.4, 2, 1.4, { e_ou: 0.22 }, 0.7), xp(0.2, { e_sad: 0.08 }, 3)] }),
  hugSelf: (r) => { const h = r.range(4, 6); return { dur: h + 0.6, acts: [...both(r, 0, 'clasp', h), ev(0.3, 'shrug', { a: -0.04 }), gz(0, r.sign() * 12, 16, h * 0.7, 0.5), xp(0.3, { e_sad: 0.08 }, h), ev(h * 0.5, 'sigh', {})] }; },
  rubFace: (r) => { const left = r.chance(0.5); return { dur: 3.6, acts: [arms(0.3, left ? 'cheek' : null, left ? null : 'cheek', 1.6), ev(0, 'sniff', {}), ev(1.4, 'sniff', {}), gz(0, r.sign() * 10, 12, 2.4, 0.4), ev(0.5, 'lids', { dur: 1.6 }), xp(0.3, { e_sad: 0.1 }, 2.4)] }; },
  weightSag: (r) => ({ dur: 5, acts: [shf(0, 'flip'), ev(0, 'lean', { a: 4 * D, dur: 4 }), ev(0.3, 'tilt', { roll: r.sign() * 6 * D, dur: 4 }), gz(0, r.sign() * 14, 12, 3.4, 0.6), ev(2, 'sigh', {})] }),
  shrugHelpless: (r) => ({ dur: 3.6, acts: [...both(r, 0, 'present', 2.6), ev(0.2, 'shrug', { a: 0.1 }), xp(0.2, { e_sad: 0.1 }, 2.6), gz(0, 0, 4, 2, 0.3), ev(0.4, 'tilt', { roll: r.sign() * 6 * D, dur: 2.6 })] }),

  /* ---------------- setup ---------------- */
  beckonCome: (r) => ({ dur: 3.4, acts: [arms(0, 'beckon', null, 2.4), gz(0, 0, 0, 2.4, 0.2), ev(0.1, 'lean', { a: 4 * D, dur: 2.2 }), xp(0, { e_happy: 0.25 }, 2.6), ev(0.2, 'tilt', { roll: r.sign() * 5 * D, dur: 2.2 })] }),
  presentOpen: (r) => ({ dur: 4, acts: [...both(r, 0, 'present', 3), ev(0.2, 'shrug', { a: 0.06 }), ev(1.2, 'nod', { a: 4 * D, n: 1 }), xp(0.2, { e_happy: 0.2 }, 3.2), gz(0, 0, 0, 2.6, 0.2)] }),
  explain: (r) => { const left = r.chance(0.5); return { dur: 6, acts: [arms(0, left ? 'talk' : null, left ? null : 'talk', 2.6), arms(2.2, left ? null : 'talk', left ? 'talk' : null, 3.4), gz(0, 0, 0, 1.6, 0.2), gz(1.8, r.sign() * 12, -2, 1.2, 0.25),
    gz(3.4, 0, 0, 1.6, 0.2), ev(0.4, 'nod', { a: 3 * D, n: 2 }), ev(2.8, 'nod', { a: 4 * D, n: 1 }), xp(0, { e_happy: 0.2 }, 5.6), ...pulses(r, 0.3, 4, 1.4, { e_aa: 0.14 }, 0.45)] }; },
  pointSide: (r) => { const left = r.chance(0.5), scr = left ? -1 : 1; return { dur: 3.6, acts: [arms(0, left ? 'wide' : null, left ? null : 'wide', 2.6), gz(0, scr * 26, 2, 1.8, 0.2), gz(2, 0, 0, 1.2, 0.2), ev(0.1, 'snap', { y: scr * 0.25, x: 0, dur: 1.8 }), xp(0, { e_happy: 0.15 }, 3)] }; },
  clapExcited: (r) => { const n = Math.floor(r.range(2, 4)), t0 = 0.6, acts = [...both(r, 0, 'present', t0 + 0.1), ev(t0, 'bouncePulse', { dur: n * 0.3 + 0.4 }), xp(0, { e_happy: 0.3 }, n * 0.3 + t0 + 0.5), gz(0, 0, -2, 1.4, 0.2)];
    for (let i = 0; i < n; i++) { acts.push(...both(r, t0 + i * 0.3, 'chest', 0.17, 1.7)); acts.push(...both(r, t0 + i * 0.3 + 0.15, 'present', 0.17, 1.7)); }
    return { dur: t0 + n * 0.3 + 0.9, acts }; },
  cheerfulSway: (r) => ({ dur: 4.6, acts: [ev(0, 'sway', { dur: 4.2, a: 0.8 }), ev(0.3, 'bouncePulse', { dur: 2.4 }), xp(0, { e_happy: 0.2 }, 4.2), gz(0.2, r.sign() * 10, -3, 1.6, 0.3), gz(2.4, 0, 0, 1.5, 0.3), ...pulses(r, 0.6, 3, 1.2, { e_ou: 0.18 }, 0.5)] })
};
/* ------------------------------------------------------------------------------------------------ gaze modes */
/* Each picker returns { y, p, hold, glide, away }: target gaze in degrees (y + = screen right, p + = down), how long to hold it,
 * and how long the move takes (0.1 = snap, 1+ = slow pursuit). */
const LOOK = {
  viewer(g, r) {
    if (g.away) return { y: r.range(-1.5, 1.5), p: r.range(-1, 1.5), hold: r.range(1.8, 4.8), glide: r.range(0.1, 0.25), away: false };
    if (r.chance(0.5)) return { y: r.range(-2.5, 2.5), p: r.range(-1.5, 2), hold: r.range(1.5, 3.5), glide: r.range(0.1, 0.2), away: false };
    return { y: r.sign() * r.range(8, 22), p: r.range(-5, 9), hold: r.range(0.7, 1.9), glide: r.chance(0.3) ? 0.5 : 0.12, away: true };
  },
  warm(g, r) {
    if (g.away) return { y: r.range(-1.5, 1.5), p: r.range(-1, 1), hold: r.range(2.2, 5), glide: 0.18, away: false };
    if (r.chance(0.65)) return { y: r.range(-2, 2), p: r.range(-1.5, 1.5), hold: r.range(1.5, 3.2), glide: 0.15, away: false };
    return { y: r.sign() * r.range(8, 18), p: r.range(-8, 4), hold: r.range(0.6, 1.4), glide: 0.14, away: true };
  },
  sweep(g, r) {
    if (g.away === false && r.chance(0.2)) return { y: r.range(-2, 2), p: r.range(0, 3), hold: r.range(0.6, 1.2), glide: 0.2, away: true };
    const dirPrev = g.dir || 1, dir = r.chance(0.7) ? -dirPrev : dirPrev, slow = r.chance(0.35);
    g.dir = dir;
    return { y: dir * r.range(12, 32), p: r.range(-2, 8), hold: slow ? r.range(0.6, 1.2) : r.range(0.5, 1.5), glide: slow ? r.range(1.2, 2.6) : r.range(0.15, 0.3), away: false };
  },
  think(g, r) {
    if (!g.away) {
      if (r.chance(0.25)) g.side = -(g.side || 1);
      const down = r.chance(0.2);
      return { y: (g.side || 1) * r.range(8, 20), p: down ? r.range(6, 10) : -r.range(7, 13), hold: r.range(1.2, 3), glide: r.range(0.15, 0.4), away: true };
    }
    return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.5, 1.2), glide: 0.2, away: false };
  },
  down(g, r) {
    if (!g.away) return { y: r.range(-18, 18), p: r.range(9, 17), hold: r.range(2, 5), glide: r.range(0.6, 1.4), away: true };
    return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.6, 1.1), glide: 0.3, away: false };
  },
  worry(g, r) {
    if (!g.away) return { y: r.sign() * r.range(10, 20), p: r.range(6, 12), hold: r.range(1.2, 2.6), glide: r.range(0.2, 0.5), away: true };
    return { y: r.range(-2, 2), p: r.range(-2, 1), hold: r.range(1, 2.2), glide: 0.2, away: false };
  },
  dart(g, r) {
    g.n = (g.n || 0) + 1;
    if (g.n % 3 === 0) return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.5, 1), glide: 0.08, away: false };
    return { y: r.sign() * r.range(10, 26), p: r.range(-8, 8), hold: r.range(0.3, 0.8), glide: r.range(0.14, 0.22), away: true };
  },
  lock(g, r) {
    if (!g.away && r.chance(0.25)) return { y: r.sign() * r.range(12, 22), p: r.range(-2, 5), hold: r.range(0.5, 0.9), glide: 0.14, away: true };
    return { y: r.range(-1.5, 1.5), p: r.range(-1, 2), hold: r.range(2, 5), glide: 0.1, away: false };
  }
};

/* ------------------------------------------------------------------------------------------------ springs */
function stepSpring(s, target, f, z, dt) {
  const w = 2 * Math.PI * f, n = Math.max(1, Math.ceil(dt * 120)), h = dt / n;
  for (let i = 0; i < n; i++) { const a = w * w * (target - s.x) - 2 * z * w * s.v; s.v += a * h; s.x += s.v * h; }
}
function springParams(k) {
  if (k.startsWith('e_')) return k === 'e_happy' || k === 'e_sad' || k === 'e_angry' || k === 'e_relaxed' || k === 'e_surprised' ? [3.8, 1] : [8, 1];
  if (k.startsWith('head_')) return [3.0, 0.7];
  if (k.startsWith('neck_')) return [2.8, 0.78];
  if (k.startsWith('chest_') || k.startsWith('upper_')) return [2.5, 0.8];
  if (k.startsWith('spine_')) return [2.2, 0.85];
  if (k.startsWith('hrot_') || k.startsWith('hpos_')) return [1.9, 0.9];
  if (k.startsWith('sh')) return [3.2, 0.82];
  if (k.endsWith('_elbowF') || k.endsWith('_elbowU')) return [2.3, 0.72];
  if (k.endsWith('_twist') || k.endsWith('_wrist')) return [3.2, 0.65];
  if (k.endsWith('_curl') || k.startsWith('fing')) return [4, 0.9];
  if (k.startsWith('L_') || k.startsWith('R_')) return [2.0, 0.75];
  return [2.5, 0.85];
}

/* ------------------------------------------------------------------------------------------------ engine */
function create(seedIn) {
  const seed = seedIn != null ? seedIn : (((Math.random() * 2147483647) | 0) || 12345);
  const rr = mulberry32(seed);
  const r = {
    f: () => rr(), range: (a, b) => a + (b - a) * rr(), chance: (p) => rr() < p, sign: () => (rr() < 0.5 ? -1 : 1),
    pick(list) { let tot = 0; for (const it of list) tot += it[1]; let x = rr() * tot; for (const it of list) { x -= it[1]; if (x <= 0) return it[0]; } return list[0][0]; }
  };
  const noise = makeNoise(rr);
  const offs = {};
  const N = (name, t, hz) => noise(t * hz + (offs[name] !== undefined ? offs[name] : (offs[name] = hashStr(name) * 1.37)));
  // a little permanent asymmetry per session: no two sessions share the exact posture
  const quirk = { roll: r.range(-1.2, 1.2) * D, armL: r.range(-1.5, 1.5) * D, armR: r.range(-1.5, 1.5) * D, yaw: r.range(-1, 1) * D };

  let name = 'idle', B = BEHAVIOUR.idle, P = POSES.idle, started = false;
  const S = {};                           // springs by channel name
  const A = {};                           // event/offset accumulator, rebuilt every frame
  const add = (k, v) => { A[k] = (A[k] || 0) + v; };
  const slots = { body: { cur: null, next: 0 }, arm: { cur: null, next: 0 }, face: { cur: null, next: 0 } };
  const active = [];                      // events started by beats
  const extra = [];                       // beats started by a state change or trigger()
  let sched = null, nextBeat = 0, lastBeat = '';
  const ctl = { L: { name: 'hang', pose: ARMP.hang, from: ARMP.hang, t0: -10, until: Infinity, fast: 1 }, R: { name: 'hang', pose: ARMP.hang, from: ARMP.hang, t0: -10, until: Infinity, fast: 1 } };
  const gaze = { y: 0, p: 0, fromY: 0, fromP: 0, t0: 0, glide: 0, hold: 1, next: 1, away: false };
  const eyeS = { y: { x: 0, v: 0 }, p: { x: 0, v: 0 } };
  const micro = { y: 0, p: 0, next: 0 };
  const shift = { target: 0, x: 0, v: 0, next: 4 };
  const breath = { p: 0 };
  const blink = { t: -1, next: 2.2, k: 1, dbl: false };
  const motif = { phase: 0, on: false, next: 0, gate: 0, f: 1 };

  const F = {
    expr: { happy: 0, sad: 0, angry: 0, relaxed: 0, surprised: 0, aa: 0, ih: 0, ou: 0, ee: 0, oh: 0, blink: 0 },
    rot: { head: { x: 0, y: 0, z: 0 }, neck: { x: 0, y: 0, z: 0 }, chest: { x: 0, y: 0, z: 0 }, upperChest: { x: 0, y: 0, z: 0 }, spine: { x: 0, y: 0, z: 0 }, hips: { x: 0, y: 0, z: 0 } },
    hips: { x: 0, y: 0, z: 0 }, shoulders: { L: 0, R: 0 },
    arm: { L: { down: 0, fwd: 0, elbowF: 0, elbowU: 0, curl: 0, twist: 0, wrist: 0, fing: [0, 0, 0, 0] }, R: { down: 0, fwd: 0, elbowF: 0, elbowU: 0, curl: 0, twist: 0, wrist: 0, fing: [0, 0, 0, 0] } },
    legs: { L: { z: 0, knee: 0 }, R: { z: 0, knee: 0 } }, eye: { yaw: 0, pitch: 0 }, state: 'idle'
  };

  function makeEvent(kind, now, ov) {
    const def = EV[kind];
    const e = { kind, t0: now, dur: def.dur(r), p: def.make(r) };
    if (ov) for (const k in ov) { if (k === 'dur') e.dur = ov.dur; else e.p[k] = ov[k]; }
    return e;
  }

  /* ---- arms: pose to pose with anticipation ---- */
  const restOf = (s) => B.rest[s === 'L' ? 0 : 1];
  function armTo(s, poseName, hold, now, fast) {
    if (poseName === 'rest') poseName = restOf(s);
    const c = ctl[s];
    c.from = c.pose; c.pose = ARMP[poseName] || ARMP.hang; c.name = poseName; c.t0 = now;
    c.until = hold > 0 ? now + hold : Infinity;
    let delta = 1;
    for (const ch of ['down', 'fwd', 'elbowF', 'elbowU']) delta = Math.max(delta, Math.abs(c.pose[ch] - c.from[ch]));
    c.fast = clamp(65 / delta, 0.6, 1.3) * (fast || 1);       // a 120 degree move is leisurely, a 30 degree move is snappy
  }

  /* ---- gaze ---- */
  function curGaze(now) {
    const gu = gaze.glide > 0 ? smooth((now - gaze.t0) / gaze.glide) : 1;
    return [gaze.fromY + (gaze.y - gaze.fromY) * gu, gaze.fromP + (gaze.p - gaze.fromP) * gu];
  }
  function applyGaze(now, pick) {
    const cg = curGaze(now), jump = Math.abs(pick.y - cg[0]);
    gaze.fromY = cg[0]; gaze.fromP = cg[1]; gaze.y = pick.y; gaze.p = pick.p; gaze.t0 = now; gaze.glide = pick.glide; gaze.away = !!pick.away;
    gaze.next = now + pick.glide + pick.hold;
    if (jump > 12 && blink.t < 0 && r.chance(0.5)) blink.next = now + 0.05;      // people blink as the gaze jumps
  }

  /* ---- beats ---- */
  function startBeat(bname, now) {
    const def = BEATS[bname];
    if (!def) return null;
    const o = def(r);
    return { name: bname, t0: now, dur: o.dur, acts: o.acts.slice().sort((a, b) => a.t - b.t), i: 0 };
  }
  function execAct(a, now, bt) {
    if (a.ev) { active.push(makeEvent(a.ev, now, a.ov)); return; }
    if (a.arms) {
      const hold = a.hold != null ? a.hold : Math.max(0.4, bt.dur - a.t);
      if (a.arms.R) armTo('R', a.arms.R, hold, now, a.fast);
      if (a.arms.L) armTo('L', a.arms.L, hold, now, a.fast);
      return;
    }
    if (a.gaze) { applyGaze(now, { y: a.gaze.y, p: a.gaze.p, hold: a.gaze.hold, glide: a.gaze.glide, away: true }); return; }
    if (a.shift !== undefined) { shift.target = a.shift === 'flip' ? (shift.target > 0.2 ? -1 : 1) : a.shift; shift.next = now + r.range(B.shift[0], B.shift[1]); }
  }
  function runBeat(bt, now) {
    const t = now - bt.t0;
    while (bt.i < bt.acts.length && bt.acts[bt.i].t <= t) execAct(bt.acts[bt.i++], now, bt);
    return t >= bt.dur;
  }
  function runBeats(now) {
    for (let i = extra.length - 1; i >= 0; i--) if (runBeat(extra[i], now)) extra.splice(i, 1);
    if (sched) {
      if (runBeat(sched, now)) { sched = null; nextBeat = now + r.range(B.beatGap[0], B.beatGap[1]); }
    } else if (now >= nextBeat && B.beats.length) {
      let bn = r.pick(B.beats);
      if (bn === lastBeat && B.beats.length > 1) bn = r.pick(B.beats);       // never the same thing twice in a row
      lastBeat = bn; sched = startBeat(bn, now);
    }
  }

  function setState(n, now) {
    if (!POSES[n]) n = 'idle';
    if (started && n === name) return;                 // never restart the same state
    started = true;
    name = n; B = BEHAVIOUR[n]; P = POSES[n];
    for (const k in slots) { slots[k].cur = null; slots[k].next = now + r.range(1.2, 2.4); }
    active.length = 0; extra.length = 0; sched = null;
    armTo('L', 'rest', 0, now); armTo('R', 'rest', 0, now);
    let lead = 0;
    for (const bn of B.enter) { const bt = startBeat(bn, now); if (bt) { extra.push(bt); lead = Math.max(lead, bt.dur); } }
    nextBeat = now + lead + r.range(B.beatGap[0], B.beatGap[1]);
    gaze.next = now + 0.4; gaze.away = false;
    shift.next = now + r.range(2, 5);
    blink.next = Math.min(blink.next, now + 1.5);
  }

  function runSlot(slotName, list, gap, now) {
    const s = slots[slotName];
    if (s.cur && now - s.cur.t0 >= s.cur.dur) { s.cur = null; s.next = now + r.range(gap[0], gap[1]); }
    if (!s.cur && now >= s.next && list.length) {
      let kind = r.pick(list);
      if (kind === s.last && list.length > 1) kind = r.pick(list);
      s.last = kind; s.cur = makeEvent(kind, now);
    }
    if (s.cur) { const e = s.cur, t = now - e.t0; EV[e.kind].fx(e.p, clamp(t / e.dur, 0, 1), t, add); }
  }

  function update(now, dt) {
    if (!started) setState('idle', now);
    dt = clamp(dt, 0.001, 0.1);
    for (const k in A) A[k] = 0;
    const V = (k) => (S[k] ? S[k].v : 0);

    // ---- behaviour: micro events, beats, events started by beats ---------------------------------------------------------
    runSlot('body', B.body, B.bodyGap, now); runSlot('arm', B.arm, B.armGap, now); runSlot('face', B.face, B.faceGap, now);
    runBeats(now);
    for (let i = active.length - 1; i >= 0; i--) {
      const e = active[i], t = now - e.t0;
      if (t >= e.dur) { active.splice(i, 1); continue; }
      EV[e.kind].fx(e.p, clamp(t / e.dur, 0, 1), t, add);
    }
    for (const s of ['L', 'R']) if (now > ctl[s].until) armTo(s, 'rest', 0, now);

    // ---- energy: the whole body is livelier or calmer from minute to minute ----------------------------------------------
    const energy = (0.85 + 0.3 * N('energy', now, 0.06)) * B.noise;

    // ---- breathing ---------------------------------------------------------------------------------------------------
    const period = B.breath[0] * (1 + 0.12 * N('bp', now, 0.1));
    breath.p += dt / period; if (breath.p >= 1) breath.p -= 1;
    const bp = breath.p, inh = 0.38;
    const b = bp < inh ? smoother(bp / inh) : bp < inh + 0.06 ? 1 : 1 - smoother((bp - inh - 0.06) / (1 - inh - 0.06));
    const depth = B.breath[1] * (0.85 + 0.3 * N('bd', now, 0.13));
    add('cx', -0.016 * b * depth); add('ux', -0.012 * b * depth); add('sx', -0.004 * b * depth);
    add('shL', 0.02 * b * depth); add('shR', 0.02 * b * depth); add('hpy', 0.002 * b * depth); add('hx', -0.006 * b * depth);
    add('L_down', -0.012 * b * depth); add('R_down', -0.012 * b * depth);
    if (name === 'angry' || name === 'warning') add('e_aa', (name === 'angry' ? 0.06 : 0.05) * (1 - b) * depth);

    // ---- weight shifting ---------------------------------------------------------------------------------------------
    if (now >= shift.next) {
      const opts = [-1, -0.55, 0, 0.55, 1].filter((v) => Math.abs(v - shift.target) >= 0.5);
      shift.target = opts[Math.floor(r.f() * opts.length)];
      shift.next = now + r.range(B.shift[0], B.shift[1]);
    }
    stepSpring(shift, shift.target, 0.55, 1, dt);
    const sa = shift.x * B.shift[2];
    add('hpx', 0.011 * sa); add('pz', 0.03 * sa); add('sz', -0.03 * sa); add('cz', -0.03 * sa); add('uz', -0.02 * sa); add('hz', 0.045 * sa);
    add('shL', 0.025 * sa); add('shR', -0.025 * sa); add('L_down', 0.02 * sa); add('R_down', -0.02 * sa);

    // ---- motif: continuous rhythmic body language with a jittered tempo -------------------------------------------------
    if (B.motif) {
      const M = B.motif;
      if (now >= motif.next) { motif.on = !motif.on; motif.next = now + (motif.on ? r.range(M.on[0], M.on[1]) : r.range(M.off[0], M.off[1])); motif.f = r.range(M.f[0], M.f[1]); }
      motif.gate += ((motif.on ? 1 : 0) - motif.gate) * (1 - Math.exp(-dt / 0.6));
      motif.phase += dt * motif.f * 2 * Math.PI * (1 + 0.12 * N('mf', now, 0.2));
      for (const m of M.map) {
        const x = motif.phase + (m[3] || 0);
        add(m[0], m[1] * motif.gate * (m[2] === 'a' ? Math.abs(Math.sin(x * 0.5)) : m[2] === 'h' ? Math.sin(x * 0.5) : Math.sin(x)));
      }
    }

    // ---- organic noise (incommensurate rates, never loops) -----------------------------------------------------------
    add('hx', 0.012 * energy * N('hx', now, 0.31)); add('hy', 0.018 * energy * N('hy', now, 0.23)); add('hz', 0.02 * energy * N('hz', now, 0.27));
    add('nx', 0.006 * energy * N('nx', now, 0.37)); add('ny', 0.008 * energy * N('ny', now, 0.29)); add('nz', 0.008 * energy * N('nz', now, 0.33));
    add('cx', 0.006 * energy * N('cx', now, 0.21)); add('cy', 0.01 * energy * N('cy', now, 0.17)); add('cz', 0.012 * energy * N('cz', now, 0.19));
    add('ux', 0.004 * energy * N('ux', now, 0.25)); add('uy', 0.006 * energy * N('uy', now, 0.22));
    add('sy', 0.008 * energy * N('sy', now, 0.15)); add('sz', 0.01 * energy * N('sz', now, 0.13));
    add('pz', 0.006 * energy * N('pz', now, 0.11)); add('py', 0.008 * energy * N('py', now, 0.12));
    add('hpx', 0.003 * energy * N('hpx', now, 0.14)); add('hpz', 0.003 * energy * N('hpz', now, 0.16));
    add('shL', 0.012 * energy * N('shL', now, 0.35)); add('shR', 0.012 * energy * N('shR', now, 0.31));
    for (const s of ['L', 'R']) {
      const lv = ctl[s].pose.live * energy;       // a raised hand drifts more than a hanging one
      add(s + '_down', 0.025 * lv * N(s + 'd', now, 0.24)); add(s + '_fwd', 0.03 * lv * N(s + 'f', now, 0.2));
      add(s + '_elbowF', 0.04 * lv * N(s + 'ef', now, 0.28)); add(s + '_twist', 0.08 * lv * N(s + 'tw', now, 0.3));
      add(s + '_wrist', 0.06 * lv * N(s + 'wr', now, 0.36)); add(s + '_curl', 0.05 * N(s + 'cu', now, 0.18));
    }
    add('e_happy', 0.03 * N('eh', now, 0.2)); add('e_relaxed', 0.02 * N('er', now, 0.17));

    // ---- follow-through: things lag what moved them ----------------------------------------------------------------------
    add('hx', -0.035 * (V('chest_x') + V('upper_x'))); add('hz', -0.05 * (V('chest_z') + V('spine_z') + V('hrot_z'))); add('hy', -0.04 * (V('chest_y') + V('upper_y') + V('spine_y')));
    add('hx', -0.25 * V('hpos_y')); add('shL', -0.3 * V('hpos_y')); add('shR', -0.3 * V('hpos_y'));
    for (const s of ['L', 'R']) {
      add(s + '_wrist', clamp(-0.06 * (V(s + '_elbowF') + 0.5 * V(s + '_down') + 0.5 * V(s + '_elbowU')), -0.35, 0.35));
      add(s + '_down', (s === 'L' ? 1 : -1) * clamp(-0.08 * (V('hrot_z') + V('chest_z')), -0.1, 0.1));
    }

    // ---- gaze director -----------------------------------------------------------------------------------------------
    if (now >= gaze.next) applyGaze(now, LOOK[B.look](gaze, r));
    const cg = curGaze(now), gy = cg[0], gp = cg[1];
    // the head takes most of the turn, the eyes the rest
    add('hy', 0.55 * gy * D); add('ny', 0.2 * gy * D); add('uy', 0.08 * gy * D); add('cy', 0.05 * gy * D); add('hz', -0.06 * gy * D);
    add('hx', 0.5 * gp * D); add('nx', 0.15 * gp * D); add('cx', 0.05 * gp * D);

    // ---- targets -> springs ------------------------------------------------------------------------------------------
    const sp = B.speed;
    const tgt = {};
    for (const k of EXPR) {
      const base = (P.e && P.e[k]) || 0;
      tgt['e_' + k] = clamp(base * (1 + 0.1 * N('x' + k, now, 0.35)) + (A['e_' + k] || 0), 0, 1);   // emotions breathe a little
    }
    const bone = (key, pre, base) => {
      tgt[pre + '_x'] = rad(base && base.x) + (A[key + 'x'] || 0);
      tgt[pre + '_y'] = rad(base && base.y) + (A[key + 'y'] || 0);
      tgt[pre + '_z'] = rad(base && base.z) + (A[key + 'z'] || 0);
    };
    bone('h', 'head', P.head); bone('n', 'neck', P.neck); bone('c', 'chest', P.chest); bone('u', 'upper', P.upperChest); bone('s', 'spine', P.spine); bone('p', 'hrot', null);
    tgt.head_z += quirk.roll; tgt.head_y += quirk.yaw;
    tgt.hpos_x = A.hpx || 0; tgt.hpos_y = A.hpy || 0; tgt.hpos_z = A.hpz || 0;
    tgt.shL = rad(P.shoulders) + (A.shL || 0); tgt.shR = rad(P.shoulders) + (A.shR || 0);
    for (const s of ['L', 'R']) {
      const c = ctl[s], age = now - c.t0, ant = age < 0.2 ? -0.14 * Math.sin(Math.PI * age / 0.2) : 0;   // anticipation: a small move the other way first
      for (const ch of ARM_CH) {
        const base = c.pose[ch];
        let v = base + (base - c.from[ch]) * ant;
        if (ch !== 'curl') v = rad(v);
        if (c.pose.osc) for (const o of c.pose.osc) if (o[0] === ch && age > o[4]) v += o[1] * Math.sin(2 * Math.PI * o[2] * (age - o[4])) * smooth((age - o[4]) / o[3]);
        v += A[s + '_' + ch] || 0;
        if (ch === 'down') v += s === 'L' ? quirk.armL : quirk.armR;
        tgt[s + '_' + ch] = ch === 'curl' ? clamp(v, 0, 1) : v;
      }
      for (let i = 0; i < 4; i++) tgt['fing' + s + i] = 0.08 * N('fi' + s + i, now, 0.22);
    }
    for (const k in tgt) {
      let s = S[k];
      if (!s) s = S[k] = { x: tgt[k], v: 0 };
      const pr = springParams(k);
      let f = k.startsWith('e_') ? pr[0] * (0.7 + 0.3 * sp) : pr[0] * sp;
      if (k.charCodeAt(1) === 95 && (k[0] === 'L' || k[0] === 'R')) f *= ctl[k[0]].fast;    // quick poses (clapping) get stiffer arms
      stepSpring(s, tgt[k], f, pr[1], dt);
    }
    const Vx = (k) => S[k].x;

    // ---- eyes: saccade first, head follows, eyes counter-rotate (VOR) -------------------------------------------------
    if (now >= micro.next) { micro.y = r.range(-1.3, 1.3); micro.p = r.range(-0.9, 0.9); micro.next = now + r.range(0.3, 1.2); }
    const dynYaw = (Vx('head_y') + Vx('neck_y') + Vx('upper_y') + Vx('chest_y') - rad(P.head && P.head.y) - rad(P.neck && P.neck.y)) / D;
    const dynPitch = (Vx('head_x') + Vx('neck_x') + Vx('chest_x') - rad(P.head && P.head.x) - rad(P.neck && P.neck.x) - rad(P.chest && P.chest.x)) / D;
    const bias = P.gaze || ZERO2;
    stepSpring(eyeS.y, clamp(gy - dynYaw + (bias.yaw || 0) + micro.y, -10, 10), 16, 0.85, dt);
    stepSpring(eyeS.p, clamp(gp - dynPitch + (bias.pitch || 0) + micro.p, -8, 8), 16, 0.85, dt);

    // ---- blinking ----------------------------------------------------------------------------------------------------
    if (blink.t < 0 && now >= blink.next) { blink.t = 0; blink.k = name === 'offline' ? 1.5 : name === 'warning' ? 0.8 : 1; }
    let pulse = 0;
    if (blink.t >= 0) {
      blink.t += dt;
      const c = 0.075 * blink.k, h = 0.025, o = 0.15 * blink.k, tb = blink.t;
      if (tb < c) pulse = smooth(tb / c); else if (tb < c + h) pulse = 1; else if (tb < c + h + o) pulse = 1 - smooth((tb - c - h) / o); else {
        blink.t = -1; pulse = 0;
        blink.next = now + (blink.dbl ? 0.28 : clamp(1.2 + -Math.log(1 - r.f() * 0.97) * (B.blink - 1.2), 1.2, 9));
        blink.dbl = !blink.dbl && r.chance(0.15);
      }
    }

    // ---- build the frame ---------------------------------------------------------------------------------------------
    const E = F.expr;
    for (const k of EXPR) E[k] = clamp(Vx('e_' + k), 0, 1);
    const joy = Math.min(1, E.happy * 1.2);                 // VRoid "Joy" already closes the eyes
    const lidFollow = 0.1 * clamp(eyeS.p.x / 8, 0, 1.2);    // lids follow the gaze down
    E.blink = clamp(Math.max(P.blink + lidFollow + 0.03 * N('lid', now, 0.2), pulse, A.blinkAdd || 0), 0, 1) * (1 - joy);

    const rot = F.rot;
    for (const [key, pre] of [['head', 'head'], ['neck', 'neck'], ['chest', 'chest'], ['upperChest', 'upper'], ['spine', 'spine'], ['hips', 'hrot']]) {
      rot[key].x = Vx(pre + '_x'); rot[key].y = Vx(pre + '_y'); rot[key].z = Vx(pre + '_z');
    }
    F.hips.x = Vx('hpos_x'); F.hips.y = Vx('hpos_y'); F.hips.z = Vx('hpos_z');
    F.shoulders.L = Vx('shL'); F.shoulders.R = Vx('shR');
    for (const s of ['L', 'R']) {
      const a = F.arm[s];
      a.down = Vx(s + '_down'); a.fwd = Vx(s + '_fwd'); a.elbowF = Vx(s + '_elbowF'); a.elbowU = Vx(s + '_elbowU');
      a.twist = Vx(s + '_twist'); a.wrist = Vx(s + '_wrist'); a.curl = Vx(s + '_curl');
      for (let i = 0; i < 4; i++) a.fing[i] = Vx('fing' + s + i);
    }
    // legs: small counter-balance so the lower body is not frozen if the camera ever pulls back
    F.legs.L.z = 0.5 * rot.hips.z; F.legs.R.z = 0.5 * rot.hips.z;
    F.legs.L.knee = 0.03 + 0.05 * Math.max(0, shift.x); F.legs.R.knee = 0.03 + 0.05 * Math.max(0, -shift.x);
    F.eye.yaw = eyeS.y.x; F.eye.pitch = eyeS.p.x;
    F.state = name;
    return F;
  }

  /* Preview helper: trigger('beat', 'clap', now) / trigger('event', 'laugh', now) / trigger('body', 'nod', now). Used by window.wapfireTrigger. */
  function trigger(slot, kind, now) {
    if (slot === 'beat') { const bt = startBeat(kind, now); if (!bt) return false; extra.push(bt); return true; }
    if (!EV[kind]) return false;
    if (slot === 'event') { active.push(makeEvent(kind, now)); return true; }
    if (!slots[slot]) return false;
    slots[slot].cur = makeEvent(kind, now); slots[slot].last = kind;
    return true;
  }

  function debug() {
    return { state: name, beat: sched && sched.name, extra: extra.map((e) => e.name), arms: { L: ctl.L.name, R: ctl.R.name }, events: active.map((e) => e.kind),
      slots: { body: slots.body.cur && slots.body.cur.kind, arm: slots.arm.cur && slots.arm.cur.kind, face: slots.face.cur && slots.face.cur.kind }, gaze: { y: gaze.y, p: gaze.p }, shift: shift.target };
  }

  return { setState, update, debug, trigger };
}

export { create, POSES, BEHAVIOUR, ARMP, BEATS, EV, EXPR, STATE_NAMES };
export default { create, POSES, BEHAVIOUR, ARMP, BEATS, EV, EXPR, STATE_NAMES };
