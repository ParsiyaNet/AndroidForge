# WAPFire Mobile 4.5.0 — production-style character motion

Feedback on 4.4.0: the **idle** motion is very good (keep it, make it richer); the **other states** still looked bad, not natural,
not like production animation.

## Why the other states still looked wrong (4.4.0)
- Each state held ONE raised arm pose for as long as the state lasted (hands at the chin, hands beside the face ...), both sides identical.
  A held, symmetrical pose reads as a statue; idle only looked good because its arms simply hang.
- Gestures were small random events that had nothing to do with where the character looked, so nothing looked intentional.
- The face was frozen at one weight (angry 0.85 for minutes), the mouth never moved, arm moves were too fast and stiff.

## What 4.5.0 changes
**Idle is untouched at its core** (breathing, weight shift, noise, gaze, blinking, the small micro gestures) and gets 12 new things to do:
hair tuck / touching the cheek, looking at her hands, stretching, humming with a sway and small lip movements, shy glance with clasped
hands, noticing something, hands behind the back, yawning (hand to mouth, eyes close), thinking with a hand at the chin,
a small wave hello, calm clasped hands, leaning in with a smile.

**All other states are choreographed with "beats".** A beat is a short piece of acting in which gaze, head, torso, both arms and the face
are timed together (look -> head follows -> hand rises -> expression -> settle). Each state has 6-8 beats, picked at random with random
side / timing / amplitude, never the same beat twice in a row, so the character is always doing something with intent:
- scanning: sweeping looks, checking a device in her hands, hand at the chin, leaning in, tapping, quick glances
- connecting: thinking with a finger tapping the chin, looking around with palms up, "hmm", apologetic "one moment", waiting sway, impatience
- success: arms-up cheer with a hop and a laugh, clapping, fist pump, bounce and sway, giggling behind the hand, wave, proud pose, sway
- password_success: approving nods, relief sigh, satisfied lean, soft clap, humming, small giggle
- password_warning: "no, no" head shake with hands up, wringing hands, hand over the mouth, sigh and shake, looking away, apology bow, nervous fidgeting
- warning: alert scanning, startle with hands at the chest, freezing to listen, gulp and glance, huddling, "stop" gesture
- angry: glare with heavy breathing, scoff and side-glance, raised fists with a stomp, fist shake, slow head shake, tense fists
- offline: big sigh and slump, looking up sadly then away, slow head shake, hugging herself, wiping the face / sniff, weight sag, helpless shrug
- setup: wave hello, beckoning, open palms, talking with both hands, pointing to a side, excited clap, cheerful sway

**Real arm poses with anticipation.** 25 arm poses (hands clasped, chest, chin, tap-on-chin, cheek, mouth, pray, fists, wave, cheer, talk ...)
were measured on the real model (`wapfireProbe`) and checked by rendering, so hands never end up outside the picture or over the face.
Arms move pose to pose with a small move the other way first, overshoot and settle; big moves are leisurely, small ones snappy; left and
right are scheduled independently so a gesture is not perfectly symmetrical.

**Follow-through.** Wrists lag the forearm, the head lags the torso and the hips, shoulders lag a hop, hanging arms swing with the body.

**Motifs.** Continuous rhythm with a jittered tempo: happy bounce (success), nervous rocking (password_warning), slow sad sway (offline),
toe-bounce (setup).

**Face acting.** Emotions breathe by +/-10 %, the mouth has its own small shapes (hum, gasp, giggle, tsk, gritted teeth), brows flick.

**No more rigid held poses**: between beats the arms return to a calm state-specific rest pose (hands low in front, clasped, tense fists ...).

## Verified here
- Real page + nara.vrm rendered in headless Chromium with a controllable clock: filmstrips of every state and of the new beats were
  inspected frame by frame (success, warning, angry, connecting, offline, setup, password_warning, idle hair-tuck / stretch).
- Engine in node: all 66 beats x 60 random draws validated (event / pose names, timings, no NaN), 3 simulated minutes per state: every beat
  of every state gets played, head-yaw autocorrelation 0.09-0.27 (no loops), 15-120 fps stable.
- Page: no errors, state switching, compact and full framing.
- NOT verified: a real Android build / on-device feel (no Android SDK here). If a state feels too busy or too calm, tune `BEHAVIOUR` at
  the top of `vrm-pose.js`: `beatGap` (pause between beats), `noise`, `breath`, `speed`; or remove a beat from the `beats` list.

## Developer aids
`wapfireTrigger('beat', 'clap')`, `('event', 'laugh')`, `('body', 'nod')` play one thing now; `wapfireMotionInfo()` shows the running beat,
arm poses and gaze; `wapfireFreezePose({...})` / `wapfireProbe(side, down, fwd, elbowF, elbowU)` for pose work.
Versions: versionCode 106 / versionName 4.5.0.
