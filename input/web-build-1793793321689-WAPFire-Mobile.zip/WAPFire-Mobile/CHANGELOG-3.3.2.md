# WAPFire Mobile 3.3.2 / Firmware 3.1.1 — BLE provisioning resource fix

## Firmware
- Added an explicit low-internal-DRAM setup/BLE maintenance profile. During first-time setup or BLE management, the firmware keeps Wi-Fi SoftAP/WebUI and BLE but defers the RF packet pool, promiscuous capture, RF worker stacks, W5500/Ethernet, NTP and HTTP reporting worker.
- Ethernet/NTP recovery loops are gated during maintenance so they cannot recreate deferred tasks. Target/RF background work is also paused.
- Completing the existing Wi-Fi Setup wizard triggers a board restart so the full RF runtime is initialized in normal mode.
- Enabling/disabling BLE management triggers a restart into the correct runtime profile. BLE maintenance mode intentionally pauses RF detection, Ethernet, NTP and HTTP reporting.
- An explicit `configured=false` Preferences marker is authoritative; legacy auto-detection runs only when no marker exists. This prevents BLE-saved first-boot credentials from skipping the normal Wi-Fi Setup wizard.
- Added serial diagnostics for BLE RX queueing, command processing, TX notifications, and internal heap/largest block.
- Corrected `BLECharacteristic::getValue()` handling for Arduino-ESP32 Core 3.3.12 using Arduino `String`.

## Android
- A command timeout no longer hides an otherwise connected encrypted GATT session.
- When pairing succeeds but no `info` response arrives, the screen shows a waiting/diagnostic card and allows retry.
- The app explains the temporary runtime trade-off while BLE management is enabled.

## Validation limits
- Static source-path checks and archive integrity checks are performed.
- Arduino/ESP32-S3 compilation, Android Gradle build, and physical hardware/phone tests were not available here; no successful build or pairing test is claimed.
