import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 101
        versionName = "4.1.55"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// Use the LivLiv character package bundled in the source tree. Do not fetch or
// overwrite character assets during Gradle configuration/build.
val verifyLocalLivLivCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val coverAsset = file("src/main/assets/assistant/characters/v03/cover.webp")
    val avatarAsset = file("src/main/assets/assistant/characters/v03/avatar.webp")

    inputs.files(modelAsset, coverAsset, avatarAsset)

    doLast {
        listOf(modelAsset, coverAsset, avatarAsset).forEach { asset ->
            if (!asset.isFile || asset.length() == 0L) {
                throw GradleException("Required bundled LivLiv asset is missing or empty: ${asset.relativeTo(projectDir)}")
            }
        }

        try {
            ZipFile(modelAsset).use { archive ->
                val modelJson = archive.getEntry("model.json")
                    ?: throw GradleException("${modelAsset.name} does not contain model.json")
                if (modelJson.size <= 0L) {
                    throw GradleException("${modelAsset.name} contains an empty model.json")
                }

                // Read every entry so corrupt/truncated ZIP data is caught before packaging.
                val entries = archive.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (!entry.isDirectory) {
                        archive.getInputStream(entry).use { input ->
                            input.copyTo(java.io.OutputStream.nullOutputStream())
                        }
                    }
                }
            }
        } catch (error: Exception) {
            throw GradleException("The bundled LivLiv model is invalid: ${error.message}", error)
        }

        logger.lifecycle(
            "Using bundled local LivLiv model: ${modelAsset.relativeTo(projectDir)}"
        )
    }
}

tasks.named("preBuild").configure {
    dependsOn(verifyLocalLivLivCharacter)
}
