# WAPFire Mobile 4.1.55 — Local LivLiv model build

- Removed the Gradle pre-build task that downloaded `v06_clean.livliv` from GitHub and overwrote the packaged character.
- The APK now packages the model already present at `app/src/main/assets/assistant/characters/v03.livliv`.
- Added a pre-build integrity check for the bundled `.livliv` archive and its local cover/avatar preview assets.
- Kept the runtime WebViewAssetLoader and `player.load('./characters/v03.livliv', ...)` path unchanged; model and textures remain local to the APK.
