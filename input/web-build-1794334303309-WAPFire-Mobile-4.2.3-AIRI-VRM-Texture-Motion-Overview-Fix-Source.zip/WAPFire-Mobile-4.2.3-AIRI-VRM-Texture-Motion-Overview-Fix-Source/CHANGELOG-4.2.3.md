# WAPFire Mobile 4.2.3

- Retains the original WAPFire 4.2.0 Compose Overview card, spacing, and 300dp character viewport.
- Uses AvatarSample_A.vrm with the pinned AIRI VRM animation pipeline; no voice, TTS, microphone, or speech-recognition features.
- Adds explicit legacy VRM 0.x orientation compatibility for AvatarSample_A.
- Preserves authored base-color texture maps, forces correct sRGB handling, and validates that color textures are present before declaring the renderer ready.
- Removes the unintended +20% vertical camera-center offset and restores the conservative 1.10 camera-fit margin.
- If the optional AIRI idle_loop clip cannot be installed, the model stays loaded and a low-amplitude local idle fallback keeps the avatar animated instead of disposing the character.
- Keeps the original native Overview layout; no change to the card height or speech-panel layout.
