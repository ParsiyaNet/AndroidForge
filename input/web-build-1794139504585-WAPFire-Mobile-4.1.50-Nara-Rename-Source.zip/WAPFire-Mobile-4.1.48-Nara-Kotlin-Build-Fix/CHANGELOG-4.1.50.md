# WAPFire Mobile 4.1.50

- Renamed the assistant tab and setup presentation to Nara (نارا).
- Updated the live character title, speech label, and accessibility description to identify Nara as the WAPFire network guardian.
- Kept the AndroidForge `v06_clean.livliv` character model unchanged; its embedded model metadata already declares the name Nara.
- Updated the assistant bootstrap asset/build version and Android versionCode to 91 / versionName 4.1.50.
- Corrected the character notice to identify the v06_clean package.
