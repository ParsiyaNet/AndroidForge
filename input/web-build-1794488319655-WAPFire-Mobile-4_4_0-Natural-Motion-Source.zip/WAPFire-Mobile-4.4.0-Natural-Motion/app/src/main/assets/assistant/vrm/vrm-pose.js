/* WAPFire 4.4.0 - VRM natural-motion engine (pure logic, no DOM, no three.js).
 *
 * create(seed?) returns { setState(name, now), update(now, dt) -> frame, debug() }.
 *
 * Why 4.3.0 looked "robotic and repeating": every state was ONE fixed pose plus a few sine waves with fixed periods
 * (so the same loop forever), gestures played once when the state began and then never again, the legs/hips/upper chest
 * never moved, and joints blended with a plain exponential lerp (no inertia, no overshoot, everything arriving together).
 *
 * 4.4.0 builds the motion in layers, all randomised so no two seconds look the same:
 *   1. base pose of the state (emotion + posture)                      -> targets
 *   2. breathing (asymmetric inhale/exhale, varying rate and depth, occasional sigh)
 *   3. weight shifting (hips / spine / shoulders counter-rotate, slow)
 *   4. smooth noise on head, neck, torso, arms, fingers (never periodic)
 *   5. gaze director: eyes saccade first, head follows with lag, eyes counter-rotate while the head catches up
 *   6. event scheduler, three independent slots (body / arms / face), each with a weighted menu per state:
 *      nods, tilts, shrugs, sighs, leaning, hand fidgets, waves, head shakes, smiles, brow flicks ... every one
 *      is created with random amplitude, duration and side
 *   7. every channel goes through an under-damped spring (head lags and overshoots a little, hips are heavier)
 *   8. natural blinking (random interval, double blinks, blink on big gaze shifts, lids follow gaze pitch)
 *
 * Conventions of the frame (all radians unless noted; WORLD semantics, vrm.js converts to the rig):
 *   pitch (x): + = nose/chest toward the floor      yaw (y): + = toward screen right      roll (z): + = top toward screen left
 *   hips.x: + = screen right, hips.z: + = toward the camera, hips.y: + = up (metres)
 *   shoulders.L/R: raise            eye.yaw/eye.pitch: DEGREES of eye rotation wanted (pitch + = down)
 *   arm: down (0 = T-pose, 1.22 = relaxed), fwd, elbowF, elbowU, twist, wrist, curl (0..1), fing[4] per-finger curl offsets
 * Expression names follow three-vrm: happy, sad, angry, relaxed, surprised (custom), aa (mouth), blink.
 */
const D = Math.PI / 180;
const rad = (v) => (v || 0) * D;
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const smooth = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const smoother = (x) => { x = clamp(x, 0, 1); return x * x * x * (x * (x * 6 - 15) + 10); };
const bell = (u) => { const s = Math.sin(Math.PI * clamp(u, 0, 1)); return s * s; };
const trap = (u, a) => smoother(u / (a || 0.25)) * smoother((1 - u) / (a || 0.25));

const EXPR = ['happy', 'sad', 'angry', 'relaxed', 'surprised', 'aa'];
const STATE_NAMES = ['idle', 'scanning', 'connecting', 'success', 'password_success', 'password_warning', 'warning', 'angry', 'offline', 'setup'];

/* ------------------------------------------------------------------------------------------------ random + noise */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeNoise(rnd) {
  const G = new Float32Array(256);
  for (let i = 0; i < 256; i++) G[i] = rnd() * 2 - 1;
  return (x) => {
    const i0 = Math.floor(x), f = x - i0;
    const a = G[i0 & 255], b = G[(i0 + 1) & 255];
    const u = f * f * f * (f * (f * 6 - 15) + 10);
    return clamp(2.4 * (a * f * (1 - u) + b * (f - 1) * u), -1, 1);
  };
}
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) % 997; }

/* ------------------------------------------------------------------------------------------------ base poses (degrees) */
const REST_ARM = { down: 70, fwd: 3, elbowF: 8, elbowU: 0, curl: 0.28, twist: 0, wrist: 0 };
const arm = (o) => Object.assign({}, REST_ARM, o || {});
const ZERO = { x: 0, y: 0, z: 0 };

const POSES = {
  idle: { e: { happy: 0.14 }, blink: 0, head: { x: 0, y: 0, z: 0 }, L: arm(), R: arm({ down: 71.5 }) },
  scanning: { e: { angry: 0.1 }, blink: 0.1, head: { x: 3, y: 0, z: 0 }, chest: { x: 1.5 },
    L: arm({ down: 72, fwd: 38, elbowF: 58 }), R: arm({ down: 72, fwd: 38, elbowF: 58 }) },
  connecting: { e: { happy: 0.1, relaxed: 0.3 }, blink: 0, head: { x: -2, y: 4, z: 6 }, gaze: { yaw: 0, pitch: -5 },
    L: arm({ down: 70, fwd: 6, elbowF: 14 }), R: arm({ down: 62, fwd: 66, elbowF: 66 }) },
  success: { e: { happy: 0.72, relaxed: 0.15 }, blink: 0, head: { x: -4, y: 0, z: 4 }, chest: { x: -2 },
    L: arm({ down: 40, fwd: 60, elbowF: 60, elbowU: 40 }), R: arm({ down: 40, fwd: 60, elbowF: 60, elbowU: 40 }) },
  password_success: { e: { happy: 0.6, relaxed: 0.2 }, blink: 0, head: { x: 0, y: 0, z: 3 },
    L: arm({ down: 78, fwd: 40, elbowF: 56 }), R: arm({ down: 78, fwd: 40, elbowF: 56 }) },
  password_warning: { e: { sad: 0.6, surprised: 0.1 }, blink: 0, head: { x: 4, y: 0, z: -6 }, gaze: { yaw: 0, pitch: 3 },
    L: arm({ down: 78, fwd: 52, elbowF: 66 }), R: arm({ down: 78, fwd: 52, elbowF: 66 }) },
  warning: { e: { surprised: 0.8, sad: 0.1 }, blink: 0, head: { x: -5, y: 0, z: 0 }, chest: { x: -4 }, shoulders: 7,
    L: arm({ down: 60, fwd: 56, elbowF: 66, elbowU: 20 }), R: arm({ down: 60, fwd: 56, elbowF: 66, elbowU: 20 }) },
  angry: { e: { angry: 0.85 }, blink: 0.2, head: { x: 11, y: 0, z: 0 }, neck: { x: 4 }, chest: { x: 7 }, spine: { x: 3 }, shoulders: 4,
    gaze: { yaw: 0, pitch: -6 },
    L: arm({ down: 78, fwd: 32, elbowF: 58, curl: 1 }), R: arm({ down: 78, fwd: 32, elbowF: 58, curl: 1 }) },
  offline: { e: { sad: 0.9 }, blink: 0.3, head: { x: 15, y: 0, z: -5 }, neck: { x: 4 }, chest: { x: 8 }, spine: { x: 4 }, shoulders: -3,
    gaze: { yaw: 0, pitch: 5 },
    L: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0.12 }), R: arm({ down: 76, fwd: 0, elbowF: 4, curl: 0.12 }) },
  setup: { e: { happy: 0.5, relaxed: 0.2 }, blink: 0, head: { x: -2, y: 0, z: 6 },
    L: arm({ down: 68 }), R: arm({ down: 68 }) }
};

/* Per-state behaviour: look mode, breathing [period s, depth], mean blink interval, noise strength, weight shift
 * [min s, max s, amount], spring speed, and a weighted menu of events per slot with the gap between them. */
const BEHAVIOUR = {
  idle: { look: 'viewer', breath: [4.4, 1], blink: 3.8, noise: 1, shift: [5, 10, 1], speed: 1,
    body: [['tilt', 3], ['nod', 1.2], ['shrug', 0.8], ['sigh', 0.9], ['lean', 1.2], ['neckroll', 1]], bodyGap: [2.8, 6.5],
    arm: [['fidget', 3], ['adjust', 1.2]], armGap: [3.5, 8],
    face: [['smile', 3], ['smirk', 1.5], ['curious', 0.8]], faceGap: [3, 8], enter: [] },
  scanning: { look: 'sweep', breath: [4.0, 0.9], blink: 5.5, noise: 0.65, shift: [6, 12, 0.6], speed: 1.1,
    body: [['lean', 3], ['focus', 2], ['tilt', 2], ['nod', 0.8]], bodyGap: [2.5, 5.5],
    arm: [['fidget', 2], ['adjust', 1]], armGap: [4, 9],
    face: [['curious', 1.5], ['smirk', 0.5]], faceGap: [4, 9], enter: [['body', 'focus']] },
  connecting: { look: 'think', breath: [4.2, 1], blink: 3.2, noise: 1.1, shift: [5, 9, 0.8], speed: 1,
    body: [['tilt', 3], ['nod', 1.5], ['shrug', 1], ['neckroll', 1], ['thinkIn', 1.5]], bodyGap: [2, 5],
    arm: [['chinTap', 3], ['fidget', 1.5], ['adjust', 1]], armGap: [2.5, 6],
    face: [['curious', 2], ['smile', 1], ['smirk', 1]], faceGap: [2.5, 6], enter: [['body', 'thinkIn']] },
  success: { look: 'warm', breath: [3.6, 1.15], blink: 3.0, noise: 1.3, shift: [3, 6, 1.2], speed: 1.3,
    body: [['bounce', 3], ['giggle', 3], ['tilt', 2], ['nod', 1.5], ['hop', 1.5], ['shrug', 0.5]], bodyGap: [1.8, 4],
    arm: [['pump', 2.5], ['fidget', 1.5], ['wave', 0.8]], armGap: [2.5, 5.5],
    face: [['grin', 3], ['smile', 2]], faceGap: [2.5, 5], enter: [['body', 'hop'], ['arm', 'pump']] },
  password_success: { look: 'warm', breath: [4, 1], blink: 3.4, noise: 1, shift: [5, 9, 1], speed: 1.1,
    body: [['nod', 3], ['tilt', 2], ['lean', 1], ['sigh', 0.6], ['giggle', 0.8]], bodyGap: [2.5, 5.5],
    arm: [['fidget', 2], ['adjust', 1.2]], armGap: [3.5, 8],
    face: [['smile', 3], ['grin', 1]], faceGap: [3, 7], enter: [['body', 'nod']] },
  password_warning: { look: 'worry', breath: [3.8, 1.05], blink: 2.8, noise: 1.1, shift: [4, 8, 1], speed: 0.95,
    body: [['shake', 3], ['sigh', 1.5], ['tilt', 2], ['shrug', 1.2]], bodyGap: [2.5, 6],
    arm: [['wring', 3], ['fidget', 1.5]], armGap: [2, 5],
    face: [['worry', 3], ['curious', 1]], faceGap: [2.5, 6], enter: [['body', 'shake']] },
  warning: { look: 'dart', breath: [2.6, 0.9], blink: 4.8, noise: 1.2, shift: [3, 6, 0.8], speed: 1.8,
    body: [['flinch', 3], ['lean', 1], ['tilt', 1.2], ['shrug', 1]], bodyGap: [1.6, 3.8],
    arm: [['wring', 1], ['fidget', 1.5], ['adjust', 1]], armGap: [2, 5],
    face: [['curious', 2], ['worry', 1]], faceGap: [2, 5], enter: [['body', 'startle']] },
  angry: { look: 'lock', breath: [2.4, 1.35], blink: 6.5, noise: 0.6, shift: [4, 8, 0.7], speed: 1.5,
    body: [['scoff', 3], ['lean', 2], ['tilt', 1], ['shrug', 0.5], ['shake', 0.7]], bodyGap: [2.2, 5],
    arm: [['clench', 3], ['fidget', 0.8]], armGap: [2, 4.5],
    face: [['glare', 3], ['smirk', 0.4]], faceGap: [2.5, 5], enter: [['body', 'lunge'], ['arm', 'clench']] },
  offline: { look: 'down', breath: [6, 1.25], blink: 2.9, noise: 0.8, shift: [6, 12, 0.8], speed: 0.65,
    body: [['sigh', 3], ['shake', 1.2], ['tilt', 1.5], ['shrug', 0.8]], bodyGap: [3, 7],
    arm: [['fidget', 2.5], ['adjust', 0.6]], armGap: [3.5, 8],
    face: [['worry', 2]], faceGap: [3, 8], enter: [['body', 'collapse']] },
  setup: { look: 'warm', breath: [4, 1], blink: 3.4, noise: 1.1, shift: [4, 8, 1], speed: 1.1,
    body: [['nod', 2], ['tilt', 3], ['bounce', 1.5], ['lean', 1.5], ['shrug', 0.6]], bodyGap: [2.2, 5],
    arm: [['wave', 1.5], ['beckon', 2.5], ['fidget', 1.5]], armGap: [3.5, 8],
    face: [['smile', 3], ['curious', 1]], faceGap: [2.5, 6], enter: [['arm', 'wave']] }
};

/* ------------------------------------------------------------------------------------------------ events */
/* Every event: dur(r) -> seconds, make(r) -> params, fx(p, u, t, add, P) adds offsets; u = 0..1 progress, t = seconds in.
 * add(key, value): hx/hy/hz head, nx.. neck, cx.. chest, ux.. upper chest, sx.. spine, hpy/hpz/hpx hips position,
 * shL/shR shoulders, L_xxx / R_xxx arms, e_xxx expressions. P is the state's base pose in degrees. */
const EV = {
  nod: { dur: (r) => r.range(0.9, 1.5), make: (r) => ({ a: r.range(4, 8) * D, n: r.chance(0.4) ? 2 : 1 }),
    fx(p, u, t, add) { const w = Math.pow(Math.sin(Math.PI * u * p.n), 2) * (1 - 0.3 * u); add('hx', p.a * w); add('nx', p.a * 0.3 * w); add('cx', p.a * 0.2 * w); } },
  tilt: { dur: (r) => r.range(2.4, 6), make: (r) => ({ roll: r.sign() * r.range(3, 8) * D, yaw: r.range(-4, 4) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add('hz', p.roll * w); add('hy', p.yaw * w); add('nz', p.roll * 0.3 * w); add('sz', -p.roll * 0.2 * w); } },
  shrug: { dur: (r) => r.range(0.9, 1.4), make: (r) => ({ a: r.range(0.07, 0.12) }),
    fx(p, u, t, add) { const w = bell(u); add('shL', p.a * w); add('shR', p.a * w); add('L_down', -0.05 * w); add('R_down', -0.05 * w); add('hx', -0.03 * w); } },
  sigh: { dur: (r) => r.range(3.6, 4.8), make: () => ({}),
    fx(p, u, t, add) {
      const ib = 0.35, b = u < ib ? smooth(u / ib) : 1 - smooth((u - ib) / (1 - ib));
      add('cx', -0.06 * b); add('ux', -0.04 * b); add('shL', 0.05 * b); add('shR', 0.05 * b); add('hx', -0.03 * b);
      const ex = bell(clamp((u - ib) / (1 - ib), 0, 1));
      add('hx', 0.06 * ex); add('shL', -0.03 * ex); add('shR', -0.03 * ex); add('e_aa', 0.1 * ex);
    } },
  lean: { dur: (r) => r.range(2, 5), make: (r) => ({ a: (r.chance(0.7) ? 1 : -1) * r.range(3, 6) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add('cx', p.a * w); add('ux', p.a * 0.5 * w); add('hx', -p.a * 0.6 * w); } },
  neckroll: { dur: () => 1.8, make: (r) => ({ s: r.sign(), a: r.range(4, 6) * D }),
    fx(p, u, t, add) { const w = Math.sin(2 * Math.PI * u) * bell(u); add('hz', p.s * p.a * w); add('ny', p.s * 0.03 * w); } },
  giggle: { dur: (r) => r.range(1, 1.6), make: () => ({}),
    fx(p, u, t, add) {
      const w = bell(u), osc = Math.sin(2 * Math.PI * 5.5 * t) * w;
      add('shL', 0.04 * osc); add('shR', 0.04 * osc); add('hpy', 0.004 * Math.abs(osc)); add('e_happy', 0.2 * w); add('hx', -0.02 * w); add('e_aa', 0.1 * w * (0.5 + 0.5 * osc));
    } },
  hop: { dur: () => 1.4, make: () => ({}),
    fx(p, u, t, add) { if (t < 1.3) { const e = Math.abs(Math.sin(Math.PI * t / 0.65)) * Math.exp(-t * 1.2); add('hpy', 0.035 * e); add('hx', 5 * D * e); } } },
  bounce: { dur: () => 1.0, make: () => ({}),
    fx(p, u, t, add) { const w = bell(u); add('hpy', 0.018 * w); add('hx', -0.02 * w); add('e_happy', 0.1 * w); } },
  startle: { dur: () => 1.8, make: () => ({}),
    fx(p, u, t, add) {
      const e = Math.exp(-t * 4.2);
      add('hx', -7 * D * e); add('cx', -5 * D * e); add('hpy', 0.012 * e); add('shL', 0.1 * e); add('shR', 0.1 * e); add('e_surprised', 0.5 * e);
    } },
  flinch: { dur: () => 0.9, make: (r) => ({ a: r.range(0.4, 0.8) }),
    fx(p, u, t, add) {
      const e = Math.exp(-t * 5) * p.a;
      add('hx', -5 * D * e); add('shL', 0.06 * e); add('shR', 0.06 * e); add('cx', -3 * D * e); add('e_surprised', 0.3 * e);
    } },
  shake: { dur: () => 2.0, make: (r) => ({ a: r.range(9, 15) * D, f: r.range(1.4, 1.8) }),
    fx(p, u, t, add) { const w = Math.exp(-t * 1.9) * Math.sin(2 * Math.PI * p.f * t); add('hy', p.a * w); add('ny', p.a * 0.3 * w); add('hx', 0.04 * bell(u)); } },
  scoff: { dur: () => 0.55, make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = bell(u); add('hx', 6 * D * w); add('hy', p.s * 5 * D * w); add('cx', 3 * D * w); add('shL', 0.04 * w); add('shR', 0.04 * w); add('e_angry', 0.1 * w); } },
  lunge: { dur: () => 1.3, make: () => ({}),
    fx(p, u, t, add) { const w = trap(u, 0.35); add('hx', 5 * D * w); add('cx', 6 * D * w); add('ux', 3 * D * w); add('shL', 0.07 * w); add('shR', 0.07 * w); add('hpz', 0.01 * w); } },
  collapse: { dur: () => 3.0, make: () => ({}),
    fx(p, u, t, add) {
      const d = smooth(u / 0.3) * (1 - 0.4 * smooth((u - 0.3) / 0.7));
      add('hx', 8 * D * d); add('shL', -0.05 * d); add('shR', -0.05 * d); add('cx', 5 * D * d); add('hpy', -0.012 * d);
    } },
  focus: { dur: () => 1.6, make: () => ({}),
    fx(p, u, t, add) { const w = trap(u, 0.4); add('hx', 3 * D * w); add('cx', 2 * D * w); add('e_angry', 0.08 * w); } },
  thinkIn: { dur: () => 2.0, make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = trap(u, 0.4); add('hz', p.s * 5 * D * w); add('hy', 4 * D * w); add('hx', -2 * D * w); } },

  fidget: { dur: (r) => r.range(1.5, 3), make: (r) => ({ s: r.chance(0.5) ? 'L' : 'R', a: r.range(8, 14) * D, c: r.range(0.08, 0.18) }),
    fx(p, u, t, add) {
      const w = bell(u);
      add(p.s + '_elbowF', p.a * w); add(p.s + '_curl', p.c * Math.sin(2 * Math.PI * 1.4 * t) * w); add(p.s + '_down', -0.03 * w); add(p.s + '_wrist', 0.1 * Math.sin(2 * Math.PI * 0.9 * t) * w);
    } },
  adjust: { dur: (r) => r.range(2, 4), make: (r) => ({ s: r.chance(0.5) ? 'L' : 'R', a: r.range(14, 22) * D }),
    fx(p, u, t, add) { const w = trap(u, 0.3); add(p.s + '_elbowF', p.a * w); add(p.s + '_down', -0.08 * w); add(p.s + '_fwd', 0.1 * w); add(p.s + '_curl', 0.1 * w); } },
  wave: { dur: (r) => r.range(2.4, 3), make: (r) => ({ big: r.chance(0.65) }),
    fx(p, u, t, add, P) {
      const w = trap(u, 0.18), osc = Math.sin(t * 2 * Math.PI * 2.4);
      // the hand stays in front of the shoulder (inside the framed picture), not out to the side
      add('R_down', (rad(p.big ? 18 : 24) - rad(P.R.down)) * w); add('R_fwd', rad((p.big ? 80 : 84) - P.R.fwd) * w); add('R_elbowF', rad(-P.R.elbowF) * w);
      add('R_elbowU', (rad(p.big ? 100 : 96) + 0.32 * osc) * w); add('e_happy', 0.45 * w); add('hz', 3 * D * w);
    } },
  beckon: { dur: () => 2.2, make: () => ({}),
    fx(p, u, t, add, P) {
      const w = trap(u, 0.25);
      add('R_down', rad(24 - P.R.down) * w); add('R_fwd', rad(88 - P.R.fwd) * w); add('R_elbowF', rad(-P.R.elbowF) * w); add('R_elbowU', (rad(62) + 0.35 * Math.sin(2 * Math.PI * 2.2 * t)) * w); add('e_happy', 0.2 * w);
    } },
  pump: { dur: () => 2.0, make: () => ({}),
    fx(p, u, t, add) {
      const pw = Math.pow(Math.sin(Math.PI * u * 2), 2) * bell(u);
      for (const s of ['L', 'R']) { add(s + '_down', -20 * D * pw); add(s + '_elbowF', 14 * D * pw); add(s + '_curl', 0.5 * pw); }
    } },
  chinTap: { dur: () => 2.0, make: () => ({}),
    fx(p, u, t, add) { const w = bell(u), o = Math.sin(2 * Math.PI * 3 * t); add('R_curl', 0.12 * Math.abs(o) * w); add('R_elbowF', 3 * D * o * w); } },
  wring: { dur: (r) => r.range(2, 3.5), make: () => ({}),
    fx(p, u, t, add) {
      const o = Math.sin(2 * Math.PI * 1.3 * t) * bell(u);
      add('L_elbowF', 5 * D * o); add('R_elbowF', -5 * D * o); add('L_curl', 0.15 * Math.abs(o)); add('R_curl', 0.15 * Math.abs(o)); add('L_twist', 0.15 * o); add('R_twist', -0.15 * o);
    } },
  clench: { dur: () => 1.6, make: () => ({}),
    fx(p, u, t, add) { const w = bell(u); for (const s of ['L', 'R']) { add(s + '_elbowF', 6 * D * w); add(s + '_down', -0.06 * w); } add('shL', 0.04 * w); add('shR', 0.04 * w); } },

  smile: { dur: (r) => r.range(2, 4), make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.35); add('e_happy', 0.28 * w); add('e_relaxed', 0.05 * w); } },
  smirk: { dur: (r) => r.range(2, 3.2), make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = trap(u, 0.35); add('e_relaxed', 0.35 * w); add('e_happy', 0.08 * w); add('hz', p.s * 2 * D * w); } },
  curious: { dur: (r) => r.range(1, 1.8), make: (r) => ({ s: r.sign() }),
    fx(p, u, t, add) { const w = bell(u); add('e_surprised', 0.16 * w); add('hx', -0.02 * w); add('hz', p.s * 2.5 * D * w); add('e_happy', 0.05 * w); } },
  grin: { dur: (r) => r.range(1.5, 3), make: () => ({}), fx(p, u, t, add) { add('e_happy', 0.18 * trap(u, 0.35)); } },
  worry: { dur: (r) => r.range(2, 4), make: () => ({}), fx(p, u, t, add) { const w = trap(u, 0.35); add('e_sad', 0.18 * w); add('e_surprised', 0.04 * w); } },
  glare: { dur: (r) => r.range(1.5, 3), make: () => ({}), fx(p, u, t, add) { add('e_angry', 0.25 * trap(u, 0.35)); } }
};

/* ------------------------------------------------------------------------------------------------ gaze modes */
/* Each picker returns { y, p, hold, glide, away }: target gaze in degrees (y + = screen right, p + = down), how long to hold it,
 * and how long the move takes (0.1 = snap, 1+ = slow pursuit). */
const LOOK = {
  viewer(g, r) {
    if (g.away) return { y: r.range(-1.5, 1.5), p: r.range(-1, 1.5), hold: r.range(1.8, 4.8), glide: r.range(0.1, 0.25), away: false };
    if (r.chance(0.5)) return { y: r.range(-2.5, 2.5), p: r.range(-1.5, 2), hold: r.range(1.5, 3.5), glide: r.range(0.1, 0.2), away: false };
    return { y: r.sign() * r.range(8, 22), p: r.range(-5, 9), hold: r.range(0.7, 1.9), glide: r.chance(0.3) ? 0.5 : 0.12, away: true };
  },
  warm(g, r) {
    if (g.away) return { y: r.range(-1.5, 1.5), p: r.range(-1, 1), hold: r.range(2.2, 5), glide: 0.18, away: false };
    if (r.chance(0.65)) return { y: r.range(-2, 2), p: r.range(-1.5, 1.5), hold: r.range(1.5, 3.2), glide: 0.15, away: false };
    return { y: r.sign() * r.range(8, 18), p: r.range(-8, 4), hold: r.range(0.6, 1.4), glide: 0.14, away: true };
  },
  sweep(g, r) {
    if (g.away === false && r.chance(0.2)) return { y: r.range(-2, 2), p: r.range(0, 3), hold: r.range(0.6, 1.2), glide: 0.2, away: true };
    const dirPrev = g.dir || 1, dir = r.chance(0.7) ? -dirPrev : dirPrev, slow = r.chance(0.35);
    g.dir = dir;
    return { y: dir * r.range(12, 32), p: r.range(-2, 8), hold: slow ? r.range(0.6, 1.2) : r.range(0.5, 1.5), glide: slow ? r.range(1.2, 2.6) : r.range(0.15, 0.3), away: false };
  },
  think(g, r) {
    if (!g.away) {
      if (r.chance(0.25)) g.side = -(g.side || 1);
      const down = r.chance(0.2);
      return { y: (g.side || 1) * r.range(8, 20), p: down ? r.range(6, 10) : -r.range(7, 13), hold: r.range(1.2, 3), glide: r.range(0.15, 0.4), away: true };
    }
    return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.5, 1.2), glide: 0.2, away: false };
  },
  down(g, r) {
    if (!g.away) return { y: r.range(-18, 18), p: r.range(9, 17), hold: r.range(2, 5), glide: r.range(0.6, 1.4), away: true };
    return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.6, 1.1), glide: 0.3, away: false };
  },
  worry(g, r) {
    if (!g.away) return { y: r.sign() * r.range(10, 20), p: r.range(6, 12), hold: r.range(1.2, 2.6), glide: r.range(0.2, 0.5), away: true };
    return { y: r.range(-2, 2), p: r.range(-2, 1), hold: r.range(1, 2.2), glide: 0.2, away: false };
  },
  dart(g, r) {
    g.n = (g.n || 0) + 1;
    if (g.n % 3 === 0) return { y: r.range(-2, 2), p: r.range(-1, 1), hold: r.range(0.5, 1), glide: 0.08, away: false };
    return { y: r.sign() * r.range(12, 34), p: r.range(-8, 8), hold: r.range(0.25, 0.7), glide: r.range(0.1, 0.17), away: true };
  },
  lock(g, r) {
    if (!g.away && r.chance(0.25)) return { y: r.sign() * r.range(15, 30), p: r.range(-2, 5), hold: r.range(0.5, 0.9), glide: 0.1, away: true };
    return { y: r.range(-1.5, 1.5), p: r.range(-1, 2), hold: r.range(2, 5), glide: 0.1, away: false };
  }
};

/* ------------------------------------------------------------------------------------------------ springs */
function stepSpring(s, target, f, z, dt) {
  const w = 2 * Math.PI * f, n = Math.max(1, Math.ceil(dt * 120)), h = dt / n;
  for (let i = 0; i < n; i++) { const a = w * w * (target - s.x) - 2 * z * w * s.v; s.v += a * h; s.x += s.v * h; }
}
function springParams(k) {
  if (k.startsWith('e_')) return k === 'e_aa' ? [8, 1] : [3.8, 1];
  if (k.startsWith('head_')) return [3.0, 0.7];
  if (k.startsWith('neck_')) return [2.8, 0.78];
  if (k.startsWith('chest_') || k.startsWith('upper_')) return [2.5, 0.8];
  if (k.startsWith('spine_')) return [2.2, 0.85];
  if (k.startsWith('hrot_') || k.startsWith('hpos_')) return [1.9, 0.9];
  if (k.startsWith('sh')) return [3.2, 0.82];
  if (k.endsWith('_elbowF') || k.endsWith('_elbowU')) return [2.6, 0.78];
  if (k.endsWith('_twist') || k.endsWith('_wrist')) return [3.5, 0.7];
  if (k.endsWith('_curl') || k.startsWith('fing')) return [3.5, 1];
  if (k.startsWith('L_') || k.startsWith('R_')) return [2.3, 0.8];
  return [2.5, 0.85];
}

/* ------------------------------------------------------------------------------------------------ engine */
function create(seedIn) {
  const seed = seedIn != null ? seedIn : (((Math.random() * 2147483647) | 0) || 12345);
  const rr = mulberry32(seed);
  const r = {
    f: () => rr(), range: (a, b) => a + (b - a) * rr(), chance: (p) => rr() < p, sign: () => (rr() < 0.5 ? -1 : 1),
    pick(list) { let tot = 0; for (const it of list) tot += it[1]; let x = rr() * tot; for (const it of list) { x -= it[1]; if (x <= 0) return it[0]; } return list[0][0]; }
  };
  const noise = makeNoise(rr);
  const offs = {};
  const N = (name, t, hz) => noise(t * hz + (offs[name] !== undefined ? offs[name] : (offs[name] = hashStr(name) * 1.37)));
  // a little permanent asymmetry per session: no two sessions share the exact posture
  const quirk = { roll: r.range(-1.2, 1.2) * D, armL: r.range(-1.5, 1.5) * D, armR: r.range(-1.5, 1.5) * D, yaw: r.range(-1, 1) * D };

  let name = 'idle', B = BEHAVIOUR.idle, P = POSES.idle, t0 = 0, started = false;
  const S = {};                           // springs by channel name
  const A = {};                           // event/offset accumulator, rebuilt every frame
  const add = (k, v) => { A[k] = (A[k] || 0) + v; };
  const slots = { body: { cur: null, next: 0 }, arm: { cur: null, next: 0 }, face: { cur: null, next: 0 } };
  const gaze = { y: 0, p: 0, fromY: 0, fromP: 0, t0: 0, glide: 0, hold: 1, next: 1, away: false };
  const eyeS = { y: { x: 0, v: 0 }, p: { x: 0, v: 0 } };
  const micro = { y: 0, p: 0, next: 0 };
  const shift = { target: 0, x: 0, v: 0, next: 4 };
  const breath = { p: 0, boost: 0 };
  const blink = { t: -1, next: 2.2, k: 1, dbl: false };
  let eyesGaze = { y: 0, p: 0 };

  const F = {
    expr: { happy: 0, sad: 0, angry: 0, relaxed: 0, surprised: 0, aa: 0, blink: 0 },
    rot: { head: { x: 0, y: 0, z: 0 }, neck: { x: 0, y: 0, z: 0 }, chest: { x: 0, y: 0, z: 0 }, upperChest: { x: 0, y: 0, z: 0 }, spine: { x: 0, y: 0, z: 0 }, hips: { x: 0, y: 0, z: 0 } },
    hips: { x: 0, y: 0, z: 0 }, shoulders: { L: 0, R: 0 },
    arm: { L: { down: 0, fwd: 0, elbowF: 0, elbowU: 0, curl: 0, twist: 0, wrist: 0, fing: [0, 0, 0, 0] }, R: { down: 0, fwd: 0, elbowF: 0, elbowU: 0, curl: 0, twist: 0, wrist: 0, fing: [0, 0, 0, 0] } },
    legs: { L: { z: 0, knee: 0 }, R: { z: 0, knee: 0 } }, eye: { yaw: 0, pitch: 0 }, state: 'idle'
  };

  function makeEvent(kind, now) {
    const def = EV[kind];
    return { kind, t0: now, dur: def.dur(r), p: def.make(r) };
  }

  function setState(n, now) {
    if (!POSES[n]) n = 'idle';
    if (started && n === name) return;                 // never restart the same state (that was one source of repetition)
    started = true;
    name = n; B = BEHAVIOUR[n]; P = POSES[n]; t0 = now;
    for (const k in slots) { slots[k].cur = null; slots[k].next = now + r.range(1.2, 2.4); }
    for (const [slot, kind] of B.enter) { slots[slot].cur = makeEvent(kind, now); slots[slot].next = now + slots[slot].cur.dur + r.range(1.5, 3); }
    gaze.next = now + 0.4; gaze.away = false;
    shift.next = now + r.range(2, 5);
    blink.next = Math.min(blink.next, now + 1.5);
  }

  function runSlot(slotName, list, gap, now, tt) {
    const s = slots[slotName];
    if (s.cur && now - s.cur.t0 >= s.cur.dur) { s.cur = null; s.next = now + r.range(gap[0], gap[1]); }
    if (!s.cur && now >= s.next && list.length) {
      let kind = r.pick(list);
      if (kind === s.last && list.length > 1) kind = r.pick(list);       // avoid the same thing twice in a row
      s.last = kind; s.cur = makeEvent(kind, now);
    }
    if (s.cur) { const e = s.cur, t = now - e.t0; EV[e.kind].fx(e.p, clamp(t / e.dur, 0, 1), t, add, P); }
  }

  function flat(k, side) { return rad((P[side] || REST_ARM)[k]); }

  function update(now, dt) {
    if (!started) setState('idle', now);
    dt = clamp(dt, 0.001, 0.1);
    const tt = Math.max(0, now - t0);
    for (const k in A) A[k] = 0;

    // ---- events ------------------------------------------------------------------------------------------------
    runSlot('body', B.body, B.bodyGap, now, tt);
    runSlot('arm', B.arm, B.armGap, now, tt);
    runSlot('face', B.face, B.faceGap, now, tt);

    // ---- energy: the whole body is livelier or calmer from minute to minute ----------------------------------------
    const energy = (0.85 + 0.3 * N('energy', now, 0.06)) * B.noise;

    // ---- breathing ---------------------------------------------------------------------------------------------------
    const period = B.breath[0] * (1 + 0.12 * N('bp', now, 0.1));
    breath.p += dt / period; if (breath.p >= 1) breath.p -= 1;
    const bp = breath.p, inh = 0.38;
    const b = bp < inh ? smoother(bp / inh) : bp < inh + 0.06 ? 1 : 1 - smoother((bp - inh - 0.06) / (1 - inh - 0.06));
    const depth = B.breath[1] * (0.85 + 0.3 * N('bd', now, 0.13));
    add('cx', -0.016 * b * depth); add('ux', -0.012 * b * depth); add('sx', -0.004 * b * depth);
    add('shL', 0.02 * b * depth); add('shR', 0.02 * b * depth); add('hpy', 0.002 * b * depth); add('hx', -0.006 * b * depth);
    add('L_down', -0.012 * b * depth); add('R_down', -0.012 * b * depth);
    if (name === 'angry' || name === 'warning') add('e_aa', (name === 'angry' ? 0.06 : 0.05) * (1 - b) * depth);

    // ---- weight shifting ---------------------------------------------------------------------------------------------
    if (now >= shift.next) {
      const opts = [-1, -0.55, 0, 0.55, 1].filter((v) => Math.abs(v - shift.target) >= 0.5);
      shift.target = opts[Math.floor(r.f() * opts.length)];
      shift.next = now + r.range(B.shift[0], B.shift[1]);
    }
    stepSpring(shift, shift.target, 0.55, 1, dt);
    const sa = shift.x * B.shift[2];
    add('hpx', 0.011 * sa); add('pz', 0.03 * sa); add('sz', -0.03 * sa); add('cz', -0.03 * sa); add('uz', -0.02 * sa); add('hz', 0.045 * sa);
    add('shL', 0.025 * sa); add('shR', -0.025 * sa); add('L_down', 0.02 * sa); add('R_down', -0.02 * sa);

    // ---- organic noise (incommensurate rates, never loops) -----------------------------------------------------------
    add('hx', 0.012 * energy * N('hx', now, 0.31)); add('hy', 0.018 * energy * N('hy', now, 0.23)); add('hz', 0.02 * energy * N('hz', now, 0.27));
    add('nx', 0.006 * energy * N('nx', now, 0.37)); add('ny', 0.008 * energy * N('ny', now, 0.29)); add('nz', 0.008 * energy * N('nz', now, 0.33));
    add('cx', 0.006 * energy * N('cx', now, 0.21)); add('cy', 0.01 * energy * N('cy', now, 0.17)); add('cz', 0.012 * energy * N('cz', now, 0.19));
    add('ux', 0.004 * energy * N('ux', now, 0.25)); add('uy', 0.006 * energy * N('uy', now, 0.22));
    add('sy', 0.008 * energy * N('sy', now, 0.15)); add('sz', 0.01 * energy * N('sz', now, 0.13));
    add('pz', 0.006 * energy * N('pz', now, 0.11)); add('py', 0.008 * energy * N('py', now, 0.12));
    add('hpx', 0.003 * energy * N('hpx', now, 0.14)); add('hpz', 0.003 * energy * N('hpz', now, 0.16));
    add('shL', 0.012 * energy * N('shL', now, 0.35)); add('shR', 0.012 * energy * N('shR', now, 0.31));
    for (const s of ['L', 'R']) {
      add(s + '_down', 0.025 * energy * N(s + 'd', now, 0.24)); add(s + '_fwd', 0.03 * energy * N(s + 'f', now, 0.2));
      add(s + '_elbowF', 0.04 * energy * N(s + 'ef', now, 0.28)); add(s + '_twist', 0.08 * energy * N(s + 'tw', now, 0.3));
      add(s + '_wrist', 0.06 * energy * N(s + 'wr', now, 0.36)); add(s + '_curl', 0.05 * N(s + 'cu', now, 0.18));
    }
    add('e_happy', 0.03 * N('eh', now, 0.2)); add('e_relaxed', 0.02 * N('er', now, 0.17));

    // ---- gaze director -----------------------------------------------------------------------------------------------
    if (now >= gaze.next) {
      const pick = LOOK[B.look](gaze, r);
      const jump = Math.abs(pick.y - gaze.y);
      gaze.fromY = gaze.glide > 0 && now - gaze.t0 < gaze.glide ? gaze.fromY + (gaze.y - gaze.fromY) * smooth((now - gaze.t0) / gaze.glide) : gaze.y;
      gaze.fromP = gaze.p;
      gaze.y = pick.y; gaze.p = pick.p; gaze.t0 = now; gaze.glide = pick.glide; gaze.away = pick.away;
      gaze.next = now + pick.glide + pick.hold;
      if (jump > 12 && blink.t < 0 && r.chance(0.5)) blink.next = now + 0.05;      // people blink as the gaze jumps
    }
    const gu = gaze.glide > 0 ? smooth((now - gaze.t0) / gaze.glide) : 1;
    const gy = gaze.fromY + (gaze.y - gaze.fromY) * gu, gp = gaze.fromP + (gaze.p - gaze.fromP) * gu;
    eyesGaze.y = gy; eyesGaze.p = gp;
    // the head takes most of the turn, the eyes the rest
    add('hy', 0.55 * gy * D); add('ny', 0.2 * gy * D); add('uy', 0.08 * gy * D); add('cy', 0.05 * gy * D); add('hz', -0.06 * gy * D);
    add('hx', 0.5 * gp * D); add('nx', 0.15 * gp * D); add('cx', 0.05 * gp * D);

    // ---- targets -> springs ------------------------------------------------------------------------------------------
    const sp = B.speed;
    const tgt = {};
    for (const k of EXPR) tgt['e_' + k] = clamp(((P.e && P.e[k]) || 0) + (A['e_' + k] || 0), 0, 1);
    const bone = (key, pre, base) => {
      tgt[pre + '_x'] = rad(base && base.x) + (A[key + 'x'] || 0);
      tgt[pre + '_y'] = rad(base && base.y) + (A[key + 'y'] || 0);
      tgt[pre + '_z'] = rad(base && base.z) + (A[key + 'z'] || 0);
    };
    bone('h', 'head', P.head); bone('n', 'neck', P.neck); bone('c', 'chest', P.chest); bone('u', 'upper', P.upperChest); bone('s', 'spine', P.spine); bone('p', 'hrot', null);
    tgt.head_z += quirk.roll; tgt.head_y += quirk.yaw;
    tgt.hpos_x = A.hpx || 0; tgt.hpos_y = A.hpy || 0; tgt.hpos_z = A.hpz || 0;
    tgt.shL = rad(P.shoulders) + (A.shL || 0); tgt.shR = rad(P.shoulders) + (A.shR || 0);
    for (const s of ['L', 'R']) {
      const base = P[s] || REST_ARM;
      tgt[s + '_down'] = rad(base.down) + (A[s + '_down'] || 0) + (s === 'L' ? quirk.armL : quirk.armR);
      tgt[s + '_fwd'] = rad(base.fwd) + (A[s + '_fwd'] || 0);
      tgt[s + '_elbowF'] = rad(base.elbowF) + (A[s + '_elbowF'] || 0);
      tgt[s + '_elbowU'] = rad(base.elbowU) + (A[s + '_elbowU'] || 0);
      tgt[s + '_twist'] = rad(base.twist) + (A[s + '_twist'] || 0);
      tgt[s + '_wrist'] = rad(base.wrist) + (A[s + '_wrist'] || 0);
      tgt[s + '_curl'] = clamp(base.curl + (A[s + '_curl'] || 0), 0, 1);
      for (let i = 0; i < 4; i++) tgt['fing' + s + i] = 0.08 * N('fi' + s + i, now, 0.22);
    }
    for (const k in tgt) {
      let s = S[k];
      if (!s) s = S[k] = { x: tgt[k], v: 0 };
      const pr = springParams(k);
      const f = k.startsWith('e_') ? pr[0] * (0.7 + 0.3 * sp) : pr[0] * sp;
      stepSpring(s, tgt[k], f, pr[1], dt);
    }
    const V = (k) => S[k].x;

    // ---- eyes: saccade first, head follows, eyes counter-rotate (VOR) -------------------------------------------------
    if (now >= micro.next) { micro.y = r.range(-1.3, 1.3); micro.p = r.range(-0.9, 0.9); micro.next = now + r.range(0.3, 1.2); }
    const dynYaw = (V('head_y') + V('neck_y') + V('upper_y') + V('chest_y') - rad(P.head && P.head.y) - rad(P.neck && P.neck.y)) / D;
    const dynPitch = (V('head_x') + V('neck_x') + V('chest_x') - rad(P.head && P.head.x) - rad(P.neck && P.neck.x) - rad(P.chest && P.chest.x)) / D;
    const bias = P.gaze || ZERO2;
    const eyeYawT = clamp(gy - dynYaw + (bias.yaw || 0) + micro.y, -10, 10);
    const eyePitchT = clamp(gp - dynPitch + (bias.pitch || 0) + micro.p, -8, 8);
    stepSpring(eyeS.y, eyeYawT, 16, 0.85, dt);
    stepSpring(eyeS.p, eyePitchT, 16, 0.85, dt);

    // ---- blinking ----------------------------------------------------------------------------------------------------
    if (blink.t < 0 && now >= blink.next) { blink.t = 0; blink.k = name === 'offline' ? 1.5 : name === 'warning' ? 0.8 : 1; }
    let pulse = 0;
    if (blink.t >= 0) {
      blink.t += dt;
      const c = 0.075 * blink.k, h = 0.025, o = 0.15 * blink.k, tb = blink.t;
      if (tb < c) pulse = smooth(tb / c); else if (tb < c + h) pulse = 1; else if (tb < c + h + o) pulse = 1 - smooth((tb - c - h) / o); else {
        blink.t = -1; pulse = 0;
        const m = B.blink;
        blink.next = now + (blink.dbl ? 0.28 : clamp(1.2 + -Math.log(1 - r.f() * 0.97) * (m - 1.2), 1.2, 9));
        blink.dbl = !blink.dbl && r.chance(0.15);
      }
    }

    // ---- build the frame ---------------------------------------------------------------------------------------------
    const E = F.expr;
    for (const k of EXPR) E[k] = clamp(V('e_' + k), 0, 1);
    const joy = Math.min(1, E.happy * 1.2);                 // VRoid "Joy" already closes the eyes
    const lidFollow = 0.1 * clamp(eyeS.p.x / 8, 0, 1.2);    // lids follow the gaze down
    E.blink = clamp(Math.max(P.blink + lidFollow + 0.03 * N('lid', now, 0.2), pulse), 0, 1) * (1 - joy);

    const rot = F.rot;
    for (const [key, pre] of [['head', 'head'], ['neck', 'neck'], ['chest', 'chest'], ['upperChest', 'upper'], ['spine', 'spine'], ['hips', 'hrot']]) {
      rot[key].x = V(pre + '_x'); rot[key].y = V(pre + '_y'); rot[key].z = V(pre + '_z');
    }
    F.hips.x = V('hpos_x'); F.hips.y = V('hpos_y'); F.hips.z = V('hpos_z');
    F.shoulders.L = V('shL'); F.shoulders.R = V('shR');
    for (const s of ['L', 'R']) {
      const a = F.arm[s];
      a.down = V(s + '_down'); a.fwd = V(s + '_fwd'); a.elbowF = V(s + '_elbowF'); a.elbowU = V(s + '_elbowU');
      a.twist = V(s + '_twist'); a.wrist = V(s + '_wrist'); a.curl = V(s + '_curl');
      for (let i = 0; i < 4; i++) a.fing[i] = V('fing' + s + i);
    }
    // legs: small counter-balance so the lower body is not frozen if the camera ever pulls back
    F.legs.L.z = 0.5 * rot.hips.z; F.legs.R.z = 0.5 * rot.hips.z;
    F.legs.L.knee = 0.03 + 0.05 * Math.max(0, shift.x); F.legs.R.knee = 0.03 + 0.05 * Math.max(0, -shift.x);
    F.eye.yaw = eyeS.y.x; F.eye.pitch = eyeS.p.x;
    F.state = name;
    return F;
  }

  /* Preview helper: start one event right now, e.g. trigger('arm', 'wave', now). Used by window.wapfireTrigger in vrm.js. */
  function trigger(slot, kind, now) {
    if (!slots[slot] || !EV[kind]) return false;
    slots[slot].cur = makeEvent(kind, now); slots[slot].last = kind;
    return true;
  }

  function debug() {
    return { state: name, slots: { body: slots.body.cur && slots.body.cur.kind, arm: slots.arm.cur && slots.arm.cur.kind, face: slots.face.cur && slots.face.cur.kind }, gaze: { y: gaze.y, p: gaze.p }, shift: shift.target };
  }

  return { setState, update, debug, trigger };
}
const ZERO2 = { yaw: 0, pitch: 0 };

export { create, POSES, BEHAVIOUR, EXPR, STATE_NAMES };
export default { create, POSES, BEHAVIOUR, EXPR, STATE_NAMES };
