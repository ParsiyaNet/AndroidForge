# WAPFire Mobile 3.3.1

## Bluetooth Low Energy
- Added a dedicated BLE discovery and secure-management screen from Discovery and Settings.
- Added Android runtime permission handling for Bluetooth scan/connect on Android 12+ and location permission for legacy BLE scanning on Android 10/11.
- Added GATT client support for the WAPFire provisioning service, secure bonding, notifications, MTU negotiation, command correlation, and bounded command timeouts.
- Added first-time credential provisioning over BLE (administrator password and WAPFire SoftAP credentials), followed by the existing Wi-Fi Setup wizard for target AP selection and verification.
- Added BLE basic-settings management for LED, sound, automatic channel tracking, self-protect, SoftAP, BLE management, and write-only password changes.
- Kept Wi-Fi as the primary transport for full Dashboard, Telemetry, Events, Logs, and the existing Setup wizard.
- Added return navigation so BLE Settings opened from Control returns to Control/Settings.
- Clears password entry fields after successful writes and prevents resubmitting the first-time provisioning form after it succeeds.

## Compatibility and security
- Existing Wi-Fi HTTP/API behavior and current attack controls are retained.
- BLE GATT writes and reads require encrypted MITM-protected pairing with a device-specific six-digit static passkey.
- The passkey is generated once, saved in NVS, and printed to the USB Serial console at 115200 baud.
- During an authenticated BLE management session, Promiscuous capture pauses and is restored after disconnect, including its previous packet filter.
- Firmware set_settings validates all provided values before applying any change to avoid partial updates on invalid input.
