# WAPFire Bluetooth LE Integration — Mobile 3.3.1 / Firmware 3.1.0

## Scope

BLE is a secondary management and provisioning transport. Existing Wi-Fi remains the primary path for the full Dashboard, Network Telemetry, Events, Logs, firmware updates, and the original Setup wizard. BLE exposes first-time credentials provisioning and a limited set of basic settings; it is not an alternate transport for high-volume telemetry or attack controls.

## Files changed

### Android
- `WAPFire-Mobile/app/src/main/java/io/wapfire/mobile/WapFireBleClient.kt` — BLE scan, GATT connection, Android bonding, notification setup, MTU negotiation, JSON command transport, and timeout handling.
- `WAPFire-Mobile/app/src/main/java/io/wapfire/mobile/MainActivity.kt` — BLE Discovery/Settings screen, first-time provisioning form, basic settings, language/theme controls, and navigation back to the originating screen.
- `WAPFire-Mobile/app/src/main/AndroidManifest.xml` — BLE feature and runtime permission declarations.
- `WAPFire-Mobile/app/build.gradle.kts` — app version 3.3.1 / versionCode 29.

### Firmware
- `WAPFireVF38/ble_provisioning.h` — secure GATT service and command queue.
- `WAPFireVF38/WAPFireVF38.ino` — includes the BLE module.
- `WAPFireVF38/modules/firmware_lifecycle.h` — BLE startup and queued command processing.
- `WAPFireVF38/webui_shared.h`, `webui_runtime.h`, `webui_api_handlers.h` — persisted BLE-management setting and API exposure.
- `WAPFireVF38/webui_page_setup.h` — firmware-version fallback text.

## BLE protocol

- Service UUID: `7f510001-7baf-4cde-a8e7-3f6f6f617001`
- RX characteristic (phone writes commands): `7f510002-7baf-4cde-a8e7-3f6f6f617001`
- TX characteristic (device notifies responses): `7f510003-7baf-4cde-a8e7-3f6f6f617001`
- Commands: `info`, `get_settings`, `initial_setup`, `set_settings`.
- Commands are JSON, correlated with a request `id`, and processed on the Arduino loop through a bounded FreeRTOS queue.
- The command payload is limited to 480 bytes. Android negotiates an ATT MTU up to 512 bytes and requires a usable MTU of at least 128.

## Security

- A random six-digit PIN (100000–999999) is generated on first BLE initialization and persisted in Preferences/NVS.
- The PIN is displayed only on the physical USB Serial console (`115200` baud). It is not included in the unauthenticated advertising packet or the `info` response.
- GATT RX/TX access requires encrypted MITM authentication; bonding and Secure Connections are requested.
- Android initiates system bonding and uses the Android pairing prompt. Enter the passkey shown in Serial Monitor.
- Do not share the PIN or expose the USB Serial log to untrusted users.

## Enable and use

### New / unconfigured device
1. Flash the updated `WAPFireVF38` firmware to the ESP32-S3.
2. Open USB Serial Monitor at 115200 baud and note the six-digit BLE pairing PIN printed during startup.
3. Install/build the Android 3.3.1 app, enable Bluetooth, open **Find WAPFire over Bluetooth**, and scan.
4. Connect to the `WAPFire-` device and complete Android secure pairing using the Serial PIN.
5. Enter the administrator password and WAPFire SoftAP SSID/password, then save.
6. After the SoftAP restarts, disconnect BLE, join the new WAPFire Wi-Fi, and finish the existing Setup wizard. That wizard still verifies and stores the target AP/BSSID; BLE does not bypass target validation.

### Already-configured device
1. Flash the updated firmware.
2. Connect to WAPFire over the existing Wi-Fi path.
3. In the Android app, open **Settings → Bluetooth management** and enable it.
4. Open the Bluetooth setup screen, scan, connect, and pair using the PIN shown in Serial Monitor.
5. Apply supported basic settings. Password fields are write-only and are cleared from the form after a successful update.

To stop BLE advertising on a configured device, turn off **Bluetooth management** and disconnect the active BLE session. Unconfigured devices advertise BLE by default so that they can be provisioned.

## Radio coexistence

ESP32-S3 uses one 2.4 GHz RF module shared by Wi-Fi and BLE. Espressif documents Wi-Fi Sniffer RX with BLE advertising/connecting/connected as supported but unstable (C1). This firmware therefore pauses Wi-Fi Promiscuous capture after the first authenticated BLE command and restores capture plus its prior packet filter when the BLE client disconnects. Full RF monitoring resumes after disconnect. BLE is not promised to remain reliable while heavy RF activity is active. See Espressif's coexistence documentation: https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-guides/coexist.html

## Android permissions

- Android 12+ requests `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT` at runtime.
- Android 10/11 requests `ACCESS_FINE_LOCATION` for BLE scanning.
- The app does not request Bluetooth advertising permission because it acts only as a BLE central/client.

## Important limits

- Wi-Fi remains required to complete target AP/BSSID selection and to use full telemetry/dashboard functionality.
- BLE provides basic setup/settings, not full WebUI/API parity.
- A BLE management connection temporarily pauses Promiscuous RF capture by design; disconnect BLE to resume.
- Existing configured devices have BLE management disabled by default. Enable it from the app's Wi-Fi Settings page before scanning.

## Validation status

- Android manifest XML parsed successfully.
- Android and firmware service/RX/TX UUIDs match exactly.
- Android BLE runtime permissions match the scan/connect implementation.
- Firmware JSON command handlers and app command names match.
- Firmware delimiter/preprocessor checks passed.
- Kotlin parser emitted no grammar/syntax diagnostics in the standalone parser check; full Android/Compose type resolution was unavailable without Android SDK and Gradle dependencies.
- A real Android build was attempted but could not start because `services.gradle.org` could not be resolved in this environment. Android SDK is not installed here.
- Firmware compilation and hardware pairing tests were not run because Arduino CLI/PlatformIO are not installed in this environment.
