package io.wapfire.mobile

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

internal data class WapFireBleDevice(
    val device: BluetoothDevice,
    val name: String,
    val address: String,
    val rssi: Int
)

/** BLE client for the authenticated WAPFire provisioning / basic-management GATT service. */
internal class WapFireBleClient(
    context: Context,
    private val onDevices: (List<WapFireBleDevice>) -> Unit,
    private val onState: (String) -> Unit,
    private val onResponse: (JSONObject) -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val bluetoothManager = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter get() = bluetoothManager?.adapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var tx: BluetoothGattCharacteristic? = null
    private var notificationReady = false
    private var mtuReady = false
    private var negotiatedMtu = 23
    private var closed = false
    private val found = linkedMapOf<String, WapFireBleDevice>()
    private var pendingCommandId: String? = null
    private val commandTimeoutRunnable = Runnable {
        if (pendingCommandId != null) {
            pendingCommandId = null
            postState("BLE command timed out. Check the device connection and retry.")
        }
    }

    private val stopScanRunnable = Runnable { stopScan() }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = addScanResult(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) { results.forEach(::addScanResult) }
        override fun onScanFailed(errorCode: Int) {
            postState("Bluetooth scan failed ($errorCode)")
        }
    }

    private val bondReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != BluetoothDevice.ACTION_BOND_STATE_CHANGED) return
            val device = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            } ?: return
            val active = gatt?.device ?: return
            if (device.address != active.address) return
            when (intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)) {
                BluetoothDevice.BOND_BONDED -> {
                    postState("Bluetooth paired securely. Discovering WAPFire service…")
                    try { gatt?.discoverServices() } catch (_: SecurityException) { postState("Bluetooth permission is missing") }
                }
                BluetoothDevice.BOND_NONE -> postState("Pairing was cancelled or rejected")
                BluetoothDevice.BOND_BONDING -> postState("Complete the Bluetooth pairing prompt. Enter the PIN shown in the WAPFire serial log.")
            }
        }
    }

    init {
        val filter = IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            appContext.registerReceiver(bondReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            appContext.registerReceiver(bondReceiver, filter)
        }
    }

    @SuppressLint("MissingPermission")
    fun scan() {
        stopScan()
        if (closed) return
        val btAdapter = adapter
        if (btAdapter == null) { postState("This phone does not support Bluetooth"); return }
        if (!btAdapter.isEnabled) { postState("Turn on Bluetooth to find WAPFire"); return }
        try {
            scanner = btAdapter.bluetoothLeScanner
            val activeScanner = scanner ?: run { postState("Bluetooth scanner is unavailable"); return }
            found.clear()
            postDevices()
            val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(UUID.fromString(SERVICE_UUID))).build()
            val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(0).build()
            activeScanner.startScan(listOf(filter), settings, scanCallback)
            postState("Scanning for WAPFire BLE devices…")
            main.removeCallbacks(stopScanRunnable)
            main.postDelayed(stopScanRunnable, 10_000L)
        } catch (e: SecurityException) {
            postState("Allow Nearby devices permission to scan")
        } catch (e: Exception) {
            postState(e.message ?: "Bluetooth scan could not start")
        }
    }

    @SuppressLint("MissingPermission")
    private fun addScanResult(result: ScanResult) {
        if (closed) return
        val serviceUuids = result.scanRecord?.serviceUuids.orEmpty()
        if (serviceUuids.none { it.uuid == UUID.fromString(SERVICE_UUID) }) return
        val device = result.device
        val name = result.scanRecord?.deviceName?.takeIf { it.isNotBlank() }
            ?: runCatching { device.name }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: "WAPFire device"
        found[device.address] = WapFireBleDevice(device, name, device.address, result.rssi)
        postDevices()
    }

    @SuppressLint("MissingPermission")
    fun connect(item: WapFireBleDevice) {
        stopScan()
        disconnectGattOnly()
        if (closed) return
        try {
            postState("Connecting to ${item.name}…")
            gatt = item.device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            postState("Allow Nearby devices permission to connect")
        } catch (e: Exception) {
            postState(e.message ?: "Could not connect to WAPFire")
        }
    }

    @SuppressLint("MissingPermission")
    fun send(command: JSONObject): Boolean {
        val activeGatt = gatt ?: return false
        val characteristic = rx ?: return false
        if (!notificationReady || !mtuReady) return false
        if (pendingCommandId != null) return false
        val id = UUID.randomUUID().toString()
        command.put("id", id)
        val bytes = command.toString().toByteArray(StandardCharsets.UTF_8)
        val maxPayload = (negotiatedMtu - 3).coerceAtLeast(20)
        if (bytes.size > maxPayload || bytes.size > 480) {
            postState("BLE command is larger than the negotiated connection payload ($maxPayload bytes)")
            return false
        }
        return try {
            pendingCommandId = id
            main.removeCallbacks(commandTimeoutRunnable)
            main.postDelayed(commandTimeoutRunnable, 20_000L)
            val result = if (Build.VERSION.SDK_INT >= 33) {
                activeGatt.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                @Suppress("DEPRECATION")
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                activeGatt.writeCharacteristic(characteristic)
            }
            if (!result) { pendingCommandId = null; main.removeCallbacks(commandTimeoutRunnable) }
            result
        } catch (_: SecurityException) {
            pendingCommandId = null
            main.removeCallbacks(commandTimeoutRunnable)
            postState("Bluetooth permission is missing")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        try { gatt?.disconnect() } catch (_: Exception) { }
        disconnectGattOnly()
        postState("Bluetooth disconnected")
    }

    @SuppressLint("MissingPermission")
    private fun disconnectGattOnly() {
        notificationReady = false
        mtuReady = false
        pendingCommandId = null
        main.removeCallbacks(commandTimeoutRunnable)
        negotiatedMtu = 23
        rx = null
        tx = null
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        main.removeCallbacks(stopScanRunnable)
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanner = null
    }

    fun close() {
        if (closed) return
        closed = true
        stopScan()
        disconnectGattOnly()
        try { appContext.unregisterReceiver(bondReceiver) } catch (_: Exception) { }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                postState("BLE connection error ($status)")
                disconnectGattOnly()
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                postState("Connected. Secure pairing required…")
                try {
                    if (g.device.bondState == BluetoothDevice.BOND_BONDED) g.discoverServices()
                    else {
                        val started = g.device.createBond()
                        if (!started) postState("Could not start secure pairing. Remove the old bond and retry.")
                    }
                } catch (e: SecurityException) { postState("Bluetooth permission is missing") }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                postState("Bluetooth disconnected")
                disconnectGattOnly()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) { postState("Could not discover WAPFire BLE service"); return }
            val service = g.getService(UUID.fromString(SERVICE_UUID))
            rx = service?.getCharacteristic(UUID.fromString(RX_UUID))
            tx = service?.getCharacteristic(UUID.fromString(TX_UUID))
            if (rx == null || tx == null) { postState("Incompatible WAPFire BLE service"); return }
            try {
                if (!g.setCharacteristicNotification(tx, true)) { postState("Could not enable BLE notifications"); return }
                val cccd = tx?.getDescriptor(UUID.fromString(CCCD_UUID))
                if (cccd == null) { postState("WAPFire notification descriptor is missing"); return }
                val started = if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothGatt.GATT_SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    g.writeDescriptor(cccd)
                }
                if (!started) postState("Could not configure BLE notifications")
            } catch (e: SecurityException) { postState("Bluetooth permission is missing") }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) { postState("BLE notification setup failed ($status)"); return }
            try {
                if (!g.requestMtu(512)) {
                    // A 20-byte MTU is not enough for our JSON provisioning messages.
                    postState("Phone rejected the BLE data-size negotiation")
                }
            } catch (e: SecurityException) { postState("Bluetooth permission is missing") }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && mtu >= 128) {
                negotiatedMtu = mtu
                mtuReady = true
                notificationReady = true
                postState("Secure WAPFire BLE connection ready (MTU $mtu)")
                send(JSONObject().put("cmd", "info"))
            } else postState("BLE MTU negotiation failed; reconnect and try again")
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                pendingCommandId = null
                main.removeCallbacks(commandTimeoutRunnable)
                postState("BLE command could not be sent ($status)")
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            val value = characteristic.value ?: return
            handleNotification(value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleNotification(value)
        }

        private fun handleNotification(value: ByteArray) {
            val payload = runCatching { JSONObject(String(value, StandardCharsets.UTF_8)) }.getOrNull() ?: return
            val id = payload.optString("id")
            if ((id.isNotBlank() && id == pendingCommandId) ||
                (id.isBlank() && !payload.optBoolean("ok", true) && pendingCommandId != null)) {
                pendingCommandId = null
                main.removeCallbacks(commandTimeoutRunnable)
            }
            main.post { if (!closed) onResponse(payload) }
        }
    }

    private fun postState(value: String) = main.post { if (!closed) onState(value) }
    private fun postDevices() = main.post { if (!closed) onDevices(found.values.sortedByDescending { it.rssi }) }

    companion object {
        const val SERVICE_UUID = "7f510001-7baf-4cde-a8e7-3f6f6f617001"
        const val RX_UUID = "7f510002-7baf-4cde-a8e7-3f6f6f617001"
        const val TX_UUID = "7f510003-7baf-4cde-a8e7-3f6f6f617001"
        const val CCCD_UUID = "00002902-0000-1000-8000-00805f9b34fb"
        const val MAX_COMMAND_BYTES = 480

        fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(android.Manifest.permission.BLUETOOTH_SCAN, android.Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
}
