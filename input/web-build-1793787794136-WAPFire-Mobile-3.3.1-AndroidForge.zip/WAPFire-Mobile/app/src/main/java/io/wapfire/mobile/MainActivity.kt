package io.wapfire.mobile

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

private enum class Stage { DISCOVERY, BLE_SETUP, LOGIN, SETUP, CONTROL }

private data class AdvancedSettingsBundle(
    val general: JSONObject = JSONObject(),
    val ethernet: JSONObject = JSONObject(),
    val httpApi: JSONObject = JSONObject(),
    val ntp: JSONObject = JSONObject(),
    val mikrotik: JSONObject = JSONObject(),
    val led: JSONObject = JSONObject(),
    val disconnectLed: JSONObject = JSONObject(),
    val schedule: JSONObject = JSONObject(),
    val whitelist: JSONObject = JSONObject(),
    val firmware: JSONObject = JSONObject(),
    val backupInfo: JSONObject = JSONObject()
)
private enum class Tab(val label: String, val fa: String, val glyph: String) {
    OVERVIEW("Overview", "نمای کلی", "⌂"),
    CLIENTS("Clients", "کلاینت‌ها", "◎"),
    EVENTS("Events", "رویدادها", "≋"),
    SETTINGS("Settings", "تنظیمات", "⚙")
}

private data class Palette(
    val bg: Color,
    val bg2: Color,
    val panel: Color,
    val panelAlt: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val green: Color,
    val orange: Color,
    val red: Color,
    val blue: Color
)

private fun colors(dark: Boolean) = if (dark) Palette(
    bg = Color(0xFF07141D), bg2 = Color(0xFF0C202B), panel = Color(0xFF102633),
    panelAlt = Color(0xFF16313E), border = Color(0xFF254652), text = Color(0xFFEAF5F7),
    muted = Color(0xFF91AAB5), accent = Color(0xFF4DE1CE), accentSoft = Color(0xFF173F45),
    green = Color(0xFF64E4A5), orange = Color(0xFFFFB86C), red = Color(0xFFFF7185), blue = Color(0xFF78A9FF)
) else Palette(
    bg = Color(0xFFF2F7F8), bg2 = Color(0xFFE5EFF2), panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFEAF3F4), border = Color(0xFFD4E2E5), text = Color(0xFF142D39),
    muted = Color(0xFF66808B), accent = Color(0xFF087F78), accentSoft = Color(0xFFD9F0EC),
    green = Color(0xFF168B5A), orange = Color(0xFFB76A18), red = Color(0xFFC33F54), blue = Color(0xFF426BC2)
)

private val detectionBreakdownNames = listOf(
    "Auth Attack",
    "Deauth Attack",
    "Deauth Airplay",
    "WPS Pixie Reaver",
    "WPS Pixie Bully",
    "Evil Twin",
    "WPA Correct Password",
    "WPA Wrong Password"
)

private val threatDisplayNames = mapOf(
    "auth_attack" to "Auth Attack",
    "deauth" to "Deauth Attack",
    "deauth_attack" to "Deauth Attack",
    "deauth_airplay" to "Deauth Airplay",
    "wps_pixie_reaver" to "WPS Pixie Reaver",
    "wps_pixie_bully" to "WPS Pixie Bully",
    "evil_twin" to "Evil Twin",
    "correct_password" to "WPA Correct Password",
    "wrong_password" to "WPA Wrong Password"
)

private fun friendlyThreatName(value: String): String? {
    val raw = value.trim()
    if (raw.isBlank()) return null
    val normalized = raw.lowercase().replace('-', '_').replace(' ', '_')
    threatDisplayNames[normalized]?.let { return it }
    return when {
        normalized.contains("wps_pixie_bully") || normalized.contains("pixie_bully") -> "WPS Pixie Bully"
        normalized.contains("wps_pixie_reaver") || normalized.contains("pixie_reaver") -> "WPS Pixie Reaver"
        normalized.contains("deauth_airplay") || normalized.contains("deauthentication_airplay") -> "Deauth Airplay"
        normalized.contains("evil_twin") || normalized.contains("evil twin") -> "Evil Twin"
        normalized.contains("wrong_password") || normalized.contains("wrong password") -> "WPA Wrong Password"
        normalized.contains("correct_password") || normalized.contains("correct password") -> "WPA Correct Password"
        normalized.contains("deauth_attack") || normalized == "deauth" || normalized.startsWith("deauth_") || normalized.startsWith("deauthentication") -> "Deauth Attack"
        normalized.contains("auth_attack") || normalized.contains("authentication") -> "Auth Attack"
        else -> null
    }
}

private val threatIdRegex = Regex(
    threatDisplayNames.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) },
    RegexOption.IGNORE_CASE
)

private fun friendlyTechnicalText(value: String): String = threatIdRegex.replace(value) { match ->
    threatDisplayNames[match.value.lowercase()] ?: match.value
}

private data class SavedDeviceLogin(val username: String, val password: String)

/** Stores only an AES-GCM ciphertext in preferences; the AES key stays in Android Keystore. */
private object DeviceLoginVault {
    private const val KEY_ALIAS = "io.wapfire.mobile.device-login.v1"
    private const val PREF_REMEMBER = "remember_device_password"
    private const val PREF_HOST = "remembered_device_host"
    private const val PREF_CIPHER = "remembered_device_password_enc"
    private const val IV_LENGTH = 12

    private fun normalizeHost(value: String): String = value.trim()
        .removePrefix("http://").removePrefix("https://").substringBefore('/')
        .lowercase(Locale.ROOT)

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    fun load(prefs: android.content.SharedPreferences, host: String): SavedDeviceLogin? {
        if (!prefs.getBoolean(PREF_REMEMBER, false)) return null
        if (normalizeHost(prefs.getString(PREF_HOST, "").orEmpty()) != normalizeHost(host)) return null
        val encoded = prefs.getString(PREF_CIPHER, null) ?: return null
        return runCatching {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > IV_LENGTH) { "Saved credential is invalid" }
            val iv = packed.copyOfRange(0, IV_LENGTH)
            val ciphertext = packed.copyOfRange(IV_LENGTH, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val clear = cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
            val split = clear.indexOf('\n')
            require(split >= 0) { "Saved credential is invalid" }
            SavedDeviceLogin(clear.substring(0, split), clear.substring(split + 1))
        }.getOrElse {
            clear(prefs)
            null
        }
    }

    fun save(prefs: android.content.SharedPreferences, host: String, username: String, password: String): Boolean {
        if (username.isBlank() || password.isEmpty()) return false
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ciphertext = cipher.doFinal((username + "\n" + password).toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + ciphertext
            prefs.edit()
                .putBoolean(PREF_REMEMBER, true)
                .putString(PREF_HOST, normalizeHost(host))
                .putString(PREF_CIPHER, Base64.encodeToString(packed, Base64.NO_WRAP))
                .apply()
            true
        }.getOrDefault(false)
    }

    fun clear(prefs: android.content.SharedPreferences) {
        prefs.edit()
            .putBoolean(PREF_REMEMBER, false)
            .remove(PREF_HOST)
            .remove(PREF_CIPHER)
            .apply()
    }
}

private fun ledModeLabel(mode: Int, fa: Boolean): String = when (mode) {
    0 -> tx(fa, "Threat detected", "تهدید شناسایی شد")
    1 -> tx(fa, "Authentication attempt", "تلاش احراز هویت")
    2 -> tx(fa, "Wrong password", "رمز اشتباه")
    3 -> tx(fa, "Correct password", "رمز صحیح")
    4 -> tx(fa, "Off", "خاموش")
    5 -> tx(fa, "Test / idle", "آزمایش / آماده")
    6 -> tx(fa, "Setup", "راه‌اندازی")
    7 -> tx(fa, "Protection", "محافظت")
    8 -> tx(fa, "Client disconnect", "قطع اتصال کلاینت")
    else -> tx(fa, "Unknown", "نامشخص")
}

private fun eventDisplayName(event: JSONObject): String {
    val type = event.optString("event_type", "system").trim().lowercase()
    friendlyThreatName(type)?.let { return it }
    val message = event.optString("message")
    val details = event.optString("details")
    friendlyThreatName(message)?.let { return it }
    friendlyThreatName(details)?.let { return it }
    return when (type) {
        "attack" -> "Attack Detected"
        "attempt" -> "Connection Attempt"
        "disconnect" -> "Client Disconnect"
        "system" -> "System Event"
        else -> "Device Event"
    }
}

private data class Snapshot(
    val configured: Boolean = false,
    val apSsid: String = "WAPFire",
    val target: String = "",
    val targetMac: String = "",
    val channel: Int = 0,
    val targetRssi: Int = 0,
    val targetAvailable: Boolean = false,
    val prom: String = "UNKNOWN",
    val traffic: Long = 0,
    val packets: Long = 0,
    val targetApRx: Long = 0,
    val dropped: Long = 0,
    val filtered: Long = 0,
    val freeHeap: Long = 0,
    val uptime: Long = 0,
    val wifiChannel: Int = 0,
    val threatLevel: String = "OPTIMAL",
    // Firmware score_tenths is 0..100, representing a 0.0..10.0 risk value.
    val threatScore: Float = 0f,
    val recentEvents: Int = 0,
    val lastEvent: String = "",
    val lastAttack: String = "",
    val ledMode: Int = 5,
    val led: Boolean = false,
    val smartLed: Boolean = false,
    val sound: Boolean = false,
    val autoChannel: Boolean = false,
    val selfProtect: Boolean = false,
    val selfProtectActive: Boolean = false,
    val softAp: Boolean = false,
    val bleManagement: Boolean = false,
    val ethernet: Boolean = false,
    val ethernetIp: String = "0.0.0.0",
    val firmware: String = "—",
    val labels: List<Pair<String, Long>> = emptyList(),
    val radioRates: List<Int> = emptyList(),
    val targetRates: List<Int> = emptyList()
) {
    companion object {
        fun from(status: JSONObject, settings: JSONObject?, chart: JSONObject?, firmwareInfo: JSONObject?): Snapshot {
            val threat = status.optJSONObject("threat_assessment") ?: JSONObject()
            val labelsJson = status.optJSONArray("labels") ?: JSONArray()
            val labelCounts = mutableMapOf<String, Long>()
            for (i in 0 until labelsJson.length()) {
                val item = labelsJson.optJSONObject(i) ?: continue
                val displayName = friendlyThreatName(item.optString("name")) ?: continue
                labelCounts[displayName] = (labelCounts[displayName] ?: 0L) + item.optLong("count")
            }
            val labels = detectionBreakdownNames.map { name -> name to (labelCounts[name] ?: 0L) }
            val radio = chart?.optJSONArray("radioRxRates") ?: JSONArray()
            val target = chart?.optJSONArray("targetApRxRates") ?: JSONArray()
            return Snapshot(
                configured = status.optBoolean("configured"),
                apSsid = status.optString("ap_ssid", "WAPFire"),
                target = status.optString("target"), targetMac = status.optString("target_mac"),
                channel = status.optInt("target_ch"), targetRssi = status.optInt("target_rssi"),
                targetAvailable = status.optBoolean("target_available"), prom = status.optString("promiscuous", "UNKNOWN"),
                traffic = status.optLong("traffic"), packets = status.optLong("packets"),
                targetApRx = chart?.optLong("target_ap_frames") ?: 0L,
                dropped = status.optLong("dropped"), filtered = status.optLong("filtered"),
                freeHeap = status.optLong("free_heap"), uptime = status.optLong("uptime"),
                wifiChannel = status.optInt("wifi_channel"), threatLevel = threat.optString("level", "OPTIMAL"),
                threatScore = (threat.optInt("score_tenths").coerceIn(0, 100) / 10f), recentEvents = threat.optInt("recent_events"),
                lastEvent = friendlyThreatName(threat.optString("last_event_label")) ?: if (threat.optString("last_event_label").isBlank()) "" else "Recent security activity", lastAttack = friendlyThreatName(status.optString("last_attack_label")) ?: "",
                ledMode = status.optInt("led_mode", 5),
                led = settings?.optBoolean("led") ?: status.optBoolean("led"),
                smartLed = settings?.optBoolean("smart_led") ?: status.optBoolean("smart_led"),
                sound = settings?.optBoolean("sound") ?: status.optBoolean("sound_enabled"),
                autoChannel = settings?.optBoolean("auto_channel") ?: status.optBoolean("auto_channel"),
                selfProtect = settings?.optBoolean("self_protect") ?: status.optBoolean("self_protect"),
                selfProtectActive = status.optBoolean("self_protect_active"),
                softAp = settings?.optBoolean("softap_enabled") ?: status.optBoolean("softap_enabled"),
                bleManagement = settings?.optBoolean("ble_management") ?: status.optBoolean("ble_management"),
                ethernet = status.optBoolean("ethernet_link_on"), ethernetIp = status.optString("ethernet_ip", "0.0.0.0"),
                firmware = firmwareInfo?.optString("version", "—") ?: "—", labels = labels,
                radioRates = (0 until radio.length()).map { radio.optInt(it) },
                targetRates = (0 until target.length()).map { target.optInt(it) }
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(7, 20, 29)
        window.navigationBarColor = AndroidColor.rgb(7, 20, 29)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        setContent { WapFireNativeApp() }
    }
}

@Composable
private fun WapFireNativeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("wapfire_native_v22", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val discovery = remember { WifiDiscovery(context) }
    val connector = remember { WifiConnector(context) }
    var isDark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var isFa by remember { mutableStateOf(prefs.getBoolean("fa", false)) }
    var stage by remember { mutableStateOf(Stage.DISCOVERY) }
    var bleReturnStage by remember { mutableStateOf(Stage.DISCOVERY) }
    var tab by remember { mutableStateOf(Tab.OVERVIEW) }
    var host by remember { mutableStateOf(prefs.getString("host", "192.168.4.1") ?: "192.168.4.1") }
    val savedLoginAtLaunch = remember { DeviceLoginVault.load(prefs, prefs.getString("host", "192.168.4.1") ?: "192.168.4.1") }
    var username by remember { mutableStateOf(savedLoginAtLaunch?.username ?: "admin") }
    var password by remember { mutableStateOf(savedLoginAtLaunch?.password ?: "") }
    var rememberPassword by remember { mutableStateOf(savedLoginAtLaunch != null) }
    var api by remember { mutableStateOf<WapFireApi?>(null) }
    // Device reachability is independent from the firmware's Promiscuous/LIVE state.
    // Keep the last snapshot and use this flag only for the app-to-device link indicator.
    var deviceOnline by remember { mutableStateOf(false) }
    var snapshot by remember { mutableStateOf(Snapshot()) }
    var logs by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var clients by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var networks by remember { mutableStateOf<List<WifiAccessPoint>>(emptyList()) }
    var lanDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedSsid by remember { mutableStateOf("") }
    var selectedBssid by remember { mutableStateOf("") }
    var wifiPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var setupAdminPass by remember { mutableStateOf("") }
    var setupApSsid by remember { mutableStateOf("WAPFire Network") }
    var setupApPass by remember { mutableStateOf("") }
    var setupStep by remember { mutableStateOf(0) }
    var setupLed by remember { mutableStateOf(true) }
    var setupSound by remember { mutableStateOf(true) }
    var setupAutoChannel by remember { mutableStateOf(true) }
    var setupSelfProtect by remember { mutableStateOf(false) }
    var setupSoftAp by remember { mutableStateOf(true) }
    var setupTarget by remember { mutableStateOf<JSONObject?>(null) }
    var targetSelecting by remember { mutableStateOf(false) }
    var targetNetworks by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var targetScanBusy by remember { mutableStateOf(false) }
    var advancedSettings by remember { mutableStateOf(AdvancedSettingsBundle()) }
    var advancedRefreshInProgress by remember { mutableStateOf(false) }
    var telemetryRefreshInProgress by remember { mutableStateOf(false) }
    var pendingBackupBytes by remember { mutableStateOf<ByteArray?>(null) }

    val backupDestinationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val bytes = pendingBackupBytes
        if (uri != null && bytes != null) {
            scope.launch {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Could not open destination file")
                }.onSuccess { notice = "WAPFire backup saved. This file contains device secrets; store it securely." }
                    .onFailure { error = it.message ?: "Could not save backup" }
                pendingBackupBytes = null
            }
        } else pendingBackupBytes = null
    }
    val restoreDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bytes = runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("Could not read backup") }
            if (bytes.isFailure) error = bytes.exceptionOrNull()?.message ?: "Could not read backup"
            else {
                val result = api?.restoreSettings(bytes.getOrThrow())
                if (result?.isSuccess == true) {
                    notice = "Settings restored. WAPFire is rebooting; reconnect and sign in again."
                    val client = api; client?.clearSession(); api = null
                    delay(3800)
                    connector.release(); stage = Stage.DISCOVERY
                } else error = result?.exceptionOrNull()?.message ?: "Restore failed"
            }
        }
    }
    val firmwareDocumentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bytes = runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("Could not read firmware image") }
            if (bytes.isFailure) error = bytes.exceptionOrNull()?.message ?: "Could not read firmware image"
            else {
                val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "firmware.bin"
                val result = api?.uploadFirmware(name, bytes.getOrThrow())
                if (result?.isSuccess == true) {
                    notice = result.getOrThrow()
                    val client = api; client?.clearSession(); api = null
                    delay(2500)
                    connector.release(); stage = Stage.DISCOVERY
                } else error = result?.exceptionOrNull()?.message ?: "Firmware upload failed"
            }
        }
    }

    val p = colors(isDark)
    LaunchedEffect(error, notice) {
        val currentError = error
        val currentNotice = notice
        if (currentError.isNotBlank() || currentNotice.isNotBlank()) {
            delay(if (currentError.isNotBlank()) 4800 else 3200)
            if (error == currentError) error = ""
            if (notice == currentNotice) notice = ""
        }
    }
    LaunchedEffect(isDark) {
        (context as? ComponentActivity)?.window?.let { window ->
            window.statusBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            window.navigationBarColor = if (isDark) AndroidColor.rgb(7, 20, 29) else AndroidColor.rgb(242, 247, 248)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (isDark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
    }
    val scheme = if (isDark) darkColorScheme(
        primary = p.accent, onPrimary = Color(0xFF05201F), background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    ) else lightColorScheme(
        primary = p.accent, onPrimary = Color.White, background = p.bg,
        surface = p.panel, onSurface = p.text, onBackground = p.text, secondary = p.blue
    )

    fun applySnapshot(status: JSONObject, settings: JSONObject? = null, chart: JSONObject? = null, firmwareInfo: JSONObject? = null) {
        val previousHadTarget = snapshot.target.isNotBlank() || snapshot.targetMac.isNotBlank()
        val updated = Snapshot.from(status, settings, chart, firmwareInfo)
        val updatedHasTarget = updated.target.isNotBlank() || updated.targetMac.isNotBlank()
        // Scan results are intentionally independent from the currently configured target.
        // This lets the user scan and choose a replacement target without clearing the old one.
        // The selection callback collapses this list to the single verified AP; a real target
        // clear still resets it so stale scan rows are not shown as the active target.
        if (previousHadTarget && !updatedHasTarget) {
            targetNetworks = emptyList()
        }
        snapshot = updated.copy(
            // Firmware version is static between logins/updates; do not replace it with a
            // placeholder when regular telemetry refreshes intentionally skip that endpoint.
            firmware = updated.firmware.takeIf { it.isNotBlank() && it != "—" } ?: snapshot.firmware,
            // Keep the last chart snapshot on tabs that do not need chart traffic, or when
            // a chart request briefly fails under load.
            targetApRx = if (chart != null) updated.targetApRx else snapshot.targetApRx,
            radioRates = if (chart != null) updated.radioRates else snapshot.radioRates,
            targetRates = if (chart != null) updated.targetRates else snapshot.targetRates
        )
        if (!status.optBoolean("configured", false) && stage == Stage.CONTROL) stage = Stage.SETUP
    }

    suspend fun refreshAdvanced() {
        if (advancedRefreshInProgress) return
        val client = api ?: return
        advancedRefreshInProgress = true
        try {
            // Keep the ESP32 WebServer request load predictable: requests are sequential,
            // and stop at the first failure instead of wasting a full timeout on every
            // remaining settings endpoint when the device is already unreachable.
            val fetchers: List<suspend () -> Result<JSONObject>> = listOf(
                { client.mobileSettings() }, { client.ethernetSettings() }, { client.httpApiSettings() },
                { client.ntpSettings() }, { client.mikrotikSettings() }, { client.ledSettings() },
                { client.disconnectLedSettings() }, { client.scheduleSettings() }, { client.whitelist() },
                { client.firmwareInfo() }, { client.backupInfo() }
            )
            val loaded = ArrayList<JSONObject>(fetchers.size)
            for (fetch in fetchers) {
                val result = fetch()
                if (result.isFailure) {
                    error = result.exceptionOrNull()?.message ?: "Could not load all device settings"
                    return
                }
                loaded += result.getOrThrow()
            }
            advancedSettings = AdvancedSettingsBundle(
                general = loaded[0], ethernet = loaded[1], httpApi = loaded[2],
                ntp = loaded[3], mikrotik = loaded[4], led = loaded[5],
                disconnectLed = loaded[6], schedule = loaded[7], whitelist = loaded[8],
                firmware = loaded[9], backupInfo = loaded[10]
            )
        } finally {
            advancedRefreshInProgress = false
        }
    }

    suspend fun refreshAll(activeTab: Tab = tab) {
        // Manual refreshes and the periodic loop can coincide. Skip the duplicate instead
        // of queuing another complete telemetry cycle behind the first one.
        if (telemetryRefreshInProgress) return
        val client = api ?: return
        telemetryRefreshInProgress = true
        try {
            val statusResult = client.status()
            if (statusResult.isFailure) {
                val reason = statusResult.exceptionOrNull()?.message ?: "Device connection lost"
                deviceOnline = false
                if (reason.contains("401") || reason.contains("Unauthorized", true)) {
                    client.clearSession()
                    api = null
                    val saved = DeviceLoginVault.load(prefs, host)
                    if (saved != null) { username = saved.username; password = saved.password; rememberPassword = true }
                    else { password = ""; rememberPassword = false }
                    stage = Stage.LOGIN
                }
                // A temporary link loss (common while an RF attack is active) is shown
                // in the top-bar link badge. Do not replace the cached dashboard with an
                // error/empty state and do not pop a toast over the last known data.
                return
            }
            val status = statusResult.getOrThrow()
            deviceOnline = true
            // Chart data is only needed on Overview. The firmware version is read at login
            // and after setup, so fetching it on every 3-second telemetry cycle is redundant.
            val chartResult = if (activeTab == Tab.OVERVIEW) client.chart() else null
            if (chartResult?.exceptionOrNull() is IOException) deviceOnline = false
            applySnapshot(status, null, chartResult?.getOrNull(), null)

            if (activeTab == Tab.EVENTS) {
                val result = client.logs()
                result.getOrNull()?.let { arr -> logs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
                if (result.exceptionOrNull() is IOException) deviceOnline = false
            }
            if (activeTab == Tab.CLIENTS || activeTab == Tab.SETTINGS) {
                val result = client.clients()
                result.getOrNull()?.let { arr -> clients = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } }
                if (result.exceptionOrNull() is IOException) deviceOnline = false
            }
        } finally {
            telemetryRefreshInProgress = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            scope.launch {
                scanning = true; error = ""; notice = ""
                connector.bindToCurrentWifi()
                networks = discovery.scan()
                lanDevices = discovery.findWapFireOnLan()
                scanning = false
                if (networks.isEmpty() && lanDevices.isEmpty()) error = tx(isFa, "No devices discovered. Enter the WAPFire IP manually.", "دستگاهی پیدا نشد. IP دستگاه را دستی وارد کن.")
            }
        } else error = tx(isFa, "Wi-Fi permission was not granted. Manual IP remains available.", "مجوز Wi-Fi داده نشد؛ ورود دستی IP همچنان فعال است.")
    }

    fun discoverNow() {
        val permissions = WifiDiscovery.requiredPermissions()
        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            error = tx(isFa, "Allow nearby Wi-Fi access to scan automatically. You can still enter an IP below.", "برای جستجوی خودکار مجوز Wi-Fi را بده؛ ورود دستی IP هم فعال است.")
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        scope.launch {
            scanning = true; error = ""; notice = ""
            connector.bindToCurrentWifi()
            val wifi = discovery.scan()
            val lan = discovery.findWapFireOnLan()
            networks = wifi
            lanDevices = lan
            scanning = false
            if (wifi.isEmpty() && lan.isEmpty()) error = tx(isFa, "No devices discovered. Enter the WAPFire IP manually.", "دستگاهی پیدا نشد. IP دستگاه را دستی وارد کن.")
        }
    }

    fun restoreRememberedLogin(targetHost: String) {
        val saved = DeviceLoginVault.load(prefs, targetHost)
        if (saved != null) {
            username = saved.username
            password = saved.password
            rememberPassword = true
        } else {
            username = "admin"
            password = ""
            rememberPassword = false
        }
    }

    fun useHost(value: String) {
        host = value.trim().removePrefix("http://").removePrefix("https://").substringBefore('/')
        prefs.edit().putString("host", host).apply()
        restoreRememberedLogin(host)
        connector.bindToCurrentWifi()
        error = ""; notice = ""
        stage = Stage.LOGIN
    }

    fun selectWifiAccessPoint(ap: WifiAccessPoint) {
        if (selectedBssid != ap.bssid) wifiPassword = ""
        selectedSsid = ap.ssid
        selectedBssid = ap.bssid
        error = ""
        notice = tx(isFa, "${ap.ssid} selected. Enter its Wi-Fi password and press Connect below.", "${ap.ssid} انتخاب شد. رمز Wi-Fi را وارد کن و دکمه اتصال پایین را بزن.")
    }

    fun startWifiConnect(ap: WifiAccessPoint) {
        if (selectedBssid != ap.bssid) {
            selectWifiAccessPoint(ap)
            return
        }
        if (ap.securityMode == "WEP") {
            error = tx(isFa, "WEP networks are not supported by Android's secure local-network join API.", "اتصال امن اندروید از شبکه‌های WEP پشتیبانی نمی‌کند.")
            return
        }
        if (ap.secured && wifiPassword.isBlank()) {
            error = tx(isFa, "Enter the Wi-Fi password for the selected access point.", "رمز Wi-Fi شبکه انتخاب‌شده را وارد کن.")
            return
        }
        if (ap.secured && wifiPassword.length !in 8..63) {
            error = tx(isFa, "WAPFire WPA2/WPA3 passphrases must contain 8–63 characters.", "رمز WPA2/WPA3 دستگاه باید ۸ تا ۶۳ نویسه باشد.")
            return
        }
        if (ap.secured && wifiPassword.any { it.code !in 0x20..0x7E }) {
            error = tx(isFa, "Android requires an ASCII Wi-Fi passphrase for WPA2/WPA3 network requests.", "برای اتصال WPA2/WPA3 از طریق Android، رمز Wi-Fi باید از نویسه‌های ASCII باشد.")
            return
        }
        busy = true; error = ""; notice = ""
        connector.connect(ap.ssid, ap.bssid, wifiPassword, ap.securityMode,
            onAvailable = { network, gateway ->
                scope.launch {
                    val actualHost = gateway.ifBlank { "192.168.4.1" }
                    val verifiedHost = discovery.findWapFireHost(network, actualHost)
                    busy = false
                    host = verifiedHost ?: actualHost
                    prefs.edit().putString("host", host).putString("known_ap_ssid", ap.ssid).apply()
                    selectedSsid = ap.ssid
                    selectedBssid = ap.bssid
                    if (verifiedHost != null) {
                        restoreRememberedLogin(host)
                        wifiPassword = ""
                        notice = tx(isFa, "WAPFire joined over ${ap.securityMode}; device WebUI verified at $host.", "اتصال به WAPFire با ${ap.securityMode} برقرار شد و WebUI دستگاه در $host پاسخ داد.")
                        stage = Stage.LOGIN
                    } else {
                        error = tx(isFa, "Android joined ${ap.ssid}, but the WAPFire login page did not answer at $actualHost. You are still connected to this Wi-Fi. Check that this is the WAPFire BSSID and SoftAP is enabled; you can also try the manual IP below.", "اندروید به ${ap.ssid} وصل شد، اما صفحه ورود WAPFire در $actualHost پاسخ نداد. اتصال Wi-Fi برقرار است؛ بررسی کن BSSID متعلق به WAPFire باشد و SoftAP فعال باشد. همچنین می‌توانی IP را در بخش دستی امتحان کنی.")
                    }
                }
            },
            onFailure = { reason ->
                busy = false
                error = if (reason.isNotBlank())
                    tx(isFa, "WAPFire Wi-Fi join failed: $reason", "اتصال Wi-Fi به WAPFire ناموفق بود: $reason")
                else tx(isFa, "Android could not join this Wi-Fi network. Check its password and try again.", "اندروید نتوانست به این شبکه وصل شود؛ رمز را بررسی و دوباره تلاش کن.")
            },
            onLost = {
                busy = false
                error = tx(isFa, "Wi-Fi link to the selected access point was lost. Re-scan and reconnect.", "اتصال Wi-Fi به اکسس‌پوینت انتخاب‌شده قطع شد؛ دوباره اسکن و متصل شو.")
            }
        )
    }

    fun signIn() {
        scope.launch {
            busy = true; error = ""; notice = ""
            deviceOnline = false
            val client = WapFireApi(host)
            val result = client.login(username, password)
            busy = false
            if (result.isSuccess) {
                api = client
                prefs.edit().putString("host", host).apply()
                val saved = if (rememberPassword) DeviceLoginVault.save(prefs, host, username, password) else {
                    DeviceLoginVault.clear(prefs); false
                }
                val status = client.status()
                if (status.isSuccess) {
                    deviceOnline = true
                    val value = status.getOrThrow()
                    applySnapshot(value, null, firmwareInfo = client.firmwareInfo().getOrNull())
                    if (!value.optBoolean("configured", false)) {
                        setupStep = 0
                        setupAdminPass = ""
                        setupApPass = ""
                        targetNetworks = emptyList()
                        targetSelecting = false
                        val initial = client.mobileSettings().getOrNull() ?: JSONObject()
                        setupApSsid = initial.optString("ap_ssid", value.optString("ap_ssid", "WAPFire")).ifBlank { "WAPFire" }
                        setupLed = initial.optBoolean("led", true)
                        setupSound = initial.optBoolean("sound", true)
                        setupAutoChannel = initial.optBoolean("auto_channel", true)
                        setupSelfProtect = initial.optBoolean("self_protect", false)
                        setupSoftAp = initial.optBoolean("softap_enabled", true)
                        val savedTargetSsid = initial.optString("target")
                        val savedTargetBssid = initial.optString("target_mac")
                        val savedTargetChannel = initial.optInt("target_ch")
                        setupTarget = if (savedTargetSsid.isNotBlank() && savedTargetBssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}")) && savedTargetChannel in 1..13) {
                            JSONObject().put("ssid", savedTargetSsid).put("bssid", savedTargetBssid).put("channel", savedTargetChannel).put("rssi", 0)
                        } else null
                    }
                    stage = if (value.optBoolean("configured", false)) Stage.CONTROL else Stage.SETUP
                    notice = if (rememberPassword && !saved)
                        tx(isFa, "Signed in, but this phone could not securely save the password.", "ورود موفق بود، اما ذخیره امن رمز روی گوشی انجام نشد.")
                    else tx(isFa, "Device session established.", "اتصال امن برقرار شد.")
                } else {
                    deviceOnline = false
                    error = status.exceptionOrNull()?.message ?: "Could not read device status"
                }
            } else error = result.exceptionOrNull()?.message ?: tx(isFa, "Authentication failed.", "ورود ناموفق بود.")
        }
    }

    LaunchedEffect(stage, tab, api) {
        if (stage == Stage.CONTROL && api != null) {
            // Settings forms are loaded once on entry, not on every telemetry poll.
            // This prevents a 15-second refresh from overwriting text the user is editing.
            if (tab == Tab.SETTINGS) refreshAdvanced()
            while (stage == Stage.CONTROL) {
                refreshAll(tab)
                delay(when (tab) { Tab.OVERVIEW -> 3000; Tab.SETTINGS -> 15000; else -> 5000 })
            }
        }
    }

    BackHandler(enabled = stage != Stage.DISCOVERY) {
        when (stage) {
            Stage.LOGIN -> stage = Stage.DISCOVERY
            Stage.BLE_SETUP -> stage = bleReturnStage
            Stage.SETUP -> if (setupStep > 0) setupStep-- else stage = Stage.DISCOVERY
            Stage.CONTROL -> { tab = Tab.OVERVIEW }
            else -> Unit
        }
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg, p.bg2, p.bg)))) {
            Box(Modifier.align(Alignment.TopEnd).padding(top = 70.dp, end = 8.dp).size(230.dp).blur(48.dp)
                .background(Brush.radialGradient(listOf(p.accent.copy(alpha = if (isDark) .20f else .13f), Color.Transparent)), CircleShape))
            Box(Modifier.align(Alignment.BottomStart).padding(bottom = 100.dp, start = 0.dp).size(260.dp).blur(54.dp)
                .background(Brush.radialGradient(listOf(p.blue.copy(alpha = if (isDark) .17f else .11f), Color.Transparent)), CircleShape))
            when (stage) {
                Stage.DISCOVERY -> DiscoveryScreen(
                    p, isFa, isDark, host, { host = it }, discovery.current(), networks, lanDevices,
                    scanning, busy, selectedSsid, selectedBssid, wifiPassword, { wifiPassword = it }, error, notice,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    onScan = { discoverNow() }, onSelectWifi = { selectWifiAccessPoint(it) },
                    onConnect = { startWifiConnect(it) },
                    onUseLan = { useHost(it) }, onUseCurrent = { val current = discovery.current(); useHost(if (current.ssid.contains("WAPFire", true)) current.gateway.ifBlank { host } else host) },
                    onManual = { useHost(host) },
                    onBluetoothSetup = { bleReturnStage = Stage.DISCOVERY; stage = Stage.BLE_SETUP },
                    onChangeWifiSelection = { selectedSsid = ""; selectedBssid = ""; wifiPassword = ""; error = ""; notice = "" }
                )
                Stage.BLE_SETUP -> BleSetupScreen(
                    p = p, fa = isFa, dark = isDark,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    onBack = { stage = bleReturnStage }
                )
                Stage.LOGIN -> LoginScreen(
                    p, isFa, isDark, host, { host = it }, username, { username = it }, password, { password = it },
                    rememberPassword, { checked -> rememberPassword = checked; if (!checked) DeviceLoginVault.clear(prefs) },
                    busy, error, notice, onBack = { stage = Stage.DISCOVERY }, onLogin = { signIn() },
                    onClear = { error = ""; notice = "" },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() }
                )
                Stage.SETUP -> FirstSetupScreen(
                    p = p, fa = isFa, dark = isDark,
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = { isFa = !isFa; prefs.edit().putBoolean("fa", isFa).apply() },
                    step = setupStep, onStep = { setupStep = it },
                    apSsid = setupApSsid, onApSsid = { setupApSsid = it },
                    apPass = setupApPass, onApPass = { setupApPass = it },
                    adminPass = setupAdminPass, onAdminPass = { setupAdminPass = it },
                    led = setupLed, onLed = { setupLed = it },
                    sound = setupSound, onSound = { setupSound = it },
                    autoChannel = setupAutoChannel, onAutoChannel = { setupAutoChannel = it },
                    selfProtect = setupSelfProtect, onSelfProtect = { setupSelfProtect = it },
                    softAp = setupSoftAp, onSoftAp = { setupSoftAp = it },
                    targetNetworks = targetNetworks, target = setupTarget,
                    targetScanning = targetScanBusy, targetSelecting = targetSelecting,
                    onTargetScan = {
                        scope.launch {
                            targetScanBusy = true; targetNetworks = emptyList(); error = ""; notice = ""
                            val result = api?.scan()
                            if (result?.isSuccess == true) {
                                val arr = result.getOrThrow()
                                val scanned = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                                val selectedBssid = setupTarget?.optString("bssid").orEmpty().trim()
                                targetNetworks = if (selectedBssid.isBlank()) scanned else
                                    scanned.filter { it.optString("bssid").trim().equals(selectedBssid, ignoreCase = true) }
                                if (targetNetworks.isEmpty()) notice = tx(isFa, "No matching access point was returned by the WAPFire radio scan.", "اکسس‌پوینت منطبق در اسکن رادیویی WAPFire پیدا نشد.")
                            } else error = result?.exceptionOrNull()?.message ?: "Target scan failed"
                            targetScanBusy = false
                        }
                    },
                    onTargetSelect = { network ->
                        scope.launch {
                            val ssid = network.optString("ssid")
                            val bssid = network.optString("bssid")
                            val channel = network.optInt("channel")
                            if (ssid.isBlank() || !isValidBssid(bssid) || channel !in 1..13) {
                                error = tx(isFa, "This access point has incomplete or invalid SSID/BSSID/channel data.", "اطلاعات SSID، BSSID یا کانال این شبکه ناقص یا نامعتبر است.")
                            } else {
                                targetSelecting = true; error = ""; notice = ""
                                val selected = api?.selectTarget(ssid, bssid, channel)
                                if (selected?.isSuccess == true) {
                                    val response = selected.getOrThrow()
                                    val verifiedBssid = response.optString("bssid", bssid).ifBlank { bssid }
                                    val verifiedChannel = response.optInt("channel", channel).takeIf { it in 1..13 } ?: channel
                                    val verifiedTarget = JSONObject()
                                        .put("ssid", response.optString("target", ssid).ifBlank { ssid })
                                        .put("bssid", verifiedBssid)
                                        .put("channel", verifiedChannel)
                                        .put("rssi", network.optInt("rssi"))
                                        .put("secured", network.optBoolean("secured"))
                                    if (isValidBssid(verifiedBssid)) {
                                        setupTarget = verifiedTarget
                                        targetNetworks = listOf(verifiedTarget)
                                        notice = tx(isFa, "Target verified by WAPFire: $ssid", "شبکه هدف توسط WAPFire تأیید شد: $ssid")
                                    } else {
                                        error = tx(isFa, "WAPFire returned an invalid target BSSID.", "فریم‌ور BSSID نامعتبر برای شبکه هدف برگرداند.")
                                    }
                                } else error = selected?.exceptionOrNull()?.message ?: "Target selection failed"
                                targetSelecting = false
                            }
                        }
                    },
                    onChangeTarget = { setupTarget = null; targetNetworks = emptyList() },
                    onRestore = { restoreDocumentLauncher.launch(arrayOf("application/json", "text/*")) },
                    saving = saving, snapshot = snapshot, error = error, notice = notice,
                    onFinish = {
                        val selected = setupTarget
                        if (selected == null) {
                            error = tx(isFa, "Select and verify a target access point before applying setup.", "قبل از اعمال Setup یک شبکه هدف انتخاب و تأیید کن.")
                        } else {
                            scope.launch {
                                saving = true; error = ""; notice = ""
                                val payload = JSONObject()
                                    .put("adminpass", setupAdminPass)
                                    .put("ap_ssid", setupApSsid)
                                    .put("ap_pass", setupApPass)
                                    .put("led", setupLed)
                                    .put("sound", setupSound)
                                    .put("auto_channel", setupAutoChannel)
                                    .put("self_protect", setupSelfProtect)
                                    .put("softap_enabled", setupSoftAp)
                                    .put("target", selected.optString("ssid"))
                                    .put("target_ch", selected.optInt("channel"))
                                    .put("target_mac", selected.optString("bssid"))
                                val client = api
                                val result = client?.updateSettings(payload)
                                saving = false
                                if (result?.isSuccess == true) {
                                    val response = result.getOrThrow()
                                    password = setupAdminPass
                                    val rememberedSetupSaved = if (rememberPassword)
                                        DeviceLoginVault.save(prefs, host, username, setupAdminPass) else true
                                    if (!rememberedSetupSaved) error = "Setup was applied, but the updated password could not be saved securely on this phone."
                                    if (response.optBoolean("wifi_restart_needed", false)) {
                                        notice = tx(isFa, "Setup saved. WAPFire is restarting its SoftAP with the new credentials. Rejoin it to continue.", "تنظیمات ذخیره شد. شبکه WAPFire با مشخصات جدید راه‌اندازی مجدد می‌شود؛ دوباره به آن وصل شو.")
                                        client?.clearSession(); api = null
                                        delay(3800)
                                        connector.release()
                                        host = "192.168.4.1"
                                        prefs.edit().putString("host", host).apply()
                                        stage = Stage.DISCOVERY
                                    } else {
                                        val status = client.status().getOrNull()
                                        if (status?.optBoolean("configured") == true) {
                                            deviceOnline = true
                                            applySnapshot(status, null, firmwareInfo = client.firmwareInfo().getOrNull())
                                            stage = Stage.CONTROL
                                            tab = Tab.OVERVIEW
                                            notice = tx(isFa, "Initial setup completed.", "راه‌اندازی اولیه کامل شد.")
                                        } else error = tx(isFa, "The device did not confirm setup completion.", "دستگاه تکمیل راه‌اندازی را تأیید نکرد.")
                                    }
                                } else error = result?.exceptionOrNull()?.message ?: "Setup could not be saved"
                            }
                        }
                    },
                    onClear = { error = ""; notice = "" },
                    onLogout = {
                        scope.launch {
                            val client = api
                            runCatching { client?.logout() }
                            client?.clearSession(); api = null; deviceOnline = false; connector.release()
                            stage = Stage.DISCOVERY; error = ""; notice = ""
                        }
                    }
                )
                Stage.CONTROL -> ControlCenter(
                    p, isFa, isDark, tab, snapshot, deviceOnline, logs, clients, error, notice,
                    onTab = { tab = it; error = ""; notice = "" },
                    onTheme = { isDark = !isDark; prefs.edit().putBoolean("dark", isDark).apply() },
                    onLanguage = {
                        val next = if (isFa) "en" else "fa"
                        scope.launch {
                            val result = api?.setLanguage(next)
                            if (result?.isSuccess == true) {
                                isFa = next == "fa"
                                prefs.edit().putBoolean("fa", isFa).apply()
                                notice = result.getOrThrow().optString("message").ifBlank { "Device language updated." }
                            } else error = result?.exceptionOrNull()?.message ?: "Could not update device language"
                        }
                    },
                    onRefresh = { scope.launch { refreshAll(tab); if (tab == Tab.SETTINGS) refreshAdvanced() } },
                    onToggle = { key, value ->
                        scope.launch {
                            val result = api?.updateSettings(JSONObject().put(key, value))
                            if (result?.isSuccess == true) {
                                val response = result.getOrThrow()
                                if (response.optBoolean("wifi_restart_needed")) {
                                    notice = tx(isFa, "Setting saved. WAPFire Wi-Fi is restarting; reconnect and sign in again.", "تنظیم ذخیره شد. Wi‑Fi دستگاه دوباره راه‌اندازی می‌شود؛ دوباره متصل شو و وارد شو.")
                                    api?.clearSession(); api = null
                                    delay(700)
                                    connector.release()
                                    stage = Stage.DISCOVERY
                                } else {
                                    notice = response.optString("message").ifBlank { tx(isFa, "${key.replace('_', ' ')} updated on WAPFire.", "تنظیم ${key.replace('_', ' ')} در WAPFire اعمال شد.") }
                                    refreshAll(tab)
                                }
                            } else error = result?.exceptionOrNull()?.message ?: "Setting was not applied"
                        }
                    },
                    targetNetworks = targetNetworks, targetScanBusy = targetScanBusy,
                    targetSelecting = targetSelecting,
                    onTargetScan = {
                        scope.launch {
                            targetScanBusy = true
                            error = ""; notice = ""
                            // Do not require clearing the current target. A scan always exposes
                            // every AP returned by the radio, regardless of the active BSSID.
                            val result = api?.scan()
                            targetScanBusy = false
                            if (result?.isSuccess == true) {
                                val found = result.getOrThrow()
                                targetNetworks = (0 until found.length()).mapNotNull { found.optJSONObject(it) }
                                if (targetNetworks.isEmpty()) notice = tx(
                                    isFa,
                                    "No access points were returned by the scan. Try scanning again.",
                                    "در این اسکن اکسس‌پوینتی برنگشت. دوباره اسکن کن."
                                )
                            } else {
                                error = result?.exceptionOrNull()?.message ?: tx(isFa, "Network scan failed.", "اسکن شبکه ناموفق بود.")
                            }
                        }
                    },
                    onSelectTarget = { network ->
                        scope.launch {
                            if (targetSelecting) return@launch
                            targetSelecting = true
                            error = ""; notice = ""
                            val ssid = network.optString("ssid")
                            val bssid = network.optString("bssid").trim()
                            val channel = network.optInt("channel")
                            if (ssid.isBlank() || !isValidBssid(bssid) || channel !in 1..13) {
                                error = tx(isFa, "This access point cannot be selected because its SSID, BSSID or channel is invalid.", "به دلیل نامعتبر بودن SSID، BSSID یا کانال، این اکسس‌پوینت قابل انتخاب نیست.")
                            } else {
                                val selected = api?.selectTarget(ssid, bssid, channel)
                                if (selected?.isSuccess == true) {
                                    val verified = selected.getOrThrow()
                                    val verifiedBssid = verified.optString("bssid", bssid).ifBlank { bssid }
                                    val verifiedChannel = verified.optInt("channel", channel).takeIf { it in 1..13 } ?: channel
                                    val selectedAp = JSONObject()
                                        .put("ssid", verified.optString("target", ssid).ifBlank { ssid })
                                        .put("bssid", verifiedBssid)
                                        .put("channel", verifiedChannel)
                                        .put("rssi", network.optInt("rssi"))
                                        .put("secured", network.optBoolean("secured"))
                                    if (!isValidBssid(verifiedBssid)) {
                                        error = tx(isFa, "WAPFire returned an invalid target BSSID.", "فریم‌ور BSSID نامعتبر برای شبکه هدف برگرداند.")
                                    } else {
                                        // Keep the verified radio as the only result even if persistence fails.
                                        targetNetworks = listOf(selectedAp)
                                        refreshAll(Tab.OVERVIEW)
                                        val saved = api?.saveTarget(ssid, verifiedBssid, verifiedChannel)
                                        if (saved?.isSuccess == true) notice = tx(isFa, "Target selected and saved.", "شبکه هدف انتخاب و ذخیره شد.")
                                        else error = saved?.exceptionOrNull()?.message ?: "Target is active but could not be saved"
                                    }
                                } else error = selected?.exceptionOrNull()?.message ?: "Target selection failed"
                            }
                            targetSelecting = false
                        }
                    },
                    onClearLogs = {
                        scope.launch {
                            val result = api?.clearLogs()
                            if (result?.isSuccess == true) { notice = tx(isFa, "Device event log cleared.", "گزارش رویدادهای دستگاه پاک شد."); refreshAll(Tab.EVENTS) }
                            else error = result?.exceptionOrNull()?.message ?: "Could not clear logs"
                        }
                    },
                    onClearTarget = {
                        scope.launch {
                            val result = api?.selectTarget("", "", 0)
                            if (result?.isSuccess == true) {
                                targetNetworks = emptyList()
                                notice = tx(isFa, "Target cleared.", "شبکه هدف پاک شد.")
                                refreshAll(Tab.OVERVIEW)
                            } else error = result?.exceptionOrNull()?.message ?: "Could not clear target"
                        }
                    },
                    onLogout = {
                        scope.launch {
                            val client = api
                            runCatching { client?.logout() }
                            client?.clearSession(); api = null; connector.release()
                            password = ""; setupAdminPass = ""; setupApPass = ""; wifiPassword = ""
                            logs = emptyList(); clients = emptyList(); targetNetworks = emptyList()
                            snapshot = Snapshot(); error = ""; notice = ""; stage = Stage.DISCOVERY; tab = Tab.OVERVIEW
                        }
                    },
                    onClearMessage = { error = ""; notice = "" },
                    advanced = advancedSettings,
                    onAdvancedSave = { module, payload ->
                        scope.launch {
                            error = ""; notice = ""
                            val result = when (module) {
                                "general" -> api?.updateSettings(payload)
                                "ethernet" -> api?.saveEthernet(payload)
                                "http_api" -> api?.saveHttpApi(payload)
                                "ntp" -> api?.saveNtp(payload)
                                "mikrotik" -> api?.saveMikrotik(payload)
                                "led" -> api?.saveLed(payload)
                                "disconnect_led" -> api?.saveDisconnectLed(payload)
                                "schedule" -> api?.saveSchedule(payload)
                                "whitelist" -> api?.saveWhitelist(payload)
                                else -> null
                            }
                            if (result?.isSuccess == true) {
                                val response = result.getOrThrow()
                                notice = response.optString("message").ifBlank { "${module.replace('_', ' ')} settings saved." }
                                if (module == "general" && payload.has("adminpass")) {
                                    password = payload.optString("adminpass")
                                    if (rememberPassword && !DeviceLoginVault.save(prefs, host, username, password)) {
                                        error = "Password changed, but the updated login could not be saved securely on this phone."
                                    }
                                }
                                if (module == "general" && response.optBoolean("wifi_restart_needed")) {
                                    notice = "Credentials / target saved. WAPFire Wi-Fi is restarting; reconnect and sign in again."
                                    api?.clearSession(); api = null
                                    delay(3600)
                                    connector.release(); stage = Stage.DISCOVERY
                                } else {
                                    refreshAdvanced()
                                }
                            } else error = result?.exceptionOrNull()?.message ?: "Could not save ${module.replace('_', ' ')} settings"
                        }
                    },
                    onAdvancedAction = { action ->
                        scope.launch {
                            error = ""; notice = ""
                            val client = api
                            when (action) {
                                "test_http_api" -> { val r = client?.testHttpApi(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "Test event sent") else error = r?.exceptionOrNull()?.message ?: "HTTP API test failed" }
                                "test_mikrotik" -> { val r = client?.testMikrotik(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "MikroTik test queued") else error = r?.exceptionOrNull()?.message ?: "MikroTik test failed" }
                                "ntp_sync_now" -> { val r = client?.syncNtpNow(); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "NTP sync initiated") else error = r?.exceptionOrNull()?.message ?: "NTP sync failed" }
                                "ntp_sync_browser" -> { val r = client?.syncNtpFromPhone(System.currentTimeMillis() / 1000L); if (r?.isSuccess == true) notice = r.getOrThrow().optString("message", "Phone time sent to WAPFire") else error = r?.exceptionOrNull()?.message ?: "Phone time sync failed" }
                                "refresh_clients" -> { refreshAll(Tab.SETTINGS); notice = tx(isFa, "Tracked client list refreshed.", "فهرست کلاینت‌های ردیابی‌شده به‌روز شد.") }
                                "check_update" -> { val r = client?.checkUpdate(); if (r?.isSuccess == true) { val v = r.getOrThrow(); notice = when { v.optBoolean("update_available") -> "Update available: ${v.optString("latest_version")}"; !v.optBoolean("automatic_updates_supported", true) -> v.optString("message").ifBlank { "No online release feed is configured. Manual OTA remains available." }; else -> "WAPFire is up to date (${v.optString("current_version")})." } } else error = r?.exceptionOrNull()?.message ?: "Update check failed" }
                                "reboot", "wifi_restart", "factory_reset", "force_setup" -> {
                                    val path = when (action) {
                                        "reboot" -> "/reboot"
                                        "wifi_restart" -> "/wifi_restart"
                                        "factory_reset" -> "/factory_reset"
                                        else -> "/force_setup"
                                    }
                                    val r = client?.deviceAction(path)
                                    if (r?.isSuccess == true) {
                                        notice = when (action) {
                                            "factory_reset" -> "Factory reset accepted. Reconnect and run setup again."
                                            "force_setup" -> "Setup mode enabled. Reconnect to WAPFire and complete setup."
                                            "reboot" -> "WAPFire is rebooting. Reconnect when it is online."
                                            else -> "Wi-Fi services are restarting. Reconnect when the access point returns."
                                        }
                                        client?.clearSession(); api = null
                                        delay(700)
                                        connector.release()
                                        if (action == "factory_reset" || action == "force_setup") {
                                            snapshot = Snapshot(); logs = emptyList(); clients = emptyList(); advancedSettings = AdvancedSettingsBundle()
                                        }
                                        stage = Stage.DISCOVERY
                                    } else error = r?.exceptionOrNull()?.message ?: "Device action failed"
                                }
                            }
                        }
                    },
                    onBackup = {
                        scope.launch {
                            val r = api?.backupSettings()
                            if (r?.isSuccess == true) {
                                val bytes = r.getOrThrow()
                                val name = "WAPFire-backup-${System.currentTimeMillis()}.json"
                                pendingBackupBytes = bytes
                                backupDestinationLauncher.launch(name)
                            } else error = r?.exceptionOrNull()?.message ?: "Backup failed"
                        }
                    },
                    onRestore = { restoreDocumentLauncher.launch(arrayOf("application/json", "text/*")) },
                    onFirmwarePick = { firmwareDocumentLauncher.launch(arrayOf("application/octet-stream", "application/x-binary", "application/firmware")) },
                    onBluetoothManage = { bleReturnStage = Stage.CONTROL; stage = Stage.BLE_SETUP }
                )
            }
            // A separate popup window is fully detached from the scrollable page's
            // measurement and nested-scroll hierarchy.
            if (error.isNotBlank() || notice.isNotBlank()) {
                Popup(
                    alignment = Alignment.TopCenter,
                    properties = PopupProperties(
                        focusable = false,
                        dismissOnBackPress = false,
                        dismissOnClickOutside = false,
                        clippingEnabled = true
                    )
                ) {
                    Box(
                        Modifier.widthIn(max = 320.dp)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .shadow(16.dp, RoundedCornerShape(14.dp))
                    ) {
                        MessageCard(
                            p,
                            if (error.isNotBlank()) error else notice,
                            error.isNotBlank(),
                            onClose = { error = ""; notice = "" }
                        )
                    }
                }
            }
        }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DiscoveryScreen(
    p: Palette, fa: Boolean, dark: Boolean, host: String, onHost: (String) -> Unit,
    current: CurrentWifi, networks: List<WifiAccessPoint>, lan: List<String>, scanning: Boolean, connecting: Boolean,
    selectedSsid: String, selectedBssid: String, wifiPassword: String, onWifiPassword: (String) -> Unit, error: String, notice: String,
    onTheme: () -> Unit, onLanguage: () -> Unit, onScan: () -> Unit,
    onSelectWifi: (WifiAccessPoint) -> Unit, onConnect: (WifiAccessPoint) -> Unit,
    onUseLan: (String) -> Unit, onUseCurrent: () -> Unit, onManual: () -> Unit, onBluetoothSetup: () -> Unit, onChangeWifiSelection: () -> Unit
) {
    val selectedAp = networks.firstOrNull { it.bssid.equals(selectedBssid, ignoreCase = true) }
    val passwordFocusRequester = remember { FocusRequester() }
    val passwordBringIntoViewRequester = remember { BringIntoViewRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(selectedBssid, selectedAp?.bssid) {
        if (selectedAp != null) {
            // Let the selected-network card enter composition before requesting visibility/focus.
            delay(180)
            passwordBringIntoViewRequester.bringIntoView()
            if (selectedAp.secured) {
                passwordFocusRequester.requestFocus()
                keyboardController?.show()
            }
        } else {
            keyboardController?.hide()
        }
    }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand(p)
            Spacer(Modifier.weight(1f))
            SmallAction(p, if (fa) "EN" else "FA", onLanguage)
            Spacer(Modifier.width(8.dp)); ThemeAction(p, dark, onTheme)
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(fa, "YOUR WIRELESS SECURITY HUB", "مرکز امنیت شبکه بی‌سیم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("WAPFire", color = p.text, fontSize = 42.sp, lineHeight = 46.sp, fontWeight = FontWeight.ExtraBold)
            Text(tx(fa, "A native control app for discovery, monitoring and device configuration.", "اپلیکیشن مستقل برای پیدا کردن دستگاه، پایش زنده و مدیریت تنظیمات."), color = p.muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        SectionCard(
            p,
            title = tx(fa, "CURRENT NETWORK", "شبکه فعلی"),
            subtitle = current.ssid.ifBlank {
                if (current.connected) tx(fa, "Wi-Fi connection detected", "اتصال Wi-Fi برقرار است")
                else tx(fa, "No Wi-Fi connection detected", "اتصال Wi-Fi شناسایی نشد")
            }
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("IP  ${current.localIp.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                    Text("Gateway  ${current.gateway.ifBlank { "—" }}", color = p.muted, fontSize = 11.sp)
                }
                ActionButton(p, tx(fa, "Use network", "استفاده"), onUseCurrent, primary = true)
            }
        }
        SectionCard(p, title = tx(fa, "DEVICE DISCOVERY", "پیدا کردن دستگاه"), subtitle = tx(fa, "Scan the local network or join the WAPFire access point.", "شبکه محلی را جستجو کن یا به اکسس‌پوینت WAPFire وصل شو.")) {
            if (selectedAp == null) {
                ActionButton(p, if (scanning) tx(fa, "Scanning…", "در حال جستجو…") else tx(fa, "Scan nearby devices", "جستجوی دستگاه‌ها"), onScan, enabled = !scanning, primary = true, modifier = Modifier.fillMaxWidth())
                if (scanning) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = p.accent, strokeWidth = 2.dp)
                    Text(tx(fa, "Looking for WAPFire…", "در حال جستجوی WAPFire…"), color = p.muted, fontSize = 12.sp)
                }
                lan.forEach { ip -> DeviceResult(p, "WAPFire device", ip, "LAN DEVICE", onClick = { onUseLan(ip) }, action = tx(fa, "Connect", "اتصال")) }
                networks.sortedByDescending { it.isWapFire }.forEach { ap ->
                    val label = if (ap.isWapFire) tx(fa, "WAPFIRE WI-FI", "شبکه WAPFire") else tx(fa, "NEARBY WI-FI", "شبکه اطراف")
                    val security = when (ap.securityMode) {
                        "WPA2_WPA3" -> "WPA2/WPA3"
                        else -> ap.securityMode
                    }
                    DeviceResult(p, ap.ssid, "${ap.bssid}  ·  Ch ${((ap.frequency - 2407) / 5).coerceAtLeast(1)}  ·  ${ap.rssi} dBm  ·  $security", label,
                        onClick = { onSelectWifi(ap) }, action = tx(fa, "Select", "انتخاب"))
                }
                if (networks.isEmpty() && !scanning) Text(tx(fa, "No nearby Wi-Fi access points found. Retry the scan or enter the device IP manually.", "شبکه Wi-Fi پیدا نشد. دوباره اسکن کن یا IP دستگاه را دستی وارد کن."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
            } else {
                val security = if (selectedAp.secured) selectedAp.securityMode else tx(fa, "Open network", "شبکه بدون رمز")
                DeviceResult(
                    p, selectedAp.ssid, "${selectedAp.bssid}  ·  ${selectedAp.rssi} dBm  ·  $security",
                    tx(fa, "SELECTED WI-FI", "شبکه انتخاب‌شده"), onClick = {}, action = "", selected = true, enabled = false
                )
                ActionButton(p, tx(fa, "Choose another network", "انتخاب شبکه دیگر"), onChangeWifiSelection,
                    enabled = !connecting, modifier = Modifier.fillMaxWidth())
            }
        }
        if (selectedSsid.isNotBlank() && selectedAp != null) {
            Box(Modifier.fillMaxWidth().bringIntoViewRequester(passwordBringIntoViewRequester)) {
                SectionCard(p, title = tx(fa, "CONNECT TO SELECTED WI-FI", "اتصال به شبکه انتخاب‌شده"), subtitle = "$selectedSsid  ·  $selectedBssid") {
                    if (selectedAp.secured) NativeField(
                        p, wifiPassword, onWifiPassword, tx(fa, "Network password", "رمز Wi-Fi"), password = true,
                        focusRequester = passwordFocusRequester
                    )
                    Text(tx(fa, "Security: ${selectedAp.securityMode}. Android may ask you to approve the local Wi-Fi connection.", "امنیت: ${selectedAp.securityMode}. ممکن است اندروید برای اتصال محلی Wi-Fi تأیید بخواهد."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                    ActionButton(p, if (connecting) tx(fa, "Joining WAPFire…", "در حال اتصال به WAPFire…") else tx(fa, "Connect to WAPFire", "اتصال به WAPFire"),
                        { onConnect(selectedAp) }, enabled = !connecting && (!selectedAp.secured || wifiPassword.length in 8..63), primary = true, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        SectionCard(p, title = tx(fa, "BLUETOOTH SETUP", "راه‌اندازی با بلوتوث"), subtitle = tx(fa, "Provision WAPFire or manage basic settings without joining its Wi-Fi network.", "بدون اتصال به Wi-Fi دستگاه، WAPFire را راه‌اندازی یا تنظیمات پایه را مدیریت کن.")) {
            Text(tx(fa, "BLE is intended for first-time setup and basic management. Wi-Fi remains the full-featured connection for live telemetry, events and logs.", "BLE برای راه‌اندازی اولیه و مدیریت تنظیمات پایه است. برای تله‌متری زنده، رویدادها و گزارش‌ها، اتصال کامل Wi-Fi حفظ می‌شود."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
            ActionButton(p, tx(fa, "Find WAPFire over Bluetooth", "پیدا کردن WAPFire با بلوتوث"), onBluetoothSetup, primary = true, modifier = Modifier.fillMaxWidth())
        }
        SectionCard(p, title = tx(fa, "MANUAL DEVICE ADDRESS", "نشانی دستی دستگاه"), subtitle = tx(fa, "For Ethernet, custom subnets or a fixed IP.", "برای Ethernet، زیرشبکه سفارشی یا IP ثابت.")) {
            NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri)
            ActionButton(p, tx(fa, "Continue to sign in", "ادامه و ورود"), onManual, primary = true, modifier = Modifier.fillMaxWidth())
        }
        Text("WAPFIRE MOBILE  ·  NATIVE ANDROID", color = p.muted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp))
    }
}

@Composable
private fun BleSetupScreen(
    p: Palette, fa: Boolean, dark: Boolean,
    onTheme: () -> Unit, onLanguage: () -> Unit, onBack: () -> Unit
) {
    val context = LocalContext.current
    var devices by remember { mutableStateOf<List<WapFireBleDevice>>(emptyList()) }
    var bleState by remember { mutableStateOf(tx(fa, "Bluetooth is ready to scan.", "بلوتوث آماده اسکن است.")) }
    var secureSessionReady by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf("") }
    var deviceName by remember { mutableStateOf("") }
    var firmware by remember { mutableStateOf("") }
    var configured by remember { mutableStateOf<Boolean?>(null) }
    var settingsLoaded by remember { mutableStateOf(false) }
    var provisioningSaved by remember { mutableStateOf(false) }
    var apSsid by remember { mutableStateOf("WAPFire Network") }
    var apPass by remember { mutableStateOf("") }
    var adminPass by remember { mutableStateOf("") }
    var led by remember { mutableStateOf(true) }
    var sound by remember { mutableStateOf(true) }
    var autoChannel by remember { mutableStateOf(true) }
    var selfProtect by remember { mutableStateOf(false) }
    var softApEnabled by remember { mutableStateOf(true) }
    var bleManagement by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    val clientRef = remember { androidx.compose.runtime.mutableStateOf<WapFireBleClient?>(null) }

    val client = remember(context) {
        WapFireBleClient(
            context = context,
            onDevices = { devices = it },
            onState = { state ->
                bleState = state
                if (state.contains("Secure WAPFire BLE connection ready", true)) secureSessionReady = true
                if (state.contains("disconnected", true) || state.contains("connection error", true) ||
                    state.contains("pairing was cancelled", true) || state.contains("timed out", true)) secureSessionReady = false
            },
            onResponse = { response ->
                val ok = response.optBoolean("ok")
                val cmd = response.optString("cmd")
                val data = response.optJSONObject("data") ?: JSONObject()
                if (!ok) {
                    busy = false
                    resultMessage = response.optString("message").ifBlank { "Bluetooth command failed." }
                } else when (cmd) {
                    "info" -> {
                        deviceName = data.optString("device", "WAPFire")
                        firmware = data.optString("firmware")
                        configured = data.optBoolean("configured")
                        apSsid = data.optString("ap_ssid", apSsid)
                        bleManagement = data.optBoolean("ble_management", true)
                        resultMessage = response.optString("message", "Secure BLE link established.")
                        clientRef.value?.send(JSONObject().put("cmd", "get_settings"))
                    }
                    "get_settings" -> {
                        apSsid = data.optString("ap_ssid", apSsid)
                        led = data.optBoolean("led", led)
                        sound = data.optBoolean("sound", sound)
                        autoChannel = data.optBoolean("auto_channel", autoChannel)
                        selfProtect = data.optBoolean("self_protect", selfProtect)
                        softApEnabled = data.optBoolean("softap_enabled", softApEnabled)
                        bleManagement = data.optBoolean("ble_management", bleManagement)
                        settingsLoaded = true
                        busy = false
                        resultMessage = tx(fa, "Device settings loaded. Passwords are never read back.", "تنظیمات دستگاه دریافت شد. رمزها از دستگاه خوانده نمی‌شوند.")
                    }
                    "initial_setup" -> {
                        busy = false
                        configured = false
                        resultMessage = response.optString("message").ifBlank {
                            tx(fa, "Credentials saved. Join the new WAPFire Wi-Fi and finish target selection in the normal Setup wizard.", "اطلاعات ذخیره شد. به Wi-Fi جدید WAPFire وصل شو و انتخاب شبکه هدف را در Setup معمولی کامل کن.")
                        }
                        adminPass = ""
                        apPass = ""
                        provisioningSaved = true
                    }
                    "set_settings" -> {
                        busy = false
                        resultMessage = response.optString("message").ifBlank { "WAPFire settings updated." }
                        if (data.optBoolean("wifi_restart_needed")) resultMessage = resultMessage + " Wi-Fi will restart; reconnect using the new AP credentials."
                        adminPass = ""
                        apPass = ""
                    }
                    else -> {
                        busy = false
                        resultMessage = response.optString("message").ifBlank { "Command completed." }
                    }
                }
            }
        )
    }
    SideEffect { clientRef.value = client }
    DisposableEffect(client) {
        onDispose { client.close(); clientRef.value = null }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) client.scan()
        else bleState = tx(fa, "Nearby devices permission is required for BLE scanning and connection.", "برای اسکن و اتصال BLE مجوز دستگاه‌های نزدیک لازم است.")
    }
    val requestScan = {
        val missing = WapFireBleClient.requiredPermissions().filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) client.scan() else permissionLauncher.launch(missing.toTypedArray())
    }

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallAction(p, "‹", onBack)
            Spacer(Modifier.width(10.dp)); Brand(p); Spacer(Modifier.weight(1f))
            SmallAction(p, if (fa) "EN" else "FA", onLanguage)
            Spacer(Modifier.width(7.dp)); ThemeAction(p, dark, onTheme)
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(fa, "BLE MANAGEMENT", "مدیریت بلوتوث"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text(tx(fa, "Connect to WAPFire", "اتصال به WAPFire"), color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Secure Bluetooth Low Energy for first setup and basic device settings.", "Bluetooth Low Energy امن برای راه‌اندازی اولیه و تنظیمات پایه دستگاه."), color = p.muted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        SectionCard(p, title = tx(fa, "01  ·  DEVICE DISCOVERY", "۰۱  ·  جستجوی دستگاه"), subtitle = tx(fa, "The device advertises as WAPFire- followed by its MAC suffix.", "دستگاه با نام WAPFire و پسوندی از MAC تبلیغ می‌شود.")) {
            ActionButton(p, tx(fa, "Scan for WAPFire", "جستجوی WAPFire"), requestScan, primary = true, modifier = Modifier.fillMaxWidth())
            Text(bleState, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
            devices.forEach { item ->
                DeviceResult(
                    p, item.name, "${item.address}  ·  ${item.rssi} dBm", "BLE DEVICE",
                    onClick = { client.connect(item); secureSessionReady = false; settingsLoaded = false; provisioningSaved = false; configured = null; resultMessage = "" },
                    action = tx(fa, "Connect", "اتصال")
                )
            }
            if (devices.isEmpty()) {
                Text(tx(fa, "No WAPFire BLE device found yet. Make sure Bluetooth is enabled and the device is powered on.", "هنوز دستگاه WAPFire پیدا نشده است. بلوتوث گوشی روشن و دستگاه روشن باشد."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                Text(tx(fa, "For an already-configured device, first enable Settings → Bluetooth management while connected over Wi-Fi. New/unconfigured devices advertise BLE automatically.", "برای دستگاهی که قبلاً راه‌اندازی شده، ابتدا در حالت اتصال Wi-Fi از Settings گزینه Bluetooth management را روشن کن. دستگاه تازه و راه‌اندازی‌نشده به‌صورت خودکار BLE را تبلیغ می‌کند."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        if (secureSessionReady) {
            SectionCard(p, title = tx(fa, "02  ·  SECURE SESSION", "۰۲  ·  نشست امن"), subtitle = if (deviceName.isNotBlank()) "$deviceName  ·  ${firmware.ifBlank { "Firmware —" }}" else "WAPFire BLE") {
                Text(bleState, color = p.green, fontSize = 11.sp)
                if (configured != null) Text(if (configured == true) tx(fa, "Device already configured", "دستگاه قبلاً پیکربندی شده") else tx(fa, "First-time provisioning available", "راه‌اندازی اولیه در دسترس است"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                ActionButton(p, tx(fa, "Disconnect Bluetooth", "قطع اتصال بلوتوث"), { client.disconnect(); secureSessionReady = false; configured = null; settingsLoaded = false }, primary = false, modifier = Modifier.fillMaxWidth())
            }
        }
        if (configured == false && !provisioningSaved) {
            SectionCard(p, title = tx(fa, "03  ·  FIRST-TIME PROVISIONING", "۰۳  ·  راه‌اندازی اولیه"), subtitle = tx(fa, "Set the administrator password and WAPFire access-point credentials.", "رمز مدیر و مشخصات اکسس‌پوینت WAPFire را تعیین کن.")) {
                Text(tx(fa, "Pairing is protected by a unique six-digit PIN printed to the device USB Serial log. Enter that PIN in Android's pairing prompt. Do not share it.", "Pairing با PIN شش‌رقمی اختصاصی محافظت می‌شود که در Serial USB دستگاه چاپ می‌شود. آن را در پنجره Pairing اندروید وارد کن و با کسی به اشتراک نگذار."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
                NativeField(p, apSsid, { apSsid = it }, tx(fa, "WAPFire Wi-Fi name", "نام Wi-Fi دستگاه"))
                NativeField(p, apPass, { apPass = it }, tx(fa, "WAPFire Wi-Fi password", "رمز Wi-Fi دستگاه"), password = true)
                NativeField(p, adminPass, { adminPass = it }, tx(fa, "Administrator password", "رمز مدیر"), password = true)
                ToggleRow(p, tx(fa, "Status LED", "چراغ وضعیت"), tx(fa, "Enable the physical status LED.", "چراغ وضعیت دستگاه فعال باشد."), led) { led = it }
                ToggleRow(p, tx(fa, "Sound alerts", "هشدار صوتی"), tx(fa, "Enable supported audible alerts.", "هشدارهای صوتی پشتیبانی‌شده فعال باشد."), sound) { sound = it }
                ToggleRow(p, tx(fa, "Automatic channel tracking", "ردگیری خودکار کانال"), tx(fa, "Track the selected target after completing Wi-Fi setup.", "پس از تکمیل راه‌اندازی Wi-Fi، کانال هدف را دنبال کند."), autoChannel) { autoChannel = it }
                ToggleRow(p, tx(fa, "Self-protect mode", "حالت محافظت از خود"), tx(fa, "Enable the configured protection response.", "واکنش حفاظتی تعریف‌شده فعال باشد."), selfProtect) { selfProtect = it }
                ActionButton(
                    p, if (busy) tx(fa, "Saving…", "در حال ذخیره…") else tx(fa, "Save initial settings", "ذخیره تنظیمات اولیه"),
                    {
                        busy = true; resultMessage = ""
                        val command = JSONObject().put("cmd", "initial_setup").put("ap_ssid", apSsid.trim())
                            .put("ap_pass", apPass).put("adminpass", adminPass)
                            .put("led", led).put("sound", sound).put("auto_channel", autoChannel)
                            .put("self_protect", selfProtect)
                        if (!client.send(command)) { busy = false; resultMessage = tx(fa, "BLE is not ready or another command is pending.", "اتصال BLE آماده نیست یا فرمان دیگری در حال اجراست.") }
                    },
                    enabled = !busy && apSsid.isNotBlank() && apPass.length in 8..63 && adminPass.length in 8..64,
                    primary = true, modifier = Modifier.fillMaxWidth()
                )
            }
        } else if (configured == false && provisioningSaved) {
            SectionCard(p, title = tx(fa, "03  ·  CONTINUE OVER WI-FI", "۰۳  ·  ادامه از طریق Wi-Fi"), subtitle = tx(fa, "Initial credentials were saved securely.", "اطلاعات اولیه با موفقیت ذخیره شد.")) {
                Text(tx(fa, "Disconnect Bluetooth, join the WAPFire access point using the new credentials, then complete the existing Setup wizard to select and verify the target access point.", "اتصال بلوتوث را قطع کن، با اطلاعات جدید به اکسس‌پوینت WAPFire وصل شو و سپس Wizard فعلی Setup را برای انتخاب و تأیید شبکه هدف کامل کن."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                ActionButton(p, tx(fa, "Disconnect and return to Wi-Fi discovery", "قطع بلوتوث و بازگشت به جستجوی Wi-Fi"), { client.disconnect(); secureSessionReady = false; onBack() }, primary = true, modifier = Modifier.fillMaxWidth())
            }
        } else if (configured == true && settingsLoaded) {
            SectionCard(p, title = tx(fa, "03  ·  BASIC DEVICE SETTINGS", "۰۳  ·  تنظیمات پایه دستگاه"), subtitle = tx(fa, "Only the supported basic settings are exposed over BLE. Passwords are write-only.", "فقط تنظیمات پایه پشتیبانی‌شده از BLE قابل مدیریت‌اند. رمزها فقط قابل نوشتن هستند.")) {
                NativeField(p, apSsid, { apSsid = it }, tx(fa, "WAPFire Wi-Fi name", "نام Wi-Fi دستگاه"))
                NativeField(p, apPass, { apPass = it }, tx(fa, "New Wi-Fi password (leave blank to keep)", "رمز جدید Wi-Fi (خالی بماند تا تغییر نکند)"), password = true)
                NativeField(p, adminPass, { adminPass = it }, tx(fa, "New administrator password (optional)", "رمز جدید مدیر (اختیاری)"), password = true)
                ToggleRow(p, tx(fa, "Status LED", "چراغ وضعیت"), tx(fa, "Enable the physical status LED.", "چراغ وضعیت دستگاه فعال باشد."), led) { led = it }
                ToggleRow(p, tx(fa, "Sound alerts", "هشدار صوتی"), tx(fa, "Enable supported audible alerts.", "هشدارهای صوتی پشتیبانی‌شده فعال باشد."), sound) { sound = it }
                ToggleRow(p, tx(fa, "Automatic channel tracking", "ردگیری خودکار کانال"), tx(fa, "Track the selected target channel.", "کانال هدف را دنبال کند."), autoChannel) { autoChannel = it }
                ToggleRow(p, tx(fa, "Self-protect mode", "حالت محافظت از خود"), tx(fa, "Enable the configured protection response.", "واکنش حفاظتی تعریف‌شده فعال باشد."), selfProtect) { selfProtect = it }
                ToggleRow(p, tx(fa, "WAPFire access point", "اکسس‌پوینت WAPFire"), tx(fa, "Keep the configuration network enabled.", "شبکه پیکربندی فعال بماند."), softApEnabled) { softApEnabled = it }
                ToggleRow(p, tx(fa, "Bluetooth management", "مدیریت بلوتوث"), tx(fa, "Keep secure BLE advertising enabled after disconnect.", "تبلیغ BLE امن پس از قطع اتصال فعال بماند."), bleManagement) { bleManagement = it }
                ActionButton(
                    p, if (busy) tx(fa, "Saving…", "در حال ذخیره…") else tx(fa, "Apply basic settings", "اعمال تنظیمات پایه"),
                    {
                        busy = true; resultMessage = ""
                        val command = JSONObject().put("cmd", "set_settings").put("ap_ssid", apSsid.trim())
                            .put("led", led).put("sound", sound).put("auto_channel", autoChannel)
                            .put("self_protect", selfProtect).put("softap_enabled", softApEnabled)
                            .put("ble_management", bleManagement)
                        if (apPass.isNotBlank()) command.put("ap_pass", apPass)
                        if (adminPass.isNotBlank()) command.put("adminpass", adminPass)
                        if (!client.send(command)) { busy = false; resultMessage = tx(fa, "BLE is not ready or another command is pending.", "اتصال BLE آماده نیست یا فرمان دیگری در حال اجراست.") }
                    },
                    enabled = !busy && apSsid.isNotBlank() && (apPass.isBlank() || apPass.length in 8..63) && (adminPass.isBlank() || adminPass.length in 8..64),
                    primary = true, modifier = Modifier.fillMaxWidth()
                )
            }
        }
        if (resultMessage.isNotBlank()) Text(resultMessage, color = p.accent, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.fillMaxWidth().background(p.accentSoft, RoundedCornerShape(12.dp)).padding(12.dp))
        SectionCard(p, title = tx(fa, "IMPORTANT RADIO NOTE", "نکته مهم رادیویی"), subtitle = tx(fa, "BLE and Wi-Fi share the ESP32-S3 2.4 GHz radio.", "BLE و Wi-Fi از رادیوی ۲.۴ گیگاهرتز مشترک ESP32-S3 استفاده می‌کنند.")) {
            Text(tx(fa, "During an authenticated BLE management session, WAPFire pauses Promiscuous capture and resumes it after disconnect. BLE is not a guaranteed control path while RF monitoring or attack-related radio activity is running.", "در طول نشست مدیریتی احراز هویت‌شده BLE، دریافت Promiscuous موقتاً متوقف و پس از قطع اتصال دوباره فعال می‌شود. هنگام پایش RF یا فعالیت رادیویی مرتبط با حمله، پایداری BLE تضمین‌شده نیست."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun LoginScreen(
    p: Palette, fa: Boolean, dark: Boolean, host: String, onHost: (String) -> Unit, username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit, rememberPassword: Boolean, onRememberPassword: (Boolean) -> Unit,
    busy: Boolean, error: String, notice: String,
    onBack: () -> Unit, onLogin: () -> Unit, onClear: () -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit
) {
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallAction(p, "‹", onBack); Spacer(Modifier.width(12.dp)); Brand(p); Spacer(Modifier.weight(1f)); SmallAction(p, if (fa) "EN" else "FA", onLanguage); Spacer(Modifier.width(7.dp)); ThemeAction(p, dark, onTheme)
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.size(74.dp).clip(RoundedCornerShape(24.dp)).background(p.accentSoft).border(1.dp, p.border, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                Text("⌑", color = p.accent, fontSize = 40.sp, fontWeight = FontWeight.Light)
            }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(tx(fa, "AUTHENTICATION", "احراز هویت"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(tx(fa, "Welcome back.", "خوش برگشتی."), color = p.text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(tx(fa, "Sign in to your WAPFire device.", "برای ورود به دستگاه WAPFire اطلاعات حساب را وارد کن."), color = p.muted, fontSize = 13.sp)
            }
            SectionCard(p, title = tx(fa, "DEVICE", "دستگاه"), subtitle = host) { NativeField(p, host, onHost, "192.168.4.1", keyboard = KeyboardType.Uri) }
            SectionCard(p, title = tx(fa, "ADMINISTRATOR ACCESS", "دسترسی مدیر"), subtitle = tx(fa, "Your device credentials", "اطلاعات ورود دستگاه")) {
                NativeField(p, username, onUsername, tx(fa, "Username", "نام کاربری"))
                NativeField(p, password, onPassword, tx(fa, "Password", "رمز عبور"), password = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Checkbox(
                        checked = rememberPassword,
                        onCheckedChange = onRememberPassword,
                        colors = CheckboxDefaults.colors(checkedColor = p.accent, uncheckedColor = p.muted)
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(tx(fa, "Remember password", "ذخیره رمز عبور"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(tx(fa, "Encrypted on this phone using Android Keystore.", "رمز روی همین گوشی با Android Keystore رمزنگاری می‌شود."), color = p.muted, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
                ActionButton(p, if (busy) tx(fa, "Authenticating…", "در حال بررسی…") else tx(fa, "Sign in", "ورود امن"), onLogin, enabled = !busy, primary = true, modifier = Modifier.fillMaxWidth())
                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
            }
            Text(tx(fa, "Credentials are sent directly to the device on your local network.", "اطلاعات ورود مستقیماً و فقط در شبکه محلی به دستگاه ارسال می‌شود."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun FirstSetupScreen(
    p: Palette, fa: Boolean, dark: Boolean, onTheme: () -> Unit, onLanguage: () -> Unit,
    step: Int, onStep: (Int) -> Unit,
    apSsid: String, onApSsid: (String) -> Unit, apPass: String, onApPass: (String) -> Unit,
    adminPass: String, onAdminPass: (String) -> Unit,
    led: Boolean, onLed: (Boolean) -> Unit, sound: Boolean, onSound: (Boolean) -> Unit,
    autoChannel: Boolean, onAutoChannel: (Boolean) -> Unit, selfProtect: Boolean, onSelfProtect: (Boolean) -> Unit,
    softAp: Boolean, onSoftAp: (Boolean) -> Unit,
    targetNetworks: List<JSONObject>, target: JSONObject?, targetScanning: Boolean, targetSelecting: Boolean,
    onTargetScan: () -> Unit, onTargetSelect: (JSONObject) -> Unit, onChangeTarget: () -> Unit, onRestore: () -> Unit,
    saving: Boolean, snapshot: Snapshot, error: String, notice: String,
    onFinish: () -> Unit, onClear: () -> Unit, onLogout: () -> Unit
) {
    var validationError by remember(step) { mutableStateOf("") }
    val selectedTargetBssid = target?.optString("bssid").orEmpty().trim()
    val visibleTargetNetworks = if (target == null) targetNetworks else
        targetNetworks.filter { it.optString("bssid").trim().equals(selectedTargetBssid, ignoreCase = true) }
    val stepTitles = listOf(
        tx(fa, "Welcome", "خوش‌آمدگویی"),
        tx(fa, "Access Point", "اکسس‌پوینت"),
        tx(fa, "Target Network", "شبکه هدف"),
        tx(fa, "Advanced Options", "تنظیمات پیشرفته"),
        tx(fa, "Final Review", "بازبینی نهایی")
    )
    fun nextStep() {
        validationError = ""
        when (step) {
            1 -> when {
                apSsid.isBlank() || apSsid.toByteArray(Charsets.UTF_8).size !in 1..32 -> validationError = tx(fa, "Access point SSID must be 1–32 UTF-8 bytes.", "نام شبکه باید بین ۱ تا ۳۲ بایت UTF-8 باشد.")
                apPass.length !in 8..63 -> validationError = tx(fa, "WPA2/WPA3 access point password must be 8–63 characters.", "رمز WPA2/WPA3 باید بین ۸ تا ۶۳ نویسه باشد.")
                apPass.any { it.code !in 0x20..0x7E } -> validationError = tx(fa, "Use printable ASCII characters for the Wi-Fi password so Android can reconnect using WPA2/WPA3.", "برای اینکه اندروید بتواند با WPA2/WPA3 دوباره وصل شود، رمز Wi-Fi را با نویسه‌های ASCII قابل‌چاپ وارد کن.")
                adminPass.length !in 8..64 -> validationError = tx(fa, "Administrator password must be 8–64 characters.", "رمز مدیر باید بین ۸ تا ۶۴ نویسه باشد.")
            }
            2 -> if (target == null || target.optString("ssid").isBlank() || target.optString("bssid").isBlank() || target.optInt("channel") !in 1..13) {
                validationError = tx(fa, "Scan and select a valid target network before continuing.", "برای ادامه یک شبکه هدف معتبر اسکن و انتخاب کن.")
            }
        }
        if (validationError.isBlank()) onStep((step + 1).coerceAtMost(4))
    }

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand(p)
            Spacer(Modifier.weight(1f))
            SmallAction(p, if (fa) "EN" else "FA", onLanguage)
            Spacer(Modifier.width(8.dp))
            ThemeAction(p, dark, onTheme)
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onLogout) { Text(tx(fa, "Disconnect", "قطع اتصال"), color = p.muted) }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(fa, "WAPFIRE CONFIGURATION", "پیکربندی WAPFIRE"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text(tx(fa, "Initial Setup", "راه‌اندازی اولیه"), color = p.text, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("${tx(fa, "STEP", "مرحله")} ${step + 1} / 5  ·  ${stepTitles[step]}", color = p.muted, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(5) { index ->
                Box(Modifier.weight(1f).height(4.dp).clip(CircleShape).background(if (index <= step) p.accent else p.border))
            }
        }
        if (validationError.isNotBlank()) MessageCard(p, validationError, true) { validationError = "" }

        when (step) {
            0 -> {
                SectionCard(p, title = tx(fa, "WELCOME TO WAPFIRE", "به WAPFIRE خوش آمدی"), subtitle = tx(fa, "This native wizard mirrors the five stages of the device WebUI setup.", "این راهنمای Native همان پنج مرحله راه‌اندازی WebUI دستگاه را پوشش می‌دهد.")) {
                    Text(tx(fa, "WAPFire monitors your selected access point, detects wireless security events and protects the network using the options you choose.", "WAPFire اکسس‌پوینت انتخابی تو را پایش می‌کند، رویدادهای امنیتی بی‌سیم را تشخیص می‌دهد و با گزینه‌هایی که انتخاب می‌کنی از شبکه محافظت می‌کند."), color = p.text, fontSize = 12.sp, lineHeight = 19.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(
                            tx(fa, "Access point SSID and WPA2/WPA3 password", "نام و رمز WPA2/WPA3 اکسس‌پوینت"),
                            tx(fa, "Target AP selection by SSID, BSSID and channel", "انتخاب AP هدف با SSID، BSSID و کانال"),
                            tx(fa, "LED, sound, auto-channel and self-protect", "LED، صدا، کانال خودکار و Self-Protect"),
                            tx(fa, "Final review before saving configuration", "بازبینی نهایی پیش از ذخیره تنظیمات")
                        ).forEach { item ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("✓", color = p.green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(item, color = p.muted, fontSize = 11.sp)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "DEVICE STATUS", "وضعیت دستگاه"), color = p.text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${tx(fa, "Firmware", "فریم‌ور")}: ${snapshot.firmware}  ·  Heap: ${snapshot.freeHeap / 1024} KB", color = p.muted, fontSize = 10.sp)
                        }
                    }
                }
                SectionCard(p, title = tx(fa, "RESTORE FROM BACKUP", "بازیابی از پشتیبان"), subtitle = tx(fa, "You can restore a previous WAPFire JSON backup. The device will reboot after a successful restore.", "می‌توانی نسخه پشتیبان JSON قبلی را بازیابی کنی. پس از بازیابی موفق، دستگاه راه‌اندازی مجدد می‌شود.")) {
                    ActionButton(p, tx(fa, "Choose backup file", "انتخاب فایل پشتیبان"), onRestore, primary = true, modifier = Modifier.fillMaxWidth())
                    Text(tx(fa, "Backup files contain administrator, Wi-Fi and integration credentials. Keep them private.", "فایل پشتیبان شامل رمز مدیر، Wi-Fi و اطلاعات اتصال سرویس‌هاست؛ آن را محرمانه نگه دار."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            1 -> {
                SectionCard(p, title = tx(fa, "ACCESS POINT CONFIGURATION", "تنظیمات اکسس‌پوینت"), subtitle = tx(fa, "These credentials are used when your phone reconnects to WAPFire.", "این مشخصات برای اتصال دوباره گوشی به WAPFire استفاده می‌شوند.")) {
                    NativeField(p, apSsid, onApSsid, tx(fa, "Network name (SSID)", "نام شبکه (SSID)"))
                    NativeField(p, apPass, onApPass, tx(fa, "Wi-Fi password (8–63 characters)", "رمز Wi-Fi (۸ تا ۶۳ نویسه)"), password = true)
                    Text(tx(fa, "Security mode: WPA2/WPA3 Transition · PMF capable, not required", "حالت امنیتی: WPA2/WPA3 Transition · PMF فعال و غیرالزامی"), color = p.green, fontSize = 10.sp)
                }
                SectionCard(p, title = tx(fa, "ADMINISTRATOR ACCOUNT", "حساب مدیر"), subtitle = tx(fa, "Set the administrator password required for WebUI and Mobile sign-in.", "رمز مدیر موردنیاز برای ورود به WebUI و اپ موبایل را تعیین کن.")) {
                    NativeField(p, adminPass, onAdminPass, tx(fa, "Administrator password (8–64 characters)", "رمز مدیر (۸ تا ۶۴ نویسه)"), password = true)
                    Text(tx(fa, "The firmware accepts the new password only when the first setup is applied successfully.", "فریم‌ور رمز جدید را هنگام اعمال موفق راه‌اندازی اولیه ذخیره می‌کند."), color = p.muted, fontSize = 10.sp)
                }
            }
            2 -> {
                SectionCard(p, title = tx(fa, "SELECT TARGET NETWORK", "انتخاب شبکه هدف"), subtitle = tx(fa, "Choose the AP WAPFire should monitor. The device verifies the exact BSSID before accepting it.", "اکسس‌پوینتی را انتخاب کن که WAPFire باید پایش کند. دستگاه پیش از پذیرش، BSSID دقیق را بررسی می‌کند.")) {
                    ActionButton(p, if (targetScanning) tx(fa, "Scanning radio…", "در حال اسکن رادیویی…") else tx(fa, "Scan networks", "اسکن شبکه‌ها"), onTargetScan, enabled = !targetScanning && !targetSelecting, primary = true, modifier = Modifier.fillMaxWidth())
                    if (targetScanning || targetSelecting) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(17.dp), color = p.accent, strokeWidth = 2.dp)
                        Text(if (targetSelecting) tx(fa, "Verifying selected BSSID…", "در حال تأیید BSSID انتخابی…") else tx(fa, "Scanning with WAPFire radio…", "در حال اسکن با رادیوی WAPFire…"), color = p.muted, fontSize = 10.sp)
                    }
                    if (visibleTargetNetworks.isEmpty() && target == null && !targetScanning) Text(tx(fa, "No scan results yet. Tap Scan networks to use the WAPFire radio scan.", "هنوز نتیجه‌ای از اسکن وجود ندارد. برای اسکن رادیویی WAPFire روی اسکن شبکه‌ها بزن."), color = p.muted, fontSize = 11.sp, lineHeight = 16.sp)
                    visibleTargetNetworks.sortedByDescending { it.optInt("rssi") }.forEach { net ->
                        val ssid = net.optString("ssid").ifBlank { "[Hidden]" }
                        val bssid = net.optString("bssid")
                        val channel = net.optInt("channel")
                        val isSelected = target?.optString("bssid", "")?.equals(bssid, true) == true
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) p.accentSoft.copy(alpha = .75f) else p.panelAlt.copy(alpha = .72f))
                                .border(1.dp, if (isSelected) p.accent else p.border, RoundedCornerShape(14.dp))
                                .clickable(enabled = !targetSelecting && ssid != "[Hidden]" && bssid.isNotBlank() && channel in 1..13) { onTargetSelect(net) }
                                .padding(11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(ssid, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("$bssid  ·  Ch $channel  ·  ${net.optInt("rssi")} dBm", color = p.muted, fontSize = 9.sp)
                            }
                            Text(if (isSelected) tx(fa, "SELECTED", "انتخاب‌شده") else tx(fa, "SELECT", "انتخاب"), color = if (isSelected) p.green else p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (target != null) {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.green.copy(alpha = .08f)).border(1.dp, p.green.copy(alpha = .40f), RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(tx(fa, "VERIFIED TARGET", "شبکه هدف تأییدشده"), color = p.green, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(target.optString("ssid"), color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${target.optString("bssid")}  ·  Ch ${target.optInt("channel")}", color = p.muted, fontSize = 10.sp)
                        }
                        ActionButton(p, tx(fa, "Choose another AP", "انتخاب AP دیگر"), onChangeTarget, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            3 -> {
                SectionCard(p, title = tx(fa, "ADVANCED OPTIONS", "تنظیمات پیشرفته"), subtitle = tx(fa, "These switches map directly to the firmware's initial setup settings.", "این کلیدها مستقیماً به تنظیمات راه‌اندازی اولیه فریم‌ور متصل‌اند.")) {
                    SetupSwitchRow(p, fa, tx(fa, "Status LED", "LED وضعیت"), tx(fa, "Visual system and alert indication.", "نمایش وضعیت و هشدارهای سیستم."), led, onLed)
                    SetupSwitchRow(p, fa, tx(fa, "Sound Alerts", "هشدار صوتی"), tx(fa, "Play device sounds for important events.", "پخش صدای دستگاه برای رویدادهای مهم."), sound, onSound)
                    SetupSwitchRow(p, fa, tx(fa, "Auto Channel Tracking", "ردیابی خودکار کانال"), tx(fa, "Follow the target AP channel automatically.", "کانال AP هدف را به‌صورت خودکار دنبال کن."), autoChannel, onAutoChannel)
                    SetupSwitchRow(p, fa, tx(fa, "Self-Protect Mode", "حالت محافظت خودکار"), tx(fa, "Enable the firmware's self-protection response when configured detection conditions are met.", "پاسخ محافظت خودکار فریم‌ور را هنگام تحقق شرایط تشخیص فعال کن."), selfProtect, onSelfProtect)
                    SetupSwitchRow(p, fa, tx(fa, "Enable SoftAP", "فعال‌سازی SoftAP"), tx(fa, "Keep the WAPFire Wi-Fi access point available for mobile/WebUI access. Disable only when Ethernet access is ready.", "اکسس‌پوینت Wi-Fi دستگاه برای دسترسی موبایل و WebUI فعال می‌ماند. فقط با آماده بودن Ethernet خاموشش کن."), softAp, onSoftAp)
                    if (!softAp) Text(tx(fa, "Warning: disabling SoftAP removes Wi-Fi access to WAPFire. Continue only when Ethernet access has already been configured and tested.", "هشدار: با غیرفعال‌کردن SoftAP دسترسی Wi-Fi به WAPFire قطع می‌شود. فقط وقتی ادامه بده که Ethernet را قبلاً تنظیم و آزمایش کرده باشی."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            4 -> {
                SectionCard(p, title = tx(fa, "FINAL REVIEW", "بازبینی نهایی"), subtitle = tx(fa, "Review the values before committing them to WAPFire.", "پیش از ذخیره روی WAPFire مقادیر را بررسی کن.")) {
                    SetupReviewRow(p, fa, "AP SSID", "نام شبکه", apSsid)
                    SetupReviewRow(p, fa, "AP Security", "امنیت شبکه", "WPA2/WPA3 Transition")
                    SetupReviewRow(p, fa, "Administrator", "مدیر", tx(fa, "Password will be updated", "رمز مدیر تغییر می‌کند"))
                    SetupReviewRow(p, fa, "Target AP", "AP هدف", target?.optString("ssid", "—") ?: "—")
                    SetupReviewRow(p, fa, "Target BSSID", "BSSID هدف", target?.optString("bssid", "—") ?: "—")
                    SetupReviewRow(p, fa, "Target Channel", "کانال هدف", target?.optInt("channel", 0)?.toString() ?: "—")
                    SetupReviewRow(p, fa, "Status LED", "LED وضعیت", if (led) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Sound Alerts", "هشدار صوتی", if (sound) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Auto Channel", "کانال خودکار", if (autoChannel) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "Self-Protect", "محافظت خودکار", if (selfProtect) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                    SetupReviewRow(p, fa, "SoftAP", "شبکه دسترسی", if (softAp) tx(fa, "Enabled", "فعال") else tx(fa, "Disabled", "غیرفعال"))
                }
                Text(tx(fa, "Applying this configuration restarts the Wi-Fi service when the AP credentials or target settings change. Rejoin WAPFire using the new SSID/password after the restart.", "با اعمال تنظیمات، در صورت تغییر مشخصات AP یا شبکه هدف، سرویس Wi-Fi راه‌اندازی مجدد می‌شود. پس از آن با SSID و رمز جدید دوباره به WAPFire وصل شو."), color = p.orange, fontSize = 10.sp, lineHeight = 16.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) ActionButton(p, tx(fa, "Back", "قبلی"), { validationError = ""; onStep(step - 1) }, enabled = !saving, modifier = Modifier.weight(1f))
            if (step < 4) ActionButton(p, tx(fa, "Next", "بعدی"), { nextStep() }, enabled = !saving && !targetSelecting, primary = true, modifier = Modifier.weight(1f))
            else ActionButton(p, if (saving) tx(fa, "Applying…", "در حال اعمال…") else tx(fa, "Apply Configuration", "اعمال تنظیمات"), onFinish, enabled = !saving, primary = true, modifier = Modifier.weight(1f))
        }
        if (saving) CircularProgressIndicator(modifier = Modifier.size(22.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SetupSwitchRow(p: Palette, fa: Boolean, title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panelAlt.copy(alpha = .55f)).border(1.dp, p.border.copy(alpha = .75f), RoundedCornerShape(14.dp)).padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun SetupReviewRow(p: Palette, fa: Boolean, label: String, labelFa: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text(if (fa) labelFa else label, color = p.muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.25f))
    }
}

@Composable
private fun ControlCenter(
    p: Palette, fa: Boolean, dark: Boolean, tab: Tab, snapshot: Snapshot, deviceOnline: Boolean, logs: List<JSONObject>, clients: List<JSONObject>, error: String, notice: String,
    onTab: (Tab) -> Unit, onTheme: () -> Unit, onLanguage: () -> Unit, onRefresh: () -> Unit,
    onToggle: (String, Boolean) -> Unit, targetNetworks: List<JSONObject>, targetScanBusy: Boolean, targetSelecting: Boolean,
    onTargetScan: () -> Unit, onSelectTarget: (JSONObject) -> Unit, onClearTarget: () -> Unit,
    onClearLogs: () -> Unit, onLogout: () -> Unit, onClearMessage: () -> Unit,
    advanced: AdvancedSettingsBundle, onAdvancedSave: (String, JSONObject) -> Unit,
    onAdvancedAction: (String) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onFirmwarePick: () -> Unit,
    onBluetoothManage: () -> Unit
) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Column(Modifier.fillMaxWidth().background(p.bg.copy(alpha = .66f)).windowInsetsPadding(WindowInsets.statusBars)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Brand(p)
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.clip(CircleShape).background(if (deviceOnline) p.accentSoft else p.panelAlt).padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(if (deviceOnline) p.green else p.orange))
                            Text(
                                if (deviceOnline) tx(fa, "LIVE", "زنده") else tx(fa, "OFFLINE", "قطع ارتباط"),
                                color = if (deviceOnline) p.text else p.orange,
                                fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp)); SmallAction(p, "↻", onRefresh)
                    Spacer(Modifier.width(6.dp)); ThemeAction(p, dark, onTheme)
                }
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().background(p.panel.copy(alpha = .76f)).border(1.dp, p.border.copy(alpha = .65f)).windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = 4.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Tab.values().forEach { item ->
                    val selected = tab == item
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (selected) p.accent.copy(alpha = .10f) else Color.Transparent).clickable { onTab(item) }.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(item.glyph, color = if (selected) p.accent else p.muted, fontSize = 19.sp)
                        Text(if (fa) item.fa else item.label, color = if (selected) p.accent else p.muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    ) { padding ->
        when (tab) {
            Tab.OVERVIEW -> OverviewPage(p, fa, snapshot, Modifier.padding(padding))
            Tab.CLIENTS -> ClientsPage(p, fa, clients, Modifier.padding(padding))
            Tab.EVENTS -> EventsPage(p, fa, logs, onClearLogs, Modifier.padding(padding))
            Tab.SETTINGS -> SettingsPage(p, fa, snapshot, onToggle, onLogout, Modifier.padding(padding), onLanguage, dark, onTheme,
                targetNetworks, targetScanBusy, targetSelecting, onTargetScan, onSelectTarget, onClearTarget,
                advanced, clients, onAdvancedSave, onAdvancedAction, onBackup, onRestore, onFirmwarePick, onBluetoothManage)
        }
    }
}

@Composable
private fun OverviewPage(p: Palette, fa: Boolean, s: Snapshot, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 14.dp, bottom = 18.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(tx(fa, "SYSTEM OVERVIEW", "نمای کلی سیستم"), color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text(tx(fa, "Wireless intelligence", "هوشمندی شبکه بی‌سیم"), color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("${tx(fa, "Firmware", "فریمور")}: ${s.firmware}   ·   ${tx(fa, "Uptime", "مدت فعالیت")}: ${formatUptime(s.uptime)}", color = p.muted, fontSize = 10.sp)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xCC1C5962), Color(0xB815303C), Color(0xA81A3C4B)))).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(24.dp)).padding(18.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "MONITORING STATUS", "وضعیت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                            val engineStatus = when {
                                !s.configured -> tx(fa, "Setup required", "نیازمند راه‌اندازی")
                                s.selfProtectActive -> tx(fa, "Protection response active", "واکنش حفاظتی فعال است")
                                s.prom.equals("ACTIVE", ignoreCase = true) && s.selfProtect -> tx(fa, "Self-protect armed", "محافظت خودکار آماده است")
                                s.prom.equals("ACTIVE", ignoreCase = true) -> tx(fa, "Monitoring active · protection off", "پایش فعال · محافظت خودکار خاموش")
                                else -> tx(fa, "Radio monitoring inactive", "پایش رادیویی غیرفعال است")
                            }
                            Text(engineStatus, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                        }
                        ThreatRing(p, s.threatScore, s.threatLevel)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2C535D)))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(fa, "MONITORED ACCESS POINT", "اکسس‌پوینت تحت پایش"), color = Color(0xFF83C6C6), fontSize = 9.sp, letterSpacing = 1.sp)
                            Text(s.target.ifBlank { tx(fa, "No target selected", "هدف انتخاب نشده") }, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (s.targetMac.isNotBlank()) s.targetMac else "${tx(fa, "Channel", "کانال")}: ${if (s.channel > 0) s.channel else "—"}", color = Color(0xFFA4C2C8), fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(if (s.targetAvailable) tx(fa, "ONLINE", "متصل") else tx(fa, "OFFLINE", "قطع"), color = if (s.targetAvailable) Color(0xFF71E4AE) else Color(0xFFFFB86C), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(if (s.targetRssi != 0) "${s.targetRssi} dBm" else "— dBm", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Text(tx(fa, "NETWORK TELEMETRY", "آمار شبکه"), color = p.muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${s.traffic.compact()}", tx(fa, "Traffic frames", "فریم شبکه"), "⌁", p.accent, Modifier.weight(1f))
                MetricTile(p, "${s.packets.compact()}", tx(fa, "Packets", "بسته‌ها"), "▤", p.blue, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile(p, "${s.targetApRx.compact()}", tx(fa, "Target AP RX", "دریافت AP هدف"), "⇣", p.orange, Modifier.weight(1f))
                MetricTile(p, "${s.filtered.compact()}", tx(fa, "Filtered frames", "فریم فیلترشده"), "≋", p.green, Modifier.weight(1f))
            }
        }
        item {
            SectionCard(p, title = tx(fa, "RADIO ACTIVITY", "فعالیت رادیویی"), subtitle = tx(fa, "Recent receive-rate samples", "نمونه‌های اخیر نرخ دریافت")) {
                NativeLineChart(p, s.radioRates, s.targetRates, Modifier.fillMaxWidth().height(150.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    LegendDot(p.accent, tx(fa, "Radio RX", "دریافت رادیو"), p)
                    LegendDot(p.blue, tx(fa, "Target AP", "اکسس‌پوینت هدف"), p)
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    MiniValue(p, "${s.wifiChannel}", tx(fa, "Wi-Fi channel", "کانال Wi-Fi"))
                    MiniValue(p, s.prom, tx(fa, "Promiscuous", "حالت شنود"))
                    MiniValue(p, "${s.dropped}", tx(fa, "Dropped", "از دست‌رفته"))
                }
            }
        }
        item {
            SectionCard(p, title = tx(fa, "DETECTION BREAKDOWN", "دسته‌بندی تشخیص‌ها"), subtitle = tx(fa, "Labels reported by the firmware", "برچسب‌های گزارش‌شده توسط فریمور")) {
                Text(tx(fa, "All eight firmware detection classes are shown. Counts are cumulative since the device counters were initialized.", "هر هشت دسته تشخیص فریم‌ور نمایش داده شده‌اند. شمارنده‌ها از زمان مقداردهی اولیه دستگاه محاسبه می‌شوند."), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
                s.labels.forEach { (name, count) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(name, color = p.text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(count.toString(), color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            SectionCard(p, title = tx(fa, "LAST DETECTION", "آخرین تشخیص"), subtitle = if (s.lastEvent.isBlank()) tx(fa, "No recent event", "رویداد تازه‌ای نیست") else s.lastEvent) {
                Text(if (s.lastAttack.isBlank()) tx(fa, "The device has not reported an active attack label.", "دستگاه برچسب حمله فعالی گزارش نکرده است.") else s.lastAttack, color = p.text, fontSize = 13.sp)
                Text("${tx(fa, "Filtered", "فیلترشده")}: ${s.filtered}   ·   ${tx(fa, "Dropped", "از دست‌رفته")}: ${s.dropped}", color = p.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ClientsPage(p: Palette, fa: Boolean, clients: List<JSONObject>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 20.dp)) {
        item {
            Text(tx(fa, "CLIENT INTELLIGENCE", "اطلاعات کلاینت‌ها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Tracked stations", "ایستگاه‌های ردگیری‌شده"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${clients.size} ${tx(fa, "observations", "مشاهده")}", color = p.muted, fontSize = 12.sp)
        }
        if (clients.isEmpty()) item { SectionCard(p, title = tx(fa, "NO CLIENT DATA", "داده‌ای وجود ندارد"), subtitle = tx(fa, "Clients appear as they are observed by the radio.", "کلاینت‌ها پس از مشاهده توسط رادیو نمایش داده می‌شوند.")) { Text(tx(fa, "Keep monitoring active and refresh this page.", "پایش را فعال نگه دار و صفحه را تازه‌سازی کن."), color = p.muted, fontSize = 12.sp) } }
        items(clients) { client ->
            SectionCard(p, title = client.optString("mac", "Unknown station"), subtitle = client.optString("state", "UNKNOWN")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${client.optInt("rssi")} dBm  ·  ${client.optInt("age_sec")}s ${tx(fa, "ago", "قبل")}", color = p.muted, fontSize = 11.sp)
                        Text(client.optString("bssid").ifBlank { tx(fa, "BSSID unavailable", "BSSID موجود نیست") }, color = p.muted, fontSize = 10.sp)
                    }
                    Text(if (client.optString("state").contains("DISCONNECT")) "!" else "•", color = if (client.optString("state").contains("DISCONNECT")) p.orange else p.green, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                if (client.optInt("reason_code") != 0) Text("${tx(fa, "Reason", "دلیل")}: ${client.optInt("reason_code")} · ${client.optString("reason_text")}", color = p.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun EventsPage(p: Palette, fa: Boolean, logs: List<JSONObject>, onClear: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tx(fa, "EVENT TIMELINE", "خط زمانی رویدادها"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Device activity", "فعالیت دستگاه"), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${logs.size} ${tx(fa, "records", "رکورد")}", color = p.muted, fontSize = 12.sp)
                }
                ActionButton(p, tx(fa, "Clear", "پاک‌کردن"), onClear)
            }
        }
        if (logs.isEmpty()) item {
            val emptyShape = RoundedCornerShape(18.dp)
            Column(Modifier.fillMaxWidth().shadow(7.dp, emptyShape).clip(emptyShape)
                .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
                .border(1.dp, p.border, emptyShape).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(tx(fa, "NO EVENTS", "رویدادی وجود ندارد"), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(tx(fa, "The device event log is currently empty.", "گزارش رویداد دستگاه خالی است."), color = p.muted, fontSize = 10.sp)
                Text(tx(fa, "New detections and system messages will appear here.", "تشخیص‌های جدید و پیام‌های سیستم اینجا نمایش داده می‌شوند."), color = p.text, fontSize = 12.sp)
            }
        }
        items(logs) { event ->
            val type = event.optString("event_type", "system").lowercase()
            val title = eventDisplayName(event)
            val isThreat = type == "attack" || friendlyThreatName(type) != null ||
                friendlyThreatName(event.optString("message")) != null || friendlyThreatName(event.optString("details")) != null
            val isCredential = type == "wrong_password" || type == "correct_password"
            val badge = when {
                isCredential -> "CREDENTIAL"
                isThreat -> "THREAT"
                type == "attempt" -> "ATTEMPT"
                type == "disconnect" -> "DISCONNECT"
                type == "system" -> "SYSTEM"
                else -> "DEVICE"
            }
            val color = when {
                type == "wrong_password" -> p.orange
                type == "correct_password" -> p.green
                type == "disconnect" -> p.blue
                type == "attempt" -> p.orange
                isThreat -> p.red
                else -> p.accent
            }
            Row(Modifier.fillMaxWidth().shadow(9.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
                .border(1.dp, p.border, RoundedCornerShape(18.dp))
                .padding(14.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Box(Modifier.width(3.dp).height(52.dp).clip(CircleShape).background(color))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(badge, color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(event.optString("formatted_time", ""), color = p.muted, fontSize = 10.sp)
                    val message = event.optString("message", "")
                    val details = event.optString("details", "")
                    if (details.isNotBlank()) Text(friendlyTechnicalText(details), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                    else if (message.isNotBlank() && friendlyThreatName(message) == null && type !in listOf("correct_password", "wrong_password")) Text(message, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(
    p: Palette, fa: Boolean, s: Snapshot, onToggle: (String, Boolean) -> Unit, onLogout: () -> Unit,
    modifier: Modifier = Modifier, onLanguage: () -> Unit, dark: Boolean, onTheme: () -> Unit,
    targetNetworks: List<JSONObject>, targetScanBusy: Boolean, targetSelecting: Boolean, onTargetScan: () -> Unit,
    onSelectTarget: (JSONObject) -> Unit, onClearTarget: () -> Unit,
    advanced: AdvancedSettingsBundle, trackedClients: List<JSONObject>, onAdvancedSave: (String, JSONObject) -> Unit,
    onAdvancedAction: (String) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onFirmwarePick: () -> Unit,
    onBluetoothManage: () -> Unit
) {
    val hasSelectedTarget = s.target.isNotBlank() || s.targetMac.isNotBlank()
    // targetNetworks is the explicit scan-result list. When a target is selected the
    // selection handler stores exactly one verified AP here; a new scan replaces it
    // with the full result set, so a previous target never blocks re-selection.
    val visibleTargetNetworks = targetNetworks
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(fa, "DEVICE CONFIGURATION", "پیکربندی دستگاه"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Settings & controls", "تنظیمات و کنترل‌ها"), color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(tx(fa, "Everything in one place, organized by function.", "همه قابلیت‌ها در یک بخش، مرتب‌شده بر اساس کاربرد."), color = p.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        SectionCard(p, title = tx(fa, "01  ·  MONITORING & TARGET", "۰۱  ·  پایش و شبکه هدف"), subtitle = tx(fa, "Choose the exact access point WAPFire should monitor.", "اکسس‌پوینتی را که WAPFire باید پایش کند، دقیق انتخاب کن.")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(s.target.ifBlank { tx(fa, "No target selected", "شبکه هدف انتخاب نشده") }, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (s.targetMac.isNotBlank()) s.targetMac else tx(fa, "Select a network to begin monitoring", "برای شروع پایش یک شبکه انتخاب کن"), color = p.muted, fontSize = 10.sp)
                    Text("CH ${if (s.channel > 0) s.channel else "—"}   ·   ${if (s.targetRssi != 0) "${s.targetRssi} dBm" else "— dBm"}", color = p.muted, fontSize = 10.sp)
                }
                Box(Modifier.clip(CircleShape).background(if (s.targetAvailable) p.green.copy(alpha = .14f) else p.orange.copy(alpha = .13f)).padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text(if (s.targetAvailable) tx(fa, "ONLINE", "فعال") else tx(fa, "OFFLINE", "غیرفعال"), color = if (s.targetAvailable) p.green else p.orange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                ActionButton(p, when {
                    targetSelecting -> tx(fa, "Selecting…", "در حال انتخاب…")
                    targetScanBusy -> tx(fa, "Scanning…", "در حال اسکن…")
                    else -> tx(fa, "Scan networks", "اسکن شبکه‌ها")
                }, onTargetScan, enabled = !targetScanBusy && !targetSelecting, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Clear target", "پاک‌کردن هدف"), onClearTarget, enabled = !targetSelecting && (s.target.isNotBlank() || s.targetMac.isNotBlank()), modifier = Modifier.weight(1f))
            }
            if (targetScanBusy || targetSelecting) CircularProgressIndicator(modifier = Modifier.size(20.dp).align(Alignment.CenterHorizontally), color = p.accent, strokeWidth = 2.dp)
            if (visibleTargetNetworks.isEmpty() && !targetScanBusy && !targetSelecting) Text(
                if (hasSelectedTarget) tx(
                    fa,
                    "You can scan and choose a different access point without clearing the current target.",
                    "برای انتخاب اکسس‌پوینت دیگر نیازی به پاک‌کردن هدف فعلی نیست؛ اسکن کن و شبکه جدید را انتخاب کن."
                ) else tx(
                    fa,
                    "Scan to show nearby access points. Selection is verified by SSID, BSSID and channel.",
                    "برای نمایش اکسس‌پوینت‌های اطراف اسکن کن. انتخاب با SSID، BSSID و کانال بررسی می‌شود."
                ),
                color = p.muted, fontSize = 11.sp, lineHeight = 17.sp
            )
            visibleTargetNetworks.forEach { net ->
                val ssid = net.optString("ssid")
                val bssid = net.optString("bssid")
                val valid = ssid.isNotBlank() && isValidBssid(bssid) && net.optInt("channel") in 1..13
                DeviceResult(p, ssid.ifBlank { tx(fa, "Hidden network", "شبکه مخفی") },
                    "$bssid  ·  CH ${net.optInt("channel")}  ·  ${net.optInt("rssi")} dBm",
                    if (!valid) "HIDDEN" else if (net.optBoolean("secured")) "SECURED" else "OPEN",
                    { if (valid && !targetSelecting && !targetScanBusy) onSelectTarget(net) },
                    if (targetSelecting) tx(fa, "Selecting…", "در حال انتخاب…") else if (targetScanBusy) tx(fa, "Scanning…", "در حال اسکن…") else if (valid) tx(fa, "Select", "انتخاب") else "",
                    enabled = valid && !targetSelecting && !targetScanBusy)
            }
        }
        SectionCard(p, title = tx(fa, "02  ·  PROTECTION", "۰۲  ·  محافظت"), subtitle = tx(fa, "Detection response and channel behavior.", "واکنش به تشخیص‌ها و رفتار کانال.")) {
            ToggleRow(p, tx(fa, "Self-protect mode", "حالت محافظت از خود"), tx(fa, "Apply the configured protection response when threats are detected.", "هنگام تشخیص تهدید، واکنش حفاظتی تعریف‌شده را اجرا می‌کند."), s.selfProtect) { onToggle("self_protect", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Automatic channel tracking", "ردگیری خودکار کانال"), tx(fa, "Follow channel changes of the selected target AP.", "تغییر کانال اکسس‌پوینت هدف را دنبال می‌کند."), s.autoChannel) { onToggle("auto_channel", it) }
        }
        SectionCard(p, title = tx(fa, "03  ·  DEVICE FEEDBACK", "۰۳  ·  بازخورد دستگاه"), subtitle = tx(fa, "Physical LED and audible alerts.", "هشدارهای نوری و صوتی دستگاه.")) {
            ToggleRow(p, tx(fa, "Status LED", "چراغ وضعیت"), tx(fa, "Enable the device status indicator.", "نشانگر وضعیت دستگاه را فعال می‌کند."), s.led) { onToggle("led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Smart LED mode", "حالت هوشمند LED"), tx(fa, "Adjust the LED behavior based on target availability.", "رفتار LED را با وضعیت در دسترس بودن هدف تنظیم می‌کند."), s.smartLed) { onToggle("smart_led", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Sound alerts", "هشدار صوتی"), tx(fa, "Play sound for supported security events.", "برای رویدادهای امنیتی پشتیبانی‌شده صدا پخش می‌کند."), s.sound) { onToggle("sound", it) }
        }
        SectionCard(p, title = tx(fa, "04  ·  CONNECTIVITY", "۰۴  ·  ارتباطات"), subtitle = tx(fa, "Access and management connectivity.", "اتصال برای دسترسی و مدیریت دستگاه.")) {
            ToggleRow(p, tx(fa, "WAPFire access point", "اکسس‌پوینت WAPFire"), tx(fa, "Keep the configuration Wi-Fi network available.", "شبکه Wi-Fi پیکربندی دستگاه را در دسترس نگه می‌دارد."), s.softAp) { onToggle("softap_enabled", it) }
            DividerLine(p)
            ToggleRow(p, tx(fa, "Bluetooth management", "مدیریت بلوتوث"), tx(fa, "Allow passkey-protected BLE provisioning and basic settings. RF promiscuous capture pauses while a paired BLE management session is active.", "راه‌اندازی و مدیریت پایه از طریق BLE با رمز Pairing. هنگام اتصال مدیریتی BLE، دریافت Promiscuous موقتاً متوقف می‌شود."), s.bleManagement) { onToggle("ble_management", it) }
            DividerLine(p)
            ActionButton(p, tx(fa, "Open Bluetooth setup & settings", "باز کردن راه‌اندازی و تنظیمات بلوتوث"), onBluetoothManage, primary = false, modifier = Modifier.fillMaxWidth())
            DividerLine(p)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Ethernet", color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (s.ethernet) s.ethernetIp else tx(fa, "No active link", "اتصال فعالی وجود ندارد"), color = p.muted, fontSize = 10.sp)
                }
                Text(if (s.ethernet) "ONLINE" else "OFFLINE", color = if (s.ethernet) p.green else p.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        SectionCard(p, title = tx(fa, "05  ·  DEVICE STATUS", "۰۵  ·  وضعیت دستگاه"), subtitle = "WAPFire ${s.firmware}") {
            InfoLine(p, tx(fa, "Radio mode", "حالت رادیو"), s.prom)
            InfoLine(p, tx(fa, "LED alert state", "وضعیت هشدار LED"), ledModeLabel(s.ledMode, fa))
            InfoLine(p, tx(fa, "Wi-Fi channel", "کانال Wi-Fi"), s.wifiChannel.toString())
            InfoLine(p, tx(fa, "Free memory", "حافظه آزاد"), "${s.freeHeap / 1024} KB")
            InfoLine(p, tx(fa, "Uptime", "مدت فعالیت"), formatUptime(s.uptime))
            InfoLine(p, tx(fa, "Dropped / filtered", "ازدست‌رفته / فیلترشده"), "${s.dropped} / ${s.filtered}")
        }
        SectionCard(p, title = tx(fa, "06  ·  APP EXPERIENCE", "۰۶  ·  تجربه برنامه"), subtitle = tx(fa, "Personal preferences for this phone.", "ترجیحات ظاهری برنامه در این گوشی.")) {
            ToggleRow(p, tx(fa, "Persian interface", "رابط فارسی"), tx(fa, "Switch the native app language.", "زبان رابط برنامه را تغییر می‌دهد."), fa) { onLanguage() }
            DividerLine(p)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(tx(fa, "Appearance", "پوسته ظاهری"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(tx(fa, "Choose dark or light glass mode.", "حالت شیشه‌ای تیره یا روشن را انتخاب کن."), color = p.muted, fontSize = 10.sp)
                }
                ThemeAction(p, dark, onTheme)
            }
        }
        AdvancedSettingsPanel(
            p = p, fa = fa, data = advanced, trackedClients = trackedClients,
            onSave = onAdvancedSave, onAction = onAdvancedAction,
            onBackup = onBackup, onRestore = onRestore, onFirmwarePick = onFirmwarePick
        )
        SectionCard(p, title = tx(fa, "SESSION", "نشست کاربری"), subtitle = tx(fa, "Safely end the authenticated device session.", "نشست احراز هویت‌شده دستگاه را به‌صورت امن خاتمه بده.")) {
            ActionButton(p, tx(fa, "Log out", "خروج از حساب"), onLogout, primary = false, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ExpandableSettingsCard(
    p: Palette, title: String, subtitle: String = "", initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember(title) { mutableStateOf(initiallyExpanded) }
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().shadow(12.dp, shape, ambientColor = Color.Black.copy(alpha = .10f), spotColor = p.accent.copy(alpha = .08f))
            .clip(shape)
            .background(Brush.linearGradient(listOf(p.panel.copy(alpha = .78f), p.panelAlt.copy(alpha = .66f), p.panel.copy(alpha = .72f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), p.border.copy(alpha = .75f), Color.White.copy(alpha = .06f))), shape)
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { expanded = !expanded }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text(if (expanded) "−" else "+", color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        if (expanded) {
            content.invoke(this)
        }
    }
}

@Composable
private fun AdvancedSettingsPanel(
    p: Palette,
    fa: Boolean,
    data: AdvancedSettingsBundle,
    trackedClients: List<JSONObject>,
    onSave: (String, JSONObject) -> Unit,
    onAction: (String) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onFirmwarePick: () -> Unit
) {
    var showBackupWarning by remember { mutableStateOf(false) }
    var showRestoreWarning by remember { mutableStateOf(false) }
    var pendingMaintenance by remember { mutableStateOf<String?>(null) }

    if (showBackupWarning) AlertDialog(
        onDismissRequest = { showBackupWarning = false },
        title = { Text(tx(fa, "Export sensitive backup?", "خروجی پشتیبان حساس؟")) },
        text = { Text(tx(fa, "The backup contains administrator and Wi-Fi credentials, MikroTik credentials, target identity and device settings. Store it securely.", "این فایل شامل رمز مدیر، رمز Wi‑Fi، اطلاعات MikroTik، مشخصات شبکه هدف و تنظیمات دستگاه است. آن را در محل امن نگه دار.")) },
        confirmButton = { TextButton(onClick = { showBackupWarning = false; onBackup() }) { Text(tx(fa, "Export backup", "خروجی گرفتن")) } },
        dismissButton = { TextButton(onClick = { showBackupWarning = false }) { Text(tx(fa, "Cancel", "لغو")) } }
    )
    if (showRestoreWarning) AlertDialog(
        onDismissRequest = { showRestoreWarning = false },
        title = { Text(tx(fa, "Restore WAPFire backup?", "بازیابی پشتیبان WAPFire؟")) },
        text = { Text(tx(fa, "This replaces saved device configuration and reboots WAPFire. You may need to reconnect using the restored access-point credentials.", "این کار تنظیمات ذخیره‌شده دستگاه را جایگزین می‌کند و WAPFire را راه‌اندازی مجدد می‌کند. ممکن است لازم باشد با مشخصات Wi‑Fi بازیابی‌شده دوباره متصل شوی.")) },
        confirmButton = { TextButton(onClick = { showRestoreWarning = false; onRestore() }) { Text(tx(fa, "Choose backup", "انتخاب فایل")) } },
        dismissButton = { TextButton(onClick = { showRestoreWarning = false }) { Text(tx(fa, "Cancel", "لغو")) } }
    )
    pendingMaintenance?.let { action ->
        val title = when (action) {
            "reboot" -> tx(fa, "Reboot WAPFire?", "راه‌اندازی مجدد WAPFire؟")
            "wifi_restart" -> tx(fa, "Restart Wi-Fi?", "راه‌اندازی مجدد Wi‑Fi؟")
            "force_setup" -> tx(fa, "Return to initial setup?", "بازگشت به راه‌اندازی اولیه؟")
            else -> tx(fa, "Factory reset?", "بازنشانی کارخانه‌ای؟")
        }
        val body = when (action) {
            "reboot" -> tx(fa, "The device will restart. The mobile app will reconnect after it is online.", "دستگاه راه‌اندازی مجدد می‌شود. برنامه پس از آنلاین‌شدن دوباره متصل خواهد شد.")
            "wifi_restart" -> tx(fa, "The WAPFire access point and radio services will restart; your phone may disconnect briefly.", "اکسس‌پوینت WAPFire و سرویس‌های رادیویی دوباره راه‌اندازی می‌شوند و ممکن است اتصال گوشی موقتاً قطع شود.")
            "force_setup" -> tx(fa, "WAPFire will return to its first-setup state while keeping its saved credentials and advanced settings. You may need to reconnect to the access point.", "WAPFire به وضعیت راه‌اندازی اولیه برمی‌گردد اما رمزها و تنظیمات پیشرفته حفظ می‌شوند. ممکن است لازم باشد دوباره به اکسس‌پوینت وصل شوی.")
            else -> tx(fa, "All saved settings and credentials will be erased. You will need to configure WAPFire again. This cannot be undone.", "تمام تنظیمات و رمزهای ذخیره‌شده پاک می‌شوند و باید WAPFire را از ابتدا پیکربندی کنی. این کار برگشت‌پذیر نیست.")
        }
        AlertDialog(
            onDismissRequest = { pendingMaintenance = null },
            title = { Text(title) }, text = { Text(body) },
            confirmButton = { TextButton(onClick = { pendingMaintenance = null; onAction(action) }) { Text(tx(fa, when (action) { "factory_reset" -> "Erase device"; "force_setup" -> "Return to setup"; else -> "Continue" }, when (action) { "factory_reset" -> "پاک کردن دستگاه"; "force_setup" -> "بازگشت به Setup"; else -> "ادامه" })) } },
            dismissButton = { TextButton(onClick = { pendingMaintenance = null }) { Text(tx(fa, "Cancel", "لغو")) } }
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(tx(fa, "ADVANCED DEVICE CONTROLS", "کنترل‌های پیشرفته دستگاه"), color = p.accent, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
        Text(tx(fa, "Every firmware feature, in its own group.", "تمام قابلیت‌های فریم‌ور، هرکدام در دسته مخصوص خودشان."), color = p.muted, fontSize = 11.sp)

        // Connectivity: Ethernet and event reporting are independent services.
        ExpandableSettingsCard(p, tx(fa, "Network · Ethernet", "شبکه · اترنت"), tx(fa, "DHCP, static addressing, DNS and hostname" , "DHCP، آدرس ثابت، DNS و نام میزبان")) {
            val src = data.ethernet
            var dhcp by remember(src.toString()) { mutableStateOf(src.optBoolean("use_dhcp", true)) }
            var ip by remember(src.toString()) { mutableStateOf(src.optString("static_ip", "192.168.1.100")) }
            var dns by remember(src.toString()) { mutableStateOf(src.optString("static_dns", "1.1.1.1")) }
            var gateway by remember(src.toString()) { mutableStateOf(src.optString("static_gateway", "192.168.1.1")) }
            var subnet by remember(src.toString()) { mutableStateOf(src.optString("static_subnet", "255.255.255.0")) }
            var hostname by remember(src.toString()) { mutableStateOf(src.optString("ethernet_hostname", "WAPFire")) }
            Text("${tx(fa, "Link", "اتصال")}: ${if (src.optInt("link_status") == 1) tx(fa, "Connected", "متصل") else tx(fa, "No link", "بدون اتصال")}  ·  ${src.optString("current_ip", "0.0.0.0")}", color = p.muted, fontSize = 10.sp)
            InfoLine(p, tx(fa, "Ethernet MAC", "مک اترنت"), src.optString("esp32_mac", "—"))
            InfoLine(p, tx(fa, "Current DNS", "DNS فعلی"), src.optString("current_dns", "—"))
            InfoLine(p, tx(fa, "Hardware status", "وضعیت سخت‌افزار"), src.optString("hardware_status", "—"))
            ToggleRow(p, "DHCP", tx(fa, "Obtain IP configuration automatically.", "تنظیمات IP به‌صورت خودکار دریافت شود."), dhcp) { dhcp = it }
            NativeField(p, hostname, { hostname = it }, tx(fa, "Ethernet hostname", "نام میزبان اترنت"))
            if (!dhcp) {
                NativeField(p, ip, { ip = it }, "Static IP")
                NativeField(p, gateway, { gateway = it }, "Gateway")
                NativeField(p, subnet, { subnet = it }, "Subnet mask")
                NativeField(p, dns, { dns = it }, "DNS server")
            }
            ActionButton(p, tx(fa, "Save Ethernet settings", "ذخیره تنظیمات اترنت"), { onSave("ethernet", JSONObject().put("use_dhcp", dhcp).put("static_ip", ip).put("static_dns", dns).put("static_gateway", gateway).put("static_subnet", subnet).put("ethernet_hostname", hostname)) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Network · HTTP event API", "شبکه · گزارش رویداد HTTP"), tx(fa, "Forward WAPFire events to your server over Ethernet." , "ارسال رویدادهای WAPFire به سرور از طریق اترنت.")) {
            val src = data.httpApi
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var url by remember(src.toString()) { mutableStateOf(src.optString("url")) }
            var port by remember(src.toString()) { mutableStateOf(src.optInt("port", 8080).toString()) }
            ToggleRow(p, tx(fa, "Enable HTTP event reporting", "فعال‌سازی گزارش رویداد HTTP"), tx(fa, "Requires an active Ethernet link.", "به اتصال فعال اترنت نیاز دارد."), enabled) { enabled = it }
            Text(tx(fa, "Ethernet service: ", "وضعیت اترنت: ") + if (src.optBoolean("ethernet_available")) tx(fa, "available", "در دسترس") else tx(fa, "unavailable", "در دسترس نیست"), color = p.muted, fontSize = 10.sp)
            NativeField(p, url, { url = it }, tx(fa, "Server URL / host path", "آدرس سرور / مسیر"))
            NativeField(p, port, { port = it.filter(Char::isDigit).take(5) }, "Port", keyboard = KeyboardType.Number)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Save", "ذخیره"), { onSave("http_api", JSONObject().put("enabled", enabled).put("url", url).put("port", port.toIntOrNull() ?: 8080)) }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Send test", "ارسال آزمایشی"), { onAction("test_http_api") }, modifier = Modifier.weight(1f))
            }
        }

        // Clock settings and phone-assisted synchronization.
        ExpandableSettingsCard(p, tx(fa, "Time · NTP & timezone", "زمان · NTP و منطقه زمانی"), tx(fa, "Automatic clock synchronization and local time." , "همگام‌سازی خودکار ساعت و زمان محلی.")) {
            val src = data.ntp
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("ntp_enabled")) }
            var server by remember(src.toString()) { mutableStateOf(src.optString("ntp_server", "pool.ntp.org")) }
            var interval by remember(src.toString()) { mutableStateOf(src.optInt("ntp_interval", 3600).toString()) }
            var timezone by remember(src.toString()) { mutableStateOf(src.optString("timezone", "UTC+0")) }
            ToggleRow(p, "NTP", tx(fa, "Synchronize the device clock automatically.", "ساعت دستگاه به‌صورت خودکار همگام‌سازی شود."), enabled) { enabled = it }
            Text("${src.optString("current_date", "—")}  ${src.optString("current_time", "—")}  ·  ${if (src.optBoolean("ntp_synced")) "SYNCED" else "NOT SYNCED"}", color = p.muted, fontSize = 10.sp)
            NativeField(p, server, { server = it }, tx(fa, "NTP server", "سرور NTP"))
            NativeField(p, interval, { interval = it.filter(Char::isDigit).take(5) }, tx(fa, "Update interval (60–86400 seconds)", "فاصله همگام‌سازی (۶۰ تا ۸۶۴۰۰ ثانیه)"), keyboard = KeyboardType.Number)
            val availableZones = remember(src.toString()) {
                val zones = src.optJSONArray("available_timezones") ?: JSONArray()
                (0 until zones.length()).map { zones.optString(it) }.filter { it.isNotBlank() }
            }
            var zoneMenuOpen by remember { mutableStateOf(false) }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(tx(fa, "Timezone", "منطقه زمانی"), color = p.muted, fontSize = 10.sp)
                Box {
                    OutlinedButton(onClick = { zoneMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(timezone, color = p.text)
                    }
                    DropdownMenu(expanded = zoneMenuOpen, onDismissRequest = { zoneMenuOpen = false }) {
                        availableZones.forEach { zone ->
                            DropdownMenuItem(text = { Text(zone) }, onClick = { timezone = zone; zoneMenuOpen = false })
                        }
                    }
                }
            }
            ActionButton(p, tx(fa, "Save NTP settings", "ذخیره تنظیمات NTP"), { onSave("ntp", JSONObject().put("ntp_enabled", enabled).put("ntp_server", server).put("ntp_interval", interval.toIntOrNull() ?: 3600).put("timezone", timezone)) }, primary = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Sync now", "همگام‌سازی اکنون"), { onAction("ntp_sync_now") }, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Use phone time", "استفاده از ساعت گوشی"), { onAction("ntp_sync_browser") }, modifier = Modifier.weight(1f))
            }
        }

        ExpandableSettingsCard(p, "MikroTik", tx(fa, "RouterOS integration and protection action." , "یکپارچگی RouterOS و اقدام حفاظتی.")) {
            val src = data.mikrotik
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var url by remember(src.toString()) { mutableStateOf(src.optString("url")) }
            var username by remember(src.toString()) { mutableStateOf(src.optString("username")) }
            var password by remember(src.toString()) { mutableStateOf("") }
            var iface by remember(src.toString()) { mutableStateOf(src.optString("interface", "wlan1")) }
            var reenable by remember(src.toString()) { mutableStateOf(src.optBoolean("reenable", true)) }
            var delay by remember(src.toString()) { mutableStateOf(src.optInt("reenable_delay", 60).toString()) }
            ToggleRow(p, tx(fa, "Enable MikroTik integration", "فعال‌سازی یکپارچگی MikroTik"), tx(fa, "Apply the configured RouterOS action when protection is triggered.", "هنگام فعال‌شدن محافظت، اقدام RouterOS تعریف‌شده اجرا شود."), enabled) { enabled = it }
            NativeField(p, url, { url = it }, tx(fa, "Router address / API endpoint", "آدرس روتر / API"))
            NativeField(p, username, { username = it }, tx(fa, "Username", "نام کاربری"))
            NativeField(p, password, { password = it }, tx(fa, "New password (leave blank to keep saved)", "رمز جدید (برای حفظ رمز قبلی خالی بگذار)"), password = true)
            NativeField(p, iface, { iface = it }, tx(fa, "Wireless interface", "رابط بی‌سیم"))
            ToggleRow(p, tx(fa, "Re-enable after action", "فعال‌سازی مجدد پس از اقدام"), tx(fa, "Restore the interface after the configured delay.", "رابط پس از زمان تعیین‌شده دوباره فعال شود."), reenable) { reenable = it }
            NativeField(p, delay, { delay = it.filter(Char::isDigit).take(3) }, tx(fa, "Re-enable delay (5–300 seconds)", "تاخیر فعال‌سازی مجدد (۵ تا ۳۰۰ ثانیه)"), keyboard = KeyboardType.Number)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Save MikroTik", "ذخیره MikroTik"), { val payload = JSONObject().put("enabled", enabled).put("url", url).put("username", username).put("interface", iface).put("reenable", reenable).put("reenable_delay", delay.toIntOrNull() ?: 60); if (password.isNotBlank()) payload.put("password", password); onSave("mikrotik", payload) }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Run test", "اجرای آزمایش"), { onAction("test_mikrotik") }, modifier = Modifier.weight(1f))
            }
            Text(if (src.optBoolean("password_set")) tx(fa, "A router password is stored; it is never shown in the app.", "رمز روتر ذخیره شده و در برنامه نمایش داده نمی‌شود.") else tx(fa, "No router password is stored.", "رمزی برای روتر ذخیره نشده است."), color = p.muted, fontSize = 9.sp)
        }

        ExpandableSettingsCard(p, tx(fa, "Lighting · WS2812 effects", "نورپردازی · افکت‌های WS2812"), tx(fa, "Effect, colors, speed and brightness." , "افکت، رنگ‌ها، سرعت و روشنایی.")) {
            val src = data.led
            var effect by remember(src.toString()) { mutableStateOf(src.optInt("effect", 12).toString()) }
            var color1 by remember(src.toString()) { mutableStateOf(src.optString("color1", "#FF0000")) }
            var color2 by remember(src.toString()) { mutableStateOf(src.optString("color2", "#00FF00")) }
            var speed by remember(src.toString()) { mutableStateOf(src.optInt("speed", 10).toString()) }
            var brightness by remember(src.toString()) { mutableStateOf(src.optInt("brightness", 128).toString()) }
            val effects = listOf(
                8 to tx(fa, "Solid", "ثابت"), 9 to tx(fa, "Breathing", "تنفسی"),
                10 to tx(fa, "Chase", "تعقیبی"), 11 to tx(fa, "Sparkle", "درخشش"),
                12 to tx(fa, "Rainbow", "رنگین‌کمان"), 13 to tx(fa, "Alternate", "متناوب"),
                14 to tx(fa, "Rainbow Chase", "تعقیب رنگین‌کمان"), 15 to tx(fa, "Fire", "آتش"),
                16 to tx(fa, "Twinkle", "چشمک‌زن"), 17 to tx(fa, "Color Wipe", "پاک‌سازی رنگ"),
                18 to tx(fa, "Theater", "تئاتر")
            )
            var effectMenuOpen by remember { mutableStateOf(false) }
            Text(tx(fa, "LED effect", "افکت LED"), color = p.muted, fontSize = 10.sp)
            Box {
                OutlinedButton(onClick = { effectMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(effects.firstOrNull { it.first == (effect.toIntOrNull() ?: 12) }?.second ?: "Rainbow", color = p.text)
                }
                DropdownMenu(expanded = effectMenuOpen, onDismissRequest = { effectMenuOpen = false }) {
                    effects.forEach { (id, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { effect = id.toString(); effectMenuOpen = false })
                    }
                }
            }
            val selectedEffect = effect.toIntOrNull() ?: 12
            val effectUsesPrimaryColor = selectedEffect in setOf(8, 9, 10, 11, 13, 17, 18)
            val effectUsesSecondaryColor = selectedEffect == 13
            if (effectUsesPrimaryColor) {
                ColorPickerField(p, fa, tx(fa, "Primary color", "رنگ اصلی"), color1) { color1 = it }
            }
            if (effectUsesSecondaryColor) {
                ColorPickerField(p, fa, tx(fa, "Secondary color", "رنگ دوم"), color2) { color2 = it }
            }
            if (!effectUsesPrimaryColor) {
                Text(tx(fa, "This effect uses its own generated palette; custom colors are not used.", "این افکت از پالت رنگی داخلی استفاده می‌کند و رنگ سفارشی ندارد."), color = p.muted, fontSize = 10.sp, lineHeight = 14.sp)
            } else if (effectUsesPrimaryColor && !effectUsesSecondaryColor) {
                Text(tx(fa, "This effect uses only the primary color.", "این افکت فقط از رنگ اصلی استفاده می‌کند."), color = p.muted, fontSize = 10.sp)
            }
            val speedValue = (speed.toIntOrNull() ?: 10).coerceIn(10, 1000)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(fa, "Speed", "سرعت"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("$speedValue ms", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(value = speedValue.toFloat(), onValueChange = { speed = it.roundToInt().coerceIn(10, 1000).toString() }, valueRange = 10f..1000f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("10 ms", color = p.muted, fontSize = 9.sp); Text("1000 ms", color = p.muted, fontSize = 9.sp)
                }
            }
            val brightnessValue = (brightness.toIntOrNull() ?: 128).coerceIn(0, 255)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(fa, "Brightness", "روشنایی"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("$brightnessValue / 255", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(value = brightnessValue.toFloat(), onValueChange = { brightness = it.roundToInt().coerceIn(0, 255).toString() }, valueRange = 0f..255f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("0", color = p.muted, fontSize = 9.sp); Text("255", color = p.muted, fontSize = 9.sp)
                }
            }
            ActionButton(p, tx(fa, "Save lighting", "ذخیره نورپردازی"), { onSave("led", JSONObject().put("effect", effect.toIntOrNull() ?: 12).put("color1", color1).put("color2", color2).put("speed", (speed.toIntOrNull() ?: 10).coerceIn(10, 1000)).put("brightness", (brightness.toIntOrNull() ?: 128).coerceIn(0, 255))) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Lighting · Client disconnect alert", "نورپردازی · هشدار قطع اتصال کلاینت"), tx(fa, "Configure the physical alert for client-initiated disconnects." , "هشدار فیزیکی قطع اتصال آغازشده از سمت کلاینت را تنظیم کن.")) {
            val src = data.disconnectLed
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled", true)) }
            var color by remember(src.toString()) { mutableStateOf(src.optString("color", "#AA00FF")) }
            ToggleRow(p, tx(fa, "Disconnect LED alert", "هشدار LED قطع اتصال"), tx(fa, "AP-originated disconnects do not trigger this alert in the current firmware baseline.", "در نسخه فعلی فریم‌ور، قطع اتصال آغازشده از سمت AP این هشدار را فعال نمی‌کند."), enabled) { enabled = it }
            ColorPickerField(p, fa, tx(fa, "Alert color", "رنگ هشدار"), color) { color = it }
            ActionButton(p, tx(fa, "Save disconnect alert", "ذخیره هشدار قطع اتصال"), { onSave("disconnect_led", JSONObject().put("enabled", enabled).put("color", color)) }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Automation · Schedule", "اتوماسیون · زمان‌بندی"), tx(fa, "Set weekly quiet hours for LED and sound." , "ساعت‌های سکوت هفتگی برای LED و صدا.")) {
            val src = data.schedule
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            var start by remember(src.toString()) { mutableStateOf(normalizeScheduleTime(src.optString("start", "22:00"), "22:00")) }
            var end by remember(src.toString()) { mutableStateOf(normalizeScheduleTime(src.optString("end", "06:00"), "06:00")) }
            var days by remember(src.toString()) { mutableStateOf(src.optInt("days", 127).coerceIn(0, 127)) }
            var action by remember(src.toString()) { mutableStateOf(src.optInt("action", 2).coerceIn(0, 2)) }
            val scheduleValid = !enabled || (days != 0 && start != end)
            ToggleRow(p, tx(fa, "Enable schedule", "فعال‌سازی زمان‌بندی"), tx(fa, "Schedule follows the device timezone.", "زمان‌بندی از منطقه زمانی خود دستگاه استفاده می‌کند."), enabled) { enabled = it }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                ScheduleTimePickerField(
                    p = p, value = start, label = tx(fa, "Start time", "شروع بازه"),
                    modifier = Modifier.weight(1f), onTimeSelected = { start = it }
                )
                ScheduleTimePickerField(
                    p = p, value = end, label = tx(fa, "End time", "پایان بازه"),
                    modifier = Modifier.weight(1f), onTimeSelected = { end = it }
                )
            }
            Text(tx(fa, "24-hour time · use the keyboard icon in the picker for direct entry.", "ساعت ۲۴ ساعته · برای ورود مستقیم، آیکون صفحه‌کلید داخل انتخابگر را بزن."), color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
            Text(tx(fa, "Days (Monday to Sunday)", "روزها (دوشنبه تا یکشنبه)"), color = p.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            val labels = if (fa) listOf("د", "س", "چ", "پ", "ج", "ش", "ی") else listOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                labels.forEachIndexed { index, label ->
                    val chosen = (days and (1 shl index)) != 0
                    Box(Modifier.weight(1f).clip(CircleShape).background(if (chosen) p.accent.copy(alpha = .2f) else p.panelAlt).border(1.dp, if (chosen) p.accent else p.border, CircleShape).clickable { days = if (chosen) days and (1 shl index).inv() else days or (1 shl index) }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                        Text(label, color = if (chosen) p.accent else p.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(tx(fa, "Action", "اقدام"), color = p.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            listOf(tx(fa, "Turn LED off", "خاموش‌کردن LED"), tx(fa, "Mute sound", "قطع صدا"), tx(fa, "LED + sound off", "خاموش‌کردن LED و صدا")).forEachIndexed { index, label ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (action == index) p.accent.copy(alpha = .12f) else p.panelAlt.copy(alpha = .52f))
                        .border(1.dp, if (action == index) p.accent.copy(alpha = .65f) else p.border, RoundedCornerShape(12.dp))
                        .clickable { action = index }.padding(horizontal = 11.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(17.dp).clip(CircleShape).border(1.5.dp, if (action == index) p.accent else p.muted, CircleShape).padding(3.dp)) {
                        if (action == index) Box(Modifier.fillMaxSize().clip(CircleShape).background(p.accent))
                    }
                    Spacer(Modifier.width(9.dp)); Text(label, color = p.text, fontSize = 11.sp)
                }
            }
            if (enabled && days == 0) {
                Text(tx(fa, "Select at least one day before enabling the schedule.", "برای فعال‌کردن زمان‌بندی، حداقل یک روز را انتخاب کن."), color = p.red, fontSize = 10.sp, lineHeight = 15.sp)
            }
            if (enabled && start == end) {
                Text(tx(fa, "Start and End cannot be the same. The firmware treats that interval as always active.", "زمان شروع و پایان نمی‌توانند یکسان باشند؛ فریم‌ور این حالت را به‌عنوان بازه همیشه‌فعال تفسیر می‌کند."), color = p.red, fontSize = 10.sp, lineHeight = 15.sp)
            }
            if (enabled && start > end) {
                Text(tx(fa, "Overnight interval: VF38 checks the weekday mask again after midnight. Also select the following day to keep the interval active.", "این بازه از نیمه‌شب عبور می‌کند: فریم‌ور VF38 بعد از نیمه‌شب روز هفته را دوباره بررسی می‌کند. برای ادامه‌ی بازه، روز بعد را هم انتخاب کن."), color = p.orange, fontSize = 10.sp, lineHeight = 15.sp)
            }
            Text("${tx(fa, "Schedule state", "وضعیت زمان‌بندی")}: ${if (src.optBoolean("active")) tx(fa, "ACTIVE", "فعال") else tx(fa, "INACTIVE", "غیرفعال")}", color = p.muted, fontSize = 9.sp)
            ActionButton(p, tx(fa, "Save schedule", "ذخیره زمان‌بندی"), { onSave("schedule", JSONObject().put("enabled", enabled).put("start", start).put("end", end).put("days", days).put("action", action)) }, enabled = scheduleValid, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Access control · Deauth whitelist", "کنترل دسترسی · فهرست سفید Deauth"), tx(fa, "Maintain trusted MAC addresses excluded by whitelist-aware logic." , "نشانی‌های MAC مورد اعتماد را برای منطق فهرست سفید نگه دار.")) {
            val src = data.whitelist
            var enabled by remember(src.toString()) { mutableStateOf(src.optBoolean("enabled")) }
            val initialEntries = remember(src.toString()) {
                val array = src.optJSONArray("entries") ?: JSONArray()
                (0 until array.length()).mapNotNull { index ->
                    val item = array.optJSONObject(index) ?: return@mapNotNull null
                    val mac = item.optString("mac").trim()
                    if (mac.isBlank()) null else mac.uppercase(Locale.US) to item.optString("name")
                }
            }
            var entryRows by remember(src.toString()) { mutableStateOf(initialEntries) }
            var newMac by remember { mutableStateOf("") }
            var newAlias by remember { mutableStateOf("") }
            var selectedTrackedMac by remember { mutableStateOf("") }
            var trackedMenuOpen by remember { mutableStateOf(false) }
            var validation by remember(src.toString()) { mutableStateOf("") }
            val tracked = trackedClients.filter { it.optString("mac").isNotBlank() }
                .distinctBy { it.optString("mac").uppercase(Locale.US) }
            ToggleRow(p, tx(fa, "Enable whitelist", "فعال‌سازی فهرست سفید"),
                tx(fa, "As in the WebUI: automatically deauthenticate clients outside this trusted list on supported WPA/WPA2 networks.", "مانند WebUI: در شبکه‌های WPA/WPA2 پشتیبانی‌شده، کلاینت‌های خارج از این فهرست مورد اعتماد به‌صورت خودکار Deauth می‌شوند."), enabled) { enabled = it }

            Text(tx(fa, "Trusted clients", "کلاینت‌های مورد اعتماد"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (entryRows.isEmpty()) {
                Text(tx(fa, "No clients have been added yet.", "هنوز کلاینتی اضافه نشده است."), color = p.muted, fontSize = 10.sp)
            } else {
                entryRows.forEachIndexed { index, (mac, alias) ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.panelAlt.copy(alpha = .62f)).padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(mac, color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(alias.ifBlank { tx(fa, "No alias", "بدون نام") }, color = p.muted, fontSize = 10.sp)
                        }
                        TextButton(onClick = { entryRows = entryRows.filterIndexed { i, _ -> i != index }; validation = "" }) {
                            Text(tx(fa, "Remove", "حذف"), color = p.red, fontSize = 11.sp)
                        }
                    }
                }
            }
            Text("${tx(fa, "Entries", "تعداد")}: ${entryRows.size}/32  ·  ${tx(fa, "Live tracked clients", "کلاینت‌های در حال ردیابی")}: ${tracked.size}", color = p.muted, fontSize = 9.sp)

            Text(tx(fa, "Add trusted client", "افزودن کلاینت مورد اعتماد"), color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(tx(fa, "Select a live tracked client to fill its MAC, or enter a MAC manually.", "یک کلاینت در حال ردیابی انتخاب کن تا MAC آن وارد شود، یا MAC را دستی بنویس."), color = p.muted, fontSize = 10.sp)
            Box {
                OutlinedButton(onClick = { trackedMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        when {
                            selectedTrackedMac.isNotBlank() -> tracked.firstOrNull { it.optString("mac").equals(selectedTrackedMac, true) }?.let { "${it.optString("mac")}  ·  ${it.optInt("rssi")} dBm" } ?: selectedTrackedMac
                            else -> tx(fa, "Choose from tracked clients (${tracked.size})", "انتخاب از کلاینت‌های ردیابی‌شده (${tracked.size})")
                        }, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                DropdownMenu(expanded = trackedMenuOpen, onDismissRequest = { trackedMenuOpen = false }) {
                    if (tracked.isEmpty()) {
                        DropdownMenuItem(text = { Text(tx(fa, "No tracked clients available", "کلاینت ردیابی‌شده‌ای موجود نیست")) }, onClick = { trackedMenuOpen = false }, enabled = false)
                    } else tracked.forEach { client ->
                        val mac = client.optString("mac").uppercase(Locale.US)
                        DropdownMenuItem(
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(mac, fontSize = 11.sp)
                                    Text("${client.optInt("rssi")} dBm  ·  ${client.optString("state", "Unknown")}", fontSize = 9.sp, color = p.muted)
                                }
                            },
                            onClick = { selectedTrackedMac = mac; newMac = mac; trackedMenuOpen = false }
                        )
                    }
                }
            }
            NativeField(p, newMac, { newMac = it.uppercase(Locale.US).take(17) }, tx(fa, "MAC address", "آدرس MAC"))
            NativeField(p, newAlias, { newAlias = it.take(64) }, tx(fa, "Device name / alias (optional)", "نام دستگاه / نام مستعار (اختیاری)"))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                ActionButton(p, tx(fa, "Add client", "افزودن کلاینت"), {
                    val normalized = newMac.trim().uppercase(Locale.US)
                    val valid = Regex("(?i)^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(normalized)
                    when {
                        entryRows.size >= 32 -> validation = tx(fa, "Maximum 32 entries are supported.", "حداکثر ۳۲ ورودی پشتیبانی می‌شود.")
                        !valid -> validation = tx(fa, "Enter a valid MAC address.", "یک آدرس MAC معتبر وارد کن.")
                        entryRows.any { it.first.equals(normalized, true) } -> validation = tx(fa, "This MAC is already in the whitelist.", "این MAC از قبل در فهرست مجاز است.")
                        else -> { entryRows = entryRows + (normalized to newAlias.trim()); newMac = ""; newAlias = ""; selectedTrackedMac = ""; validation = "" }
                    }
                }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Refresh clients", "به‌روزرسانی کلاینت‌ها"), { onAction("refresh_clients") }, modifier = Modifier.weight(1f))
            }
            if (validation.isNotBlank()) Text(validation, color = p.red, fontSize = 10.sp)
            ActionButton(p, tx(fa, "Save whitelist", "ذخیره فهرست سفید"), {
                val arr = JSONArray()
                entryRows.forEach { (mac, alias) -> arr.put(JSONObject().put("mac", mac).put("name", alias.take(64))) }
                onSave("whitelist", JSONObject().put("enabled", enabled).put("entries", arr))
            }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Device security · Credentials", "امنیت دستگاه · اعتبارنامه‌ها"), tx(fa, "Change device login and WAPFire access-point credentials." , "تغییر رمز ورود دستگاه و مشخصات اکسس‌پوینت WAPFire.")) {
            val src = data.general
            var ssid by remember(src.toString()) { mutableStateOf(src.optString("ap_ssid", "WAPFire")) }
            var adminPass by remember { mutableStateOf("") }
            var apPass by remember { mutableStateOf("") }
            Text(tx(fa, "Leave password fields empty to keep the current credentials.", "برای حفظ رمزهای فعلی، فیلدهای رمز را خالی بگذار."), color = p.muted, fontSize = 10.sp)
            Text(if (src.optBoolean("ap_pass_set")) tx(fa, "WAPFire Wi-Fi password is configured.", "رمز Wi‑Fi شبکه WAPFire تنظیم شده است.") else tx(fa, "WAPFire access point is open (no password stored).", "اکسس‌پوینت WAPFire بدون رمز است."), color = p.muted, fontSize = 9.sp)
            NativeField(p, ssid, { ssid = it }, tx(fa, "WAPFire AP SSID", "نام شبکه WAPFire"))
            NativeField(p, apPass, { apPass = it }, tx(fa, "New WAPFire Wi-Fi password", "رمز جدید Wi‑Fi WAPFire"), password = true)
            NativeField(p, adminPass, { adminPass = it }, tx(fa, "New administrator password", "رمز جدید مدیر"), password = true)
            InfoLine(p, tx(fa, "Beacon response", "پاسخ Beacon"), if (src.optBoolean("beacon_mode")) tx(fa, "ACTIVE", "فعال") else tx(fa, "Standby", "آماده‌باش"))
            Text(tx(fa, "Beacon transmission is not a normal device-security switch. Firmware activates it automatically during Self-Protect when an attack is detected and the target AP is known, then disables it when protection ends.", "ارسال Beacon یک کلید معمولی در امنیت دستگاه نیست. فریم‌ور هنگام فعال‌شدن Self-Protect، در صورت تشخیص حمله و مشخص‌بودن AP هدف، آن را خودکار فعال می‌کند و پس از پایان محافظت غیرفعال می‌سازد."), color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
            ActionButton(p, tx(fa, "Save device credentials", "ذخیره اعتبارنامه‌های دستگاه"), {
                val payload = JSONObject().put("ap_ssid", ssid)
                if (apPass.isNotBlank()) payload.put("ap_pass", apPass)
                if (adminPass.isNotBlank()) payload.put("adminpass", adminPass)
                onSave("general", payload)
                apPass = ""; adminPass = ""
            }, primary = true, modifier = Modifier.fillMaxWidth())
        }

        ExpandableSettingsCard(p, tx(fa, "Firmware · Backup & maintenance", "فریم‌ور · پشتیبان و نگهداری"), tx(fa, "Device information, export, restore, OTA and system actions." , "اطلاعات دستگاه، خروجی، بازیابی، OTA و عملیات سیستمی.")) {
            val fw = data.firmware
            InfoLine(p, "Firmware", fw.optString("version", "—"))
            InfoLine(p, "Chip", fw.optString("esp_model", "—"))
            InfoLine(p, "ESP-IDF", fw.optString("sdk", "—"))
            InfoLine(p, "Flash", fw.optString("flash", "—"))
            InfoLine(p, "CPU", fw.optString("cpu_freq", "—"))
            InfoLine(p, "Free OTA space", fw.optString("free_space", "—"))
            InfoLine(p, "PSRAM", fw.optString("psram", "—"))
            InfoLine(p, "Free heap", fw.optString("free_heap", "—"))
            InfoLine(p, "Largest free block", fw.optString("max_alloc", "—"))
            if (fw.optString("build_tag").isNotBlank()) InfoLine(p, "Build", fw.optString("build_tag"))
            val backup = data.backupInfo
            if (backup.length() > 0) {
                InfoLine(p, tx(fa, "Saved settings", "تنظیمات ذخیره‌شده"), backup.optString("settings_count", "—"))
                InfoLine(p, tx(fa, "Backup format", "فرمت پشتیبان"), backup.optString("version", "WAPFire"))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Export backup", "خروجی پشتیبان"), { showBackupWarning = true }, primary = true, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Restore backup", "بازیابی پشتیبان"), { showRestoreWarning = true }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(p, tx(fa, "Check update", "بررسی به‌روزرسانی"), { onAction("check_update") }, modifier = Modifier.weight(1f))
                ActionButton(p, tx(fa, "Install .bin", "نصب فایل .bin"), onFirmwarePick, primary = true, modifier = Modifier.weight(1f))
            }
            Text(tx(fa, "OTA accepts a native ESP32 firmware .bin image. Do not power off the board during upload.", "OTA یک فایل firmware با فرمت .bin مخصوص ESP32 می‌پذیرد. هنگام بارگذاری برق برد را قطع نکن."), color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
            DividerLine(p)
            ActionButton(p, tx(fa, "Restart Wi-Fi services", "راه‌اندازی مجدد سرویس‌های Wi‑Fi"), { pendingMaintenance = "wifi_restart" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Reboot device", "راه‌اندازی مجدد دستگاه"), { pendingMaintenance = "reboot" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Return to initial setup", "بازگشت به راه‌اندازی اولیه"), { pendingMaintenance = "force_setup" }, modifier = Modifier.fillMaxWidth())
            ActionButton(p, tx(fa, "Factory reset", "بازنشانی کارخانه‌ای"), { pendingMaintenance = "factory_reset" }, modifier = Modifier.fillMaxWidth())
            Text(tx(fa, "Return to setup preserves saved settings but disables normal configured mode. Factory reset erases saved settings and credentials.", "بازگشت به Setup تنظیمات ذخیره‌شده را نگه می‌دارد اما حالت پیکربندی‌شده را غیرفعال می‌کند. بازنشانی کارخانه‌ای تنظیمات و رمزها را پاک می‌کند."), color = p.red, fontSize = 9.sp)
        }
    }
}


@Composable
private fun ColorPickerField(
    p: Palette,
    fa: Boolean,
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panelAlt.copy(alpha = .58f))
            .border(1.dp, p.border.copy(alpha = .75f), RoundedCornerShape(14.dp))
            .clickable { open = true }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(runCatching { Color(AndroidColor.parseColor(value)) }.getOrDefault(Color.Red))
            .border(1.dp, Color.White.copy(alpha = .45f), RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(value.uppercase(Locale.US), color = p.muted, fontSize = 10.sp)
        }
        Text(tx(fa, "Choose", "انتخاب رنگ"), color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    if (open) ColorPickerDialog(p, fa, label, value, onDismiss = { open = false }, onApply = { onValueChange(it); open = false })
}

@Composable
private fun ColorPickerDialog(
    p: Palette,
    fa: Boolean,
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    val hsv = remember(initial) {
        val values = floatArrayOf(0f, 1f, 1f)
        runCatching { AndroidColor.colorToHSV(AndroidColor.parseColor(initial), values) }
        values
    }
    var hue by remember(initial) { mutableStateOf(hsv[0]) }
    var saturation by remember(initial) { mutableStateOf(hsv[1]) }
    var brightness by remember(initial) { mutableStateOf(hsv[2]) }
    val pickedInt = AndroidColor.HSVToColor(floatArrayOf(hue, saturation, brightness))
    val pickedCompose = Color(pickedInt)
    val hex = String.format(Locale.US, "#%06X", pickedInt and 0xFFFFFF)
    fun updateSv(x: Float, y: Float, width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        saturation = (x / width).coerceIn(0f, 1f)
        brightness = (1f - y / height).coerceIn(0f, 1f)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = p.text) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SaturationValueColorPicker(
                    hue = hue, saturation = saturation, brightness = brightness,
                    onPick = { x, y, w, h -> updateSv(x, y, w, h) }
                )
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tx(fa, "Hue", "ته‌رنگ"), color = p.text, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${hue.roundToInt()}°", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(pickedCompose)
                        .border(1.dp, p.border, RoundedCornerShape(10.dp)))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(hex, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(tx(fa, "Selected color", "رنگ انتخاب‌شده"), color = p.muted, fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(hex) }) { Text(tx(fa, "Apply", "اعمال"), color = p.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(fa, "Cancel", "لغو"), color = p.muted) } }
    )
}

@Composable
private fun SaturationValueColorPicker(
    hue: Float,
    saturation: Float,
    brightness: Float,
    onPick: (Float, Float, Float, Float) -> Unit
) {
    val hueColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, 1f, 1f)))
    Canvas(
        Modifier.fillMaxWidth().height(190.dp)
            .pointerInput(hue) {
                detectTapGestures { point -> onPick(point.x, point.y, size.width.toFloat(), size.height.toFloat()) }
            }
            .pointerInput(hue) {
                detectDragGestures { change, _ ->
                    onPick(change.position.x, change.position.y, size.width.toFloat(), size.height.toFloat())
                }
            }
    ) {
        drawRect(brush = Brush.horizontalGradient(listOf(Color.White, hueColor)))
        drawRect(brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
        val x = saturation * size.width
        val y = (1f - brightness) * size.height
        drawCircle(Color.Black.copy(alpha = .82f), radius = 11.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
        drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun Brand(p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(p.accent, p.blue))), contentAlignment = Alignment.Center) {
            Text("W", color = Color(0xFF08202A), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("WAPFIRE", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.7.sp)
            Text("WIRELESS INTELLIGENCE", color = p.muted, fontSize = 8.sp, letterSpacing = 1.1.sp)
        }
    }
}

@Composable
private fun ThemeAction(p: Palette, dark: Boolean, onTheme: () -> Unit) {
    // Exact Welcome Back theme glyph: one half-filled circle (contrast icon).
    // Keep the same glyph in both themes; tapping it toggles the active theme.
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(shape)
            .background(p.panelAlt.copy(alpha = .70f))
            .border(1.dp, p.border.copy(alpha = .78f), shape)
            .clickable { onTheme() }
            .padding(horizontal = 9.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(17.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.minDimension * .42f
            val origin = Offset(cx - radius, cy - radius)
            val diameter = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f)
            val color = p.text

            // Solid left semicircle; the right half remains transparent.
            drawArc(
                color = color,
                startAngle = 90f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = origin,
                size = diameter
            )
            // Continuous outer ring and the straight center split.
            drawCircle(color = color, radius = radius, center = Offset(cx, cy), style = Stroke(width = 1.05.dp.toPx()))
            drawLine(
                color = color,
                start = Offset(cx, cy - radius),
                end = Offset(cx, cy + radius),
                strokeWidth = 1.05.dp.toPx()
            )
        }
    }
}

@Composable
private fun SmallAction(p: Palette, label: String, onClick: () -> Unit) {
    // Match the theme control exactly: both controls are 36 × 36 dp.
    // Keep language codes LTR even inside the Persian RTL screen.
    Box(
        Modifier.size(36.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(p.panelAlt.copy(alpha = .70f))
            .border(1.dp, p.border.copy(alpha = .78f), RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = label,
                color = p.text,
                fontSize = if (label.length == 2) 11.sp else 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp)
            )
        }
    }
}

@Composable
private fun SectionCard(p: Palette, title: String, subtitle: String = "", content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(23.dp)
    Column(Modifier.fillMaxWidth().shadow(14.dp, shape, ambientColor = Color.Black.copy(alpha = .12f), spotColor = p.accent.copy(alpha = .10f))
        .clip(shape)
        .background(Brush.linearGradient(listOf(p.panel.copy(alpha = .84f), p.panelAlt.copy(alpha = .70f), p.panel.copy(alpha = .78f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), p.border.copy(alpha = .78f), Color.White.copy(alpha = .05f))), shape)
        .padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        content.invoke(this)
    }
}

@Composable
private fun ScheduleTimePickerField(
    p: Palette,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    onTimeSelected: (String) -> Unit
) {
    val context = LocalContext.current
    val safeValue = normalizeScheduleTime(value, "22:00")
    val parts = safeValue.split(":")
    val initialHour = parts[0].toInt()
    val initialMinute = parts[1].toInt()
    OutlinedButton(
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute -> onTimeSelected(String.format(Locale.US, "%02d:%02d", hour, minute)) },
                initialHour,
                initialMinute,
                true
            ).show()
        },
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(13.dp),
        border = BorderStroke(1.dp, p.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp), horizontalAlignment = Alignment.Start) {
            Text(label, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(safeValue, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun MessageCard(p: Palette, message: String, danger: Boolean, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(p.panel)
            .border(1.dp, (if (danger) p.red else p.green).copy(alpha = .72f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (danger) "!" else "✓", color = if (danger) p.red else p.green, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(9.dp))
        Text(
            message,
            color = p.text,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(28.dp).clip(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
            Text("×", color = p.muted, fontSize = 18.sp)
        }
    }
}

@Composable
private fun ActionButton(p: Palette, label: String, onClick: () -> Unit, enabled: Boolean = true, primary: Boolean = false, modifier: Modifier = Modifier) {
    val bg = if (primary) p.accent else p.panelAlt
    val fg = if (primary) Color(0xFF06232A) else p.text
    Box(modifier.clip(RoundedCornerShape(13.dp)).background(if (enabled) bg else bg.copy(alpha = .45f)).border(1.dp, if (primary) p.accent else p.border, RoundedCornerShape(13.dp)).clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) fg else p.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NativeField(p: Palette, value: String, onValue: (String) -> Unit, label: String, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text, focusRequester: FocusRequester? = null) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth().then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        label = { Text(label, fontSize = 12.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(13.dp),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = p.text, unfocusedTextColor = p.text,
            focusedBorderColor = p.accent, unfocusedBorderColor = p.border,
            focusedLabelColor = p.accent, unfocusedLabelColor = p.muted,
            cursorColor = p.accent
        )
    )
}

@Composable
private fun DeviceResult(p: Palette, title: String, detail: String, badge: String, onClick: () -> Unit, action: String, selected: Boolean = false, enabled: Boolean = true) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape)
        .background(if (selected) Brush.linearGradient(listOf(p.accentSoft.copy(alpha = .82f), p.accentSoft.copy(alpha = .58f))) else Brush.linearGradient(listOf(p.panelAlt.copy(alpha = .82f), p.panel.copy(alpha = .64f))))
        .border(1.dp, if (selected) p.accent else p.border.copy(alpha = .68f), shape)
        .clickable(enabled = enabled && action.isNotBlank()) { onClick() }.padding(11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(p.accentSoft), contentAlignment = Alignment.Center) { Text("⌁", color = p.accent, fontSize = 18.sp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (badge.isNotBlank()) Text(badge, color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        if (action.isNotBlank()) Text(action, color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricTile(p: Palette, value: String, label: String, glyph: String, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.shadow(8.dp, shape).clip(shape)
        .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
        .border(1.dp, p.border, shape).padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(glyph, color = color, fontSize = 15.sp); Spacer(Modifier.weight(1f)); Box(Modifier.size(5.dp).clip(CircleShape).background(color)) }
        Text(value, color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = p.muted, fontSize = 10.sp)
    }
}

@Composable
private fun ThreatRing(p: Palette, score: Float, level: String) {
    val normalizedScore = score.coerceIn(0f, 10f)
    val color = when (level.uppercase()) {
        "CRITICAL", "HIGH" -> p.red
        "WARNING", "MONITORING", "MEDIUM", "MODERATE" -> p.orange
        "OPTIMAL", "LOW" -> p.green
        else -> p.blue
    }
    val scoreText = String.format(Locale.US, "%.1f", normalizedScore)
    Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(color.copy(alpha = .18f), -90f, 360f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
            // Firmware score_tenths is 0..100 (= 0.0..10.0). One risk point is 36 degrees.
            drawArc(color, -90f, normalizedScore * 36f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("$scoreText/10", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(level.uppercase(), color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun NativeLineChart(p: Palette, primary: List<Int>, secondary: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val pad = 8.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        for (i in 0..3) {
            val y = pad + h * i / 3f
            drawLine(p.border, Offset(pad, y), Offset(size.width - pad, y), 1.dp.toPx())
        }
        fun drawSeries(values: List<Int>, color: Color, stroke: Float) {
            if (values.size < 2) return
            val max = (primary + secondary).maxOrNull()?.coerceAtLeast(1) ?: 1
            val path = Path()
            values.forEachIndexed { index, v ->
                val x = pad + (w * index / (values.size - 1).toFloat())
                val y = pad + h - (v.coerceAtLeast(0).toFloat() / max) * h
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        drawSeries(primary, p.accent, 2.5.dp.toPx())
        drawSeries(secondary, p.blue, 2.dp.toPx())
    }
}

@Composable
private fun LegendDot(color: Color, label: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(label, color = p.muted, fontSize = 9.sp)
    }
}

@Composable
private fun MiniValue(p: Palette, value: String, label: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.muted, fontSize = 8.sp)
    }
}

@Composable
private fun ToggleRow(p: Palette, title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun DividerLine(p: Palette) { Box(Modifier.fillMaxWidth().height(1.dp).background(p.border)) }

@Composable
private fun InfoLine(p: Palette, key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

private val BSSID_PATTERN = Regex("(?i)^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")
private val SCHEDULE_TIME_PATTERN = Regex("^\\d{2}:\\d{2}$")

private fun isValidBssid(value: String): Boolean = BSSID_PATTERN.matches(value.trim())

private fun normalizeScheduleTime(value: String, fallback: String): String {
    if (!SCHEDULE_TIME_PATTERN.matches(value)) return fallback
    val hour = value.substring(0, 2).toIntOrNull() ?: return fallback
    val minute = value.substring(3, 5).toIntOrNull() ?: return fallback
    return if (hour in 0..23 && minute in 0..59) value else fallback
}

private fun tx(fa: Boolean, en: String, persian: String) = if (fa) persian else en
private fun Long.compact(): String = when {
    this >= 1_000_000 -> String.format("%.1fM", this / 1_000_000.0)
    this >= 1_000 -> String.format("%.1fK", this / 1_000.0)
    else -> toString()
}
private fun formatUptime(ms: Long): String {
    if (ms <= 0) return "—"
    val seconds = ms / 1000
    val days = seconds / 86400
    val hours = (seconds % 86400) / 3600
    val minutes = (seconds % 3600) / 60
    return if (days > 0) "${days}d ${hours}h" else if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
}
