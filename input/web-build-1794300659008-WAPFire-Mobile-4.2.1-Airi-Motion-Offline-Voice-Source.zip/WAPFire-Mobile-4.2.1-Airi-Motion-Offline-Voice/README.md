# WAPFire Mobile 4.2.1 — Hiyori Motion + Offline Persian/English Voice

This source update improves Hiyori's Live2D idle movement and replaces Android system Text-to-Speech with a bundled offline Persian/English voice for Nara.

See `OFFLINE-VOICE-AND-AIRI-MOTION-4.2.1.md` for implementation details, model/runtime licenses, the first-build download requirements, and validation limits.

The first full build requires an Internet connection so Gradle can fetch and checksum the Sherpa-ONNX runtime and Musa FA/EN Matcha model. Once included in the APK and installed, voice generation runs locally without Android TTS language downloads or an Internet connection.
