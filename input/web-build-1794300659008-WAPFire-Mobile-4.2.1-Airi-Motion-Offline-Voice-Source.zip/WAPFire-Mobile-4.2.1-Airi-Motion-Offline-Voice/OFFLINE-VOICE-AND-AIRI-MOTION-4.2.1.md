# WAPFire Mobile 4.2.1 — Nara offline voice and Live2D motion

## Offline voice

- Nara now uses the bundled Sherpa-ONNX 2.0.1 runtime and the Musa Matcha FA/EN voice model.
- Both the acoustic model and Vocos vocoder, token vocabulary, and phoneme data are copied into the APK as assets by `ensureOfflineVoiceBundle`.
- On first launch the assets are copied to the app's private no-backup directory. Audio is generated locally and played through `AudioTrack`.
- Android system Text-to-Speech settings, installed voices, and an Internet connection are no longer used.
- The build task downloads the official Sherpa AAR and model package only if the files are missing or incomplete. The AAR and acoustic checkpoint are SHA-256 checked.
- The complete APK will be significantly larger (roughly 150–200 MB depending on the native libraries, model files, and APK split/compression). The source ZIP remains small because the large, licensed model files are fetched during build.

## Live2D motion

- The existing Hiyori Cubism model and its nine bundled Idle motions remain unchanged.
- The renderer explicitly starts the model's Idle group and retries once after initialization.
- The idle-focus/breathing/talking controller follows the same plugin-style separation used by AIRI's Live2D stage, adapted to this app's existing Pixi Live2D WebView (the full AIRI Vue application is not bundled).
- AIRI project reference: https://github.com/moeru-ai/airi
- The previous custom eye-gaze writes used `set`, suppressing eye movement from the model's own motion curves. They now blend additively with the Cubism motions.
- A light AIRI-style idle focus layer adds slowly shifting gaze, natural body/head sway, breathing, and a subtle talking nod. Native Cubism blinking is retained.
- Speaking callbacks from offline audio continue driving the model's mouth animation.

## Third-party notices

- Sherpa-ONNX: Apache License 2.0. Project: https://github.com/k2-fsa/sherpa-onnx
- Musa FA/EN Matcha model: CC0-1.0 as declared by its publisher. Model page: https://huggingface.co/mah92/Musa-FA_EN-Matcha-TTS-Model
- The original Live2D Hiyori sample data and existing PixiJS/Cubism notices remain in `app/src/main/assets/assistant/hiyori/LICENSES.txt`.

## Build note

Run the existing `build-apk.bat` or `gradlew.bat assembleDebug` with Internet access so Gradle can retrieve any missing runtime/model files. The existing character-package task also refreshes its GitHub asset during `preBuild`. After the APK is installed, Nara's speech works offline and does not consult Android TTS settings. The project was source-reviewed here; an Android APK build/device playback test was not run in this environment because the Android SDK and network access are unavailable.
