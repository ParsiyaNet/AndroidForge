# WAPFire Mobile 4.2.1

## Nara offline voice
- Replaced the Android `TextToSpeech` device-voice dependency with Sherpa-ONNX 2.0.1.
- Added a bilingual Persian/English Musa Matcha acoustic model, Vocos vocoder, and its token/phoneme data to the APK build pipeline.
- Added SHA-256 checks for the Sherpa AAR and selected Musa acoustic model.
- Speech is generated locally and played through Android `AudioTrack`; Android Settings voice installation is no longer required.

## Hiyori / Live2D motion
- Explicitly starts the model's bundled Idle motion group after load, with one initialization retry.
- Blends gaze with Cubism motion curves rather than overwriting them.
- Adds subtle idle eye focus, breathing, head/body sway, and speaking nod while retaining the model's native blink animation.

## Build
- Version code: 103
- Version name: 4.2.1
- The first full build downloads the voice runtime/model. The resulting APK contains the voice assets for offline use.
