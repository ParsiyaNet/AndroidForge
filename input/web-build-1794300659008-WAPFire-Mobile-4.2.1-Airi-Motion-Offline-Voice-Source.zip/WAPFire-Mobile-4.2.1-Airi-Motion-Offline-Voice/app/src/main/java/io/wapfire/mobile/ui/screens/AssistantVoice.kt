package io.wapfire.mobile.ui.screens

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsMatchaModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

/**
 * WAPFire 4.2.1: bundled Persian + English offline speech.
 *
 * This deliberately does not use Android TextToSpeech or the voices installed in device settings.
 * The bilingual Musa Matcha model and Sherpa-ONNX runtime are packaged by the Gradle asset task.
 * Model files are copied to private app storage on first run and inference/playback stay offline.
 */
internal class AssistantVoice(
    context: Context,
    private val onSpeaking: (Boolean) -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { task ->
        Thread(task, "WAPFire-Offline-TTS").apply { isDaemon = true }
    }
    private val closed = AtomicBoolean(false)
    private val generation = AtomicInteger(0)
    @Volatile private var engine: OfflineTts? = null
    @Volatile private var activeTrack: AudioTrack? = null
    @Volatile private var initializationError: Throwable? = null
    private var warningShown = false

    init {
        worker.execute {
            try {
                engine = createEngine()
            } catch (error: Throwable) {
                initializationError = error
                android.util.Log.e(TAG, "Bundled offline voice initialization failed", error)
            }
        }
    }

    /** The language flag is retained for the screen API; the bundled model is bilingual. */
    fun speak(text: String, fa: Boolean) {
        if (closed.get() || text.isBlank()) return
        val request = generation.incrementAndGet()
        stopTrack()
        try {
            worker.execute {
                try {
                    if (request != generation.get() || closed.get()) return@execute
                    val tts = engine ?: throw (initializationError
                        ?: IOException("Offline voice engine is not ready"))
                    val audio = tts.generate(text, 0, 1.0f)
                    if (request != generation.get() || closed.get()) return@execute
                    if (audio.samples.isEmpty() || audio.sampleRate <= 0) {
                        throw IOException("Offline voice returned empty audio")
                    }
                    playAudio(audio.samples, audio.sampleRate, request)
                } catch (error: Throwable) {
                    if (request == generation.get() && !closed.get()) {
                        android.util.Log.e(TAG, "Offline speech failed (fa=$fa)", error)
                        dispatchSpeaking(false)
                        warnOnce(fa)
                    }
                }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // Screen was disposed while a speech request was being queued.
        }
    }

    private fun createEngine(): OfflineTts {
        val modelRoot = File(appContext.noBackupFilesDir, "wapfire/tts/fa_en_musa")
        if (!File(modelRoot, "model.onnx").isFile || !File(modelRoot, "vocoder.onnx").isFile ||
            !File(modelRoot, "tokens.txt").isFile || !File(modelRoot, "espeak-ng-data").isDirectory) {
            copyAssetTree("tts/fa_en_musa", modelRoot)
        }

        val acoustic = File(modelRoot, "model.onnx")
        val vocoder = File(modelRoot, "vocoder.onnx")
        val tokens = File(modelRoot, "tokens.txt")
        val espeak = File(modelRoot, "espeak-ng-data")
        require(acoustic.length() > 50_000_000L) { "Bundled Musa acoustic model is missing or incomplete" }
        require(vocoder.length() > 1_000_000L) { "Bundled Vocos model is missing or incomplete" }
        require(tokens.length() > 100L && espeak.isDirectory) { "Bundled phoneme data is missing" }

        val matcha = OfflineTtsMatchaModelConfig(
            acousticModel = acoustic.absolutePath,
            vocoder = vocoder.absolutePath,
            tokens = tokens.absolutePath,
            dataDir = espeak.absolutePath,
            lexicon = "",
            noiseScale = 1.0f,
            lengthScale = 1.0f
        )
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                matcha = matcha,
                numThreads = 2,
                provider = "cpu"
            ),
            maxNumSentences = 1
        )
        return OfflineTts(config = config)
    }

    /** Copy packaged assets once. AssetManager transparently streams compressed or stored files. */
    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = appContext.assets.list(assetPath).orEmpty()
        if (children.isNotEmpty()) {
            if (!destination.exists() && !destination.mkdirs()) {
                throw IOException("Cannot create voice data directory: $destination")
            }
            for (child in children) {
                copyAssetTree("$assetPath/$child", File(destination, child))
            }
        } else {
            destination.parentFile?.let { if (!it.exists() && !it.mkdirs()) throw IOException("Cannot create $it") }
            appContext.assets.open(assetPath).use { input ->
                destination.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
        }
    }

    private fun playAudio(samples: FloatArray, sampleRate: Int, request: Int) {
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) throw IOException("Unsupported audio output format ($minBuffer)")

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuffer * 2, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        activeTrack = track
        if (request != generation.get() || closed.get()) {
            runCatching { track.release() }
            if (activeTrack === track) activeTrack = null
            return
        }

        try {
            dispatchSpeaking(true)
            track.play()
            val shorts = ShortArray(2048)
            var offset = 0
            while (offset < samples.size && request == generation.get() && !closed.get()) {
                val count = minOf(shorts.size, samples.size - offset)
                for (i in 0 until count) {
                    val value = samples[offset + i].coerceIn(-1.0f, 1.0f)
                    shorts[i] = (value * 32767.0f).toInt().toShort()
                }
                val written = track.write(shorts, 0, count, AudioTrack.WRITE_BLOCKING)
                if (written < 0) throw IOException("AudioTrack write failed: $written")
                if (written == 0) throw IOException("AudioTrack returned zero samples while writing")
                offset += written
            }
            // Wait for buffered samples to finish before closing the output stream.
            while (request == generation.get() && !closed.get() && track.playState == AudioTrack.PLAYSTATE_PLAYING &&
                track.playbackHeadPosition.toLong() < samples.size.toLong()) {
                Thread.sleep(20)
            }
        } finally {
            runCatching { track.pause() }
            runCatching { track.flush() }
            runCatching { track.release() }
            if (activeTrack === track) activeTrack = null
            if (request == generation.get()) dispatchSpeaking(false)
        }
    }

    private fun stopTrack() {
        val track = activeTrack ?: return
        activeTrack = null
        runCatching { track.pause() }
        runCatching { track.flush() }
        runCatching { track.stop() }
        dispatchSpeaking(false)
    }

    private fun dispatchSpeaking(value: Boolean) {
        main.post { if (!closed.get() || !value) onSpeaking(value) }
    }

    private fun warnOnce(fa: Boolean) {
        synchronized(this) {
            if (warningShown || closed.get()) return
            warningShown = true
        }
        val message = if (fa) {
            "صدای آفلاین داخل برنامه بارگذاری نشد. نسخهٔ کامل برنامه را با فایل‌های صدای همراه بساز."
        } else {
            "The bundled offline voice could not be loaded. Build the full app with its voice assets."
        }
        main.post {
            if (!closed.get()) Toast.makeText(appContext, message, Toast.LENGTH_LONG).show()
        }
    }

    fun stop() {
        generation.incrementAndGet()
        stopTrack()
        dispatchSpeaking(false)
    }

    fun shutdown() {
        if (!closed.compareAndSet(false, true)) return
        generation.incrementAndGet()
        stopTrack()
        try {
            worker.execute {
                runCatching { engine?.release() }
                engine = null
                worker.shutdown()
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            worker.shutdownNow()
        }
    }

    private companion object {
        const val TAG = "WapFireOfflineTts"
    }
}
