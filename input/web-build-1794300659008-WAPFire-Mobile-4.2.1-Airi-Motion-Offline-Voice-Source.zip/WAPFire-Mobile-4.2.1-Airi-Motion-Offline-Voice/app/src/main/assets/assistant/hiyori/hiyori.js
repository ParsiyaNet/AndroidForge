/* WAPFire 4.2.1 - Hiyori Momose (Live2D Cubism 4) assistant renderer.
 * Same native contract as the previous page: window.wapfireSetState(state),
 * WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg).
 * New: window.wapfireSetSpeaking(bool) for lip movement while the phone speaks. */
(function () {
  'use strict';
  const BUILD = '4.2.1';
  window.__wfPreflightStarted = true;
  window.__wfAssistantBuildVersion = BUILD;
  window.__wfAssistantDocumentExpected = true;

  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const compact = q.get('compact') !== '0';
  const $ = (id) => document.getElementById(id);
  const bridge = window.WapFireNative;
  document.documentElement.lang = fa ? 'fa' : 'en';
  document.body.className = compact ? 'compact' : 'full';

  let ready = false;
  let model = null;
  let app = null;
  let rawModel = null;
  let pendingState = q.get('state') || 'idle';
  let speaking = false;
  const userZoom = parseFloat(q.get('zoom') || '1') || 1;
  const userDy = parseFloat(q.get('dy') || '0') || 0;

  function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
  function fatal(message) {
    const text = String(message).slice(0, 400);
    console.error(text);
    const box = $('loading');
    if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
    report(text);
    try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
  }
  window.addEventListener('error', (e) => { if (!ready) fatal('Hiyori error: ' + (e.message || e)); });
  window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('Hiyori error: ' + ((e.reason && e.reason.message) || e.reason)); });

  /* ---------- states ---------- */
  const PILL = {
    idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
    success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
    warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
    setup: ['Setup required', 'نیازمند راه‌اندازی']
  };
  // Hiyori has no expression files, so every state is a small pose layered on top of her idle motions.
  const DEFAULT_POSE = { mouthForm: 0.35, mouthOpen: 0, eyeOpen: 1, eyeSmile: 0, cheek: 0, browY: 0, browAngle: 0,
    angleX: 0, angleY: 0, angleZ: 0, bodyX: 0, bodyZ: 0, gazeX: 0, gazeY: 0, scan: 0, scanSpeed: 1, shake: 0, bounce: 0 };
  const POSES = {
    idle: {},
    scanning: { mouthForm: 0.15, browY: 0.25, scan: 1, scanSpeed: 1.1, angleY: 2 },
    connecting: { mouthForm: 0, mouthOpen: 0.1, browY: 0.35, angleZ: 7, gazeX: -0.5, gazeY: 0.5 },
    success: { mouthForm: 1, mouthOpen: 0.3, eyeSmile: 0.9, cheek: 0.9, browY: 0.3, bounce: 1 },
    password_success: { mouthForm: 0.9, mouthOpen: 0.2, eyeSmile: 0.7, cheek: 0.6, browY: 0.2 },
    password_warning: { mouthForm: -0.55, eyeOpen: 0.9, browY: -0.15, browAngle: 0.5, angleZ: -6, angleY: -3 },
    warning: { mouthForm: -0.35, mouthOpen: 0.25, browY: 0.7, angleY: 3, scan: 0.6, scanSpeed: 2.6 },
    angry: { mouthForm: -1, eyeOpen: 0.78, browY: -0.6, browAngle: -0.5, angleY: -3, shake: 1 },
    offline: { mouthForm: -0.4, eyeOpen: 0.55, browY: -0.2, angleY: -12, angleZ: -5 },
    setup: { mouthForm: 0.6, eyeSmile: 0.25, browY: 0.3, angleZ: 5 }
  };
  const cur = Object.assign({}, DEFAULT_POSE);
  let tgt = Object.assign({}, DEFAULT_POSE);
  let speakOpen = 0;

  // AIRI-style idle focus driver: slow gaze shifts and breathing layered over Cubism motions.
  const idleFocus = { x: 0, y: 0, targetX: 0, targetY: 0, nextShiftAt: 0 };
  let idleMotionRetry = 0;
  let motionManager = null;

  const randomBetween = (low, high) => low + Math.random() * (high - low);
  function updateIdleFocus(nowMs, dt, talking) {
    if (nowMs >= idleFocus.nextShiftAt) {
      if (talking) {
        idleFocus.targetX = randomBetween(-0.10, 0.10);
        idleFocus.targetY = randomBetween(-0.08, 0.08);
      } else {
        // Natural short glances, with longer rests looking toward the user.
        const glance = Math.random();
        idleFocus.targetX = glance < 0.56 ? randomBetween(-0.12, 0.12) : randomBetween(-0.42, 0.42);
        idleFocus.targetY = randomBetween(-0.18, 0.18);
      }
      idleFocus.nextShiftAt = nowMs + randomBetween(talking ? 950 : 1800, talking ? 1900 : 4200);
    }
    const follow = 1 - Math.exp(-dt * (talking ? 3.8 : 2.2));
    idleFocus.x += (idleFocus.targetX - idleFocus.x) * follow;
    idleFocus.y += (idleFocus.targetY - idleFocus.y) * follow;
  }

  function startModelIdleMotion() {
    if (!model || !model.internalModel || !model.internalModel.motionManager) return;
    motionManager = model.internalModel.motionManager;
    try {
      const priority = (PIXI.live2d.MotionPriority && PIXI.live2d.MotionPriority.IDLE !== undefined)
        ? PIXI.live2d.MotionPriority.IDLE : 1;
      // The model ships nine original Idle motions. Start that group explicitly instead of
      // relying only on the library's automatic idle-request state machine.
      const result = model.motion('Idle', undefined, priority);
      if (result && typeof result.catch === 'function') result.catch((e) => report('Idle motion: ' + e));
    } catch (e) {
      report('Idle motion could not start: ' + (e && e.message ? e.message : e));
    }
  }

  function showState(name) {
    const state = POSES[name] ? name : 'idle';
    pendingState = state;
    $('shell').dataset.state = state;
    $('stateText').textContent = PILL[state][fa ? 1 : 0];
    tgt = Object.assign({}, DEFAULT_POSE, POSES[state]);
  }
  window.wapfireSetState = (state) => { try { showState(String(state)); } catch (e) { report(String(e)); } };
  window.wapfireSetSpeaking = (on) => { speaking = !!on; };

  /* ---------- parameter access (raw Cubism Core model) ---------- */
  const paramIndex = {};
  function bindParameters() {
    const ids = rawModel.parameters.ids;
    for (let i = 0; i < ids.length; i++) paramIndex[ids[i]] = i;
  }
  function put(id, value, mode) {
    const i = paramIndex[id];
    if (i === undefined) return;
    const p = rawModel.parameters;
    const now = p.values[i];
    const v = mode === 'add' ? now + value : mode === 'min' ? Math.min(now, value) : value;
    p.values[i] = Math.max(p.minimumValues[i], Math.min(p.maximumValues[i], v));
  }

  let lastTime = performance.now();
  function applyPose() {
    if (!rawModel) return;
    const nowMs = performance.now();
    const dt = Math.min(0.1, Math.max(0.001, (nowMs - lastTime) / 1000));
    lastTime = nowMs;
    const t = nowMs / 1000;
    const a = 1 - Math.exp(-dt * 6);
    for (const k in cur) cur[k] += (tgt[k] - cur[k]) * a;

    const speakTarget = speaking ? 0.15 + 0.6 * Math.abs(Math.sin(t * 13)) * (0.55 + 0.45 * Math.sin(t * 4.1 + 1)) : 0;
    speakOpen += (speakTarget - speakOpen) * (1 - Math.exp(-dt * 18));

    updateIdleFocus(nowMs, dt, speaking);
    const sweep = Math.sin(t * cur.scanSpeed * 2) * cur.scan;
    const gazeX = cur.gazeX + idleFocus.x * 0.58 + sweep * 0.8;
    const gazeY = cur.gazeY + idleFocus.y * 0.58;
    const breath = Math.sin(t * 1.25) * 0.5 + 0.5;
    const idleSway = Math.sin(t * 0.72) * 0.75 + Math.sin(t * 0.31 + 1.4) * 0.35;
    const talkNod = speaking ? Math.sin(t * 2.7) * 0.75 : 0;
    const bounce = Math.sin(t * 5) * cur.bounce;
    const shake = Math.sin(t * 28) * cur.shake;

    put('ParamMouthForm', cur.mouthForm + (speaking ? Math.sin(t * 9) * 0.25 : 0), 'set');
    put('ParamMouthOpenY', Math.max(cur.mouthOpen, speakOpen), 'set');
    // The Cubism model already provides eye blink and motion curves. A minimum blend
    // lets state expressions close eyes without disabling its native random blinking.
    put('ParamEyeLOpen', cur.eyeOpen, 'min');
    put('ParamEyeROpen', cur.eyeOpen, 'min');
    put('ParamEyeLSmile', cur.eyeSmile, 'add');
    put('ParamEyeRSmile', cur.eyeSmile, 'add');
    put('ParamCheek', cur.cheek, 'add');
    put('ParamBrowLY', cur.browY, 'add');
    put('ParamBrowRY', cur.browY, 'add');
    put('ParamBrowLAngle', cur.browAngle, 'add');
    put('ParamBrowRAngle', cur.browAngle, 'add');
    // Add gaze instead of setting it: previous code erased the model's own eye motion.
    put('ParamEyeBallX', gazeX, 'add');
    put('ParamEyeBallY', gazeY, 'add');
    put('ParamAngleX', cur.angleX + gazeX * 5.5 + idleSway * 0.45, 'add');
    put('ParamAngleY', cur.angleY + bounce * 2 + breath * 0.12 + talkNod, 'add');
    put('ParamAngleZ', cur.angleZ + shake * 1.5 + idleSway * 0.5, 'add');
    put('ParamBodyAngleX', cur.bodyX + gazeX * 1.6 + idleSway * 0.4, 'add');
    put('ParamBodyAngleY', bounce * 3 + Math.sin(t * 1.25) * 0.45, 'add');
    put('ParamBodyAngleZ', cur.bodyZ + shake * 0.6 + idleSway * 0.35, 'add');
    put('ParamShoulderY', Math.sin(t * 1.25) * 0.12, 'add');
    put('ParamBreath', 0.42 + Math.sin(t * 1.25) * 0.08, 'add');
  }

  /* ---------- framing ---------- */
  // Measured from Hiyori.moc3 with Cubism Core 4.2.2 (rest pose, canvas pixels):
  // canvas 2976x4175, hair/ahoge top y=303, chin y=1014, character x-range 922..2126.
  const M = { canvasW: 2976, top: 303, chin: 1014, left: 922, right: 2126 };
  // Targets taken from the Nara screenshots: where the head starts and how tall the head is,
  // as a fraction of the stage height (the body is cropped by the stage bottom like Nara's).
  const FRAME = {
    full: { top: 0.188, head: 0.32, maxW: 0.92 },
    compact: { top: 0.022, head: 0.41, maxW: 0.92 }
  };
  function fit() {
    if (!app || !model) return;
    const box = $('stageBox');
    const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
    app.renderer.resize(W, H);
    const cfg = compact ? FRAME.compact : FRAME.full;
    const baseW = model.width / model.scale.x;          // should be the 2976px canvas
    const unit = baseW > 0 ? M.canvasW / baseW : 1;
    let s = (cfg.head * H) / (M.chin - M.top);
    s = Math.min(s, (cfg.maxW * W) / (M.right - M.left)) * userZoom;
    model.scale.set(s * unit);
    model.x = W / 2 - ((M.left + M.right) / 2) * s;
    model.y = H * (cfg.top + userDy) - M.top * s;
  }
  window.wapfireFrame = (zoom, dy) => { /* debugging aid: window.wapfireFrame(1.1, 0.02) */ fit(); return { zoom, dy }; };

  /* ---------- boot ---------- */
  async function boot() {
    if (!window.Live2DCubismCore) throw new Error('Live2D Cubism Core did not load.');
    if (!window.PIXI || !PIXI.live2d) throw new Error('Pixi / Live2D plugin did not load.');
    window.__wfEngineBooted = true;
    try { PIXI.live2d.Live2DModel.registerTicker(PIXI.Ticker); } catch (e) { /* already registered */ }

    const canvas = $('stage');
    app = new PIXI.Application({
      view: canvas, autoStart: true, antialias: true, backgroundAlpha: 0,
      resolution: Math.min(window.devicePixelRatio || 1, 2), autoDensity: true,
      width: Math.max(40, canvas.clientWidth || 300), height: Math.max(40, canvas.clientHeight || 300)
    });
    model = await PIXI.live2d.Live2DModel.from('./model/Hiyori.model3.json', { autoInteract: false });
    app.stage.addChild(model);

    const core = model.internalModel.coreModel;
    rawModel = core._model || (core.getModel && core.getModel());
    if (!rawModel || !rawModel.parameters) throw new Error('Unexpected Live2D model structure.');
    bindParameters();
    model.internalModel.on('beforeModelUpdate', applyPose);

    fit();
    startModelIdleMotion();
    // Retry once after the first model update; some Cubism runtimes do not accept an
    // idle motion until their first ticker cycle has initialized the motion state.
    idleMotionRetry = window.setTimeout(startModelIdleMotion, 700);
    if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
    window.addEventListener('resize', () => requestAnimationFrame(fit));
    window.addEventListener('pagehide', () => { if (idleMotionRetry) clearTimeout(idleMotionRetry); });
    showState(pendingState);
    // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    fit();
    ready = true;
    window.__wfRendererReady = true;
    $('loading').style.display = 'none';
    try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
  }
  showState(pendingState);
  boot().catch((error) => fatal('Hiyori failed to start: ' + ((error && error.message) || error)));
})();
