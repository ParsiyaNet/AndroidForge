import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 103
        versionName = "4.2.1"
        ndk {
            // Phone targets only; omit x86 native payload from the bundled inference runtime.
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
    androidResources {
        noCompress += listOf("onnx")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

val sherpaRuntimeAar = file("libs/sherpa-onnx-2.0.1.aar")

dependencies {
    // The lazy file tree stays empty during IDE sync; ensureOfflineVoiceBundle
    // adds the checksum-verified AAR before compile tasks resolve this classpath.
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("sherpa-onnx-*.aar"))))

    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// WAPFire 4.1.50: fetch the selected AndroidForge character package at build time.
// Source: https://github.com/ParsiyaNet/AndroidForge/blob/main/v06_clean.livliv
// The .livliv archive is embedded in the APK; runtime remains offline.
val downloadV06CleanCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val previewDir = file("src/main/assets/assistant/characters/v03")
    val expectedGitBlobSha1 = "112bbede0967362103ec297a368b881531bf00c5"
    val sourceUrl = "https://raw.githubusercontent.com/ParsiyaNet/AndroidForge/main/v06_clean.livliv"

    outputs.files(modelAsset, File(previewDir, "cover.webp"), File(previewDir, "avatar.webp"))
    outputs.upToDateWhen { false }

    doLast {
        fun gitBlobSha1(file: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
        }

        modelAsset.parentFile.mkdirs()
        previewDir.mkdirs()
        val tempModel = File(modelAsset.parentFile, "v06-clean.download.livliv")
        var lastFailure: Exception? = null
        var downloaded = false

        for (attempt in 1..3) {
            var activeConnection: HttpURLConnection? = null
            try {
                val connection = URL(sourceUrl).openConnection() as HttpURLConnection
                activeConnection = connection
                connection.connectTimeout = 30000
                connection.readTimeout = 120000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.50")
                connection.setRequestProperty("Accept", "application/octet-stream")
                val status = connection.responseCode
                if (status != HttpURLConnection.HTTP_OK) {
                    throw IOException("HTTP $status from $sourceUrl")
                }
                connection.inputStream.use { input ->
                    tempModel.outputStream().use { output -> input.copyTo(output) }
                }

                val actualSha = gitBlobSha1(tempModel)
                if (actualSha != expectedGitBlobSha1) {
                    throw GradleException("AndroidForge v06_clean.livliv changed: expected $expectedGitBlobSha1, received $actualSha")
                }

                val entries = linkedSetOf<String>()
                ZipFile(tempModel).use { archive ->
                    archive.entries().asSequence().filterNot { it.isDirectory }.forEach { entry ->
                        val name = entry.name.replace('\\', '/')
                        if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) {
                            throw GradleException("Unsafe path in v06_clean.livliv: ${entry.name}")
                        }
                        entries.add(name)
                    }
                    if (entries.none { it.substringAfterLast('/') == "model.json" }) {
                        throw GradleException("v06_clean.livliv does not contain model.json")
                    }
                    if (entries.none { it.substringAfterLast('/') == "avatar.webp" }) {
                        throw GradleException("v06_clean.livliv does not contain avatar.webp")
                    }
                    val imageCount = entries.count { it.substringAfterLast('.').lowercase() in setOf("webp", "png", "jpg", "jpeg") }
                    if (imageCount < 10) throw GradleException("v06_clean.livliv image set looks incomplete ($imageCount image files)")

                    listOf("cover.webp", "avatar.webp").forEach { wanted ->
                        val entry = archive.entries().asSequence().firstOrNull { !it.isDirectory && it.name.substringAfterLast('/') == wanted }
                        if (entry != null) {
                            val destination = File(previewDir, wanted)
                            archive.getInputStream(entry).use { input ->
                                destination.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                    }
                }

                Files.move(tempModel.toPath(), modelAsset.toPath(), StandardCopyOption.REPLACE_EXISTING)
                downloaded = true
                logger.lifecycle("Downloaded and verified AndroidForge v06_clean.livliv (Git blob SHA-1 $actualSha). Character assets are embedded; runtime remains offline.")
                break
            } catch (error: Exception) {
                lastFailure = error
                tempModel.delete()
                logger.warn("AndroidForge v06_clean.livliv download attempt $attempt failed: ${error.message}")
            } finally {
                activeConnection?.disconnect()
            }
        }
        tempModel.delete()
        if (!downloaded) {
            throw GradleException("Could not download and package AndroidForge v06_clean.livliv. Check GitHub access from the build runner.", lastFailure)
        }
    }
}

// WAPFire 4.2.1: package a bilingual, fully offline Persian/English voice.
// Sherpa-ONNX 2.0.1 AAR and Musa Matcha model are downloaded only when absent/invalid,
// then the model is copied into app assets and therefore into the generated APK.
val offlineVoiceDir = file("src/main/assets/tts/fa_en_musa")
val offlineVoiceModel = File(offlineVoiceDir, "model.onnx")
val offlineVoiceVocoder = File(offlineVoiceDir, "vocoder.onnx")
val offlineVoiceTokens = File(offlineVoiceDir, "tokens.txt")
val offlineVoiceData = File(offlineVoiceDir, "espeak-ng-data")

val ensureOfflineVoiceBundle by tasks.registering {
    outputs.files(sherpaRuntimeAar, offlineVoiceModel, offlineVoiceVocoder, offlineVoiceTokens)
    outputs.dir(offlineVoiceData)
    outputs.upToDateWhen {
        sherpaRuntimeAar.isFile && sherpaRuntimeAar.length() > 30_000_000L &&
            offlineVoiceModel.isFile && offlineVoiceModel.length() > 50_000_000L &&
            offlineVoiceVocoder.isFile && offlineVoiceVocoder.length() > 1_000_000L &&
            offlineVoiceTokens.isFile && offlineVoiceTokens.length() > 100L &&
            offlineVoiceData.isDirectory && offlineVoiceData.walkTopDown().any { it.isFile }
    }

    doLast {
        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
        }

        fun download(url: String, destination: File, expectedSha256: String? = null) {
            destination.parentFile?.mkdirs()
            if (destination.isFile && destination.length() > 1024L &&
                (expectedSha256 == null || sha256(destination).equals(expectedSha256, true))) return
            destination.delete()
            val temp = File(destination.parentFile, destination.name + ".download")
            var failure: Exception? = null
            for (attempt in 1..3) {
                var connection: HttpURLConnection? = null
                try {
                    val active = URL(url).openConnection() as HttpURLConnection
                    connection = active
                    active.connectTimeout = 30000
                    active.readTimeout = 300000
                    active.instanceFollowRedirects = true
                    active.setRequestProperty("User-Agent", "WAPFire-Mobile/4.2.1 Offline-TTS")
                    active.setRequestProperty("Accept", "application/octet-stream")
                    if (active.responseCode != HttpURLConnection.HTTP_OK) {
                        throw IOException("HTTP ${active.responseCode} for $url")
                    }
                    active.inputStream.use { input -> temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) } }
                    if (temp.length() <= 1024L) throw IOException("Downloaded file is unexpectedly small: $url")
                    if (expectedSha256 != null && !sha256(temp).equals(expectedSha256, true)) {
                        throw IOException("SHA-256 verification failed for $url")
                    }
                    Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    return
                } catch (error: Exception) {
                    failure = error
                    temp.delete()
                    logger.warn("Offline voice download attempt $attempt failed: ${error.message}")
                } finally {
                    connection?.disconnect()
                }
            }
            throw GradleException("Could not download the offline voice component: $url", failure)
        }

        // Official Sherpa-ONNX Android runtime. SHA-256 is published by its v2.0.1 release.
        download(
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.1/sherpa-onnx-2.0.1.aar",
            sherpaRuntimeAar,
            "a8d09d1d32f3eb8520482c6d3d43fae674681c5b050385967c70a3c2c9bf0ee7"
        )

        val validAssets = offlineVoiceModel.isFile && offlineVoiceModel.length() > 50_000_000L &&
            offlineVoiceVocoder.isFile && offlineVoiceVocoder.length() > 1_000_000L &&
            offlineVoiceTokens.isFile && offlineVoiceTokens.length() > 100L &&
            offlineVoiceData.isDirectory && offlineVoiceData.walkTopDown().any { it.isFile }
        if (!validAssets) {
            val work = layout.buildDirectory.dir("offline-voice-musa").get().asFile
            work.deleteRecursively()
            val extracted = File(work, "extract").apply { mkdirs() }
            val archive = File(work, "matcha-tts-fa_en-musa.tar.bz2")
            val vocoderDownload = File(work, "vocos-22khz-univ.onnx")
            download(
                "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/matcha-tts-fa_en-musa.tar.bz2",
                archive
            )
            download(
                "https://github.com/k2-fsa/sherpa-onnx/releases/download/vocoder-models/vocos-22khz-univ.onnx",
                vocoderDownload
            )

            // Windows 10/11 and Linux both provide a tar executable with bzip2 support.
            val process = ProcessBuilder("tar", "-xjf", archive.absolutePath, "-C", extracted.absolutePath)
                .redirectErrorStream(true).start()
            val tarOutput = process.inputStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()
            if (exitCode != 0) throw GradleException("Could not extract offline voice model archive (tar exit $exitCode): $tarOutput")

            val acoustic = extracted.walkTopDown().firstOrNull { file ->
                file.isFile && file.extension.equals("onnx", true) &&
                    (file.name.contains("musa", true) || file.name.equals("model.onnx", true))
            } ?: throw GradleException("Musa Matcha acoustic model was not found in the downloaded package")
            val tokens = extracted.walkTopDown().firstOrNull { file ->
                file.isFile && (file.name.equals("tokens.txt", true) || file.name.equals("tokens_sherpa_with_fa.txt", true))
            } ?: throw GradleException("Musa Persian/English token vocabulary was not found in the downloaded package")
            val espeak = extracted.walkTopDown().firstOrNull { file -> file.isDirectory && file.name.equals("espeak-ng-data", true) }
                ?: throw GradleException("Musa phoneme data (espeak-ng-data) was not found in the downloaded package")

            // Pin the exact CC0 Musa checkpoint published for this bilingual model.
            val expectedModelSha = "3f7ab414560cc15185405d73c09260f4ffcfdd86f2025c78a93f9ccf86b123a1"
            if (!sha256(acoustic).equals(expectedModelSha, true)) {
                throw GradleException("Unexpected Musa acoustic model SHA-256 ${sha256(acoustic)}; refusing to package an unverified model")
            }
            offlineVoiceDir.deleteRecursively()
            offlineVoiceDir.mkdirs()
            Files.copy(acoustic.toPath(), offlineVoiceModel.toPath(), StandardCopyOption.REPLACE_EXISTING)
            Files.copy(tokens.toPath(), offlineVoiceTokens.toPath(), StandardCopyOption.REPLACE_EXISTING)
            Files.copy(vocoderDownload.toPath(), offlineVoiceVocoder.toPath(), StandardCopyOption.REPLACE_EXISTING)
            espeak.copyRecursively(offlineVoiceData, overwrite = true)
            work.deleteRecursively()
        }

        logger.lifecycle("Verified and packaged Sherpa-ONNX 2.0.1 + Musa FA/EN Matcha offline voice assets.")
    }
}

tasks.named("preBuild").configure {
    dependsOn(downloadV06CleanCharacter, ensureOfflineVoiceBundle)
}

