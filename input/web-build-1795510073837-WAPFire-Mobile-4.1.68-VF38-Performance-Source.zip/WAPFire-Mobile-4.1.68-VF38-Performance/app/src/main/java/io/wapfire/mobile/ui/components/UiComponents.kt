package io.wapfire.mobile.ui.components

import io.wapfire.mobile.model.*


import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.ComposeShader as AndroidComposeShader
import android.graphics.LinearGradient as AndroidLinearGradient
import android.graphics.RadialGradient as AndroidRadialGradient
import android.graphics.Shader as AndroidShader
import android.graphics.PorterDuff
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject


@Composable
internal fun ColorPickerField(
    p: Palette,
    fa: Boolean,
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panelAlt.copy(alpha = .58f))
            .border(1.dp, p.border.copy(alpha = .75f), RoundedCornerShape(14.dp))
            .clickable { open = true }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(runCatching { Color(AndroidColor.parseColor(value)) }.getOrDefault(Color.Red))
            .border(1.dp, Color.White.copy(alpha = .45f), RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(value.uppercase(Locale.US), color = p.muted, fontSize = 10.sp)
        }
        Text(tx(fa, "Choose", "انتخاب رنگ"), color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    if (open) ColorPickerDialog(p, fa, label, value, onDismiss = { open = false }, onApply = { onValueChange(it); open = false })
}

@Composable
internal fun ColorPickerDialog(
    p: Palette,
    fa: Boolean,
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    val hsv = remember(initial) {
        val values = floatArrayOf(0f, 1f, 1f)
        runCatching { AndroidColor.colorToHSV(AndroidColor.parseColor(initial), values) }
        values
    }
    var hue by remember(initial) { mutableStateOf(hsv[0]) }
    var saturation by remember(initial) { mutableStateOf(hsv[1]) }
    var brightness by remember(initial) { mutableStateOf(hsv[2]) }
    val pickedInt = AndroidColor.HSVToColor(floatArrayOf(hue, saturation, brightness))
    val pickedCompose = Color(pickedInt)
    val hex = String.format(Locale.US, "#%06X", pickedInt and 0xFFFFFF)
    fun updateSv(x: Float, y: Float, width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        saturation = (x / width).coerceIn(0f, 1f)
        brightness = (1f - y / height).coerceIn(0f, 1f)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = p.text) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SaturationValueColorPicker(
                    hue = hue, saturation = saturation, brightness = brightness,
                    onPick = { x, y, w, h -> updateSv(x, y, w, h) }
                )
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tx(fa, "Hue", "ته‌رنگ"), color = p.text, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${hue.roundToInt()}°", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(pickedCompose)
                        .border(1.dp, p.border, RoundedCornerShape(10.dp)))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(hex, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(tx(fa, "Selected color", "رنگ انتخاب‌شده"), color = p.muted, fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(hex) }) { Text(tx(fa, "Apply", "اعمال"), color = p.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(fa, "Cancel", "لغو"), color = p.muted) } }
    )
}

@Composable
internal fun SaturationValueColorPicker(
    hue: Float,
    saturation: Float,
    brightness: Float,
    onPick: (Float, Float, Float, Float) -> Unit
) {
    val hueColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, 1f, 1f)))
    Canvas(
        Modifier.fillMaxWidth().height(190.dp)
            .pointerInput(hue) {
                detectTapGestures { point -> onPick(point.x, point.y, size.width.toFloat(), size.height.toFloat()) }
            }
            .pointerInput(hue) {
                detectDragGestures { change, _ ->
                    onPick(change.position.x, change.position.y, size.width.toFloat(), size.height.toFloat())
                }
            }
    ) {
        drawRect(brush = Brush.horizontalGradient(listOf(Color.White, hueColor)))
        drawRect(brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
        val x = saturation * size.width
        val y = (1f - brightness) * size.height
        drawCircle(Color.Black.copy(alpha = .82f), radius = 11.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
        drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
internal fun Brand(p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(p.accent, p.blue))), contentAlignment = Alignment.Center) {
            Text("W", color = p.onAccent, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("WAPFIRE", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.7.sp)
            Text("WIRELESS INTELLIGENCE", color = p.muted, fontSize = 8.sp, letterSpacing = 1.1.sp)
        }
    }
}

/**
 * Full-quality Liquid Glass surface, optimized for older GPUs.
 *
 * The earlier implementation used one Android setShadowLayer + ClipOp.Difference pass for every
 * glass card. That path was expensive on older Adreno/Mali devices and was still present after the
 * 4.1.63 partial optimization. The glass itself is now rendered by one composed shader, followed
 * by the same specular edge glint and refracting rim. No color stops, alpha values, or pixel ratios
 * are reduced for older devices.
 */
@Suppress("UNUSED_PARAMETER")
internal fun Modifier.liquidGlass(
    p: Palette,
    shape: androidx.compose.ui.graphics.Shape,
    strength: Float = 1f,
    elevation: androidx.compose.ui.unit.Dp = 16.dp,
    tint: Color = p.accent,
    // When set, the glass body is drawn at exactly this opacity (used by the bottom tab bar so
    // content scrolling underneath cannot bleed through the labels).
    bodyAlpha: Float? = null
): Modifier {
    // Keep the parameter for call-site compatibility. The expensive per-card drop shadow is
    // replaced by the full-strength refracting rim; no surface shader quality is reduced.
    val dark = p.dark
    val bodyA = bodyAlpha ?: ((if (dark) .58f else .68f) * strength).coerceIn(.20f, .96f)
    val bodyB = bodyAlpha ?: ((if (dark) .40f else .52f) * strength).coerceIn(.16f, .92f)

    return this
        .clip(shape)
        .drawWithCache {
            val width = size.width
            val height = size.height
            val outline = shape.createOutline(size, layoutDirection, this)
            val glassPath = Path().apply {
                when (outline) {
                    is Outline.Rectangle -> addRect(outline.rect)
                    is Outline.Rounded -> addRoundRect(outline.roundRect)
                    is Outline.Generic -> addPath(outline.path)
                }
            }.asAndroidPath()

            val fillPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.FILL
                if (width > 0f && height > 0f) {
                    // Same three Full Glass layers as 4.1.61/4.1.63, composited in their original
                    // order by the GPU as one draw instead of three full-surface blend passes.
                    val bodyShader = AndroidLinearGradient(
                        0f, 0f, width, height,
                        intArrayOf(
                            p.panel.copy(alpha = bodyA).toArgb(),
                            p.panelAlt.copy(alpha = bodyB).toArgb(),
                            p.panel.copy(alpha = bodyA * .92f).toArgb()
                        ),
                        floatArrayOf(0f, .5f, 1f),
                        AndroidShader.TileMode.CLAMP
                    )
                    val lightBleedShader = AndroidLinearGradient(
                        0f, 0f, width, height,
                        intArrayOf(
                            tint.copy(alpha = if (dark) .17f else .10f).toArgb(),
                            Color.Transparent.toArgb(),
                            p.blue.copy(alpha = if (dark) .12f else .08f).toArgb()
                        ),
                        floatArrayOf(0f, .5f, 1f),
                        AndroidShader.TileMode.CLAMP
                    )
                    val specularShader = AndroidLinearGradient(
                        0f, 0f, 0f, height,
                        intArrayOf(
                            Color.White.copy(alpha = if (dark) .10f else .50f).toArgb(),
                            Color.Transparent.toArgb()
                        ),
                        floatArrayOf(0f, .42f),
                        AndroidShader.TileMode.CLAMP
                    )
                    // ComposeShader treats shaderA as destination and shaderB as source.
                    // This therefore reproduces the original body -> light-bleed -> sheen order.
                    val bleedOverBody = AndroidComposeShader(
                        bodyShader, lightBleedShader, PorterDuff.Mode.SRC_OVER
                    )
                    shader = AndroidComposeShader(
                        bleedOverBody, specularShader, PorterDuff.Mode.SRC_OVER
                    )
                }
            }

            // The top glint remains identical in width, position, color and opacity.
            val glintPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 1.4f
                color = android.graphics.Color.TRANSPARENT
                if (width > 0f) {
                    shader = AndroidLinearGradient(
                        width * .12f, 0f, width * .88f, 0f,
                        intArrayOf(
                            Color.Transparent.toArgb(),
                            Color.White.copy(alpha = if (dark) .55f else .95f).toArgb(),
                            Color.Transparent.toArgb()
                        ),
                        floatArrayOf(0f, .5f, 1f),
                        AndroidShader.TileMode.CLAMP
                    )
                }
            }

            // Keep the original Full Glass refracting rim and all its color stops.
            val rimColors = if (dark) intArrayOf(
                Color.White.copy(alpha = .46f).toArgb(),
                Color.White.copy(alpha = .07f).toArgb(),
                tint.copy(alpha = .12f).toArgb(),
                tint.copy(alpha = .42f).toArgb()
            ) else intArrayOf(
                Color.White.copy(alpha = .98f).toArgb(),
                p.border.copy(alpha = .55f).toArgb(),
                tint.copy(alpha = .38f).toArgb()
            )
            val rimStops = if (dark) floatArrayOf(0f, .38f, .70f, 1f)
                else floatArrayOf(0f, .40f, 1f)
            val rimPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 1.dp.toPx()
                strokeJoin = android.graphics.Paint.Join.ROUND
                color = android.graphics.Color.TRANSPARENT
                if (width > 0f && height > 0f) {
                    shader = AndroidLinearGradient(
                        0f, 0f, width, height,
                        rimColors,
                        rimStops,
                        AndroidShader.TileMode.CLAMP
                    )
                }
            }

            val glintStartX = width * .12f
            val glintEndX = width * .88f
            onDrawBehind {
                drawIntoCanvas { canvas ->
                    val native = canvas.nativeCanvas
                    native.drawPath(glassPath, fillPaint)
                    native.drawLine(glintStartX, 1.2f, glintEndX, 1.2f, glintPaint)
                    native.drawPath(glassPath, rimPaint)
                }
            }
        }
}

/**
 * App-wide backdrop: an opaque two-tone gradient plus three soft coloured lights (accent, sky blue,
 * violet). The glass surfaces above it pick these lights up, which is what makes them look like glass.
 * Must stay fully opaque: the preloaded character WebViews are parked underneath it.
 */
@Composable
internal fun GlassBackdrop(p: Palette, modifier: Modifier = Modifier.fillMaxSize()) {
    Box(
        modifier.drawWithCache {
            val width = size.width
            val height = size.height
            if (width <= 0f || height <= 0f) {
                onDrawBehind { drawRect(p.bg) }
            } else {
                // The base gradient and all three ambient lights are composed into one shader.
                // Their order, centers, radii, colors and alpha values match the original backdrop.
                val baseShader = AndroidLinearGradient(
                    0f, 0f, 0f, height,
                    intArrayOf(p.bg.toArgb(), p.bg2.toArgb(), p.bg.toArgb()),
                    floatArrayOf(0f, .5f, 1f),
                    AndroidShader.TileMode.CLAMP
                )
                val accentShader = AndroidRadialGradient(
                    width * .95f, height * .08f, width * .80f,
                    intArrayOf(
                        p.accent.copy(alpha = if (p.dark) .30f else .24f).toArgb(),
                        Color.Transparent.toArgb()
                    ), null, AndroidShader.TileMode.CLAMP
                )
                val blueShader = AndroidRadialGradient(
                    width * .02f, height * .58f, width * .90f,
                    intArrayOf(
                        p.blue.copy(alpha = if (p.dark) .20f else .17f).toArgb(),
                        Color.Transparent.toArgb()
                    ), null, AndroidShader.TileMode.CLAMP
                )
                val violetShader = AndroidRadialGradient(
                    width * .78f, height * .98f, width * .75f,
                    intArrayOf(
                        p.violet.copy(alpha = if (p.dark) .22f else .16f).toArgb(),
                        Color.Transparent.toArgb()
                    ), null, AndroidShader.TileMode.CLAMP
                )
                // ComposeShader treats shaderA as destination and shaderB as source.
                // Keep the original accent -> blue -> violet paint order over the base gradient.
                val baseWithAccent = AndroidComposeShader(
                    baseShader, accentShader, PorterDuff.Mode.SRC_OVER
                )
                val baseWithBlue = AndroidComposeShader(
                    baseWithAccent, blueShader, PorterDuff.Mode.SRC_OVER
                )
                val fullBackdrop = AndroidComposeShader(
                    baseWithBlue, violetShader, PorterDuff.Mode.SRC_OVER
                )
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.FILL
                    shader = fullBackdrop
                }
                onDrawBehind {
                    drawIntoCanvas { canvas ->
                        canvas.nativeCanvas.drawRect(0f, 0f, width, height, paint)
                    }
                }
            }
        }
    )
}

/**
 * Space covered by the translucent top bar / floating bottom bar. Pages add it INSIDE their
 * scrolling area, so content scrolls underneath the glass bars and shows through them.
 */
internal val LocalContentInset = androidx.compose.runtime.compositionLocalOf { androidx.compose.foundation.layout.PaddingValues(0.dp) }

@Composable
internal fun ThemeAction(p: Palette, dark: Boolean, onTheme: () -> Unit) {
    // Exact Welcome Back theme glyph: one half-filled circle (contrast icon).
    // Keep the same glyph in both themes; tapping it toggles the active theme.
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(36.dp)
            .liquidGlass(p, shape, strength = .9f, elevation = 0.dp)
            .clickable { onTheme() }
            .padding(horizontal = 9.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(17.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.minDimension * .42f
            val origin = Offset(cx - radius, cy - radius)
            val diameter = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f)
            val color = p.text

            // Solid left semicircle; the right half remains transparent.
            drawArc(
                color = color,
                startAngle = 90f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = origin,
                size = diameter
            )
            // Continuous outer ring and the straight center split.
            drawCircle(color = color, radius = radius, center = Offset(cx, cy), style = Stroke(width = 1.05.dp.toPx()))
            drawLine(
                color = color,
                start = Offset(cx, cy - radius),
                end = Offset(cx, cy + radius),
                strokeWidth = 1.05.dp.toPx()
            )
        }
    }
}

@Composable
internal fun SmallAction(p: Palette, label: String, onClick: () -> Unit) {
    // Match the theme control exactly: both controls are 36 × 36 dp.
    // Keep language codes LTR even inside the Persian RTL screen.
    Box(
        Modifier.size(36.dp)
            .liquidGlass(p, RoundedCornerShape(12.dp), strength = .9f, elevation = 0.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = label,
                color = p.text,
                fontSize = if (label.length == 2) 11.sp else 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp)
            )
        }
    }
}

@Composable
internal fun SectionCard(p: Palette, title: String, subtitle: String = "", content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().liquidGlass(p, shape, strength = 1.05f, elevation = 14.dp)
        .padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        content.invoke(this)
    }
}

@Composable
internal fun ScheduleTimePickerField(
    p: Palette,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    onTimeSelected: (String) -> Unit
) {
    val context = LocalContext.current
    val safeValue = normalizeScheduleTime(value, "22:00")
    val parts = safeValue.split(":")
    val initialHour = parts[0].toInt()
    val initialMinute = parts[1].toInt()
    OutlinedButton(
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute -> onTimeSelected(String.format(Locale.US, "%02d:%02d", hour, minute)) },
                initialHour,
                initialMinute,
                true
            ).show()
        },
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(13.dp),
        border = BorderStroke(1.dp, p.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp), horizontalAlignment = Alignment.Start) {
            Text(label, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(safeValue, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
internal fun MessageCard(p: Palette, message: String, danger: Boolean, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(p.panel)
            .border(1.dp, (if (danger) p.red else p.green).copy(alpha = .72f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (danger) "!" else "✓", color = if (danger) p.red else p.green, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(9.dp))
        Text(
            message,
            color = p.text,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(28.dp).clip(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
            Text("×", color = p.muted, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun ActionButton(p: Palette, label: String, onClick: () -> Unit, enabled: Boolean = true, primary: Boolean = false, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    val fg = if (primary) p.onAccent else p.text
    val base = if (primary) {
        // Primary buttons: a lit accent -> sky gradient with a glossy top edge.
        Modifier.clip(shape)
            .background(Brush.linearGradient(listOf(p.accent, p.blue)), alpha = if (enabled) 1f else .45f)
            .background(Brush.verticalGradient(0f to Color.White.copy(alpha = if (enabled) .30f else .10f), .55f to Color.Transparent))
            .border(1.dp, Color.White.copy(alpha = if (p.dark) .34f else .55f), shape)
    } else {
        Modifier.liquidGlass(p, shape, strength = if (enabled) .9f else .55f, elevation = 0.dp)
    }
    Box(modifier.then(base).clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) fg else p.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun NativeField(p: Palette, value: String, onValue: (String) -> Unit, label: String, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text, focusRequester: FocusRequester? = null) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth().then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        label = { Text(label, fontSize = 12.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(13.dp),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = p.text, unfocusedTextColor = p.text,
            focusedBorderColor = p.accent, unfocusedBorderColor = p.border,
            focusedLabelColor = p.accent, unfocusedLabelColor = p.muted,
            cursorColor = p.accent
        )
    )
}

@Composable
internal fun DeviceResult(p: Palette, title: String, detail: String, badge: String, onClick: () -> Unit, action: String, selected: Boolean = false, enabled: Boolean = true) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape)
        .background(if (selected) Brush.linearGradient(listOf(p.accentSoft.copy(alpha = .82f), p.accentSoft.copy(alpha = .58f))) else Brush.linearGradient(listOf(p.panelAlt.copy(alpha = .82f), p.panel.copy(alpha = .64f))))
        .border(1.dp, if (selected) p.accent else p.border.copy(alpha = .68f), shape)
        .clickable(enabled = enabled && action.isNotBlank()) { onClick() }.padding(11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(p.accentSoft), contentAlignment = Alignment.Center) { Text("⌁", color = p.accent, fontSize = 18.sp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (badge.isNotBlank()) Text(badge, color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        if (action.isNotBlank()) Text(action, color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun MetricTile(p: Palette, value: String, label: String, glyph: String, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Column(modifier.liquidGlass(p, shape, strength = .95f, elevation = 10.dp, tint = color)
        .padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(glyph, color = color, fontSize = 15.sp); Spacer(Modifier.weight(1f)); Box(Modifier.size(5.dp).clip(CircleShape).background(color)) }
        Text(value, color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = p.muted, fontSize = 10.sp)
    }
}

@Composable
internal fun ThreatRing(p: Palette, score: Float, level: String) {
    val normalizedScore = score.coerceIn(0f, 10f)
    // 4.1.61: the Overview status card now follows the active theme (glass in dark AND light),
    // so the ring uses the theme's own status colours, which are tuned for contrast in each mode.
    val color = when (level.uppercase()) {
        "CRITICAL", "HIGH" -> p.red
        "WARNING", "MONITORING", "MEDIUM", "MODERATE" -> p.orange
        "OPTIMAL", "LOW" -> p.green
        else -> p.blue
    }
    val scoreText = String.format(Locale.US, "%.1f", normalizedScore)
    Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(color.copy(alpha = .18f), -90f, 360f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
            // Firmware score_tenths is 0..100 (= 0.0..10.0). One risk point is 36 degrees.
            drawArc(color, -90f, normalizedScore * 36f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("$scoreText/10", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(level.uppercase(), color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
internal fun NativeLineChart(p: Palette, primary: List<Int>, secondary: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val pad = 8.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        for (i in 0..3) {
            val y = pad + h * i / 3f
            drawLine(p.border, Offset(pad, y), Offset(size.width - pad, y), 1.dp.toPx())
        }
        fun drawSeries(values: List<Int>, color: Color, stroke: Float) {
            if (values.size < 2) return
            val max = (primary + secondary).maxOrNull()?.coerceAtLeast(1) ?: 1
            val path = Path()
            values.forEachIndexed { index, v ->
                val x = pad + (w * index / (values.size - 1).toFloat())
                val y = pad + h - (v.coerceAtLeast(0).toFloat() / max) * h
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        drawSeries(primary, p.accent, 2.5.dp.toPx())
        drawSeries(secondary, p.blue, 2.dp.toPx())
    }
}

@Composable
internal fun NativeMetricChart(
    p: Palette,
    values: List<Float>,
    color: Color,
    fixedPercentScale: Boolean = false,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val padX = 5.dp.toPx()
        val padY = 5.dp.toPx()
        val chartWidth = (size.width - padX * 2f).coerceAtLeast(1f)
        val chartHeight = (size.height - padY * 2f).coerceAtLeast(1f)
        for (i in 0..2) {
            val y = padY + chartHeight * i / 2f
            drawLine(p.border.copy(alpha = 0.75f), Offset(padX, y), Offset(size.width - padX, y), 0.8.dp.toPx())
        }
        if (values.isEmpty()) return@Canvas

        val series = values.takeLast(48)
        val rawMin = series.minOrNull() ?: 0f
        val rawMax = series.maxOrNull() ?: 1f
        val rangeMin: Float
        val rangeMax: Float
        if (fixedPercentScale) {
            rangeMin = 0f
            rangeMax = 100f
        } else {
            val span = (rawMax - rawMin).coerceAtLeast(1f)
            val margin = span * 0.12f
            rangeMin = (rawMin - margin).coerceAtLeast(0f)
            rangeMax = rawMax + margin
        }
        val range = (rangeMax - rangeMin).coerceAtLeast(1f)
        val path = Path()
        var lastPoint = Offset(padX, size.height - padY)
        series.forEachIndexed { index, value ->
            val x = if (series.size <= 1) padX + chartWidth else padX + chartWidth * index / (series.size - 1).toFloat()
            val normalized = ((value - rangeMin) / range).coerceIn(0f, 1f)
            val y = padY + chartHeight * (1f - normalized)
            val point = Offset(x, y)
            if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
            lastPoint = point
        }
        drawPath(path, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(color, radius = 3.dp.toPx(), center = lastPoint)
    }
}

internal fun LegendDot(color: Color, label: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(label, color = p.muted, fontSize = 9.sp)
    }
}

@Composable
internal fun MiniValue(p: Palette, value: String, label: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.muted, fontSize = 8.sp)
    }
}

@Composable
internal fun ToggleRow(p: Palette, title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
internal fun DividerLine(p: Palette) { Box(Modifier.fillMaxWidth().height(1.dp).background(p.border)) }

@Composable
internal fun InfoLine(p: Palette, key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
