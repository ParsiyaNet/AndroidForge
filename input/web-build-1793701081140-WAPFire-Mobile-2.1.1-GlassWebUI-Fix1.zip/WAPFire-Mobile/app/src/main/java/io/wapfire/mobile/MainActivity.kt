package io.wapfire.mobile

import android.app.DownloadManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import org.json.JSONObject

private enum class AppStage { DISCOVERY, CONSOLE }
private enum class ConsolePage(val route: String, val titleEn: String, val titleFa: String, val glyph: String) {
    OVERVIEW("/home", "Overview", "نمای کلی", "◉"),
    TARGET("/settings", "Target AP", "اکسس‌پوینت هدف", "⌖"),
    SETTINGS("/settings", "Settings", "تنظیمات", "⚙"),
    LOGS("/logs", "Activity", "رویدادها", "≋"),
    SETUP("/setup", "Setup", "راه‌اندازی", "✧")
}

private data class AppPalette(
    val backgroundTop: Color,
    val backgroundBottom: Color,
    val surface: Color,
    val surfaceStrong: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accent2: Color,
    val success: Color,
    val danger: Color,
    val shadow: Color
)

private fun palette(dark: Boolean) = if (dark) AppPalette(
    backgroundTop = Color(0xFF0A202A),
    backgroundBottom = Color(0xFF07111C),
    surface = Color(0xCC142B38),
    surfaceStrong = Color(0xF0183040),
    border = Color(0x665DADB2),
    text = Color(0xFFF0F7FA),
    muted = Color(0xFFA2B7C2),
    accent = Color(0xFF66E8D1),
    accent2 = Color(0xFF88A9FF),
    success = Color(0xFF6CE7A7),
    danger = Color(0xFFFF7889),
    shadow = Color(0x55000000)
) else AppPalette(
    backgroundTop = Color(0xFFF5FBFE),
    backgroundBottom = Color(0xFFDDEAF0),
    surface = Color(0xCCFFFFFF),
    surfaceStrong = Color(0xF4FFFFFF),
    border = Color(0xB8FFFFFF),
    text = Color(0xFF183141),
    muted = Color(0xFF5D7583),
    accent = Color(0xFF087F78),
    accent2 = Color(0xFF526FD1),
    success = Color(0xFF168B5A),
    danger = Color(0xFFC94355),
    shadow = Color(0x220A3548)
)

class MainActivity : ComponentActivity() {
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uploadCallback?.onReceiveValue(uri?.let { arrayOf(it) })
        uploadCallback = null
    }

    fun showFilePicker(callback: ValueCallback<Array<Uri>>): Boolean {
        uploadCallback?.onReceiveValue(null)
        uploadCallback = callback
        return try {
            filePicker.launch("*/*")
            true
        } catch (_: Exception) {
            uploadCallback = null
            false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        setContent { WapFireMobileApp() }
    }

    override fun onDestroy() {
        uploadCallback?.onReceiveValue(null)
        uploadCallback = null
        super.onDestroy()
    }
}

@Composable
private fun WapFireMobileApp() {
    val context = LocalContext.current
    val activity = remember(context) { context.findMainActivity() }
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("wapfire_mobile_v2", Context.MODE_PRIVATE) }
    val discovery = remember { WifiDiscovery(context) }
    val connector = remember { WifiConnector(context) }

    var stage by remember { mutableStateOf(AppStage.DISCOVERY) }
    var darkTheme by remember { mutableStateOf(prefs.getBoolean("dark_theme", true)) }
    var isFa by remember { mutableStateOf(prefs.getBoolean("persian", false)) }
    var currentWifi by remember { mutableStateOf(discovery.current()) }
    var wifiResults by remember { mutableStateOf<List<WifiAccessPoint>>(emptyList()) }
    var lanDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var manualHost by remember { mutableStateOf(prefs.getString("last_host", "192.168.4.1") ?: "192.168.4.1") }
    var wifiPassword by remember { mutableStateOf("") }
    var host by remember { mutableStateOf(prefs.getString("last_host", "192.168.4.1") ?: "192.168.4.1") }
    var connecting by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var selectedSsid by remember { mutableStateOf("") }
    var page by remember { mutableStateOf(ConsolePage.OVERVIEW) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var webLoading by remember { mutableStateOf(true) }
    var webError by remember { mutableStateOf("") }
    var webTitle by remember { mutableStateOf("") }

    val p = palette(darkTheme)

    LaunchedEffect(darkTheme) {
        activity?.window?.let { window ->
            window.statusBarColor = if (darkTheme) AndroidColor.rgb(7, 19, 29) else AndroidColor.rgb(245, 251, 254)
            window.navigationBarColor = if (darkTheme) AndroidColor.rgb(7, 17, 28) else AndroidColor.rgb(221, 234, 240)
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (darkTheme) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            scope.launch {
                scanning = true
                error = ""
                connector.bindToCurrentWifi()
                currentWifi = discovery.current()
                wifiResults = discovery.scan()
                lanDevices = discovery.findWapFireOnLan()
                scanning = false
                if (wifiResults.isEmpty() && lanDevices.isEmpty()) {
                    error = tx(isFa, "No matching device found. Try manual IP or connect to the WAPFire Wi-Fi first.", "دستگاهی پیدا نشد. IP را دستی وارد کن یا ابتدا به Wi-Fi دستگاه وصل شو.")
                }
            }
        } else {
            error = tx(isFa, "Wi-Fi scan permission is required for automatic discovery. Manual IP still works.", "برای جستجوی خودکار مجوز Wi-Fi لازم است؛ ورود IP دستی همچنان فعال است.")
        }
    }

    fun scanDevices() {
        val missing = WifiDiscovery.requiredPermissions().filter {
            ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
            return
        }
        scope.launch {
            scanning = true
            error = ""
            notice = ""
            try {
                connector.bindToCurrentWifi()
                currentWifi = discovery.current()
                wifiResults = discovery.scan()
                lanDevices = discovery.findWapFireOnLan()
                if (wifiResults.isEmpty() && lanDevices.isEmpty()) {
                    error = tx(isFa, "No WAPFire signature found on this Wi-Fi. Enter its IP manually.", "در این شبکه دستگاهی پیدا نشد؛ IP دستگاه را دستی وارد کن.")
                } else {
                    notice = tx(isFa, "Discovery scan completed.", "جستجوی دستگاه‌ها کامل شد.")
                }
            } catch (e: Exception) {
                error = e.message ?: tx(isFa, "Discovery failed.", "جستجو ناموفق بود.")
            } finally { scanning = false }
        }
    }

    fun openConsole(value: String) {
        val normalized = normalizeDeviceUrl(value)
        host = normalized
        manualHost = normalized.removePrefix("http://").removePrefix("https://")
        prefs.edit().putString("last_host", manualHost).apply()
        page = ConsolePage.OVERVIEW
        webLoading = true
        webError = ""
        stage = AppStage.CONSOLE
    }

    fun connectWifi(ap: WifiAccessPoint) {
        if (ap.secured && wifiPassword.isBlank()) {
            selectedSsid = ap.ssid
            error = tx(isFa, "Enter the password for ${ap.ssid} first.", "ابتدا رمز شبکهٔ ${ap.ssid} را وارد کن.")
            return
        }
        connecting = true
        error = ""
        selectedSsid = ap.ssid
        connector.connect(
            ssid = ap.ssid,
            password = if (ap.secured) wifiPassword else "",
            onAvailable = {
                connecting = false
                currentWifi = discovery.current()
                // WAPFire's default SoftAP gateway. Change it in the manual field if configured differently.
                openConsole("192.168.4.1")
                notice = tx(isFa, "Connected to ${ap.ssid}. Opening WAPFire…", "به شبکه ${ap.ssid} وصل شدی؛ در حال بازکردن WAPFire…")
            },
            onUnavailable = {
                connecting = false
                error = tx(isFa, "Could not connect to ${ap.ssid}. Check the password or connect in Android Wi-Fi settings.", "اتصال به ${ap.ssid} ناموفق بود؛ رمز را بررسی کن یا از تنظیمات Wi-Fi اندروید وصل شو.")
            },
            onLost = {
                connecting = false
                if (stage == AppStage.CONSOLE) webError = tx(isFa, "Wi-Fi connection was lost. Reconnect to WAPFire and retry.", "اتصال Wi-Fi قطع شد؛ دوباره به WAPFire وصل شو.")
            }
        )
    }

    fun connectToCurrentWifi() {
        val current = discovery.current()
        currentWifi = current
        connector.bindToCurrentWifi()
        val candidate = when {
            current.ssid.contains("wapfire", true) || current.localIp.startsWith("192.168.4.") -> current.gateway.ifBlank { "192.168.4.1" }
            lanDevices.size == 1 -> lanDevices.first()
            lanDevices.size > 1 -> {
                error = tx(isFa, "More than one WAPFire device was found. Choose one from the results below.", "بیش از یک دستگاه WAPFire پیدا شد؛ یکی را از فهرست انتخاب کن.")
                return
            }
            else -> ""
        }
        if (candidate.isBlank()) {
            error = tx(isFa, "No WAPFire device was verified on this network. Scan the LAN or enter its IP manually.", "در این شبکه دستگاه WAPFire تأیید نشد؛ LAN را جستجو کن یا IP را دستی وارد کن.")
        } else openConsole(candidate)
    }

    LaunchedEffect(Unit) {
        currentWifi = discovery.current()
        connector.bindToCurrentWifi()
        if (currentWifi.ssid.contains("wapfire", true)) {
            manualHost = "192.168.4.1"
            host = manualHost
        }
    }

    MaterialTheme(colorScheme = if (darkTheme) darkColorScheme(
        primary = p.accent, secondary = p.accent2, background = p.backgroundBottom,
        surface = p.surfaceStrong, onPrimary = Color(0xFF06151B), onBackground = p.text,
        onSurface = p.text, outline = p.border
    ) else lightColorScheme(
        primary = p.accent, secondary = p.accent2, background = p.backgroundBottom,
        surface = p.surfaceStrong, onPrimary = Color.White, onBackground = p.text,
        onSurface = p.text, outline = p.border
    )) {
        if (stage == AppStage.DISCOVERY) {
            DiscoveryScreen(
                p = p,
                isFa = isFa,
                currentWifi = currentWifi,
                networks = wifiResults,
                lanDevices = lanDevices,
                manualHost = manualHost,
                onManualHost = { manualHost = it },
                wifiPassword = wifiPassword,
                onWifiPassword = { wifiPassword = it },
                selectedSsid = selectedSsid,
                scanning = scanning,
                connecting = connecting,
                error = error,
                notice = notice,
                darkTheme = darkTheme,
                onTheme = {
                    val nextDark = !darkTheme
                    darkTheme = nextDark
                    prefs.edit().putBoolean("dark_theme", nextDark).apply()
                },
                onLanguage = {
                    val nextFa = !isFa
                    isFa = nextFa
                    prefs.edit().putBoolean("persian", nextFa).apply()
                },
                onScan = { scanDevices() },
                onConnectWifi = { connectWifi(it) },
                onUseLan = { openConsole(it) },
                onUseCurrent = { connectToCurrentWifi() },
                onManualConnect = {
                    if (manualHost.isBlank()) error = tx(isFa, "Enter an IP address or hostname.", "IP یا نام میزبان را وارد کن.")
                    else openConsole(manualHost)
                },
                onClearMessages = { error = ""; notice = "" }
            )
        } else {
            WebConsoleScreen(
                p = p,
                isFa = isFa,
                darkTheme = darkTheme,
                host = host,
                webView = webView,
                page = page,
                loading = webLoading,
                error = webError,
                webTitle = webTitle,
                onPage = { next ->
                    page = next
                    webError = ""
                },
                onTheme = {
                    val nextDark = !darkTheme
                    darkTheme = nextDark
                    prefs.edit().putBoolean("dark_theme", nextDark).apply()
                },
                onLanguage = {
                    val nextFa = !isFa
                    isFa = nextFa
                    prefs.edit().putBoolean("persian", nextFa).apply()
                    webView?.evaluateJavascript(webLanguageScript(nextFa), null)
                },
                onDisconnect = {
                    webView?.stopLoading()
                    webView?.loadUrl("about:blank")
                    webView?.destroy()
                    webView = null
                    connector.release()
                    stage = AppStage.DISCOVERY
                    webError = ""
                    webLoading = true
                },
                onRefresh = { webError = ""; webView?.reload() },
                onRetry = {
                    connector.bindToCurrentWifi()
                    webError = ""
                    webLoading = true
                    webView?.loadUrl(host.trimEnd('/') + "/")
                },
                onWebTitle = { webTitle = it },
                onWebLoading = { webLoading = it },
                onWebError = { webError = it },
                onWebView = { webView = it },
                onFilePicker = { callback -> activity?.showFilePicker(callback) ?: false }
            )
        }
    }

    BackHandler(enabled = stage == AppStage.CONSOLE) {
        if (webView?.canGoBack() == true) webView?.goBack()
        else {
            webView?.stopLoading()
            webView?.loadUrl("about:blank")
            webView?.destroy()
            webView = null
            connector.release()
            stage = AppStage.DISCOVERY
        }
    }
}


private fun Context.findMainActivity(): MainActivity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is MainActivity) return current
        current = current.baseContext
    }
    return current as? MainActivity
}

private fun normalizeDeviceUrl(input: String): String {
    var value = input.trim().trimEnd('/')
    if (value.isBlank()) value = "192.168.4.1"
    if (!value.startsWith("http://", true) && !value.startsWith("https://", true)) value = "http://$value"
    return value
}

private fun tx(isFa: Boolean, en: String, fa: String): String = if (isFa) fa else en

@Composable
private fun DiscoveryScreen(
    p: AppPalette,
    isFa: Boolean,
    currentWifi: CurrentWifi,
    networks: List<WifiAccessPoint>,
    lanDevices: List<String>,
    manualHost: String,
    onManualHost: (String) -> Unit,
    wifiPassword: String,
    onWifiPassword: (String) -> Unit,
    selectedSsid: String,
    scanning: Boolean,
    connecting: Boolean,
    error: String,
    notice: String,
    darkTheme: Boolean,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onScan: () -> Unit,
    onConnectWifi: (WifiAccessPoint) -> Unit,
    onUseLan: (String) -> Unit,
    onUseCurrent: () -> Unit,
    onManualConnect: () -> Unit,
    onClearMessages: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(p.backgroundTop, p.backgroundBottom)))) {
        AmbientGlow(p)
        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandMark(p, Modifier.size(48.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("WAPFIRE", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp)
                    Text("WIRELESS INTELLIGENCE", color = p.muted, fontSize = 9.sp, letterSpacing = 1.7.sp)
                }
                HeaderToggle(p, if (darkTheme) "☼" else "☾", onTheme, "Theme")
                Spacer(Modifier.width(7.dp))
                HeaderToggle(p, if (isFa) "EN" else "FA", onLanguage, "Language")
            }

            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(tx(isFa, "Your network,\nunder control.", "شبکه‌ات،\nتحت کنترل تو."), color = p.text, fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                Text(
                    tx(isFa, "Discover your WAPFire appliance and open its complete control center.", "دستگاه WAPFire را پیدا کن و به مرکز کنترل کامل آن وارد شو."),
                    color = p.muted, fontSize = 13.sp, lineHeight = 20.sp
                )
            }

            if (error.isNotBlank() || notice.isNotBlank()) {
                GlassPanel(p, modifier = Modifier.fillMaxWidth()) {
                    if (error.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("!", color = p.danger, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(9.dp))
                            Text(error, color = p.text, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
                            Text("×", color = p.muted, modifier = Modifier.clickable { onClearMessages() }.padding(4.dp))
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✓", color = p.success, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(9.dp))
                            Text(notice, color = p.text, fontSize = 12.sp)
                        }
                    }
                }
            }

            GlassPanel(p) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx(isFa, "CURRENT CONNECTION", "اتصال فعلی"), color = p.muted, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(currentWifi.ssid.ifBlank { tx(isFa, "No Wi-Fi network", "اتصال Wi-Fi فعال نیست") }, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${tx(isFa, "Gateway", "دروازه")}: ${currentWifi.gateway.ifBlank { "—" }}   ·   IP: ${currentWifi.localIp.ifBlank { "—" }}", color = p.muted, fontSize = 10.sp)
                    }
                    Box(Modifier.size(40.dp).clip(CircleShape).background(p.accent.copy(alpha = .13f)).border(1.dp, p.accent.copy(alpha = .35f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("⌁", color = p.accent, fontSize = 22.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    PrimaryGlassButton(p, tx(isFa, "Use this network", "استفاده از این شبکه"), onUseCurrent, Modifier.weight(1f), enabled = currentWifi.ssid.isNotBlank() || lanDevices.isNotEmpty())
                    SecondaryGlassButton(p, tx(isFa, "Scan LAN", "جستجوی LAN"), onScan, Modifier.weight(1f), enabled = !scanning)
                }
            }

            GlassPanel(p) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx(isFa, "FIND WAPFIRE", "پیدا کردن WAPFIRE"), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(tx(isFa, "Scan nearby Wi-Fi and the current local network", "شبکه‌های Wi-Fi اطراف و شبکه محلی را جستجو کن"), color = p.muted, fontSize = 10.sp)
                    }
                    SecondaryGlassButton(p, if (scanning) tx(isFa, "Scanning…", "در حال جستجو…") else tx(isFa, "Rescan", "جستجوی مجدد"), onScan, enabled = !scanning)
                }
                if (scanning) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(17.dp), strokeWidth = 2.dp, color = p.accent)
                        Spacer(Modifier.width(10.dp))
                        Text(tx(isFa, "Searching for WAPFire devices…", "در حال جستجوی دستگاه‌های WAPFire…"), color = p.muted, fontSize = 11.sp)
                    }
                }
                if (lanDevices.isNotEmpty()) {
                    Spacer(Modifier.height(13.dp))
                    Text(tx(isFa, "FOUND ON LOCAL NETWORK", "پیدا شده در شبکه محلی"), color = p.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    lanDevices.forEach { ip ->
                        DeviceRow(p, title = "WAPFire", detail = "$ip · ${tx(isFa, "Web interface detected", "رابط وب شناسایی شد")}", meta = "LAN", action = tx(isFa, "Open", "بازکردن"), busy = false) { onUseLan(ip) }
                    }
                }
                val displayNetworks = networks.sortedWith(compareByDescending<WifiAccessPoint> { it.isWapFire }.thenByDescending { it.rssi }).take(8)
                if (displayNetworks.isNotEmpty()) {
                    Spacer(Modifier.height(13.dp))
                    Text(tx(isFa, "NEARBY WI-FI NETWORKS", "شبکه‌های Wi-Fi اطراف"), color = p.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    displayNetworks.forEach { ap ->
                        DeviceRow(
                            p = p,
                            title = ap.ssid,
                            detail = "${if (ap.secured) "WPA / secured" else "Open network"} · ${ap.frequency} MHz",
                            meta = "${ap.rssi} dBm",
                            action = if (connecting && selectedSsid == ap.ssid) tx(isFa, "Joining…", "در حال اتصال…") else tx(isFa, "Connect", "اتصال"),
                            busy = connecting && selectedSsid == ap.ssid,
                            highlighted = ap.isWapFire
                        ) { onConnectWifi(ap) }
                    }
                }
                if (networks.isEmpty() && lanDevices.isEmpty() && !scanning) {
                    Spacer(Modifier.height(10.dp))
                    Text(tx(isFa, "No scan results yet. Use Rescan or enter the device address below.", "هنوز نتیجه‌ای نیست. دوباره جستجو کن یا نشانی دستگاه را پایین وارد کن."), color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
                }
            }

            if (selectedSsid.isNotBlank()) {
                GlassPanel(p) {
                    Text(tx(isFa, "WI-FI PASSWORD", "رمز Wi-Fi"), color = p.text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(tx(isFa, "Enter the password for $selectedSsid, then tap Connect on its row.", "رمز شبکهٔ $selectedSsid را وارد کن و دوباره روی اتصال همان شبکه بزن."), color = p.muted, fontSize = 10.sp, lineHeight = 16.sp)
                    Spacer(Modifier.height(7.dp))
                    GlassTextField(p, wifiPassword, onWifiPassword, tx(isFa, "Network password", "رمز شبکه"), password = true)
                }
            }

            GlassPanel(p) {
                Text(tx(isFa, "MANUAL CONNECTION", "اتصال دستی"), color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Use this when WAPFire is on Ethernet, has a custom IP, or discovery cannot find it.", "وقتی WAPFire با Ethernet متصل است، IP سفارشی دارد یا جستجو آن را پیدا نمی‌کند از این بخش استفاده کن."), color = p.muted, fontSize = 10.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(10.dp))
                GlassTextField(p, manualHost, onManualHost, tx(isFa, "Device IP / hostname", "IP یا نام میزبان دستگاه"), keyboardType = KeyboardType.Uri, placeholder = "192.168.4.1")
                Spacer(Modifier.height(10.dp))
                PrimaryGlassButton(p, tx(isFa, "Open WAPFire control center", "بازکردن مرکز کنترل WAPFire"), onManualConnect, Modifier.fillMaxWidth())
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text("WAPFIRE MOBILE 2.1.1  ·  ANDROID 10+", color = p.muted.copy(alpha = .75f), fontSize = 9.sp, letterSpacing = 1.2.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun WebConsoleScreen(
    p: AppPalette,
    isFa: Boolean,
    darkTheme: Boolean,
    host: String,
    webView: WebView?,
    page: ConsolePage,
    loading: Boolean,
    error: String,
    webTitle: String,
    onPage: (ConsolePage) -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit,
    onRetry: () -> Unit,
    onWebTitle: (String) -> Unit,
    onWebLoading: (Boolean) -> Unit,
    onWebError: (String) -> Unit,
    onWebView: (WebView?) -> Unit,
    onFilePicker: (ValueCallback<Array<Uri>>) -> Boolean
) {
    val context = LocalContext.current
    val baseUrl = remember(host) { normalizeDeviceUrl(host).trimEnd('/') }
    val latestPage by androidx.compose.runtime.rememberUpdatedState(page)
    val latestDark by androidx.compose.runtime.rememberUpdatedState(darkTheme)
    val latestFa by androidx.compose.runtime.rememberUpdatedState(isFa)
    val latestError by androidx.compose.runtime.rememberUpdatedState(onWebError)
    val latestLoading by androidx.compose.runtime.rememberUpdatedState(onWebLoading)
    val latestTitle by androidx.compose.runtime.rememberUpdatedState(onWebTitle)
    val latestOnFilePicker by androidx.compose.runtime.rememberUpdatedState(onFilePicker)

    Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(p.backgroundTop, p.backgroundBottom))).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrandMark(p, Modifier.size(38.dp))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text("WAPFIRE", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(if (error.isBlank()) p.success else p.danger))
                    Spacer(Modifier.width(5.dp))
                    Text(host.removePrefix("http://").removePrefix("https://"), color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (webTitle.isNotBlank()) {
                        Text("  ·  ${webTitle.take(26)}", color = p.muted.copy(alpha = .85f), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            SmallGlassIcon(p, if (darkTheme) "☼" else "☾", onTheme, tx(isFa, "Switch appearance", "تغییر پوسته"))
            SmallGlassIcon(p, if (isFa) "EN" else "FA", onLanguage, tx(isFa, "Switch language", "تغییر زبان"))
            SmallGlassIcon(p, "↻", onRefresh, tx(isFa, "Refresh page", "تازه‌سازی صفحه"))
            SmallGlassIcon(p, "⇥", {
                webView?.evaluateJavascript("fetch('/logout',{method:'POST',credentials:'same-origin'}).finally(function(){window.location.href='/';});", null)
                webView?.postDelayed({ onDisconnect() }, 700)
            }, tx(isFa, "Sign out / change device", "خروج / تغییر دستگاه"))
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 7.dp)) {
            AndroidView(
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)),
                factory = { ctx ->
                    WebView(ctx).apply {
                        setBackgroundColor(android.graphics.Color.TRANSPARENT)
                        overScrollMode = View.OVER_SCROLL_NEVER
                        isVerticalScrollBarEnabled = true
                        isHorizontalScrollBarEnabled = false
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        settings.setSupportMultipleWindows(false)
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = false
                        settings.displayZoomControls = false
                        settings.cacheMode = WebSettings.LOAD_NO_CACHE
                        settings.defaultTextEncodingName = "UTF-8"
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        settings.userAgentString = settings.userAgentString + " WAPFireMobile/2.1.1"
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
                        webChromeClient = object : WebChromeClient() {
                            override fun onShowFileChooser(
                                webView: WebView?,
                                filePathCallback: ValueCallback<Array<Uri>>?,
                                fileChooserParams: WebChromeClient.FileChooserParams?
                            ): Boolean {
                                if (filePathCallback == null) return false
                                return latestOnFilePicker(filePathCallback)
                            }
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                latestTitle(title.orEmpty())
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val uri = request?.url ?: return false
                                if (uri.host.equals(Uri.parse(baseUrl).host, ignoreCase = true)) return false
                                return try {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    true
                                } catch (_: Exception) { true }
                            }

                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                latestLoading(true)
                                latestError("")
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                latestLoading(false)
                                latestError("")
                                latestTitle(view?.title.orEmpty())
                                view?.evaluateJavascript(webThemeScript(latestDark), null)
                                view?.evaluateJavascript(webApplyLanguageScript(latestFa), null)
                                val finishedPath = runCatching { Uri.parse(url.orEmpty()).path.orEmpty() }.getOrDefault("")
                                if (latestPage == ConsolePage.TARGET && finishedPath in listOf("/home", "/setup")) {
                                    view?.let { pageView -> pageView.postDelayed({ pageView.loadUrl("$baseUrl/settings") }, 180) }
                                } else if (latestPage == ConsolePage.TARGET) {
                                    view?.let { pageView -> pageView.postDelayed({ pageView.evaluateJavascript(targetScrollScript(), null) }, 350) }
                                }
                            }

                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                                if (request?.isForMainFrame == true) {
                                    latestLoading(false)
                                    latestError(error?.description?.toString() ?: "Unable to reach WAPFire")
                                }
                            }
                        }
                        setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                            try {
                                val filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                                val request = DownloadManager.Request(Uri.parse(url)).apply {
                                    setTitle(filename)
                                    setDescription("WAPFire download")
                                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                                    addRequestHeader("User-Agent", userAgent)
                                    CookieManager.getInstance().getCookie(baseUrl)?.let { addRequestHeader("Cookie", it) }
                                    mimeType?.let { setMimeType(it) }
                                }
                                val manager = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                manager.enqueue(request)
                            } catch (_: Exception) { }
                        })
                        loadUrl("$baseUrl/")
                        onWebView(this)
                    }
                },
                update = { view ->
                    if (view.url.isNullOrBlank() || view.url == "about:blank") view.loadUrl("$baseUrl/")
                }
            )

            if (loading) {
                Surface(
                    color = p.surface.copy(alpha = .93f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, p.border),
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp).shadow(10.dp, RoundedCornerShape(16.dp))
                ) {
                    Row(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = p.accent)
                        Spacer(Modifier.width(8.dp))
                        Text(tx(isFa, "Loading device interface…", "در حال بارگذاری رابط دستگاه…"), color = p.text, fontSize = 10.sp)
                    }
                }
            }

            if (error.isNotBlank()) {
                GlassPanel(p, Modifier.align(Alignment.Center).fillMaxWidth()) {
                    Text(tx(isFa, "Device connection interrupted", "ارتباط با دستگاه قطع شد"), color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(error, color = p.muted, fontSize = 11.sp, lineHeight = 17.sp)
                    Spacer(Modifier.height(12.dp))
                    PrimaryGlassButton(p, tx(isFa, "Retry connection", "تلاش مجدد برای اتصال"), onRetry, Modifier.fillMaxWidth())
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(p.surfaceStrong.copy(alpha = .96f), p.surface.copy(alpha = .88f))))
                .border(1.dp, p.border, RoundedCornerShape(22.dp))
                .padding(horizontal = 3.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ConsolePage.values().forEach { item ->
                val selected = page == item
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                        .background(if (selected) p.accent.copy(alpha = if (darkTheme) .17f else .12f) else Color.Transparent)
                        .clickable { onPage(item) }
                        .padding(vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(item.glyph, color = if (selected) p.accent else p.muted, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (isFa) item.titleFa else item.titleEn, color = if (selected) p.accent else p.muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }

    LaunchedEffect(page, baseUrl) {
        val w = webView ?: return@LaunchedEffect
        val path = when (page) {
            ConsolePage.TARGET, ConsolePage.SETTINGS -> "/settings"
            else -> page.route
        }
        val desired = baseUrl + path
        val current = w.url.orEmpty()
        val currentPath = runCatching { Uri.parse(current).path.orEmpty() }.getOrDefault("")
        if (currentPath != path && currentPath != "/" && currentPath.isNotBlank()) {
            w.loadUrl(desired)
        } else if (currentPath == path) {
            if (page == ConsolePage.TARGET) w.evaluateJavascript(targetScrollScript(), null)
            else if (page == ConsolePage.SETTINGS) w.evaluateJavascript("window.scrollTo(0,0)", null)
        } else if (currentPath == "/") {
            // Let the device's own login and first-setup redirects run normally.
        }
    }

    LaunchedEffect(darkTheme, baseUrl) {
        webView?.evaluateJavascript(webThemeScript(darkTheme), null)
    }
}

@Composable
private fun AmbientGlow(p: AppPalette) {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(Brush.radialGradient(listOf(p.accent.copy(alpha = .13f), Color.Transparent)), radius = size.width * .55f, center = androidx.compose.ui.geometry.Offset(size.width * .92f, size.height * .07f))
        drawCircle(Brush.radialGradient(listOf(p.accent2.copy(alpha = .10f), Color.Transparent)), radius = size.width * .62f, center = androidx.compose.ui.geometry.Offset(size.width * .02f, size.height * .73f))
    }
}

@Composable
private fun BrandMark(p: AppPalette, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(p.accent.copy(alpha = .24f), p.accent2.copy(alpha = .13f))))
        .border(1.dp, p.accent.copy(alpha = .4f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
        Text("W", color = p.accent, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp)
    }
}

@Composable
private fun HeaderToggle(p: AppPalette, label: String, onClick: () -> Unit, description: String) {
    Surface(onClick = onClick, color = p.surface.copy(alpha = .8f), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, p.border), modifier = Modifier.sizeIn(minWidth = 39.dp, minHeight = 36.dp)) {
        Box(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            Text(label, color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SmallGlassIcon(p: AppPalette, glyph: String, onClick: () -> Unit, label: String) {
    Surface(onClick = onClick, color = p.surface.copy(alpha = .8f), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, p.border), modifier = Modifier.size(37.dp)) {
        Box(contentAlignment = Alignment.Center) { Text(glyph, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun GlassPanel(p: AppPalette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.shadow(13.dp, RoundedCornerShape(24.dp), ambientColor = p.shadow, spotColor = p.shadow)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(p.surfaceStrong.copy(alpha = .82f), p.surface.copy(alpha = .76f))))
            .border(1.dp, p.border.copy(alpha = .88f), RoundedCornerShape(24.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun DeviceRow(
    p: AppPalette,
    title: String,
    detail: String,
    meta: String,
    action: String,
    busy: Boolean,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp))
            .background(if (highlighted) p.accent.copy(alpha = .10f) else p.surface.copy(alpha = .45f))
            .border(1.dp, if (highlighted) p.accent.copy(alpha = .42f) else p.border.copy(alpha = .65f), RoundedCornerShape(16.dp))
            .padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(35.dp).clip(RoundedCornerShape(12.dp)).background(p.accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
            Text(if (highlighted) "W" else "⌁", color = p.accent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(7.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(meta, color = p.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onClick, enabled = !busy, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 1.dp)) {
                if (busy) CircularProgressIndicator(Modifier.size(12.dp), color = p.accent, strokeWidth = 1.5.dp)
                else Text(action, color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PrimaryGlassButton(p: AppPalette, label: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 46.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = if (p.backgroundBottom.luminance() < .35f) Color(0xFF06201F) else Color.White, disabledContainerColor = p.accent.copy(alpha = .35f)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 0.dp)
    ) { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
}

@Composable
private fun SecondaryGlassButton(p: AppPalette, label: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 44.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, p.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text, disabledContentColor = p.muted.copy(alpha = .6f))
    ) { Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun GlassTextField(
    p: AppPalette,
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    placeholder: String = ""
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label, fontSize = 11.sp) },
        placeholder = { if (placeholder.isNotBlank()) Text(placeholder, fontSize = 11.sp) },
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(14.dp),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedBorderColor = p.accent,
            unfocusedBorderColor = p.border,
            focusedLabelColor = p.accent,
            unfocusedLabelColor = p.muted,
            focusedTextColor = p.text,
            unfocusedTextColor = p.text,
            cursorColor = p.accent,
            focusedContainerColor = p.surface.copy(alpha = .76f),
            unfocusedContainerColor = p.surface.copy(alpha = .54f)
        )
    )
}


private fun webApplyLanguageScript(persian: Boolean): String {
    val lang = if (persian) "fa" else "en"
    return "(function(){try{localStorage.setItem('wapfire_ui_language','$lang');var sel=document.getElementById('language_select');if(sel)sel.value='$lang';if(window.applyUILanguage)window.applyUILanguage('$lang');}catch(e){}})();"
}

private fun webLanguageScript(persian: Boolean): String {
    val lang = if (persian) "fa" else "en"
    return "(function(){try{localStorage.setItem('wapfire_ui_language','$lang');var sel=document.getElementById('language_select');if(sel)sel.value='$lang';if(window.applyUILanguage)window.applyUILanguage('$lang');if(window.changeUILanguage){window.changeUILanguage('$lang');}else{fetch('/api/language',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({language:'$lang'})}).then(function(r){if(r.ok)return r.json();}).then(function(d){if(d&&d.language&&window.applyUILanguage)window.applyUILanguage(d.language);}).catch(function(){});}}catch(e){}})();"
}

private fun targetScrollScript(): String = """(function(){
  const nodes=[...document.querySelectorAll('.panel-title,.step-title,h1,h2,h3')];
  const target=nodes.find(n=>{const t=(n.textContent||'').toUpperCase();return t.includes('TARGET MANAGEMENT')||t.includes('مدیریت شبکه');});
  if(target){const panel=target.closest('.panel')||target; panel.scrollIntoView({behavior:'smooth',block:'start'});}
})();"""

private fun webThemeScript(dark: Boolean): String {
    val css = if (dark) """
:root{
 color-scheme:dark!important;
 --wapfire-blue:#67ead5!important;--wapfire-gold:#f4cb7a!important;--wapfire-dark:#07131d!important;
 --wapfire-panel:rgba(15,31,44,.78)!important;--text-primary:#f1f7fa!important;--text-secondary:#b6c7cf!important;
 --background-primary:#07131d!important;--background-secondary:#102635!important;--border-color:rgba(124,215,214,.20)!important;
 --panel-border:rgba(124,215,214,.20)!important;--input-background:rgba(9,25,36,.72)!important;--input-border:rgba(124,215,214,.30)!important;
 --input-text:#f1f7fa!important;--input-placeholder:#94aab4!important;--nav-background:rgba(12,28,40,.78)!important;
 --card-background:rgba(102,232,213,.06)!important;--card-border:rgba(102,232,213,.14)!important;
 --success:#6ce7a7!important;--warning:#f5bf69!important;--danger:#ff7889!important;
}
html,body{background:radial-gradient(ellipse at 15% 0%,#123a42 0%,#0b1d29 38%,#07131d 100%)!important;color:#f1f7fa!important;background-attachment:fixed!important;}
body{font-family:Inter,'Segoe UI',Roboto,Arial,sans-serif!important;overflow-x:hidden!important;}
.navbar{display:none!important}.mobile-menu,.hamburger-menu{display:none!important}
.panel,.setup-wizard,.steps-container,.login-container,.login-card,.logs-container,.log-card,.backup-section,.step,.selected-target,.scan-item,.system-card,.stat-card{
 background:rgba(17,37,52,.72)!important;backdrop-filter:blur(22px) saturate(155%)!important;-webkit-backdrop-filter:blur(22px) saturate(155%)!important;
 border:1px solid rgba(142,220,219,.19)!important;box-shadow:0 12px 34px rgba(0,0,0,.18)!important;border-radius:20px!important;
}
.panel::before{opacity:.65!important}
input,select,textarea,.input-field{background:rgba(6,21,31,.72)!important;color:#f2f8fb!important;border:1px solid rgba(137,215,212,.32)!important;border-radius:12px!important;}
input::placeholder,textarea::placeholder{color:#8fa8b3!important}
button,.btn,.nav-btn,.mobile-nav-btn{border-radius:13px!important;box-shadow:none!important}
.panel-header{border-bottom-color:rgba(120,205,210,.18)!important}
.panel-icon{filter:saturate(.9)!important}
.status-item,.metric-card,.chart-card,.chart-container,.visualization,.selected-target,.scan-list,.scan-item,.target-item,.client-card,.log-card,.log-entry,.legend,.legend-item,.info-card,.system-card{
 background:rgba(110,180,190,.075)!important;border:1px solid rgba(130,205,210,.16)!important;border-radius:15px!important;
}
.status-value,.metric-value,.target-name{letter-spacing:.01em!important}
.progress-container,.progress-bar{border-radius:999px!important;overflow:hidden!important}
.btn-primary,.btn-secondary,.btn-success{background:linear-gradient(135deg,#27b9a6,#168c8c)!important;border-color:rgba(117,241,219,.46)!important;color:#041c20!important;font-weight:700!important}
.status-message,.status-box{border-radius:12px!important}
.dashboard-grid{gap:12px!important}.main-container{gap:12px!important}
""" else """
:root{
 color-scheme:light!important;
 --wapfire-blue:#087f78!important;--wapfire-gold:#b17a26!important;--wapfire-dark:#edf4f7!important;
 --wapfire-panel:rgba(255,255,255,.79)!important;--text-primary:#183141!important;--text-secondary:#58717f!important;
 --background-primary:#f4f9fb!important;--background-secondary:#e2edf2!important;--border-color:rgba(45,104,120,.17)!important;
 --panel-border:rgba(45,104,120,.19)!important;--input-background:rgba(255,255,255,.82)!important;--input-border:rgba(54,119,131,.24)!important;
 --input-text:#183141!important;--input-placeholder:#718794!important;--nav-background:rgba(248,252,254,.82)!important;
 --card-background:rgba(255,255,255,.68)!important;--card-border:rgba(55,119,132,.14)!important;
 --success:#168b5a!important;--warning:#a96714!important;--danger:#c94355!important;
}
html,body{background:radial-gradient(ellipse at 15% 0%,#ffffff 0%,#edf5f8 42%,#dce9ef 100%)!important;color:#183141!important;background-attachment:fixed!important;}
body{font-family:Inter,'Segoe UI',Roboto,Arial,sans-serif!important;overflow-x:hidden!important;}
.navbar{display:none!important}.mobile-menu,.hamburger-menu{display:none!important}
.panel,.setup-wizard,.steps-container,.login-container,.login-card,.logs-container,.log-card,.backup-section,.step,.selected-target,.scan-item,.system-card,.stat-card{
 background:rgba(255,255,255,.72)!important;backdrop-filter:blur(22px) saturate(155%)!important;-webkit-backdrop-filter:blur(22px) saturate(155%)!important;
 border:1px solid rgba(255,255,255,.82)!important;box-shadow:0 12px 34px rgba(42,82,100,.10)!important;border-radius:20px!important;
}
.panel::before{opacity:.45!important}
input,select,textarea,.input-field{background:rgba(255,255,255,.88)!important;color:#183141!important;border:1px solid rgba(54,119,131,.25)!important;border-radius:12px!important;}
input::placeholder,textarea::placeholder{color:#718794!important}
button,.btn,.nav-btn,.mobile-nav-btn{border-radius:13px!important;box-shadow:none!important}
.panel-header{border-bottom-color:rgba(45,104,120,.14)!important}
.status-item,.metric-card,.chart-card,.chart-container,.visualization,.selected-target,.scan-list,.scan-item,.target-item,.client-card,.log-card,.log-entry,.legend,.legend-item,.info-card,.system-card{
 background:rgba(255,255,255,.62)!important;border:1px solid rgba(55,119,132,.13)!important;border-radius:15px!important;
}
.status-value,.metric-value,.target-name{letter-spacing:.01em!important}
.progress-container,.progress-bar{border-radius:999px!important;overflow:hidden!important}
.btn-primary,.btn-secondary,.btn-success{background:linear-gradient(135deg,#2bb5a0,#168c8c)!important;border-color:rgba(22,140,140,.28)!important;color:#ffffff!important;font-weight:700!important}
.status-message,.status-box{border-radius:12px!important}
.dashboard-grid{gap:12px!important}.main-container{gap:12px!important}
"""
    val mobile = """
@media(max-width:900px){
 body{padding-left:0!important;padding-right:0!important}
 .main-container{display:block!important;grid-template-columns:1fr!important;padding:12px!important;margin:0!important;max-width:none!important}
 .main-content,.sidebar{width:100%!important;max-width:none!important}
 .dashboard-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important;margin-bottom:12px!important}
 .dashboard-grid>.panel{min-width:0!important;margin:0!important}
 .panel{padding:14px!important;margin-top:12px!important}
 .settings-container{display:flex!important;flex-direction:column!important;gap:12px!important;padding:10px!important;margin:0!important;max-width:none!important}
 .settings-container>.panel,.settings-container>div{min-width:0!important;width:100%!important}
 .logs-container{padding:12px!important;margin:0!important;max-width:none!important}
 .logs-table-container{overflow-x:auto!important;max-width:100%!important}
 .mobile-bottom-bar{position:relative!important;left:auto!important;right:auto!important;bottom:auto!important;margin:14px 10px 8px!important;width:auto!important;border:1px solid var(--border-color)!important;border-radius:18px!important;box-shadow:0 10px 28px rgba(0,0,0,.12)!important;}
 .setup-wizard{margin:5px auto!important;width:100%!important;max-width:none!important;border-radius:20px!important}
 .wizard-header{padding:16px!important;gap:12px!important}
 .steps-container{padding:16px!important}
 .step-title{font-size:1.15rem!important}
 .login-container{width:100%!important;max-width:460px!important;margin:auto!important}
 .nav-buttons{display:none!important}
 .dashboard-network-activity canvas{max-width:100%!important}
 .main-container,.settings-container,.logs-container{box-sizing:border-box!important;min-width:0!important}
 canvas,svg,img,video{max-width:100%!important}
}
@media(max-width:480px){
 .dashboard-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
 .panel{padding:12px!important;border-radius:17px!important}
 .metric-card,.status-card{min-width:0!important}
 .settings-container{padding:8px!important}
 .steps-container{padding:12px!important}
 .step-indicator{gap:7px!important}
 .step-dot{width:24px!important;height:24px!important}
 .logs-cards{grid-template-columns:1fr!important}
 .input-group{margin-bottom:1rem!important}
}
"""
    val completeCss = css + mobile + "\n*{-webkit-tap-highlight-color:transparent!important} html{scroll-behavior:smooth!important}"
    val quoted = JSONObject.quote(completeCss)
    val themeColor = if (dark) "#07131d" else "#edf4f7"
    return "(function(){try{var s=document.getElementById('wapfire-mobile-theme');if(!s){s=document.createElement('style');s.id='wapfire-mobile-theme';document.head.appendChild(s);}s.textContent=$quoted;document.documentElement.style.colorScheme='${if (dark) "dark" else "light"}';var m=document.querySelector('meta[name=theme-color]');if(m)m.content='$themeColor';}catch(e){}})();"
}

private fun Color.luminance(): Float = (0.2126f * red + 0.7152f * green + 0.0722f * blue)
