# Feature Checklist (Prototype 1)

Legend: **Done** = implemented in source with logic tests where marked. **Partial** = present but reduced.
**Not started** = absent. Nothing here has been run on a device yet.

## Core desktop and windows

| Item | Status | Notes |
|---|---|---|
| Desktop canvas with background | Done | Background color toggles off to the theme color |
| Drag windows by title bar | Done | Clamped so a strip of the window stays on screen |
| Resize windows | Partial | Bottom-left and bottom-right grips only. No top or side handles |
| Minimize / maximize / restore / close | Done | Maximize fills the canvas area, not behind the taskbar |
| Focus and z-order | Done | Logic tested |
| Boundary constraints | Done | Logic tested, including tiny canvases |
| Per-window independent state | Done | Each window stores its own content |
| Window title configuration | Not started | Titles are fixed per type |
| Notes window, text persists | Done | Saved through DataStore after a 300 ms debounce |
| Calculator: + − × ÷, parentheses, errors | Done | Logic tested, including division by zero |
| Both windows coexist | Done | Independent content, z-order, and focus |
| Snap to edges | Partial | Snaps to left, right, and top edges. Toggle in Behavior |
| Window open animation | Done | Fade and slight scale. Duration configurable. Close animation not implemented |

## Components

| Component | Toggle effect | Fallback when off |
|---|---|---|
| Taskbar | Hides the bottom or top bar | Menu button is always shown |
| Desktop background | Uses theme background instead of custom color | n/a |
| Floating menu button | Hides the Menu button | Forced visible while the taskbar is hidden |
| Window title bars | Replaces headers with a thin drag strip | Minimize, maximize, and close move into the Menu |
| Window borders | Removes the outline | n/a |
| Workspace switcher | Hides the tab strip | Switching is in the Menu |
| Settings entry | Hides the taskbar Settings button | Settings always in the Menu. Depends on Taskbar |

Each component has a default, a "Restore default" action, and dependency handling.

## Desktop Builder

| Section | Status |
|---|---|
| Components | Done |
| Appearance: dark theme, background and accent swatches, corner radius, borders and thickness, opacity, taskbar height, icon size, position | Done |
| Behavior: animations and duration, default window size, snapping, large touch targets | Done |
| Workspaces: add, rename, switch, delete with confirmation | Done |
| Saved arrangements: save and restore with confirmation | Done |
| Reset to defaults with confirmation | Done. Keeps windows and workspaces |
| Settings persist across restarts | Done. Written to DataStore after a 300 ms debounce |
| Invalid stored settings do not crash | Done. Values are clamped and non-finite numbers replaced. Logic tested |

## Taskbar and workspaces

| Item | Status |
|---|---|
| Toggle visibility, height, icon size, top or bottom position | Done |
| Lists open windows, marks the active one, minimized shown dimmed | Done |
| Click to restore, focus, or minimize | Done |
| Open Notes and Calculator from the taskbar | Done |
| Two or more independent workspaces, create, rename, switch, delete | Done. Logic tested |
| Each workspace keeps its own windows and positions | Done. Logic tested |
| Layouts survive restart | Done |
| Saved window arrangements | Done. Logic tested |

## Android integration (Phase E)

| Item | Status |
|---|---|
| List installed apps (package visibility) | Not started |
| Launch installed apps via Android activity launch | Not started |
| Embed third-party app windows in the canvas | Not possible without special privileges. See limitations below |

No fake window for external apps is included. Launching installed apps is the next step,
but windowing them on the canvas is limited by Android. See the Android limitations section below.

## Accessibility and quality

| Item | Status |
|---|---|
| Window controls have content descriptions | Done |
| Touch targets: default 30 dp buttons, large mode 40 dp | Done. Default is below the 48 dp guideline |
| Portrait and landscape | Done via layout. Not tested on device |
| Windows re-fit after rotation or canvas change | Done. Logic tested |
| Unit tests: geometry, window manager, workspaces, components, settings, calculator | Written, not yet run |
| UI tests | Not started |
| Release APK build | Configured. Not yet run |
| GitHub Actions build workflow | Not started |

## Android limitations for third-party windows

- Ordinary apps cannot move or resize other apps' windows. Android offers multi-window (split screen and
  freeform on some devices) as a system feature, and the user controls it.
- Freeform windows and launching into a specific window size vary by Android version and manufacturer.
- Launching an installed app opens it in its own task. It does not become a window on this canvas.
- Taskbar and Menu do not replace or hide Android's status bar or navigation bar.
- Next step: enumerate launchable apps with package visibility rules, and document which devices support
  multi-window launch flags before promising any embedding.
