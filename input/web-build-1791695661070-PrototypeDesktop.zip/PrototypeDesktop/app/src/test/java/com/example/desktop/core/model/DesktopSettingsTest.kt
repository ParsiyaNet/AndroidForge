package com.example.desktop.core.model

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

class DesktopSettingsTest {
    private val json = Json { ignoreUnknownKeys = true }

    @Test
    fun outOfRangeValuesAreClamped() {
        val s = DesktopSettings(
            cornerRadius = 500f,
            taskbarHeight = -4f,
            borderThickness = 0f,
            windowOpacity = 0f,
            animationDurationMs = 99_999,
        ).sanitized()
        assertEquals(32f, s.cornerRadius, 0f)
        assertEquals(40f, s.taskbarHeight, 0f)
        assertEquals(0.5f, s.borderThickness, 0f)
        assertEquals(0.4f, s.windowOpacity, 0f)
        assertEquals(800, s.animationDurationMs)
    }

    @Test
    fun nonFiniteValuesFallBackToDefaults() {
        val s = DesktopSettings(cornerRadius = Float.NaN, taskbarHeight = Float.POSITIVE_INFINITY).sanitized()
        assertEquals(DesktopSettings().cornerRadius, s.cornerRadius, 0f)
        assertEquals(DesktopSettings().taskbarHeight, s.taskbarHeight, 0f)
    }

    @Test
    fun settingsSurviveJsonRoundTrip() {
        val original = DesktopSettings(
            darkTheme = false,
            accentColor = 0xFFB388EBL,
            taskbarPosition = TaskbarPosition.TOP,
            disabledComponents = setOf("BORDERS", "TASKBAR"),
        )
        val restored = json.decodeFromString<DesktopSettings>(json.encodeToString(original))
        assertEquals(original, restored)
    }

    @Test
    fun missingFieldsUseDefaults() {
        val restored = json.decodeFromString<DesktopSettings>("{\"darkTheme\":false}")
        assertEquals(false, restored.darkTheme)
        assertEquals(DesktopSettings().taskbarHeight, restored.taskbarHeight, 0f)
    }
}
