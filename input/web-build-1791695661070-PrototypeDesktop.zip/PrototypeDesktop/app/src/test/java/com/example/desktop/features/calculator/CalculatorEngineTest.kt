package com.example.desktop.features.calculator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorEngineTest {
    private fun value(expression: String): Double {
        val result = CalculatorEngine.evaluate(expression)
        assertTrue("expected a value for '$expression' but was $result", result is CalcResult.Value)
        return (result as CalcResult.Value).number
    }

    private fun isError(expression: String): Boolean = CalculatorEngine.evaluate(expression) is CalcResult.Error

    @Test
    fun multiplicationBindsTighterThanAddition() {
        assertEquals(14.0, value("2+3*4"), 1e-9)
    }

    @Test
    fun parenthesesOverridePrecedence() {
        assertEquals(20.0, value("(2+3)*4"), 1e-9)
    }

    @Test
    fun subtractionAndDivisionWork() {
        assertEquals(7.5, value("10-5/2*1"), 1e-9)
    }

    @Test
    fun unaryMinusIsSupported() {
        assertEquals(-6.0, value("-3*2"), 1e-9)
        assertEquals(-6.0, value("2*-3"), 1e-9)
    }

    @Test
    fun decimalsAreSupported() {
        assertEquals(0.5, value("1/2"), 1e-9)
        assertEquals(2.25, value("1.5*1.5"), 1e-9)
    }

    @Test
    fun divisionByZeroIsAnError() {
        assertTrue(isError("1/0"))
        assertTrue(isError("5/(2-2)"))
    }

    @Test
    fun invalidExpressionsAreErrors() {
        assertTrue(isError("2+"))
        assertTrue(isError("2..3"))
        assertTrue(isError("(2+3"))
        assertTrue(isError("2+3)"))
        assertTrue(isError("abc"))
    }

    @Test
    fun emptyExpressionIsEmpty() {
        assertEquals(CalcResult.Empty, CalculatorEngine.evaluate(""))
    }

    @Test
    fun equalsReplacesExpressionWithResult() {
        assertEquals("0.5", CalculatorEngine.applyKey("1/2", "="))
    }

    @Test
    fun equalsWithErrorKeepsExpression() {
        assertEquals("1/0", CalculatorEngine.applyKey("1/0", "="))
    }

    @Test
    fun keypadSymbolsAreNormalized() {
        var expression = ""
        for (key in listOf("6", "×", "2", "÷")) {
            expression = CalculatorEngine.applyKey(expression, key)
        }
        assertEquals("6*2/", expression)
    }

    @Test
    fun clearAndBackspace() {
        assertEquals("", CalculatorEngine.applyKey("12+3", "C"))
        assertEquals("12+", CalculatorEngine.applyKey("12+3", "DEL"))
    }

    @Test
    fun formatHidesTrailingZeros() {
        assertEquals("14", CalculatorEngine.format(14.0))
        assertEquals("0.333333333333", CalculatorEngine.format(1.0 / 3.0))
    }
}
