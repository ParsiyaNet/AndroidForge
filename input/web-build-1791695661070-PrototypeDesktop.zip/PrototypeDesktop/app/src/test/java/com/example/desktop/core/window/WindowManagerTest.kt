package com.example.desktop.core.window

import com.example.desktop.core.model.Bounds
import com.example.desktop.core.model.DesktopLayout
import com.example.desktop.core.model.WindowType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WindowManagerTest {
    private val bounds = Bounds(10f, 10f, 200f, 150f)
    private val canvas = CanvasSize(360f, 640f)

    private fun twoNotes(): DesktopLayout {
        val first = WindowManager.open(DesktopLayout(), "a", WindowType.NOTES, bounds)
        return WindowManager.open(first, "b", WindowType.NOTES, bounds)
    }

    private fun topId(layout: DesktopLayout): String =
        WindowManager.visibleWindows(layout).last().id

    @Test
    fun openedWindowBecomesActiveAndOnTop() {
        val layout = twoNotes()
        assertEquals("b", layout.activeWindowId)
        assertEquals("b", topId(layout))
    }

    @Test
    fun focusRaisesWindowToFront() {
        val layout = WindowManager.focus(twoNotes(), "a")
        assertEquals("a", layout.activeWindowId)
        assertEquals("a", topId(layout))
    }

    @Test
    fun minimizedWindowIsHiddenAndClosingActiveFallsBackToVisibleWindow() {
        val minimized = WindowManager.minimize(twoNotes(), "b")
        assertEquals(listOf("a"), WindowManager.visibleWindows(minimized).map { it.id })
        assertEquals("a", minimized.activeWindowId)

        val closed = WindowManager.close(twoNotes(), "b")
        assertEquals(listOf("a"), closed.windows.map { it.id })
        assertEquals("a", closed.activeWindowId)
    }

    @Test
    fun restoringMinimizedWindowFocusesIt() {
        val layout = WindowManager.restore(WindowManager.minimize(twoNotes(), "a"), "a")
        assertEquals("a", layout.activeWindowId)
        assertEquals("a", topId(layout))
    }

    @Test
    fun maximizeAndRestoreReturnsToPreviousBounds() {
        val area = Bounds(0f, 0f, 360f, 600f)
        val maximized = WindowManager.toggleMaximize(twoNotes(), "a", area)
        assertTrue(maximized.windows.first { it.id == "a" }.maximized)
        assertEquals(area, maximized.windows.first { it.id == "a" }.bounds)

        val restored = WindowManager.toggleMaximize(maximized, "a", area)
        val window = restored.windows.first { it.id == "a" }
        assertFalse(window.maximized)
        assertEquals(bounds, window.bounds)
    }

    @Test
    fun maximizedWindowCannotBeDragged() {
        val maximized = WindowManager.toggleMaximize(twoNotes(), "a", Bounds(0f, 0f, 360f, 600f))
        val moved = WindowManager.move(maximized, "a", 50f, 50f, canvas, snap = false)
        assertEquals(maximized.windows.first { it.id == "a" }.bounds, moved.windows.first { it.id == "a" }.bounds)
    }

    @Test
    fun contentStaysIsolatedBetweenWindows() {
        val layout = WindowManager.updateContent(twoNotes(), "a", "hello")
        assertEquals("hello", layout.windows.first { it.id == "a" }.content)
        assertEquals("", layout.windows.first { it.id == "b" }.content)
    }

    @Test
    fun windowLimitIsEnforced() {
        var layout = DesktopLayout()
        repeat(WindowManager.MAX_WINDOWS + 10) { i ->
            layout = WindowManager.open(layout, "w$i", WindowType.CALCULATOR, bounds)
        }
        assertEquals(WindowManager.MAX_WINDOWS, layout.windows.size)
    }

    @Test
    fun repeatedOpenAndCloseDoesNotAccumulateWindows() {
        var layout = DesktopLayout()
        repeat(200) { i ->
            layout = WindowManager.open(layout, "w$i", WindowType.NOTES, bounds)
            layout = WindowManager.close(layout, "w$i")
        }
        assertTrue(layout.windows.isEmpty())
        assertNull(layout.activeWindowId)
    }

    @Test
    fun sanitizeDropsWindowsWithInvalidGeometry() {
        val broken = DesktopLayout(
            windows = listOf(
                WindowManager.open(DesktopLayout(), "ok", WindowType.NOTES, bounds).windows.first(),
                WindowManager.open(DesktopLayout(), "bad", WindowType.NOTES, Bounds(Float.NaN, 0f, 100f, 100f)).windows.first(),
            ),
            activeWindowId = "bad",
        )
        val clean = WindowManager.sanitize(broken)
        assertEquals(listOf("ok"), clean.windows.map { it.id })
        assertNull(clean.activeWindowId)
    }

    @Test
    fun fitToCanvasResizesMaximizedWindowToNewCanvas() {
        val maximized = WindowManager.toggleMaximize(twoNotes(), "a", Bounds(0f, 0f, 360f, 640f))
        val rotated = WindowManager.fitToCanvas(maximized, CanvasSize(640f, 360f))
        assertEquals(Bounds(0f, 0f, 640f, 360f), rotated.windows.first { it.id == "a" }.bounds)
    }
}
