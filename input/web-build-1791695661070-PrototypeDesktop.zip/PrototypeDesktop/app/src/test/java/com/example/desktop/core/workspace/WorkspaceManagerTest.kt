package com.example.desktop.core.workspace

import com.example.desktop.core.model.Bounds
import com.example.desktop.core.model.WindowType
import com.example.desktop.core.model.WorkspaceState
import com.example.desktop.core.window.WindowManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkspaceManagerTest {
    private val bounds = Bounds(10f, 10f, 200f, 150f)

    @Test
    fun initialStateHasTwoWorkspaces() {
        val state = WorkspaceManager.initial()
        assertEquals(2, state.workspaces.size)
        assertEquals(state.workspaces.first().id, state.activeWorkspaceId)
    }

    @Test
    fun windowsDoNotLeakBetweenWorkspaces() {
        val first = WorkspaceManager.initial()
        val withWindow = WorkspaceManager.updateActiveLayout(first) {
            WindowManager.open(it, "note-1", WindowType.NOTES, bounds)
        }
        assertEquals(1, WorkspaceManager.activeWorkspace(withWindow).layout.windows.size)

        val other = WorkspaceManager.switchWorkspace(withWindow, withWindow.workspaces[1].id)
        assertTrue(WorkspaceManager.activeWorkspace(other).layout.windows.isEmpty())

        val back = WorkspaceManager.switchWorkspace(other, withWindow.workspaces[0].id)
        assertEquals(listOf("note-1"), WorkspaceManager.activeWorkspace(back).layout.windows.map { it.id })
    }

    @Test
    fun createAndRenameWorkspace() {
        val created = WorkspaceManager.createWorkspace(WorkspaceManager.initial(), "ws-new", "  Design  ")
        assertEquals("ws-new", created.activeWorkspaceId)
        assertEquals("Design", created.workspaces.last().name)

        val renamed = WorkspaceManager.renameWorkspace(created, "ws-new", "   ")
        assertEquals("Design", renamed.workspaces.last().name)
    }

    @Test
    fun cannotDeleteLastWorkspace() {
        val single = WorkspaceState(
            workspaces = listOf(WorkspaceManager.initial().workspaces.first()),
            activeWorkspaceId = "workspace-1",
        )
        assertEquals(single, WorkspaceManager.deleteWorkspace(single, "workspace-1"))
    }

    @Test
    fun deletingActiveWorkspaceSwitchesToRemainingOne() {
        val state = WorkspaceManager.initial()
        val deleted = WorkspaceManager.deleteWorkspace(state, state.activeWorkspaceId)
        assertEquals(1, deleted.workspaces.size)
        assertEquals(deleted.workspaces.first().id, deleted.activeWorkspaceId)
    }

    @Test
    fun saveAndRestoreArrangement() {
        var state = WorkspaceManager.updateActiveLayout(WorkspaceManager.initial()) {
            WindowManager.open(it, "a", WindowType.NOTES, bounds)
        }
        state = WorkspaceManager.saveArrangement(state, "Writing")
        state = WorkspaceManager.updateActiveLayout(state) { WindowManager.close(it, "a") }
        assertTrue(WorkspaceManager.activeWorkspace(state).layout.windows.isEmpty())

        state = WorkspaceManager.restoreArrangement(state, 0)
        assertEquals(listOf("a"), WorkspaceManager.activeWorkspace(state).layout.windows.map { it.id })
    }

    @Test
    fun sanitizeRepairsMissingActiveWorkspace() {
        val broken = WorkspaceState(WorkspaceManager.initial().workspaces, activeWorkspaceId = "missing")
        assertEquals("workspace-1", WorkspaceManager.sanitize(broken).activeWorkspaceId)
    }

    @Test
    fun sanitizeReplacesEmptyWorkspaceList() {
        val empty = WorkspaceState(emptyList(), activeWorkspaceId = "x")
        assertEquals(2, WorkspaceManager.sanitize(empty).workspaces.size)
    }
}
