package com.example.desktop.core.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ComponentRegistryTest {
    @Test
    fun settingsEntryIsBlockedWhileTaskbarIsDisabled() {
        val disabled = setOf(DesktopComponent.TASKBAR.name)
        assertFalse(ComponentRegistry.isEnabled(DesktopComponent.SETTINGS_ENTRY, disabled))
    }

    @Test
    fun floatingControlIsForcedVisibleWhileTaskbarIsHidden() {
        val taskbarOff = setOf(DesktopComponent.TASKBAR.name, DesktopComponent.FLOATING_CONTROL.name)
        assertTrue(ComponentRegistry.isFloatingControlVisible(taskbarOff))
    }

    @Test
    fun floatingControlHiddenWhenBothTaskbarAndControlAreOn() {
        val floatingOff = setOf(DesktopComponent.FLOATING_CONTROL.name)
        assertFalse(ComponentRegistry.isFloatingControlVisible(floatingOff))
    }

    @Test
    fun restoreDefaultReenablesComponent() {
        val disabled = setOf(DesktopComponent.BORDERS.name)
        val restored = ComponentRegistry.restoreDefault(disabled, DesktopComponent.BORDERS)
        assertTrue(ComponentRegistry.isEnabled(DesktopComponent.BORDERS, restored))
    }

    @Test
    fun setEnabledIsIdempotent() {
        val once = ComponentRegistry.withEnabled(emptySet(), DesktopComponent.BACKGROUND, false)
        val twice = ComponentRegistry.withEnabled(once, DesktopComponent.BACKGROUND, false)
        assertEquals(once, twice)
    }
}
