package com.example.desktop.core.window

import com.example.desktop.core.model.Bounds
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class WindowGeometryTest {
    private val canvas = CanvasSize(360f, 640f)
    private val window = Bounds(100f, 100f, 200f, 150f)

    private fun assertClose(expected: Float, actual: Float) {
        assertTrue("expected $expected but was $actual", abs(expected - actual) < 0.001f)
    }

    @Test
    fun draggingPastRightEdgeKeepsSomeOfWindowVisible() {
        val moved = WindowGeometry.move(window, 1000f, 0f, canvas, snap = false)
        assertClose(canvas.width - WindowGeometry.MIN_VISIBLE, moved.x)
    }

    @Test
    fun draggingAboveTopEdgeStopsAtZero() {
        val moved = WindowGeometry.move(window, 0f, -1000f, canvas, snap = false)
        assertClose(0f, moved.y)
    }

    @Test
    fun clampDoesNotThrowOnCanvasSmallerThanMinimumSize() {
        val tiny = CanvasSize(50f, 50f)
        val result = WindowGeometry.clamp(Bounds(0f, 0f, 300f, 300f), tiny)
        assertClose(WindowGeometry.MIN_WIDTH, result.width)
        assertClose(WindowGeometry.MIN_HEIGHT, result.height)
    }

    @Test
    fun resizingFromRightChangesWidthOnly() {
        val r = WindowGeometry.resize(window, ResizeEdges(right = true), 50f, 0f, canvas)
        assertClose(250f, r.width)
        assertClose(100f, r.x)
    }

    @Test
    fun resizingFromLeftKeepsRightEdgeFixed() {
        val r = WindowGeometry.resize(window, ResizeEdges(left = true), -30f, 0f, canvas)
        assertClose(230f, r.width)
        assertClose(70f, r.x)
        assertClose(window.right, r.right)
    }

    @Test
    fun resizingNeverGoesBelowMinimumSize() {
        val r = WindowGeometry.resize(window, ResizeEdges(right = true, bottom = true), -500f, -500f, canvas)
        assertClose(WindowGeometry.MIN_WIDTH, r.width)
        assertClose(WindowGeometry.MIN_HEIGHT, r.height)
    }

    @Test
    fun snappingPullsWindowToNearbyLeftEdge() {
        val snapped = WindowGeometry.snapToEdges(Bounds(5f, 100f, 200f, 150f), canvas)
        assertClose(0f, snapped.x)
    }

    @Test
    fun cascadeOffsetsSuccessiveWindows() {
        val first = WindowGeometry.cascade(0, canvas, 200f, 150f)
        val second = WindowGeometry.cascade(1, canvas, 200f, 150f)
        assertTrue(second.x > first.x && second.y > first.y)
    }
}
