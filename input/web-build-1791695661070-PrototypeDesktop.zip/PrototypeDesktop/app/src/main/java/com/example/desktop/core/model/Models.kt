package com.example.desktop.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class WindowType(val defaultTitle: String) {
    NOTES("Notes"),
    CALCULATOR("Calculator"),
}

@Serializable
data class Bounds(val x: Float, val y: Float, val width: Float, val height: Float) {
    val right: Float get() = x + width
    val bottom: Float get() = y + height
}

@Serializable
data class WindowState(
    val id: String,
    val type: WindowType,
    val title: String,
    val bounds: Bounds,
    val zIndex: Int,
    val minimized: Boolean = false,
    val maximized: Boolean = false,
    val restoreBounds: Bounds? = null,
    val content: String = "",
)

@Serializable
data class DesktopLayout(
    val windows: List<WindowState> = emptyList(),
    val activeWindowId: String? = null,
)

@Serializable
data class SavedArrangement(val name: String, val windows: List<WindowState>)

@Serializable
data class Workspace(
    val id: String,
    val name: String,
    val layout: DesktopLayout = DesktopLayout(),
    val arrangements: List<SavedArrangement> = emptyList(),
)

@Serializable
data class WorkspaceState(
    val workspaces: List<Workspace>,
    val activeWorkspaceId: String,
)
