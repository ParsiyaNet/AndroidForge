package com.example.desktop.core.window

import com.example.desktop.core.model.Bounds
import kotlin.math.abs
import kotlin.math.max

data class CanvasSize(val width: Float, val height: Float)

data class ResizeEdges(
    val left: Boolean = false,
    val right: Boolean = false,
    val top: Boolean = false,
    val bottom: Boolean = false,
)

/** Pure geometry used by the window manager. All values are in dp. */
object WindowGeometry {
    const val TITLE_BAR_HEIGHT = 36f
    const val MIN_WIDTH = 160f
    const val MIN_HEIGHT = 120f
    /** Horizontal space that must stay visible so a window can always be grabbed. */
    const val MIN_VISIBLE = 48f
    const val SNAP_THRESHOLD = 12f

    private const val CASCADE_STEP = 32f
    private const val CASCADE_ORIGIN = 24f
    private const val CASCADE_SLOTS = 8

    /** Keeps size within limits and the window reachable on the canvas. Never throws. */
    fun clamp(b: Bounds, canvas: CanvasSize): Bounds {
        val width = b.width.coerceIn(MIN_WIDTH, max(MIN_WIDTH, canvas.width))
        val height = b.height.coerceIn(MIN_HEIGHT, max(MIN_HEIGHT, canvas.height))
        val minX = MIN_VISIBLE - width
        val maxX = max(minX, canvas.width - MIN_VISIBLE)
        val x = b.x.coerceIn(minX, maxX)
        val y = b.y.coerceIn(0f, max(0f, canvas.height - TITLE_BAR_HEIGHT))
        return Bounds(x, y, width, height)
    }

    fun move(b: Bounds, dx: Float, dy: Float, canvas: CanvasSize, snap: Boolean): Bounds {
        val moved = clamp(b.copy(x = b.x + dx, y = b.y + dy), canvas)
        return if (snap) snapToEdges(moved, canvas) else moved
    }

    fun snapToEdges(b: Bounds, canvas: CanvasSize): Bounds {
        var x = b.x
        var y = b.y
        if (abs(x) < SNAP_THRESHOLD) x = 0f
        if (abs(x + b.width - canvas.width) < SNAP_THRESHOLD) x = canvas.width - b.width
        if (abs(y) < SNAP_THRESHOLD) y = 0f
        return b.copy(x = x, y = y)
    }

    /** Resizes from the requested edges. The opposite edge stays where it was. */
    fun resize(b: Bounds, edges: ResizeEdges, dx: Float, dy: Float, canvas: CanvasSize): Bounds {
        var x = b.x
        var y = b.y
        var w = b.width
        var h = b.height
        if (edges.right) w = max(MIN_WIDTH, w + dx)
        if (edges.bottom) h = max(MIN_HEIGHT, h + dy)
        if (edges.left) {
            val newWidth = max(MIN_WIDTH, w - dx)
            x += w - newWidth
            w = newWidth
        }
        if (edges.top) {
            val newHeight = max(MIN_HEIGHT, h - dy)
            y += h - newHeight
            h = newHeight
        }
        return clamp(Bounds(x, y, w, h), canvas)
    }

    fun cascade(index: Int, canvas: CanvasSize, width: Float, height: Float): Bounds {
        val offset = CASCADE_STEP * (index % CASCADE_SLOTS)
        return clamp(Bounds(CASCADE_ORIGIN + offset, CASCADE_ORIGIN + offset, width, height), canvas)
    }
}
