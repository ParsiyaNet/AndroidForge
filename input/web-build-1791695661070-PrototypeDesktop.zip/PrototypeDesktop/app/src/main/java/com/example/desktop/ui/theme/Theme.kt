package com.example.desktop.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.desktop.core.model.DesktopSettings

val BackgroundPresets: List<Long> = listOf(
    0xFF1B2330L, 0xFF1A2419L, 0xFF2A1F2EL, 0xFF14262BL, 0xFF2B2A24L, 0xFFE9ECF1L,
)

val AccentPresets: List<Long> = listOf(
    0xFF4FB3BFL, 0xFF7C9CFFL, 0xFF6BCB77L, 0xFFF2A65AL, 0xFFE76F7AL, 0xFFB388EBL,
)

@Composable
fun DesktopTheme(settings: DesktopSettings, content: @Composable () -> Unit) {
    val accent = Color(settings.accentColor)
    val scheme = if (settings.darkTheme) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF0B1116),
            background = Color(0xFF141A22),
            surface = Color(0xFF1E2531),
            surfaceVariant = Color(0xFF262F3D),
            onSurface = Color(0xFFE6EAF0),
            onSurfaceVariant = Color(0xFFA9B4C2),
            outline = Color(0xFF4A5566),
            outlineVariant = Color(0xFF384252),
            error = Color(0xFFFF8A80),
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            background = Color(0xFFF3F5F8),
            surface = Color.White,
            surfaceVariant = Color(0xFFE6EAF0),
            onSurface = Color(0xFF1A1F2B),
            onSurfaceVariant = Color(0xFF5A6474),
            outline = Color(0xFFA5AFBD),
            outlineVariant = Color(0xFFD0D6E0),
            error = Color(0xFFB3261E),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
