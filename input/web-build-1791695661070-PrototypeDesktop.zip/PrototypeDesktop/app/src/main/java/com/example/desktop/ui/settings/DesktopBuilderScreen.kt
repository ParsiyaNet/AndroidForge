package com.example.desktop.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.desktop.core.components.ComponentRegistry
import com.example.desktop.core.components.DesktopComponent
import com.example.desktop.core.model.TaskbarPosition
import com.example.desktop.core.model.Workspace
import com.example.desktop.core.workspace.WorkspaceManager
import com.example.desktop.ui.desktop.DesktopUiState
import com.example.desktop.ui.desktop.DesktopViewModel
import com.example.desktop.ui.theme.AccentPresets
import com.example.desktop.ui.theme.BackgroundPresets

@Composable
fun DesktopBuilderScreen(ui: DesktopUiState, vm: DesktopViewModel, onClose: () -> Unit) {
    val s = ui.settings
    val disabled = s.disabledComponents
    val active = WorkspaceManager.activeWorkspace(ui.workspaces)
    val canDeleteWorkspace = ui.workspaces.workspaces.size > 1

    var confirmReset by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<Workspace?>(null) }
    var pendingRestore by remember { mutableStateOf<Int?>(null) }
    var arrangementName by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Desktop Builder",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = onClose) { Text("Done") }
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Section("Components") {
                    DesktopComponent.entries.forEach { c ->
                        ComponentRow(
                            component = c,
                            disabled = disabled,
                            onToggle = { vm.setComponentEnabled(c, it) },
                            onRestore = { vm.restoreComponentDefault(c) },
                        )
                    }
                }

                Section("Appearance") {
                    SwitchRow("Dark theme", s.darkTheme) { v -> vm.updateSettings { it.copy(darkTheme = v) } }
                    SwatchRow("Background color", BackgroundPresets, s.backgroundColor) { v ->
                        vm.updateSettings { it.copy(backgroundColor = v) }
                    }
                    SwatchRow("Accent color", AccentPresets, s.accentColor) { v ->
                        vm.updateSettings { it.copy(accentColor = v) }
                    }
                    SliderRow("Window corner radius", s.cornerRadius, 0f..32f, { "${it.toInt()} dp" }) { v ->
                        vm.updateSettings { it.copy(cornerRadius = v) }
                    }
                    SwitchRow("Window borders", s.borderVisible) { v ->
                        vm.updateSettings { it.copy(borderVisible = v) }
                    }
                    SliderRow("Border thickness", s.borderThickness, 0.5f..4f, { "%.1f dp".format(it) }) { v ->
                        vm.updateSettings { it.copy(borderThickness = v) }
                    }
                    SliderRow("Window opacity", s.windowOpacity, 0.4f..1f, { "${(it * 100).toInt()}%" }) { v ->
                        vm.updateSettings { it.copy(windowOpacity = v) }
                    }
                    SliderRow("Taskbar height", s.taskbarHeight, 40f..96f, { "${it.toInt()} dp" }) { v ->
                        vm.updateSettings { it.copy(taskbarHeight = v) }
                    }
                    SliderRow("Taskbar icon size", s.taskbarIconSize, 16f..40f, { "${it.toInt()} dp" }) { v ->
                        vm.updateSettings { it.copy(taskbarIconSize = v) }
                    }
                    Text("Taskbar position", style = MaterialTheme.typography.bodyLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TaskbarPosition.entries.forEach { pos ->
                            FilterChip(
                                selected = s.taskbarPosition == pos,
                                onClick = { vm.updateSettings { it.copy(taskbarPosition = pos) } },
                                label = { Text(if (pos == TaskbarPosition.TOP) "Top" else "Bottom") },
                            )
                        }
                    }
                }

                Section("Behavior") {
                    SwitchRow("Window animations", s.animationsEnabled) { v ->
                        vm.updateSettings { it.copy(animationsEnabled = v) }
                    }
                    SliderRow("Animation duration", s.animationDurationMs.toFloat(), 0f..800f, { "${it.toInt()} ms" }) { v ->
                        vm.updateSettings { it.copy(animationDurationMs = v.toInt()) }
                    }
                    SliderRow("Default window width", s.defaultWindowWidth, 200f..800f, { "${it.toInt()} dp" }) { v ->
                        vm.updateSettings { it.copy(defaultWindowWidth = v) }
                    }
                    SliderRow("Default window height", s.defaultWindowHeight, 160f..900f, { "${it.toInt()} dp" }) { v ->
                        vm.updateSettings { it.copy(defaultWindowHeight = v) }
                    }
                    SwitchRow("Snap windows to edges", s.snapToEdges) { v ->
                        vm.updateSettings { it.copy(snapToEdges = v) }
                    }
                    SwitchRow("Large touch targets", s.largeTouchTargets) { v ->
                        vm.updateSettings { it.copy(largeTouchTargets = v) }
                    }
                }

                Section("Workspaces") {
                    ui.workspaces.workspaces.forEach { ws ->
                        WorkspaceRow(
                            workspace = ws,
                            isActive = ws.id == active.id,
                            canDelete = canDeleteWorkspace,
                            onRename = { vm.renameWorkspace(ws.id, it) },
                            onSwitch = { vm.switchWorkspace(ws.id) },
                            onDelete = { pendingDelete = ws },
                        )
                    }
                    OutlinedButton(
                        onClick = { vm.createWorkspace("") },
                        enabled = ui.workspaces.workspaces.size < WorkspaceManager.MAX_WORKSPACES,
                    ) { Text("Add workspace") }
                }

                Section("Saved arrangements in ${active.name}") {
                    OutlinedTextField(
                        value = arrangementName,
                        onValueChange = { arrangementName = it },
                        label = { Text("Arrangement name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(onClick = {
                        vm.saveArrangement(arrangementName)
                        arrangementName = ""
                    }) { Text("Save current layout") }
                    if (active.arrangements.isEmpty()) {
                        Text(
                            "No saved arrangements yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    active.arrangements.forEachIndexed { index, arrangement ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(arrangement.name, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { pendingRestore = index }) { Text("Restore") }
                        }
                    }
                }

                Section("Reset") {
                    OutlinedButton(onClick = { confirmReset = true }) { Text("Reset to defaults") }
                    Text(
                        "Resets appearance, behavior and component toggles. Open windows and workspaces are kept.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Reset settings?",
            text = "Appearance, behavior and component toggles return to their defaults.",
            confirm = "Reset",
            onConfirm = {
                vm.resetSettings()
                confirmReset = false
            },
            onDismiss = { confirmReset = false },
        )
    }
    pendingDelete?.let { ws ->
        ConfirmDialog(
            title = "Delete \"${ws.name}\"?",
            text = "Its windows and saved arrangements will be removed. This cannot be undone.",
            confirm = "Delete",
            onConfirm = {
                vm.deleteWorkspace(ws.id)
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null },
        )
    }
    pendingRestore?.let { index ->
        val name = active.arrangements.getOrNull(index)?.name ?: "arrangement"
        ConfirmDialog(
            title = "Restore \"$name\"?",
            text = "Windows currently open in ${active.name} will be replaced.",
            confirm = "Restore",
            onConfirm = {
                vm.restoreArrangement(index)
                pendingRestore = null
            },
            onDismiss = { pendingRestore = null },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun ComponentRow(
    component: DesktopComponent,
    disabled: Set<String>,
    onToggle: (Boolean) -> Unit,
    onRestore: () -> Unit,
) {
    val enabled = component.name !in disabled
    val effective = ComponentRegistry.isEnabled(component, disabled)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(component.displayName, style = MaterialTheme.typography.titleSmall)
            Text(
                component.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (enabled && !effective) {
                Text(
                    "Blocked: turn on ${component.dependencies().joinToString { it.displayName }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            TextButton(onClick = onRestore) { Text("Restore default") }
        }
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    format: (Float) -> String,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Text(format(value), style = MaterialTheme.typography.bodyMedium)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwatchRow(label: String, presets: List<Long>, selected: Long, onPick: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            presets.forEach { color ->
                val isSelected = color == selected
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(color))
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant,
                            shape = CircleShape,
                        )
                        .clickable { onPick(color) }
                        .semantics { contentDescription = "$label option ${presets.indexOf(color) + 1}" },
                )
            }
        }
    }
}

@Composable
private fun WorkspaceRow(
    workspace: Workspace,
    isActive: Boolean,
    canDelete: Boolean,
    onRename: (String) -> Unit,
    onSwitch: () -> Unit,
    onDelete: () -> Unit,
) {
    var name by remember(workspace.id, workspace.name) { mutableStateOf(workspace.name) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(if (isActive) "Active workspace" else "Workspace") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = { onRename(name) },
                enabled = name.isNotBlank() && name.trim() != workspace.name,
            ) { Text("Rename") }
            if (!isActive) {
                OutlinedButton(onClick = onSwitch) { Text("Switch") }
            }
            if (canDelete) {
                TextButton(onClick = onDelete) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    text: String,
    confirm: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
