package com.example.desktop.ui.taskbar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.desktop.core.model.WindowState
import com.example.desktop.core.model.WindowType

@Composable
fun Taskbar(
    height: Dp,
    iconSize: Dp,
    windows: List<WindowState>,
    activeWindowId: String?,
    showSettings: Boolean,
    onWindowClick: (WindowState) -> Unit,
    onOpen: (WindowType) -> Unit,
    onSettings: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().height(height),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shadowElevation = 6.dp,
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            FilledTonalButton(onClick = { onOpen(WindowType.NOTES) }) { Text("+ Notes") }
            FilledTonalButton(onClick = { onOpen(WindowType.CALCULATOR) }) { Text("+ Calc") }
            LazyRow(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                items(windows, key = { it.id }) { window ->
                    TaskbarItem(
                        window = window,
                        active = window.id == activeWindowId,
                        iconSize = iconSize,
                        onClick = { onWindowClick(window) },
                    )
                }
            }
            if (showSettings) {
                TextButton(onClick = onSettings) { Text("Settings") }
            }
        }
    }
}

@Composable
private fun TaskbarItem(window: WindowState, active: Boolean, iconSize: Dp, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) primary.copy(alpha = 0.22f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(6.dp))
                .background(primary.copy(alpha = if (window.minimized) 0.4f else 1f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = window.title.take(1),
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.labelMedium,
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            text = if (window.minimized) "${window.title} (min)" else window.title,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 120.dp),
        )
    }
}
