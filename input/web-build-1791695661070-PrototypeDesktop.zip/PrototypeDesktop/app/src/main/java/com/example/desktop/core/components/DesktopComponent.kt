package com.example.desktop.core.components

/**
 * Optional desktop elements. Each one changes the real interface when toggled.
 * Dependencies are resolved by [ComponentRegistry]; a component is only active when
 * it and everything it depends on are enabled.
 */
enum class DesktopComponent(
    val displayName: String,
    val description: String,
    val defaultEnabled: Boolean = true,
) {
    TASKBAR("Taskbar", "Window list and app bar along one screen edge."),
    BACKGROUND("Desktop background", "Colored canvas behind windows. Off uses the theme background."),
    FLOATING_CONTROL(
        "Floating menu button",
        "Round button that opens the desktop menu. Always shown while the taskbar is hidden.",
    ),
    TITLE_BARS(
        "Window title bars",
        "Headers with drag area and buttons. Off leaves a thin drag strip and moves buttons into the menu.",
    ),
    BORDERS("Window borders", "Outline drawn around each window."),
    WORKSPACE_SWITCHER(
        "Workspace switcher",
        "Tab strip for switching workspaces. Off keeps switching available in the menu.",
    ),
    SETTINGS_ENTRY(
        "Settings entry",
        "Settings button in the taskbar. Settings always remain available in the menu.",
    );

    fun dependencies(): Set<DesktopComponent> = when (this) {
        SETTINGS_ENTRY -> setOf(TASKBAR)
        else -> emptySet()
    }
}

object ComponentRegistry {
    fun isEnabled(component: DesktopComponent, disabled: Set<String>): Boolean =
        component.name !in disabled && component.dependencies().all { isEnabled(it, disabled) }

    /** The floating button is the fallback control, so it is always shown while the taskbar is hidden. */
    fun isFloatingControlVisible(disabled: Set<String>): Boolean =
        isEnabled(DesktopComponent.FLOATING_CONTROL, disabled) || !isEnabled(DesktopComponent.TASKBAR, disabled)

    fun withEnabled(disabled: Set<String>, component: DesktopComponent, enabled: Boolean): Set<String> =
        if (enabled) disabled - component.name else disabled + component.name

    fun restoreDefault(disabled: Set<String>, component: DesktopComponent): Set<String> =
        withEnabled(disabled, component, component.defaultEnabled)
}
