package com.example.desktop.core.window

import com.example.desktop.core.model.Bounds
import com.example.desktop.core.model.DesktopLayout
import com.example.desktop.core.model.WindowState
import com.example.desktop.core.model.WindowType

/**
 * Pure window-management engine. Every function takes a layout and returns a new layout,
 * so it can be unit tested without Android and reused by any window content.
 */
object WindowManager {
    const val MAX_WINDOWS = 24
    private const val Z_LIMIT = 1_000_000

    fun visibleWindows(layout: DesktopLayout): List<WindowState> =
        layout.windows.filter { !it.minimized }.sortedBy { it.zIndex }

    fun topVisibleId(windows: List<WindowState>): String? =
        windows.filter { !it.minimized }.maxByOrNull { it.zIndex }?.id

    fun open(
        layout: DesktopLayout,
        id: String,
        type: WindowType,
        bounds: Bounds,
        content: String = "",
    ): DesktopLayout {
        if (layout.windows.size >= MAX_WINDOWS || layout.windows.any { it.id == id }) return layout
        val base = headroom(layout)
        val window = WindowState(
            id = id,
            type = type,
            title = type.defaultTitle,
            bounds = bounds,
            zIndex = topZ(base) + 1,
            content = content,
        )
        return base.copy(windows = base.windows + window, activeWindowId = id)
    }

    fun focus(layout: DesktopLayout, id: String): DesktopLayout {
        val target = layout.windows.find { it.id == id } ?: return layout
        if (target.minimized) return layout
        if (layout.activeWindowId == id && target.zIndex == topZ(layout)) return layout
        val base = headroom(layout)
        val z = topZ(base) + 1
        return base.copy(
            windows = base.windows.map { if (it.id == id) it.copy(zIndex = z) else it },
            activeWindowId = id,
        )
    }

    fun close(layout: DesktopLayout, id: String): DesktopLayout {
        val remaining = layout.windows.filterNot { it.id == id }
        val active = if (layout.activeWindowId == id) topVisibleId(remaining) else layout.activeWindowId
        return layout.copy(windows = remaining, activeWindowId = active)
    }

    fun minimize(layout: DesktopLayout, id: String): DesktopLayout {
        val updated = updateWindow(layout, id) { it.copy(minimized = true) }
        val active = if (layout.activeWindowId == id) topVisibleId(updated.windows) else layout.activeWindowId
        return updated.copy(activeWindowId = active)
    }

    fun restore(layout: DesktopLayout, id: String): DesktopLayout =
        focus(updateWindow(layout, id) { it.copy(minimized = false) }, id)

    fun toggleMaximize(layout: DesktopLayout, id: String, area: Bounds): DesktopLayout {
        val updated = updateWindow(layout, id) { w ->
            if (w.maximized) {
                w.copy(bounds = w.restoreBounds ?: w.bounds, maximized = false, restoreBounds = null)
            } else {
                w.copy(restoreBounds = w.bounds, bounds = area, maximized = true)
            }
        }
        return focus(updated, id)
    }

    fun move(
        layout: DesktopLayout,
        id: String,
        dx: Float,
        dy: Float,
        canvas: CanvasSize,
        snap: Boolean,
    ): DesktopLayout {
        val target = layout.windows.find { it.id == id } ?: return layout
        if (target.maximized || target.minimized) return layout
        val updated = updateWindow(layout, id) {
            it.copy(bounds = WindowGeometry.move(it.bounds, dx, dy, canvas, snap))
        }
        return focus(updated, id)
    }

    fun resize(
        layout: DesktopLayout,
        id: String,
        edges: ResizeEdges,
        dx: Float,
        dy: Float,
        canvas: CanvasSize,
    ): DesktopLayout {
        val target = layout.windows.find { it.id == id } ?: return layout
        if (target.maximized || target.minimized) return layout
        val updated = updateWindow(layout, id) {
            it.copy(bounds = WindowGeometry.resize(it.bounds, edges, dx, dy, canvas))
        }
        return focus(updated, id)
    }

    fun updateContent(layout: DesktopLayout, id: String, content: String): DesktopLayout =
        updateWindow(layout, id) { it.copy(content = content) }

    /** Re-fits windows after the canvas changes size, for example on rotation or taskbar toggle. */
    fun fitToCanvas(layout: DesktopLayout, canvas: CanvasSize): DesktopLayout {
        val full = Bounds(0f, 0f, canvas.width, canvas.height)
        return layout.copy(
            windows = layout.windows.map { w ->
                if (w.maximized) {
                    w.copy(
                        bounds = full,
                        restoreBounds = w.restoreBounds?.let { WindowGeometry.clamp(it, canvas) },
                    )
                } else {
                    w.copy(bounds = WindowGeometry.clamp(w.bounds, canvas))
                }
            },
        )
    }

    /** Drops windows with unusable geometry, duplicate ids and extra windows beyond the limit. */
    fun sanitize(layout: DesktopLayout): DesktopLayout {
        val valid = layout.windows
            .filter { it.bounds.isUsable() }
            .distinctBy { it.id }
            .take(MAX_WINDOWS)
            .map { w -> w.copy(restoreBounds = w.restoreBounds?.takeIf { it.isUsable() }) }
        val active = layout.activeWindowId?.takeIf { id -> valid.any { it.id == id && !it.minimized } }
        return DesktopLayout(valid, active)
    }

    private fun Bounds.isUsable(): Boolean =
        x.isFinite() && y.isFinite() && width.isFinite() && height.isFinite() && width > 0f && height > 0f

    private fun topZ(layout: DesktopLayout): Int = layout.windows.maxOfOrNull { it.zIndex } ?: 0

    private fun headroom(layout: DesktopLayout): DesktopLayout =
        if (topZ(layout) >= Z_LIMIT) renumber(layout) else layout

    private fun renumber(layout: DesktopLayout): DesktopLayout {
        val order = layout.windows.sortedBy { it.zIndex }
            .mapIndexed { index, w -> w.id to index + 1 }
            .toMap()
        return layout.copy(windows = layout.windows.map { it.copy(zIndex = order.getValue(it.id)) })
    }

    private fun updateWindow(
        layout: DesktopLayout,
        id: String,
        transform: (WindowState) -> WindowState,
    ): DesktopLayout = layout.copy(windows = layout.windows.map { if (it.id == id) transform(it) else it })
}
