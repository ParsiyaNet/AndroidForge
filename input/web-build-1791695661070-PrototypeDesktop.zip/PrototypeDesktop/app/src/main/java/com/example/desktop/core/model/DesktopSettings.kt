package com.example.desktop.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class TaskbarPosition { TOP, BOTTOM }

@Serializable
data class DesktopSettings(
    val darkTheme: Boolean = true,
    val backgroundColor: Long = 0xFF1B2330L,
    val accentColor: Long = 0xFF4FB3BFL,
    val cornerRadius: Float = 14f,
    val borderVisible: Boolean = true,
    val borderThickness: Float = 1f,
    val windowOpacity: Float = 1f,
    val taskbarHeight: Float = 56f,
    val taskbarIconSize: Float = 26f,
    val taskbarPosition: TaskbarPosition = TaskbarPosition.BOTTOM,
    val animationsEnabled: Boolean = true,
    val animationDurationMs: Int = 220,
    val defaultWindowWidth: Float = 340f,
    val defaultWindowHeight: Float = 420f,
    val snapToEdges: Boolean = true,
    val largeTouchTargets: Boolean = false,
    /** Names of [com.example.desktop.core.components.DesktopComponent] that are switched off. */
    val disabledComponents: Set<String> = emptySet(),
) {
    /** Clamps stored values to supported ranges so corrupted settings cannot break the layout. */
    fun sanitized(): DesktopSettings = copy(
        cornerRadius = cornerRadius.finiteOr(14f).coerceIn(0f, 32f),
        borderThickness = borderThickness.finiteOr(1f).coerceIn(0.5f, 4f),
        windowOpacity = windowOpacity.finiteOr(1f).coerceIn(0.4f, 1f),
        taskbarHeight = taskbarHeight.finiteOr(56f).coerceIn(40f, 96f),
        taskbarIconSize = taskbarIconSize.finiteOr(26f).coerceIn(16f, 40f),
        animationDurationMs = animationDurationMs.coerceIn(0, 800),
        defaultWindowWidth = defaultWindowWidth.finiteOr(340f).coerceIn(200f, 800f),
        defaultWindowHeight = defaultWindowHeight.finiteOr(420f).coerceIn(160f, 900f),
    )
}

private fun Float.finiteOr(fallback: Float): Float = if (isFinite()) this else fallback
