package com.example.desktop.ui.desktop

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.desktop.core.model.DesktopSettings
import com.example.desktop.core.model.WindowState
import com.example.desktop.core.window.ResizeEdges
import com.example.desktop.core.window.WindowGeometry

/**
 * Renders one floating window. Gesture callbacks report movement in dp.
 * Pixel-to-dp conversion happens here so the view-model never sees device density.
 */
@Composable
fun WindowView(
    window: WindowState,
    settings: DesktopSettings,
    active: Boolean,
    titleBarVisible: Boolean,
    borderVisible: Boolean,
    onFocus: () -> Unit,
    onMove: (Float, Float) -> Unit,
    onResize: (ResizeEdges, Float, Float) -> Unit,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onClose: () -> Unit,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current.density
    val large = settings.largeTouchTargets
    val shape = RoundedCornerShape(settings.cornerRadius.dp)
    val animate = settings.animationsEnabled
    val progress = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (animate) progress.animateTo(1f, tween(durationMillis = settings.animationDurationMs))
    }
    val currentFocus by rememberUpdatedState(onFocus)
    val bounds = window.bounds
    val borderColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    val gripSize: Dp = if (large) 36.dp else 26.dp

    val frame = Modifier
        .zIndex(window.zIndex.toFloat())
        .offset(bounds.x.dp, bounds.y.dp)
        .size(bounds.width.dp, bounds.height.dp)
        .graphicsLayer {
            alpha = progress.value
            val scale = 0.94f + 0.06f * progress.value
            scaleX = scale
            scaleY = scale
        }
        .pointerInput(window.id) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                currentFocus()
            }
        }

    Surface(
        modifier = if (borderVisible) frame.border(settings.borderThickness.dp, borderColor, shape) else frame,
        shape = shape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = settings.windowOpacity),
        shadowElevation = if (active) 10.dp else 3.dp,
    ) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                if (titleBarVisible) {
                    TitleBar(
                        title = window.title,
                        active = active,
                        maximized = window.maximized,
                        large = large,
                        onDrag = { dx, dy -> onMove(dx / density, dy / density) },
                        onMinimize = onMinimize,
                        onToggleMaximize = onToggleMaximize,
                        onClose = onClose,
                    )
                } else {
                    Box(Modifier.fillMaxWidth().height(12.dp).dragGesture { dx, dy ->
                        onMove(dx / density, dy / density)
                    })
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    content()
                }
            }
            if (!window.maximized) {
                ResizeGrip(
                    alignment = Alignment.BottomEnd,
                    edges = ResizeEdges(right = true, bottom = true),
                    size = gripSize,
                    color = borderColor,
                ) { edges, dx, dy -> onResize(edges, dx / density, dy / density) }
                ResizeGrip(
                    alignment = Alignment.BottomStart,
                    edges = ResizeEdges(left = true, bottom = true),
                    size = gripSize,
                    color = borderColor,
                ) { edges, dx, dy -> onResize(edges, dx / density, dy / density) }
            }
        }
    }
}

@Composable
private fun TitleBar(
    title: String,
    active: Boolean,
    maximized: Boolean,
    large: Boolean,
    onDrag: (Float, Float) -> Unit,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onClose: () -> Unit,
) {
    val height = if (large) 44.dp else WindowGeometry.TITLE_BAR_HEIGHT.dp
    val buttonSize = if (large) 40.dp else 30.dp
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .fillMaxWidth()
            .height(height)
            .background(if (active) primary.copy(alpha = 0.16f) else Color.Transparent)
            .dragGesture(onDrag)
            .padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        WindowButton("–", "Minimize window", buttonSize, onMinimize)
        WindowButton(if (maximized) "▣" else "□", if (maximized) "Restore window" else "Maximize window", buttonSize, onToggleMaximize)
        WindowButton("×", "Close window", buttonSize, onClose)
    }
}

@Composable
private fun WindowButton(symbol: String, description: String, size: Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Text(symbol, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun BoxScope.ResizeGrip(
    alignment: Alignment,
    edges: ResizeEdges,
    size: Dp,
    color: Color,
    onResize: (ResizeEdges, Float, Float) -> Unit,
) {
    val latest by rememberUpdatedState(onResize)
    Box(
        Modifier
            .align(alignment)
            .size(size)
            .pointerInput(edges) {
                detectDragGestures { change, amount ->
                    change.consume()
                    latest(edges, amount.x, amount.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
private fun Modifier.dragGesture(onDrag: (Float, Float) -> Unit): Modifier {
    val latest by rememberUpdatedState(onDrag)
    return this.pointerInput(Unit) {
        detectDragGestures { change, amount ->
            change.consume()
            latest(amount.x, amount.y)
        }
    }
}
