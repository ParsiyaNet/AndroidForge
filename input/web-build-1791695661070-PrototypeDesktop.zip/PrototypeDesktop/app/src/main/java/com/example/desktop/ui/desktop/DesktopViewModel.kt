package com.example.desktop.ui.desktop

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.desktop.core.components.ComponentRegistry
import com.example.desktop.core.components.DesktopComponent
import com.example.desktop.core.model.Bounds
import com.example.desktop.core.model.DesktopLayout
import com.example.desktop.core.model.DesktopSettings
import com.example.desktop.core.model.WindowType
import com.example.desktop.core.model.WorkspaceState
import com.example.desktop.core.persistence.DesktopPreferences
import com.example.desktop.core.window.CanvasSize
import com.example.desktop.core.window.ResizeEdges
import com.example.desktop.core.window.WindowGeometry
import com.example.desktop.core.window.WindowManager
import com.example.desktop.core.workspace.WorkspaceManager
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class DesktopUiState(
    val loaded: Boolean = false,
    val settings: DesktopSettings = DesktopSettings(),
    val workspaces: WorkspaceState = WorkspaceManager.initial(),
) {
    val activeLayout: DesktopLayout
        get() = WorkspaceManager.activeWorkspace(workspaces).layout
}

@OptIn(FlowPreview::class)
class DesktopViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = DesktopPreferences(application)
    private val _state = MutableStateFlow(DesktopUiState())
    val state: StateFlow<DesktopUiState> = _state.asStateFlow()

    private var canvas = CanvasSize(360f, 640f)
    private var canvasKnown = false

    init {
        viewModelScope.launch {
            // Read storage once. Later writes flow from state to disk, never back,
            // so in-progress typing cannot be overwritten by a stale read.
            val settings = preferences.settings.first()
            val workspaces = preferences.workspaces.first()
            val fitted = if (canvasKnown) fitAll(workspaces) else workspaces
            _state.update { it.copy(loaded = true, settings = settings, workspaces = fitted) }

            launch {
                _state.map { it.settings }.distinctUntilChanged().debounce(300)
                    .collect { preferences.saveSettings(it) }
            }
            launch {
                _state.map { it.workspaces }.distinctUntilChanged().debounce(300)
                    .collect { preferences.saveWorkspaces(it) }
            }
        }
    }

    // Settings

    fun updateSettings(transform: (DesktopSettings) -> DesktopSettings) {
        _state.update { it.copy(settings = transform(it.settings).sanitized()) }
    }

    fun setComponentEnabled(component: DesktopComponent, enabled: Boolean) = updateSettings { s ->
        s.copy(disabledComponents = ComponentRegistry.withEnabled(s.disabledComponents, component, enabled))
    }

    fun restoreComponentDefault(component: DesktopComponent) = updateSettings { s ->
        s.copy(disabledComponents = ComponentRegistry.restoreDefault(s.disabledComponents, component))
    }

    /** Resets appearance, behavior and component toggles. Windows and workspaces are kept. */
    fun resetSettings() = updateSettings { DesktopSettings() }

    // Canvas

    fun reportCanvas(width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        val next = CanvasSize(width, height)
        canvasKnown = true
        if (next == canvas) return
        canvas = next
        if (_state.value.loaded) mutateWorkspaces { fitAll(it) }
    }

    // Windows

    fun openWindow(type: WindowType) {
        val s = _state.value.settings
        val count = _state.value.activeLayout.windows.size
        val bounds = WindowGeometry.cascade(count, canvas, s.defaultWindowWidth, s.defaultWindowHeight)
        mutateLayout { WindowManager.open(it, UUID.randomUUID().toString(), type, bounds) }
    }

    fun focusWindow(id: String) = mutateLayout { WindowManager.focus(it, id) }

    fun closeWindow(id: String) = mutateLayout { WindowManager.close(it, id) }

    fun minimizeWindow(id: String) = mutateLayout { WindowManager.minimize(it, id) }

    fun restoreWindow(id: String) = mutateLayout { WindowManager.restore(it, id) }

    fun toggleMaximize(id: String) = mutateLayout { WindowManager.toggleMaximize(it, id, canvasBounds()) }

    fun moveWindow(id: String, dx: Float, dy: Float) {
        val snap = _state.value.settings.snapToEdges
        mutateLayout { WindowManager.move(it, id, dx, dy, canvas, snap) }
    }

    fun resizeWindow(id: String, edges: ResizeEdges, dx: Float, dy: Float) =
        mutateLayout { WindowManager.resize(it, id, edges, dx, dy, canvas) }

    fun setWindowContent(id: String, content: String) =
        mutateLayout { WindowManager.updateContent(it, id, content) }

    // Workspaces

    fun createWorkspace(name: String) =
        mutateWorkspaces { WorkspaceManager.createWorkspace(it, UUID.randomUUID().toString(), name) }

    fun renameWorkspace(id: String, name: String) =
        mutateWorkspaces { WorkspaceManager.renameWorkspace(it, id, name) }

    fun deleteWorkspace(id: String) = mutateWorkspaces { WorkspaceManager.deleteWorkspace(it, id) }

    fun switchWorkspace(id: String) = mutateWorkspaces { WorkspaceManager.switchWorkspace(it, id) }

    fun saveArrangement(name: String) = mutateWorkspaces { WorkspaceManager.saveArrangement(it, name) }

    fun restoreArrangement(index: Int) =
        mutateWorkspaces { fitAll(WorkspaceManager.restoreArrangement(it, index)) }

    // Helpers

    private fun canvasBounds() = Bounds(0f, 0f, canvas.width, canvas.height)

    private fun mutateLayout(transform: (DesktopLayout) -> DesktopLayout) {
        _state.update {
            it.copy(workspaces = WorkspaceManager.updateActiveLayout(it.workspaces, transform))
        }
    }

    private fun mutateWorkspaces(transform: (WorkspaceState) -> WorkspaceState) {
        _state.update { it.copy(workspaces = transform(it.workspaces)) }
    }

    private fun fitAll(state: WorkspaceState): WorkspaceState = state.copy(
        workspaces = state.workspaces.map { it.copy(layout = WindowManager.fitToCanvas(it.layout, canvas)) },
    )
}
