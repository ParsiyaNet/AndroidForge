package com.example.desktop.ui.desktop

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.desktop.core.components.ComponentRegistry
import com.example.desktop.core.components.DesktopComponent
import com.example.desktop.core.model.TaskbarPosition
import com.example.desktop.core.model.WindowType
import com.example.desktop.core.model.WorkspaceState
import com.example.desktop.core.window.WindowManager
import com.example.desktop.core.workspace.WorkspaceManager
import com.example.desktop.features.calculator.CalculatorContent
import com.example.desktop.features.notes.NotesContent
import com.example.desktop.ui.settings.DesktopBuilderScreen
import com.example.desktop.ui.taskbar.Taskbar
import com.example.desktop.ui.theme.DesktopTheme

@Composable
fun DesktopScreen(viewModel: DesktopViewModel = viewModel()) {
    val ui by viewModel.state.collectAsStateWithLifecycle()
    DesktopTheme(ui.settings) {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .windowInsetsPadding(WindowInsets.safeDrawing),
        ) {
            if (ui.loaded) {
                DesktopContent(ui, viewModel)
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun DesktopContent(ui: DesktopUiState, vm: DesktopViewModel) {
    val settings = ui.settings
    val disabled = settings.disabledComponents
    val taskbarOn = ComponentRegistry.isEnabled(DesktopComponent.TASKBAR, disabled)
    val switcherOn = ComponentRegistry.isEnabled(DesktopComponent.WORKSPACE_SWITCHER, disabled)
    val settingsEntryOn = ComponentRegistry.isEnabled(DesktopComponent.SETTINGS_ENTRY, disabled)
    val backgroundOn = ComponentRegistry.isEnabled(DesktopComponent.BACKGROUND, disabled)
    val titleBarsOn = ComponentRegistry.isEnabled(DesktopComponent.TITLE_BARS, disabled)
    val bordersOn = ComponentRegistry.isEnabled(DesktopComponent.BORDERS, disabled) && settings.borderVisible
    val floatingVisible = ComponentRegistry.isFloatingControlVisible(disabled)
    val taskbarAtTop = taskbarOn && settings.taskbarPosition == TaskbarPosition.TOP
    val taskbarAtBottom = taskbarOn && settings.taskbarPosition == TaskbarPosition.BOTTOM
    val layout = ui.activeLayout

    var menuOpen by rememberSaveable { mutableStateOf(false) }
    var builderOpen by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = builderOpen) { builderOpen = false }

    val canvasColor = if (backgroundOn) Color(settings.backgroundColor) else MaterialTheme.colorScheme.background

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (taskbarAtTop) {
                TaskbarFor(ui, vm, settingsEntryOn) { builderOpen = true }
            }
            if (switcherOn) {
                WorkspaceSwitcher(
                    state = ui.workspaces,
                    onSwitch = { vm.switchWorkspace(it) },
                    onAdd = { vm.createWorkspace("") },
                )
            }
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).background(canvasColor)) {
                LaunchedEffect(maxWidth, maxHeight) {
                    vm.reportCanvas(maxWidth.value, maxHeight.value)
                }
                if (layout.windows.none { !it.minimized }) {
                    Text(
                        "No open windows. Use the taskbar or the Menu button to open an app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    )
                }
                WindowManager.visibleWindows(layout).forEach { window ->
                    key(window.id) {
                        WindowView(
                            window = window,
                            settings = settings,
                            active = window.id == layout.activeWindowId,
                            titleBarVisible = titleBarsOn,
                            borderVisible = bordersOn,
                            onFocus = { vm.focusWindow(window.id) },
                            onMove = { dx, dy -> vm.moveWindow(window.id, dx, dy) },
                            onResize = { edges, dx, dy -> vm.resizeWindow(window.id, edges, dx, dy) },
                            onMinimize = { vm.minimizeWindow(window.id) },
                            onToggleMaximize = { vm.toggleMaximize(window.id) },
                            onClose = { vm.closeWindow(window.id) },
                        ) {
                            when (window.type) {
                                WindowType.NOTES -> NotesContent(window.id, window.content) {
                                    vm.setWindowContent(window.id, it)
                                }
                                WindowType.CALCULATOR -> CalculatorContent(window.content) {
                                    vm.setWindowContent(window.id, it)
                                }
                            }
                        }
                    }
                }
            }
            if (taskbarAtBottom) {
                TaskbarFor(ui, vm, settingsEntryOn) { builderOpen = true }
            }
        }

        if (floatingVisible) {
            FloatingMenuButton(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .padding(bottom = if (taskbarAtBottom) settings.taskbarHeight.dp else 0.dp),
                onClick = { menuOpen = true },
            )
        }
        if (menuOpen) {
            DesktopMenu(
                ui = ui,
                vm = vm,
                onDismiss = { menuOpen = false },
                onOpenBuilder = {
                    menuOpen = false
                    builderOpen = true
                },
            )
        }
        if (builderOpen) {
            DesktopBuilderScreen(ui = ui, vm = vm, onClose = { builderOpen = false })
        }
    }
}

@Composable
private fun TaskbarFor(ui: DesktopUiState, vm: DesktopViewModel, showSettings: Boolean, onSettings: () -> Unit) {
    val layout = ui.activeLayout
    Taskbar(
        height = ui.settings.taskbarHeight.dp,
        iconSize = ui.settings.taskbarIconSize.dp,
        windows = layout.windows,
        activeWindowId = layout.activeWindowId,
        showSettings = showSettings,
        onWindowClick = { window ->
            when {
                window.minimized -> vm.restoreWindow(window.id)
                window.id == layout.activeWindowId -> vm.minimizeWindow(window.id)
                else -> vm.focusWindow(window.id)
            }
        },
        onOpen = { vm.openWindow(it) },
        onSettings = onSettings,
    )
}

@Composable
private fun WorkspaceSwitcher(state: WorkspaceState, onSwitch: (String) -> Unit, onAdd: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        state.workspaces.forEach { ws ->
            FilterChip(
                selected = ws.id == state.activeWorkspaceId,
                onClick = { onSwitch(ws.id) },
                label = { Text(ws.name, maxLines = 1) },
            )
        }
        AssistChip(
            onClick = onAdd,
            label = { Text("+ New") },
            enabled = state.workspaces.size < WorkspaceManager.MAX_WORKSPACES,
        )
    }
}

@Composable
private fun FloatingMenuButton(modifier: Modifier, onClick: () -> Unit) {
    FloatingActionButton(
        onClick = onClick,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    ) {
        Text("Menu", style = MaterialTheme.typography.labelLarge)
    }
}

/**
 * Fallback access to every desktop action. It always lists Settings and workspaces,
 * so the desktop stays usable even when the taskbar and workspace switcher are hidden.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DesktopMenu(
    ui: DesktopUiState,
    vm: DesktopViewModel,
    onDismiss: () -> Unit,
    onOpenBuilder: () -> Unit,
) {
    val layout = ui.activeLayout
    val active = layout.windows.firstOrNull { it.id == layout.activeWindowId }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            MenuHeading("Open")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.openWindow(WindowType.NOTES); onDismiss() }) { Text("Notes") }
                OutlinedButton(onClick = { vm.openWindow(WindowType.CALCULATOR); onDismiss() }) { Text("Calculator") }
            }

            MenuHeading("Windows")
            if (layout.windows.isEmpty()) {
                Text("No windows in this workspace.", style = MaterialTheme.typography.bodyMedium)
            }
            layout.windows.sortedByDescending { it.zIndex }.forEach { w ->
                TextButton(onClick = {
                    if (w.minimized) vm.restoreWindow(w.id) else vm.focusWindow(w.id)
                    onDismiss()
                }) {
                    Text(if (w.minimized) "${w.title} (minimized)" else w.title)
                }
            }

            active?.let { w ->
                MenuHeading("Active window: ${w.title}")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.minimizeWindow(w.id); onDismiss() }) { Text("Minimize") }
                    OutlinedButton(onClick = { vm.toggleMaximize(w.id); onDismiss() }) {
                        Text(if (w.maximized) "Restore" else "Maximize")
                    }
                    OutlinedButton(onClick = { vm.closeWindow(w.id); onDismiss() }) { Text("Close") }
                }
            }

            MenuHeading("Workspaces")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ui.workspaces.workspaces.forEach { ws ->
                    FilterChip(
                        selected = ws.id == ui.workspaces.activeWorkspaceId,
                        onClick = { vm.switchWorkspace(ws.id); onDismiss() },
                        label = { Text(ws.name) },
                    )
                }
            }

            Button(onClick = onOpenBuilder, modifier = Modifier.fillMaxWidth()) {
                Text("Desktop Builder")
            }
        }
    }
}

@Composable
private fun MenuHeading(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}
