package com.example.desktop.core.workspace

import com.example.desktop.core.model.DesktopLayout
import com.example.desktop.core.model.SavedArrangement
import com.example.desktop.core.model.Workspace
import com.example.desktop.core.model.WorkspaceState
import com.example.desktop.core.window.WindowManager

/** Pure workspace operations. Each workspace owns its own [DesktopLayout]. */
object WorkspaceManager {
    const val MAX_WORKSPACES = 6
    const val MAX_ARRANGEMENTS = 8
    private const val MAX_NAME_LENGTH = 32

    fun initial(): WorkspaceState {
        val first = Workspace(id = "workspace-1", name = "Workspace 1")
        val second = Workspace(id = "workspace-2", name = "Workspace 2")
        return WorkspaceState(workspaces = listOf(first, second), activeWorkspaceId = first.id)
    }

    fun activeWorkspace(state: WorkspaceState): Workspace =
        state.workspaces.firstOrNull { it.id == state.activeWorkspaceId } ?: state.workspaces.first()

    fun createWorkspace(state: WorkspaceState, id: String, name: String): WorkspaceState {
        if (state.workspaces.size >= MAX_WORKSPACES) return state
        val label = cleanName(name) ?: "Workspace ${state.workspaces.size + 1}"
        return state.copy(
            workspaces = state.workspaces + Workspace(id = id, name = label),
            activeWorkspaceId = id,
        )
    }

    fun renameWorkspace(state: WorkspaceState, id: String, name: String): WorkspaceState {
        val label = cleanName(name) ?: return state
        return state.copy(
            workspaces = state.workspaces.map { if (it.id == id) it.copy(name = label) else it },
        )
    }

    fun deleteWorkspace(state: WorkspaceState, id: String): WorkspaceState {
        if (state.workspaces.size <= 1 || state.workspaces.none { it.id == id }) return state
        val remaining = state.workspaces.filterNot { it.id == id }
        val active = if (state.activeWorkspaceId == id) remaining.first().id else state.activeWorkspaceId
        return WorkspaceState(workspaces = remaining, activeWorkspaceId = active)
    }

    fun switchWorkspace(state: WorkspaceState, id: String): WorkspaceState =
        if (state.workspaces.any { it.id == id }) state.copy(activeWorkspaceId = id) else state

    fun updateActiveLayout(state: WorkspaceState, transform: (DesktopLayout) -> DesktopLayout): WorkspaceState =
        updateActiveWorkspace(state) { it.copy(layout = transform(it.layout)) }

    fun saveArrangement(state: WorkspaceState, name: String): WorkspaceState =
        updateActiveWorkspace(state) { ws ->
            val label = cleanName(name) ?: "Arrangement ${ws.arrangements.size + 1}"
            val saved = SavedArrangement(label, ws.layout.windows)
            ws.copy(arrangements = (ws.arrangements + saved).takeLast(MAX_ARRANGEMENTS))
        }

    fun restoreArrangement(state: WorkspaceState, index: Int): WorkspaceState =
        updateActiveWorkspace(state) { ws ->
            val saved = ws.arrangements.getOrNull(index) ?: return@updateActiveWorkspace ws
            ws.copy(layout = WindowManager.sanitize(DesktopLayout(windows = saved.windows, activeWindowId = null)))
        }

    /** Repairs stored state: removes duplicates, bad windows, and restores a valid active workspace. */
    fun sanitize(state: WorkspaceState): WorkspaceState {
        val workspaces = state.workspaces
            .distinctBy { it.id }
            .take(MAX_WORKSPACES)
            .map { it.copy(layout = WindowManager.sanitize(it.layout)) }
        if (workspaces.isEmpty()) return initial()
        val active = if (workspaces.any { it.id == state.activeWorkspaceId }) {
            state.activeWorkspaceId
        } else {
            workspaces.first().id
        }
        return WorkspaceState(workspaces = workspaces, activeWorkspaceId = active)
    }

    private fun updateActiveWorkspace(state: WorkspaceState, transform: (Workspace) -> Workspace): WorkspaceState {
        val activeId = activeWorkspace(state).id
        return state.copy(
            workspaces = state.workspaces.map { if (it.id == activeId) transform(it) else it },
        )
    }

    private fun cleanName(raw: String): String? = raw.trim().take(MAX_NAME_LENGTH).ifEmpty { null }
}
