package com.example.desktop.features.calculator

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs

sealed interface CalcResult {
    data class Value(val number: Double) : CalcResult
    data class Error(val message: String) : CalcResult
    data object Empty : CalcResult
}

/**
 * Evaluates arithmetic with standard precedence and parentheses.
 * Grammar: expr = term (('+'|'-') term)*, term = factor (('*'|'/') factor)*,
 * factor = '-' factor | number | '(' expr ')'.
 */
object CalculatorEngine {
    const val MAX_LENGTH = 64

    fun evaluate(expression: String): CalcResult {
        val source = expression.filterNot { it.isWhitespace() }
        if (source.isEmpty()) return CalcResult.Empty
        return try {
            val parser = Parser(source)
            val value = parser.parseExpression()
            if (!parser.atEnd()) return CalcResult.Error("Invalid expression")
            if (value.isNaN() || value.isInfinite()) {
                CalcResult.Error("Result out of range")
            } else {
                CalcResult.Value(value)
            }
        } catch (e: CalcException) {
            CalcResult.Error(e.message ?: "Invalid expression")
        }
    }

    /** Applies one keypad press to the expression text and returns the new text. */
    fun applyKey(current: String, key: String): String = when (key) {
        "C" -> ""
        "DEL" -> current.dropLast(1)
        "=" -> when (val result = evaluate(current)) {
            is CalcResult.Value -> format(result.number)
            else -> current
        }
        else -> if (current.length >= MAX_LENGTH) current else current + normalize(key)
    }

    fun format(value: Double): String {
        val rounded = BigDecimal(value).round(MathContext(12)).stripTrailingZeros()
        return if (abs(value) >= 1e12) rounded.toString() else rounded.toPlainString()
    }

    private fun normalize(key: String): String = when (key) {
        "÷" -> "/"
        "×" -> "*"
        "−" -> "-"
        else -> key
    }
}

private class CalcException(message: String) : RuntimeException(message)

private class Parser(private val s: String) {
    private var pos = 0

    fun atEnd(): Boolean = pos >= s.length

    fun parseExpression(): Double {
        var value = parseTerm()
        while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
            val op = s[pos++]
            val right = parseTerm()
            value = if (op == '+') value + right else value - right
        }
        return value
    }

    private fun parseTerm(): Double {
        var value = parseFactor()
        while (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
            val op = s[pos++]
            val right = parseFactor()
            if (op == '*') {
                value *= right
            } else {
                if (right == 0.0) throw CalcException("Cannot divide by zero")
                value /= right
            }
        }
        return value
    }

    private fun parseFactor(): Double {
        if (pos >= s.length) throw CalcException("Incomplete expression")
        val c = s[pos]
        return when {
            c == '-' -> {
                pos++
                -parseFactor()
            }
            c == '(' -> {
                pos++
                val value = parseExpression()
                expect(')')
                value
            }
            c.isDigit() || c == '.' -> parseNumber()
            else -> throw CalcException("Invalid expression")
        }
    }

    private fun parseNumber(): Double {
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        return s.substring(start, pos).toDoubleOrNull() ?: throw CalcException("Invalid number")
    }

    private fun expect(c: Char) {
        if (pos < s.length && s[pos] == c) {
            pos++
        } else {
            throw CalcException("Missing '$c'")
        }
    }
}
