package com.example.desktop.core.persistence

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.desktop.core.model.DesktopSettings
import com.example.desktop.core.model.WorkspaceState
import com.example.desktop.core.workspace.WorkspaceManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException

private val Context.desktopDataStore by preferencesDataStore(name = "desktop_prefs")

/**
 * Persists settings and workspaces as JSON strings in DataStore.
 * Corrupt or unreadable values fall back to defaults instead of crashing.
 */
class DesktopPreferences(context: Context) {
    private val dataStore = context.applicationContext.desktopDataStore
    private val json = Json { ignoreUnknownKeys = true }
    private val settingsKey = stringPreferencesKey("settings_json")
    private val workspacesKey = stringPreferencesKey("workspaces_json")

    val settings: Flow<DesktopSettings> = reading { prefs ->
        decode<DesktopSettings>(prefs[settingsKey])?.sanitized() ?: DesktopSettings()
    }

    val workspaces: Flow<WorkspaceState> = reading { prefs ->
        decode<WorkspaceState>(prefs[workspacesKey])?.let { WorkspaceManager.sanitize(it) }
            ?: WorkspaceManager.initial()
    }

    suspend fun saveSettings(settings: DesktopSettings) {
        val encoded = json.encodeToString(settings)
        dataStore.edit { it[settingsKey] = encoded }
    }

    suspend fun saveWorkspaces(state: WorkspaceState) {
        val encoded = json.encodeToString(state)
        dataStore.edit { it[workspacesKey] = encoded }
    }

    private fun <T> reading(mapper: (Preferences) -> T): Flow<T> =
        dataStore.data
            .catch { e ->
                if (e is IOException) emit(emptyPreferences()) else throw e
            }
            .map(mapper)

    private inline fun <reified T> decode(raw: String?): T? =
        raw?.let { runCatching { json.decodeFromString<T>(it) }.getOrNull() }
}
