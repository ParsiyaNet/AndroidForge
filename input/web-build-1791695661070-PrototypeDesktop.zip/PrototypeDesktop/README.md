# Prototype Desktop (Prototype 1)

A Kotlin + Jetpack Compose prototype of a touch-first desktop canvas for Android. It has a floating-window
manager, a configurable taskbar, workspaces, a modular component system, and a Desktop Builder settings screen.

> **Status:** source written but not compiled or run on a device. The first build may need small fixes.
> Pure logic (geometry, window manager, workspaces, components, settings, calculator) has unit tests.
> UI has no automated tests yet. See `FEATURE_CHECKLIST.md`.

## Build

Requirements: Android Studio Ladybug (2024.2) or newer, JDK 17, Android SDK 34.

1. Open the `PrototypeDesktop` folder in Android Studio and let it sync.
2. Run unit tests: `./gradlew test` (Windows: `gradlew.bat test`).
3. Build a debug APK: `./gradlew assembleDebug`
   Output: `app/build/outputs/apk/debug/app-debug.apk`
4. Install on a device with USB debugging on: `./gradlew installDebug`

The Gradle wrapper is not checked in. Generate it once with a locally installed Gradle 8.7 or newer:

    gradle wrapper --gradle-version 8.7

Android Studio also creates it when you sync. Gradle 8.7 or newer is required by AGP 8.5.2.

Versions: AGP 8.5.2, Kotlin 2.0.21 (with the Compose compiler plugin), Compose BOM 2024.09.00,
DataStore 1.1.1, kotlinx.serialization 1.7.3, JUnit 4.13.2.

## Architecture

    app/src/main/java/com/example/desktop/
      MainActivity.kt
      core/
        model/          Serializable data: windows, layouts, workspaces, DesktopSettings
        window/         WindowGeometry (pure math), WindowManager (pure state transitions)
        workspace/      WorkspaceManager (pure workspace operations)
        components/     DesktopComponent enum + ComponentRegistry (toggles and dependencies)
        persistence/    DesktopPreferences (DataStore, JSON, falls back to defaults on bad data)
      features/
        notes/          NotesContent (editable text window body)
        calculator/     CalculatorEngine (pure parser), CalculatorContent (keypad UI)
      ui/
        theme/          DesktopTheme built from DesktopSettings
        desktop/        DesktopScreen, DesktopViewModel, WindowView
        taskbar/        Taskbar
        settings/       DesktopBuilderScreen

Design rules:

- **Pure core.** `core/` and `features/calculator/CalculatorEngine` have no Android imports, so they run as plain JVM tests.
  Every window and workspace operation is `(layout, args) -> layout`.
- **One source of truth.** `DesktopViewModel` holds a single `StateFlow<DesktopUiState>`. Compose only reads it.
  Storage is read once at startup. After that, state flows out to DataStore (debounced), never back in,
  so a stale read cannot overwrite what the user is typing.
- **Window content is data.** Each window stores a `content` string (note text or calculator expression), so content
  persists with the layout. New window types need a `WindowType` entry and a composable branch in `DesktopContent`.
- **Components are switches with real effects.** `ComponentRegistry` decides what is visible. Fallbacks keep the
  desktop usable: the floating Menu button appears whenever the taskbar is hidden, and the Menu always lists
  Settings, Windows, the active-window actions, and workspaces.
- **Coordinates are dp.** `WindowView` converts pixel drag amounts to dp once, so the engine never depends on screen density.
  The canvas size is reported by the UI and used for clamping.

## Known limitations

- Not compiled in the authoring environment. Expect possible compile errors to fix on first build.
- Installed third-party apps are not integrated (Phase E). See `FEATURE_CHECKLIST.md`.
- Room is not used. Workspaces and settings are stored as JSON in DataStore, which is enough for a
  few small documents.
- Each keystroke in Notes updates the view-model state, so the whole desktop recomposes. This is fine for
  a prototype but should be scoped to the window before many windows are open.
- Window title text is fixed per type. Renaming a window is not implemented.
