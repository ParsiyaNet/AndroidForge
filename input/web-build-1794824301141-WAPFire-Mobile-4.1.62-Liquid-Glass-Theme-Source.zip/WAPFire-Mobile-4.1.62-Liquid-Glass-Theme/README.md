# WAPFire Mobile 4.1.62

Android companion app for WAPFire. This source package includes the native Kotlin/Jetpack Compose app, bundled offline Nara assistant assets, and Gradle build scripts.

See `CHANGELOG-4.1.62.md` for the latest visual fixes and `VALIDATION-4.1.62.txt` for the checks performed.
