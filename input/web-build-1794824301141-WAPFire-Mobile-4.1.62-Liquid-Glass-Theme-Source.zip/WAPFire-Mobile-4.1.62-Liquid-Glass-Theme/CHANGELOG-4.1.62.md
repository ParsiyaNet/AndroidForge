# 4.1.62 — Parked WebView bleed fix + stronger bottom navigation glass

## Visual fixes
- Every liquid-glass fill layer now receives the same explicit rounded shape, preventing rectangular fill
  layers from appearing behind rounded metric tiles on affected Android composition paths.
- Preloaded Nara WebViews remain attached and measured for warm-up, but now use `alpha = 0f` while parked.
  This prevents their native hardware layers from appearing as hard-edged dark rectangles beneath translucent
  Compose cards. The view returns to `alpha = 1f` only when the assistant screen adopts it.
- Increased the floating bottom navigation glass strength from `1.35` to `1.55` so content behind the
  navigation buttons is less visible and labels remain easier to read in dark mode.

## Unchanged
- WebView preloading, WebGL sizing, assistant state, navigation behavior, networking and monitoring logic.
