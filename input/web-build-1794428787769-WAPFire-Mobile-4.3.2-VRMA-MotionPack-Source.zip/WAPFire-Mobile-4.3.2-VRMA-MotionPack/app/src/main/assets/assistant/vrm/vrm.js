/* WAPFire 4.3.2 - VRM character renderer driven by the original VRMA Motion Pack.
 * Native contract remains unchanged:
 *   window.wapfireSetState(state) / WapFireNative.reportReady() / reportStatus() / reportFatal()
 * Body motion is loaded from pixiv's VRMA files and retargeted by @pixiv/three-vrm-animation.
 * The local pose engine is retained for facial expressions/blinks only; it never writes humanoid bones.
 */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { VRMAnimationLoaderPlugin, createVRMAnimationClip } from '@pixiv/three-vrm-animation';
import { create as createPose } from './vrm-pose.js';

const BUILD = '4.3.2';
window.__wfPreflightStarted = true;
window.__wfAssistantBuildVersion = BUILD;
window.__wfAssistantDocumentExpected = true;
window.__wfEngineBooted = true;

const q = new URLSearchParams(location.search);
const fa = q.get('lang') !== 'en';
const compact = q.get('compact') !== '0';
const $ = (id) => document.getElementById(id);
const bridge = window.WapFireNative;
document.documentElement.lang = fa ? 'fa' : 'en';
document.body.className = compact ? 'compact' : 'full';

const D = Math.PI / 180;
const userZoom = parseFloat(q.get('zoom') || '1') || 1;
const userDy = parseFloat(q.get('dy') || '0') || 0;
let pendingState = q.get('state') || 'idle';
let stateRevision = 0;
let ready = false;

function report(message) {
  try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ }
}
function fatal(message) {
  const text = String(message).slice(0, 400);
  console.error(text);
  const box = $('loading');
  if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
  report(text);
  try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
}
window.addEventListener('error', (e) => { if (!ready) fatal('VRM error: ' + (e.message || e)); });
window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('VRM error: ' + ((e.reason && e.reason.message) || e.reason)); });

/* ---------- native-facing state labels ---------- */
const PILL = {
  idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
  success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
  warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
  setup: ['Setup required', 'نیازمند راه‌اندازی']
};
const poseSeed = (Date.now() ^ Math.floor(Math.random() * 0x7fffffff)) >>> 0;
const poseEngine = createPose(poseSeed || 7);
const nowSec = () => performance.now() / 1000;

/* ---------- original VRMA Motion Pack ----------
 * 01 Show full body | 02 Greeting | 03 Peace sign | 04 Shoot
 * 05 Spin | 06 Model pose | 07 Squat
 * Gestures are played once, then settle into the Model pose. No motion is run in a fixed loop.
 */
const MOTIONS = {
  intro:      { file: 'VRMA_01.vrma', label: 'Show full body' },
  greeting:   { file: 'VRMA_02.vrma', label: 'Greeting' },
  peace:      { file: 'VRMA_03.vrma', label: 'Peace sign' },
  shoot:      { file: 'VRMA_04.vrma', label: 'Shoot' },
  spin:       { file: 'VRMA_05.vrma', label: 'Spin' },
  modelPose:  { file: 'VRMA_06.vrma', label: 'Model pose' },
  squat:      { file: 'VRMA_07.vrma', label: 'Squat' }
};
const STATE_MOTION = {
  idle: 'modelPose', scanning: 'modelPose', connecting: 'spin',
  success: 'peace', password_success: 'peace',
  password_warning: 'shoot', warning: 'shoot', angry: 'shoot',
  offline: 'squat', setup: 'greeting'
};

let vrm = null;
let facing = 1;
let loader = null;
let mixer = null;
let activeAction = null;
let activeMotionId = null;
let motionRequestToken = 0;
const motionCache = new Map();
const motionPromises = new Map();
let exprNames = new Set();
let surprisedName = null;

function setExpr(name, value) {
  if (name && exprNames.has(name) && vrm && vrm.expressionManager) {
    vrm.expressionManager.setValue(name, Math.max(0, Math.min(1, value || 0)));
  }
}

function showState(name) {
  const state = PILL[name] ? name : 'idle';
  const changed = state !== pendingState;
  pendingState = state;
  if (changed) stateRevision++;
  $('shell').dataset.state = state;
  $('stateText').textContent = PILL[state][fa ? 1 : 0];
  poseEngine.setState(state, nowSec());
  // Same-state notifications are deliberately ignored: never restart an animation mid-gesture.
  if (changed && ready) void playStateMotion(state);
}
window.wapfireSetState = (state) => { try { showState(String(state)); } catch (e) { report(String(e)); } };

/* ---------- three.js scene ---------- */
const canvas = $('stage');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setClearColor(0x000000, 0);
canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (!ready) fatal('WebGL context lost while starting.'); });

const scene = new THREE.Scene();
const FOV = 20;
const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 30);
const key = new THREE.DirectionalLight(0xffffff, Math.PI);
key.position.set(0.5, 0.9, 1.2).normalize();
scene.add(key);
scene.add(new THREE.AmbientLight(0xffffff, 0.45));

/* ---------- framing (measured from the VRM mesh) ---------- */
const M = { top: 1.495, chin: 1.23, halfW: 0.207 };
const FRAME = {
  full: { top: 0.188, head: 0.32, maxW: 0.92 },
  compact: { top: 0.022, head: 0.41, maxW: 0.92 }
};
function fit() {
  const box = $('stageBox');
  const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
  renderer.setSize(W, H, false);
  camera.aspect = W / H;
  const cfg = compact ? FRAME.compact : FRAME.full;
  const headH = M.top - M.chin;
  let worldH = headH / cfg.head;
  worldH = Math.max(worldH, (2 * M.halfW / cfg.maxW) / camera.aspect) / userZoom;
  const topY = M.top + (cfg.top + userDy) * worldH;
  const cy = topY - worldH / 2;
  const dist = (worldH / 2) / Math.tan(FOV * D / 2);
  camera.position.set(0, cy, facing * dist);
  camera.lookAt(0, cy, 0);
  camera.updateProjectionMatrix();
}
window.wapfireFrame = (zoom, dy) => { fit(); return { zoom, dy }; };

/* ---------- facial expression layer only ----------
 * VRMA owns every humanoid bone. This layer only blends VRM expression presets and blinks.
 */
function applyExpressions(frame) {
  const E = frame && frame.expr ? frame.expr : {};
  setExpr('happy', E.happy);
  setExpr('sad', E.sad);
  setExpr('angry', E.angry);
  setExpr('relaxed', E.relaxed);
  setExpr(surprisedName, E.surprised);
  setExpr('blink', E.blink);
}

/* ---------- VRMA loading and playback ---------- */
async function loadMotion(id) {
  if (motionCache.has(id)) return motionCache.get(id);
  if (motionPromises.has(id)) return motionPromises.get(id);
  const meta = MOTIONS[id];
  if (!meta) throw new Error('Unknown VRMA motion: ' + id);
  const promise = (async () => {
    report((fa ? 'بارگذاری حرکت: ' : 'Loading motion: ') + meta.label);
    const gltfMotion = await loader.loadAsync('./motions/' + meta.file);
    const animation = gltfMotion.userData && gltfMotion.userData.vrmAnimations && gltfMotion.userData.vrmAnimations[0];
    if (!animation) throw new Error(meta.file + ' has no VRM animation extension.');
    const clip = createVRMAnimationClip(animation, vrm);
    if (!clip || !clip.tracks || clip.tracks.length === 0) throw new Error(meta.file + ' produced an empty animation clip.');
    clip.name = 'WAPFire-' + id;
    motionCache.set(id, clip);
    report((fa ? 'حرکت آماده شد: ' : 'Motion ready: ') + meta.label + ' (' + clip.duration.toFixed(1) + 's)');
    return clip;
  })();
  motionPromises.set(id, promise);
  try {
    return await promise;
  } catch (error) {
    motionPromises.delete(id);
    throw error;
  }
}

async function playMotion(id, options = {}) {
  if (!vrm || !mixer || !loader) return false;
  const token = ++motionRequestToken;
  const revision = options.expectedRevision === undefined ? stateRevision : options.expectedRevision;
  const fade = Math.max(0.15, options.fade === undefined ? 0.72 : options.fade);
  try {
    const clip = await loadMotion(id);
    if (token !== motionRequestToken || revision !== stateRevision) return false;
    // A state can map to the same clip as the current state; keep it running/held rather than restarting it.
    if (activeMotionId === id && activeAction) return true;

    const action = mixer.clipAction(clip);
    if (activeAction && activeAction !== action) activeAction.fadeOut(fade);
    action.reset();
    action.enabled = true;
    action.paused = false;
    action.clampWhenFinished = true;
    action.setLoop(THREE.LoopOnce, 1);
    action.fadeIn(fade).play();
    activeAction = action;
    activeMotionId = id;

    if (options.settleToBase && id !== 'modelPose') {
      const settleAfter = (event) => {
        if (event.action !== action) return;
        mixer.removeEventListener('finished', settleAfter);
        if (activeAction !== action || revision !== stateRevision) return;
        void playMotion('modelPose', { fade: 0.82, expectedRevision: revision });
      };
      mixer.addEventListener('finished', settleAfter);
    }
    return true;
  } catch (error) {
    console.warn('VRMA playback failed for ' + id, error);
    report((fa ? 'خطا در حرکت ' : 'Motion error: ') + (MOTIONS[id] ? MOTIONS[id].label : id));
    return false;
  }
}

async function playStateMotion(state, expectedRevision = stateRevision) {
  const id = STATE_MOTION[state] || 'modelPose';
  if (id === 'modelPose') return playMotion(id, { expectedRevision, fade: 0.72 });
  return playMotion(id, { expectedRevision, fade: 0.72, settleToBase: true });
}

// Developer/test hook: play a pack item by its two-digit number (01..07).
window.wapfirePlayMotion = (number) => {
  const id = ({ '01': 'intro', '02': 'greeting', '03': 'peace', '04': 'shoot', '05': 'spin', '06': 'modelPose', '07': 'squat' })[String(number).padStart(2, '0')];
  if (!id) return Promise.resolve(false);
  return playMotion(id, { settleToBase: id !== 'modelPose' });
};
window.wapfireVrmInfo = () => JSON.stringify({
  build: BUILD,
  renderer: 'VRMA Motion Pack',
  activeMotion: activeMotionId,
  loadedMotions: Array.from(motionCache.keys()),
  expressions: Array.from(exprNames),
  surprised: surprisedName
});

/* ---------- main loop ---------- */
let last = performance.now();
function tick() {
  const nowMs = performance.now();
  const dt = Math.min(0.1, Math.max(0.001, (nowMs - last) / 1000));
  last = nowMs;
  if (vrm) {
    applyExpressions(poseEngine.update(nowMs / 1000, dt));
    if (mixer) mixer.update(dt);
    vrm.update(dt);
  }
  renderer.render(scene, camera);
}

/* ---------- boot ---------- */
async function boot() {
  report(fa ? 'در حال بارگذاری مدل VRM…' : 'Loading VRM model…');
  loader = new GLTFLoader();
  loader.register((parser) => new VRMLoaderPlugin(parser));
  loader.register((parser) => new VRMAnimationLoaderPlugin(parser));

  let lastPct = -1;
  const gltf = await loader.loadAsync('./model/nara.vrm', (e) => {
    if (!e.lengthComputable) return;
    const pct = Math.floor((e.loaded / e.total) * 100);
    if (pct !== lastPct && pct % 10 === 0) { lastPct = pct; report((fa ? 'بارگذاری مدل VRM… ' : 'Loading VRM model… ') + pct + '%'); }
  });
  vrm = gltf.userData.vrm;
  if (!vrm) throw new Error('The file is not a VRM model.');
  if (VRMUtils.removeUnnecessaryVertices) VRMUtils.removeUnnecessaryVertices(gltf.scene);
  if (VRMUtils.removeUnnecessaryJoints) VRMUtils.removeUnnecessaryJoints(vrm.scene);
  VRMUtils.rotateVRM0(vrm);
  vrm.scene.traverse((o) => { o.frustumCulled = false; });
  scene.add(vrm.scene);

  const em = vrm.expressionManager;
  exprNames = new Set(em ? Object.keys(em.expressionMap || {}) : []);
  surprisedName = ['Surprised', 'surprised'].find((n) => exprNames.has(n)) || null;
  mixer = new THREE.AnimationMixer(vrm.scene);
  report('VRM ready; loading the original VRMA motion.');

  fit();
  if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
  window.addEventListener('resize', () => requestAnimationFrame(fit));

  // At first idle launch, play the pack's full-body entrance once, then settle into its model pose.
  // If native sends a different initial state while loading, play the latest state instead.
  for (let attempt = 0; attempt < 4; attempt++) {
    const state = pendingState;
    const revision = stateRevision;
    let ok;
    if (state === 'idle' && attempt === 0) {
      ok = await playMotion('intro', { expectedRevision: revision, fade: 0.7, settleToBase: true });
      if (!ok && revision === stateRevision) ok = await playMotion('modelPose', { expectedRevision: revision });
    } else {
      ok = await playStateMotion(state, revision);
      if (!ok && revision === stateRevision && state !== 'idle') {
        await playMotion('modelPose', { expectedRevision: revision });
      }
    }
    if (revision === stateRevision) break;
  }

  renderer.setAnimationLoop(tick);
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  fit();
  ready = true;
  window.__wfRendererReady = true;
  $('loading').style.display = 'none';
  report('VRM ready: ' + window.wapfireVrmInfo());
  try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
}

showState(pendingState);
boot().catch((error) => fatal('VRM failed to start: ' + ((error && error.message) || error)));
