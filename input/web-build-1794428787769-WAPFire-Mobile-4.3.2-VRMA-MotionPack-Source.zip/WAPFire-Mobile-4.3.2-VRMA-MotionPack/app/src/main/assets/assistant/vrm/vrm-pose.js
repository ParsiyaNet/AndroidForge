/* WAPFire 4.3.2 facial expression layer.
 * All humanoid body motion comes from the supplied VRMA Motion Pack.
 * This module only blends face expressions and irregular blinks; it never writes bones.
 */
const EXPRESSIONS = ['happy', 'sad', 'angry', 'relaxed', 'surprised'];
const STATE_TARGETS = {
  idle:             { happy: 0.13 },
  scanning:         { relaxed: 0.06, angry: 0.06 },
  connecting:       { happy: 0.10, relaxed: 0.28 },
  success:          { happy: 1.00 },
  password_success: { happy: 0.68, relaxed: 0.18 },
  password_warning: { sad: 0.62, surprised: 0.10 },
  warning:          { surprised: 0.82, sad: 0.10 },
  angry:            { angry: 0.92 },
  offline:          { sad: 0.82 },
  setup:            { happy: 0.46, relaxed: 0.18 }
};
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

function create(seedValue) {
  let seed = (Math.abs(Math.floor(Number.isFinite(seedValue) ? seedValue : 7)) % 2147483646) + 1;
  const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const range = (low, high) => low + (high - low) * random();
  let state = 'idle';
  const current = Object.fromEntries(EXPRESSIONS.map((key) => [key, STATE_TARGETS.idle[key] || 0]));
  let blinkStarted = -1;
  let nextBlink = 0;
  let doubleBlinkPending = false;

  function setState(name, now) {
    const next = STATE_TARGETS[name] ? name : 'idle';
    if (next === state) return false;
    state = next;
    return true;
  }

  function update(now, dt) {
    const safeDt = clamp(Number.isFinite(dt) ? dt : 1 / 60, 0, 0.1);
    const target = STATE_TARGETS[state] || STATE_TARGETS.idle;
    const blend = 1 - Math.exp(-safeDt / 0.34);
    for (const key of EXPRESSIONS) {
      current[key] += ((target[key] || 0) - current[key]) * blend;
    }

    if (nextBlink === 0) nextBlink = now + range(1.6, 3.3);
    if (blinkStarted < 0 && now >= nextBlink) blinkStarted = now;

    let blink = 0;
    if (blinkStarted >= 0) {
      const age = now - blinkStarted;
      const duration = 0.16;
      if (age < duration) {
        blink = Math.pow(Math.sin(Math.PI * clamp(age / duration, 0, 1)), 1.2);
      } else {
        blinkStarted = -1;
        if (!doubleBlinkPending && random() < 0.13) {
          doubleBlinkPending = true;
          nextBlink = now + range(0.22, 0.38);
        } else {
          doubleBlinkPending = false;
          nextBlink = now + range(2.1, 5.0);
        }
      }
    }

    return { expr: { ...current, blink } };
  }

  return { setState, update };
}

export { create, STATE_TARGETS, EXPRESSIONS };
export default { create, STATE_TARGETS, EXPRESSIONS };
