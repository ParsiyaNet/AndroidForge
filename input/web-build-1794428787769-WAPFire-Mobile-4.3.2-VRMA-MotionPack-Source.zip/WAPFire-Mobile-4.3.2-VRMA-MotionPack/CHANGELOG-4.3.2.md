# WAPFire Mobile 4.3.2 — Native VRMA Motion Pack integration

- Replaced procedural full-body bone movement with the seven supplied pixiv VRMA Motion Pack animations.
- Added the official `@pixiv/three-vrm-animation` 3.3.3 runtime, pinned alongside `@pixiv/three-vrm` 3.3.3 and Three.js 0.170.0.
- Added the VRMA loader plugin and retargeted each VRMA clip to the current Nara VRM humanoid using `createVRMAnimationClip`.
- Added state-aware motion selection: initial entrance, greeting, peace sign, shoot/alert, spin/connecting, model pose/idle, and squat/offline.
- Gestures play once and crossfade back to the Model pose; no supplied motion is put into a fixed repeating loop.
- Duplicate state notifications do not restart the current clip. A newer state supersedes an animation that is still loading.
- Kept the facial expression and blink layer, but removed its writes to humanoid bones so it cannot fight the VRMA animation mixer.
- Added all seven VRMA assets to the WebView asset preflight and local Android assets. Runtime playback remains offline.
- Added the pixiv VRoid Project animation credit and retained the original motion-pack readme files.

Validation completed: all seven files parse as GLB 2.0 with `VRMC_vrm_animation` specVersion `1.0`, contain one animation each, and create non-empty humanoid animation input data (metadata: 53–91 channels; durations 7.27–11.80 seconds). JavaScript syntax and project asset-reference checks pass.

Not verified in this environment: a full Android APK build (Gradle requires downloading the pinned JavaScript runtime) or visual playback on a physical Android device. The included Gradle task fetches the missing runtime at build time.
