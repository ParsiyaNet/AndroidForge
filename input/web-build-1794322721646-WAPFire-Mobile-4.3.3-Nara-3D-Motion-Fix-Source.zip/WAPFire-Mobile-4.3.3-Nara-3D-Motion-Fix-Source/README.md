# WAPFire Mobile 4.3.3 — Nara 3D Motion Fix (No Unity)

Based on WAPFire Mobile 4.2.0 — Dark Matte Glass. Nara is a real VRM avatar rendered in Android WebView with Three.js r180 and @pixiv/three-vrm 3.5.5. Unity and all character audio/voice subsystems are excluded.

## 4.3.3 motion corrections

- Restores the calibrated AvatarSample_A relaxed shoulder/elbow pose from the earlier WAPFire VRM renderer.
- Removes mismatched full-body VRMA clips that caused arm/torso intersections and abrupt repeated cycles.
- Uses short, one-shot, rig-calibrated procedural gestures for success, warning and angry states. Each gesture has a continuous cubic Hermite path and returns to the relaxed pose.
- Same-state telemetry updates no longer reset gestures to their first frame.
- Idle breathing, subtle head/shoulder movement, scanning gaze, blink timing, facial expressions, and VRM spring bones continue locally without looping a full-body clip.
- Touch reactions use a gentle head/facial response rather than moving a hand through the torso.
- Restores the 4.2.0 camera framing: compact Overview zoom 1.38 and immersive zoom 1.10 / 1.06 / 1.00 depending on viewport aspect.

## Offline runtime

The Android Gradle `preBuild` task retrieves version-pinned Three.js r180 and @pixiv/three-vrm 3.5.5 modules into app assets and rewrites their imports for local WebView use. The VRM model is packaged with the app. After Build and installation, the model, renderer and all animation logic run locally; no external assets or audio are fetched at runtime. The initial Build needs network access for pinned renderer modules.

## Build

AndroidForge can build the ZIP using the Android/Gradle target and `assembleDebug`. The direct Gradle command is:

```powershell
.\gradlew.bat :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`. Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compile/target SDK 35, minimum SDK 29.

## Verification status

`VALIDATION-4.3.3.txt` records source-level checks. JavaScript syntax and archive integrity are checked in the preparation environment. The Android project was not compiled into an APK and the gestures were not visually verified on a physical device; treat this as a source correction requiring AndroidForge Build and device-side confirmation.

## Licensing

See `app/src/main/assets/assistant/VRM-MODEL-ATTRIBUTION.txt` and the vendor MIT license files generated during Build. AvatarSample_A retains its embedded VRoid Hub permission profile.
