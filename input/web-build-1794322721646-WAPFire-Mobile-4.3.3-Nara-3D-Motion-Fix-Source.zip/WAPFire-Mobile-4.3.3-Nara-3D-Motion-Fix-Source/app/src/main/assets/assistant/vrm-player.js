import * as THREE from './vendor/three.module.js';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';
import { VRMLoaderPlugin, VRMUtils } from './vendor/three-vrm.module.min.js';

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const smooth = (value) => {
  const t = clamp(value, 0, 1);
  return t * t * (3 - 2 * t);
};
const lerp = (a, b, t) => a + (b - a) * t;

// This avatar is authored in a strict T-pose. These calibrated offsets are from
// WAPFire's previous working VRM renderer and keep both arms beside the torso.
const REST_POSE = Object.freeze({
  headX: 0, headY: 0, headZ: 0,
  neckX: 0, neckY: 0, neckZ: 0,
  spineX: 0, spineY: 0, spineZ: 0,
  chestX: 0, chestY: 0, chestZ: 0,
  upperChestX: 0, upperChestY: 0, upperChestZ: 0,
  hipsY: 0,
  leftShoulderZ: 0, rightShoulderZ: 0,
  leftUpperArmX: 0, leftUpperArmY: 0, leftUpperArmZ: 1.10,
  rightUpperArmX: 0, rightUpperArmY: 0, rightUpperArmZ: -1.10,
  leftLowerArmX: 0, leftLowerArmY: 0, leftLowerArmZ: 0.18,
  rightLowerArmX: 0, rightLowerArmY: 0, rightLowerArmZ: -0.18,
  leftHandX: 0, leftHandY: 0, leftHandZ: 0,
  rightHandX: 0, rightHandY: 0, rightHandZ: 0,
});

// Every gesture is a short, hand-authored pose sequence for this exact rig.
// No generic full-body clip is looped, so hands cannot be driven across the chest
// by an unrelated avatar's motion capture. The final key always returns to REST_POSE.
const GESTURES = {
  success: [
    [0.00, {}],
    [0.30, { rightUpperArmZ: 0.34, rightLowerArmX: -0.16, rightHandZ: -0.04 }],
    [0.62, { rightUpperArmZ: 0.56, rightLowerArmX: -0.30, rightHandZ: 0.10 }],
    [0.84, { rightUpperArmZ: 0.56, rightLowerArmX: -0.30, rightHandY: 0.20 }],
    [1.06, { rightUpperArmZ: 0.56, rightLowerArmX: -0.30, rightHandY: -0.19 }],
    [1.28, { rightUpperArmZ: 0.56, rightLowerArmX: -0.30, rightHandY: 0.17 }],
    [1.50, { rightUpperArmZ: 0.56, rightLowerArmX: -0.30, rightHandY: -0.12 }],
    [1.82, { rightUpperArmZ: 0.40, rightLowerArmX: -0.18 }],
    [2.24, {}],
  ],
  warning: [
    [0.00, {}],
    [0.28, { leftUpperArmZ: -0.23, rightUpperArmZ: 0.23, leftLowerArmX: -0.10, rightLowerArmX: 0.10 }],
    [0.72, { leftUpperArmZ: -0.32, rightUpperArmZ: 0.32, leftLowerArmX: -0.12, rightLowerArmX: 0.12 }],
    [1.02, { leftUpperArmZ: -0.32, rightUpperArmZ: 0.32, leftLowerArmX: -0.12, rightLowerArmX: 0.12 }],
    [1.48, { leftUpperArmZ: -0.18, rightUpperArmZ: 0.18, leftLowerArmX: -0.06, rightLowerArmX: 0.06 }],
    [1.92, {}],
  ],
  angry: [
    [0.00, {}],
    [0.20, { leftUpperArmZ: -0.08, rightUpperArmZ: 0.08, leftLowerArmX: -0.19, rightLowerArmX: 0.19, chestX: -0.025, headX: -0.025 }],
    [0.54, { leftUpperArmZ: -0.10, rightUpperArmZ: 0.10, leftLowerArmX: -0.22, rightLowerArmX: 0.22, chestX: -0.025, headX: -0.025 }],
    [0.94, { leftUpperArmZ: -0.06, rightUpperArmZ: 0.06, leftLowerArmX: -0.13, rightLowerArmX: 0.13 }],
    [1.38, {}],
  ],
};

const STATE_HOLD = {
  idle: {},
  scanning: {},
  connecting: { headZ: 0.035, neckZ: 0.018 },
  success: {},
  password_success: {},
  password_warning: { headX: -0.018 },
  warning: { headX: -0.018 },
  angry: {},
  offline: { headX: 0.045, headZ: 0.035, chestX: 0.012 },
  setup: { headZ: -0.035, neckZ: -0.018 },
};

const EMOTION_ALIASES = {
  happy: ['happy', 'joy', 'Joy', 'fun', 'Fun'],
  angry: ['angry', 'Angry'],
  sad: ['sad', 'sorrow', 'Sorrow'],
  surprised: ['surprised', 'Surprised'],
  relaxed: ['relaxed', 'neutral', 'Neutral'],
  blink: ['blink', 'Blink'],
};

/** Offline VRM companion. All body motion is procedural and calibrated to AvatarSample_A. */
export class Player {
  constructor(canvas, options = {}) {
    if (!(canvas instanceof HTMLCanvasElement)) throw new TypeError('Nara 3D requires a canvas element.');
    this.canvas = canvas;
    this.options = options;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
      premultipliedAlpha: true,
      depth: true,
      stencil: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setClearColor(0x000000, 0);
    this.maxAnisotropy = Math.min(this.renderer.capabilities.getMaxAnisotropy(), 8);
    this.pixelRatio = Math.min(options.maxPixelRatio || window.devicePixelRatio || 1, 1.5);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(28, 1, 0.01, 100);
    this.camera.position.set(0, 1, 3);
    this.scene.add(new THREE.HemisphereLight(0xd6eaff, 0x26364b, 1.7));
    const key = new THREE.DirectionalLight(0xfff4ea, 2.25);
    key.position.set(-2.6, 4.5, 4.0);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x83cfff, 0.88);
    fill.position.set(3.2, 2.3, -2.0);
    this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xa5caff, 0.48);
    rim.position.set(-1.5, 2.6, -3.5);
    this.scene.add(rim);

    this.model = { name: 'AvatarSample_A' };
    this.vrm = null;
    this.bones = Object.create(null);
    this.state = 'idle';
    this.stateStarted = 0;
    this.externalEmotion = null;
    this.away = false;
    this.view = { x: 0, y: -0.025, zoom: 1 };
    this.puppet = { model: { canvas: [1024, 1536] }, zoom: 1, panY: 0 };
    this.bounds = new THREE.Box3();
    this.center = new THREE.Vector3(0, 0.8, 0);
    this.dimensions = new THREE.Vector3(0.6, 1.6, 0.4);
    this.lookTarget = new THREE.Object3D();
    this.scene.add(this.lookTarget);
    this.look = { x: 0, y: 0 };
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();

    this.currentPose = { ...REST_POSE };
    this.transitionFrom = { ...REST_POSE };
    this.transitionStarted = 0;
    this.transitionDuration = 0.58;
    this.clock = 0;
    this.nextBlinkAt = 2.7 + Math.random() * 2.2;
    this.blinkStarted = -10;
    this.touchStarted = -10;
    this.touchUntil = -1;
    this.raf = 0;
    this.lastFrame = 0;
    this.disposed = false;
    this.visible = true;
    this.onContextLost = null;

    this._onContextLost = (event) => {
      event.preventDefault();
      this.pause();
      this.onContextLost?.();
    };
    this._onVisibility = () => {
      this.visible = document.visibilityState !== 'hidden';
      if (this.visible && options.autoplay !== false) this.play();
    };
    this._onPointerDown = (event) => {
      if (!this.vrm || !event || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return;
      const rect = this.canvas.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      this.pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -(((event.clientY - rect.top) / rect.height) * 2 - 1));
      this.raycaster.setFromCamera(this.pointer, this.camera);
      const hits = this.raycaster.intersectObject(this.vrm.scene, true);
      if (hits.length) this.triggerTouch();
    };
    canvas.addEventListener('webglcontextlost', this._onContextLost, false);
    canvas.addEventListener('pointerdown', this._onPointerDown, { passive: true });
    document.addEventListener('visibilitychange', this._onVisibility);
    this.resize();
    if (options.autoplay !== false) this.play();
  }

  _createLoader() {
    const loader = new GLTFLoader();
    loader.crossOrigin = 'anonymous';
    loader.register((parser) => new VRMLoaderPlugin(parser));
    return loader;
  }

  _getBone(name) {
    try { return this.vrm?.humanoid?.getNormalizedBoneNode?.(name) || null; }
    catch (_) { return null; }
  }

  async load(url, { onProgress } = {}) {
    if (this.disposed) throw new Error('Renderer disposed before character load.');
    const gltf = await this._createLoader().loadAsync(url, (event) => {
      if (typeof onProgress === 'function' && event.total > 0) {
        onProgress({ step: 'model', progress: clamp(event.loaded / event.total, 0, 1) });
      }
    });
    const vrm = gltf?.userData?.vrm;
    if (!vrm?.scene || !vrm?.humanoid) throw new Error('AvatarSample_A did not contain a valid VRM humanoid rig.');
    this.vrm = vrm;
    VRMUtils.rotateVRM0(vrm);
    try { VRMUtils.combineSkeletons(vrm.scene); }
    catch (error) { console.warn('Optional skeleton optimization skipped:', error); }

    vrm.scene.traverse((object) => {
      object.frustumCulled = false;
      const materials = Array.isArray(object.material) ? object.material : (object.material ? [object.material] : []);
      for (const material of materials) {
        for (const value of Object.values(material)) {
          if (value?.isTexture) {
            value.anisotropy = this.maxAnisotropy;
            value.needsUpdate = true;
          }
        }
      }
    });

    this.scene.add(vrm.scene);
    vrm.scene.updateMatrixWorld(true);
    this.bounds.setFromObject(vrm.scene);
    if (this.bounds.isEmpty()) throw new Error('AvatarSample_A contains no visible mesh geometry.');
    this.bounds.getCenter(this.center);
    this.bounds.getSize(this.dimensions);
    if (!Number.isFinite(this.dimensions.y) || this.dimensions.y < 0.2) throw new Error('Avatar model dimensions are invalid.');

    this.model = {
      name: vrm.meta?.name || vrm.meta?.title || 'AvatarSample_A',
      format: `VRM ${vrm.meta?.metaVersion || '0.x'}`,
      expressions: vrm.expressionManager?.expressions?.map((item) => item.expressionName) || [],
    };

    const names = [
      'head', 'neck', 'spine', 'chest', 'upperChest', 'hips',
      'leftShoulder', 'rightShoulder', 'leftUpperArm', 'rightUpperArm',
      'leftLowerArm', 'rightLowerArm', 'leftHand', 'rightHand',
    ];
    for (const name of names) {
      const bone = this._getBone(name);
      if (bone) this.bones[name] = {
        bone,
        rotation: bone.rotation.clone(),
        position: bone.position.clone(),
      };
    }

    // Establish the same relaxed shoulder/elbow pose used by the earlier WAPFire VRM player.
    this._applyPose(REST_POSE);
    if (vrm.lookAt) {
      vrm.lookAt.target = this.lookTarget;
      vrm.lookAt.autoUpdate = true;
    }
    this.lookAt(null, 0);
    this._applyStateExpression();
    this._updateCamera();
    this.resize();
    this._renderOnce();
    if (typeof onProgress === 'function') onProgress({ step: 'model', progress: 1 });
    return this;
  }

  _findExpression(names) {
    const manager = this.vrm?.expressionManager;
    if (!manager) return null;
    for (const name of (EMOTION_ALIASES[names] || [names])) {
      if (manager.getExpression?.(name)) return name;
    }
    return null;
  }

  _setExpression(name, weight) {
    const manager = this.vrm?.expressionManager;
    if (!manager) return;
    const resolved = this._findExpression(name);
    if (resolved) manager.setValue(resolved, clamp(weight, 0, 1));
  }

  _applyStateExpression() {
    if (!this.vrm?.expressionManager) return;
    for (const name of ['happy', 'angry', 'sad', 'surprised', 'relaxed']) this._setExpression(name, 0);
    const stateExpression = {
      idle: ['relaxed', 0.12],
      scanning: ['relaxed', 0.12],
      connecting: ['relaxed', 0.16],
      setup: ['relaxed', 0.16],
      success: ['happy', 0.52],
      password_success: ['happy', 0.52],
      password_warning: ['surprised', 0.34],
      warning: ['surprised', 0.34],
      angry: ['angry', 0.62],
      offline: ['sad', 0.42],
    }[this.state];
    if (stateExpression) this._setExpression(stateExpression[0], stateExpression[1]);
    if (this.externalEmotion) {
      const alias = ({ smile: 'happy', shy: 'relaxed', happy: 'happy', sad: 'sad', angry: 'angry', surprised: 'surprised' })[this.externalEmotion] || this.externalEmotion;
      this._setExpression(alias, 0.38);
    }
  }

  setExpression(expression) {
    this.externalEmotion = expression == null ? null : String(expression);
    this._applyStateExpression();
  }

  setAway(value) { this.away = !!value; }

  _sampleGesture(elapsed, keys) {
    if (!keys || keys.length < 2 || elapsed <= 0 || elapsed >= keys[keys.length - 1][0]) return {};
    let index = 0;
    while (index < keys.length - 2 && elapsed > keys[index + 1][0]) index++;
    const a = keys[index];
    const b = keys[index + 1];
    const before = keys[Math.max(0, index - 1)];
    const after = keys[Math.min(keys.length - 1, index + 2)];
    const span = Math.max(0.001, b[0] - a[0]);
    const u = clamp((elapsed - a[0]) / span, 0, 1);
    const u2 = u * u;
    const u3 = u2 * u;
    const h00 = 2 * u3 - 3 * u2 + 1;
    const h10 = u3 - 2 * u2 + u;
    const h01 = -2 * u3 + 3 * u2;
    const h11 = u3 - u2;
    const channels = new Set([...Object.keys(a[1]), ...Object.keys(b[1])]);
    const output = {};
    for (const channel of channels) {
      const p0 = before[1][channel] || 0;
      const p1 = a[1][channel] || 0;
      const p2 = b[1][channel] || 0;
      const p3 = after[1][channel] || 0;
      const t0 = before[0];
      const t1 = a[0];
      const t2 = b[0];
      const t3 = after[0];
      // Time-aware cubic Hermite interpolation preserves velocity through the middle
      // keys; only the beginning and end ease to rest. This avoids the robotic stop/start
      // feeling of applying smoothstep separately to every keyframe.
      const slope1 = index === 0 ? 0 : ((p2 - p0) / Math.max(0.001, t2 - t0)) * span;
      const slope2 = index + 1 === keys.length - 1 ? 0 : ((p3 - p1) / Math.max(0.001, t3 - t1)) * span;
      let value = h00 * p1 + h10 * slope1 + h01 * p2 + h11 * slope2;
      const low = Math.min(p1, p2) - 0.04;
      const high = Math.max(p1, p2) + 0.04;
      value = clamp(value, low, high);
      output[channel] = value;
    }
    return output;
  }

  _desiredPose() {
    const pose = { ...REST_POSE };
    const hold = STATE_HOLD[this.state] || {};
    for (const [key, value] of Object.entries(hold)) pose[key] = value;

    const elapsed = Math.max(0, this.clock - this.stateStarted);
    const gestureName = this.state === 'password_success' ? 'success' :
      (this.state === 'password_warning' ? 'warning' : this.state);
    const gesture = this._sampleGesture(elapsed, GESTURES[gestureName]);
    for (const [key, value] of Object.entries(gesture)) pose[key] = (pose[key] || 0) + value;

    // Blush is an expression/head reaction only; no hand is sent through the torso or face.
    if (this.touchUntil >= 0 && this.clock < this.touchUntil) {
      const age = this.clock - this.touchStarted;
      const envelope = Math.sin(Math.PI * clamp(age / Math.max(0.1, this.touchUntil - this.touchStarted), 0, 1));
      pose.headZ += 0.045 * envelope;
      pose.headX -= 0.012 * envelope;
    }

    // Continuous low-amplitude life motion. This phase never resets when a state changes.
    const t = this.clock;
    if (!this.away) {
      pose.chestX += Math.sin(t * 1.25) * 0.009;
      pose.spineX += Math.sin(t * 1.25 - 0.35) * 0.004;
      pose.headZ += Math.sin(t * 0.48) * 0.009;
      pose.headY += Math.sin(t * 0.36) * 0.012;
      pose.leftUpperArmY += Math.sin(t * 0.72) * 0.012;
      pose.rightUpperArmY -= Math.sin(t * 0.72) * 0.012;
      pose.leftHandZ += Math.sin(t * 0.72 + 0.4) * 0.014;
      pose.rightHandZ -= Math.sin(t * 0.72 + 0.4) * 0.014;
    }
    if (this.state === 'scanning') {
      pose.headY += Math.sin(t * 0.62) * 0.055;
      pose.neckY += Math.sin(t * 0.62) * 0.022;
    }
    if (this.state === 'offline') {
      pose.chestX += Math.sin(t * 0.82) * 0.004;
    }
    return pose;
  }

  _applyPose(pose) {
    for (const [name, item] of Object.entries(this.bones)) {
      const bone = item.bone;
      // Match the previous WAPFire VRM player's known-good local Euler offsets exactly.
      bone.rotation.copy(item.rotation);
      bone.rotation.x += pose[`${name}X`] || 0;
      bone.rotation.y += pose[`${name}Y`] || 0;
      bone.rotation.z += pose[`${name}Z`] || 0;
      if (name === 'hips') {
        bone.position.copy(item.position);
        bone.position.y += pose.hipsY || 0;
      }
    }
  }

  setState(value, force = false) {
    const requested = String(value || '').toLowerCase();
    const nextState = Object.prototype.hasOwnProperty.call(STATE_HOLD, requested) ? requested : 'idle';
    // Ignore repeated telemetry updates for the same state. A state transition should not
    // restart a gesture from frame zero; only a real state change starts a new reaction.
    if (nextState === this.state) return false;
    this.transitionFrom = { ...this.currentPose };
    this.transitionStarted = this.clock;
    this.transitionDuration = 0.58;
    this.state = nextState;
    this.stateStarted = this.clock;
    this._applyStateExpression();
    return true;
  }

  triggerTouch() {
    if (!this.vrm || this.clock < this.touchUntil) return false;
    this.touchStarted = this.clock;
    this.touchUntil = this.clock + 1.45;
    this._applyStateExpression();
    return true;
  }

  lookAt(x, y = 0) {
    this.look = x == null ? { x: 0, y: 0 } : { x: clamp(Number(x) || 0, -1, 1), y: clamp(Number(y) || 0, -1, 1) };
    this._updateLookTarget(0, false);
  }

  _updateLookTarget(time, animate) {
    const scan = animate && this.state === 'scanning' ? Math.sin(time * 0.62) * 0.12 : 0;
    const x = this.center.x + (this.look.x + scan) * this.dimensions.x * 0.9;
    const headY = this.bounds.isEmpty() ? 1.35 : this.bounds.min.y + this.dimensions.y * 0.83;
    const y = headY + this.look.y * this.dimensions.y * 0.22;
    this.lookTarget.position.set(x, y, this.center.z + Math.max(this.dimensions.y * 2.5, 2.5));
  }

  blink() { this.blinkStarted = this.clock; }

  _updateCamera() {
    if (!this.vrm || this.bounds.isEmpty()) return;
    const aspect = Math.max(0.25, this.canvas.clientWidth / Math.max(1, this.canvas.clientHeight));
    this.camera.aspect = aspect;
    const halfFov = THREE.MathUtils.degToRad(this.camera.fov / 2);
    const heightDistance = this.dimensions.y / (2 * Math.tan(halfFov));
    const widthDistance = this.dimensions.x / (2 * Math.tan(halfFov) * aspect);
    const zoom = clamp(this.view.zoom || 1, 0.75, 1.55);
    const baseDistance = Math.max(heightDistance, widthDistance, 1.0) * 1.10;
    const distance = baseDistance / zoom;
    const targetY = this.center.y - (this.view.y || 0) * this.dimensions.y;
    const targetX = this.center.x + (this.view.x || 0) * this.dimensions.x;
    this.camera.position.set(targetX, targetY, this.center.z + distance);
    this.camera.lookAt(targetX, targetY, this.center.z);
    this.camera.near = Math.max(0.01, distance / 100);
    this.camera.far = distance + this.dimensions.y * 5 + 10;
    this.camera.updateProjectionMatrix();
  }

  resize() {
    if (this.disposed) return;
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.max(1, this.canvas.clientWidth || rect.width || 1);
    const height = Math.max(1, this.canvas.clientHeight || rect.height || 1);
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(width, height, false);
    this._updateCamera();
    this._renderOnce();
  }

  _update(delta) {
    if (!this.vrm) return;
    this.clock += delta;
    const target = this._desiredPose();
    const transitionAmount = smooth((this.clock - this.transitionStarted) / this.transitionDuration);
    const pose = {};
    for (const key of Object.keys(REST_POSE)) {
      pose[key] = lerp(this.transitionFrom[key] ?? REST_POSE[key], target[key] ?? REST_POSE[key], transitionAmount);
    }
    this.currentPose = pose;
    this._applyPose(pose);

    if (this.clock >= this.nextBlinkAt) {
      this.blinkStarted = this.clock;
      this.nextBlinkAt = this.clock + 2.8 + Math.random() * 2.4;
    }
    const blinkAge = this.clock - this.blinkStarted;
    const blinkWeight = blinkAge >= 0 && blinkAge < 0.16 ? Math.sin((blinkAge / 0.16) * Math.PI) : 0;
    this._setExpression('blink', this.away ? Math.max(blinkWeight, 0.72) : blinkWeight);
    if (this.touchUntil >= 0 && this.clock < this.touchUntil) {
      const touchAge = this.clock - this.touchStarted;
      const touchEnvelope = Math.sin(Math.PI * clamp(touchAge / Math.max(0.1, this.touchUntil - this.touchStarted), 0, 1));
      this._setExpression('relaxed', 0.16 + 0.18 * touchEnvelope);
    }
    this._updateLookTarget(this.clock, true);
    this.vrm.update(delta);
  }

  _renderOnce() {
    if (this.disposed || !this.renderer || !this.visible) return;
    this.renderer.render(this.scene, this.camera);
  }

  _frame = (timestamp) => {
    if (!this.raf || this.disposed) return;
    const rawDelta = this.lastFrame ? (timestamp - this.lastFrame) / 1000 : 1 / 30;
    this.lastFrame = timestamp;
    const delta = clamp(rawDelta, 0, 1 / 20);
    if (this.visible) {
      this._update(delta);
      this.renderer.render(this.scene, this.camera);
    }
    this.raf = requestAnimationFrame(this._frame);
  };

  play() {
    if (this.disposed || this.raf) return;
    this.lastFrame = 0;
    this.raf = requestAnimationFrame(this._frame);
  }

  pause() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.lastFrame = 0;
  }

  dispose() {
    if (this.disposed) return;
    this.pause();
    this.disposed = true;
    this.canvas.removeEventListener('webglcontextlost', this._onContextLost, false);
    this.canvas.removeEventListener('pointerdown', this._onPointerDown, false);
    document.removeEventListener('visibilitychange', this._onVisibility);
    if (this.vrm?.scene) {
      this.scene.remove(this.vrm.scene);
      try { VRMUtils.deepDispose(this.vrm.scene); } catch (_) { /* best effort GPU cleanup */ }
    }
    this.renderer.dispose();
    this.bones = Object.create(null);
    this.vrm = null;
  }
}
