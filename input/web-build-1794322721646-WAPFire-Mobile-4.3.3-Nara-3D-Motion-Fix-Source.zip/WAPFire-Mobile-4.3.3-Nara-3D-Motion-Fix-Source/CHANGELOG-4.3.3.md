# WAPFire Mobile 4.3.3

- Replaced mismatched looping full-body VRMA clips with calibrated, one-shot procedural humanoid gestures for AvatarSample_A.
- Restored the known relaxed shoulder/elbow baseline pose to prevent arm/torso intersections.
- Added eased success wave, outward warning gesture, subtle angry pose, stable sad/thinking holds, and continuous non-resetting idle/scanning micro-motion.
- Prevented repeated same-state telemetry updates from restarting gestures.
- Restored the 4.2.0 framing scale: Overview zoom 1.38 and responsive full-screen zoom 1.10 / 1.06 / 1.00.
- Removed unused VRMA runtime imports, assets, download tasks, and attribution.
- Still no Unity, TTS, speech recognition, voice controls, or runtime network loading.

- Matched bone Euler offsets to the prior working WAPFire VRM baseline to preserve AvatarSample_A's calibrated local arm pose.
