package io.wapfire.mobile

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.LinkProperties
import android.net.MacAddress
import java.net.Inet4Address
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class WifiAccessPoint(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val secured: Boolean,
    val frequency: Int,
    val securityMode: String,
    val capabilities: String
) {
    val isWapFire: Boolean get() = ssid.contains("wapfire", ignoreCase = true)
}

data class CurrentWifi(val ssid: String, val gateway: String, val localIp: String = "", val netmask: String = "")

class WifiDiscovery(context: Context) {
    private val appContext = context.applicationContext
    private val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun scan(): List<WifiAccessPoint> = withContext(Dispatchers.IO) {
        try { wifi.startScan() } catch (_: Exception) { false }
        delay(1400)
        try {
            wifi.scanResults
                .filter { it.SSID.isNotBlank() }
                // Preserve same-SSID APs: BSSID is the unique radio identity used to join
                // the exact selected WAPFire access point.
                .distinctBy { it.BSSID.orEmpty().lowercase(Locale.ROOT) }
                .sortedByDescending { it.level }
                .map {
                    val caps = it.capabilities.orEmpty().uppercase(Locale.ROOT)
                    val hasSae = caps.contains("SAE")
                    val hasPsk = caps.contains("PSK")
                    val security = when {
                        hasSae && hasPsk -> "WPA2_WPA3"
                        hasSae -> "WPA3"
                        hasPsk -> "WPA2"
                        caps.contains("WEP") -> "WEP"
                        else -> "OPEN"
                    }
                    WifiAccessPoint(
                        ssid = it.SSID,
                        bssid = it.BSSID.orEmpty(),
                        rssi = it.level,
                        secured = security != "OPEN",
                        frequency = it.frequency,
                        securityMode = security,
                        capabilities = caps
                    )
                }
        } catch (_: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    fun current(): CurrentWifi {
        return try {
            val info = wifi.connectionInfo
            val raw = info?.ssid.orEmpty()
            val ssid = raw.removePrefix("\"").removeSuffix("\"").takeIf { it != "<unknown ssid>" }.orEmpty()
            val dhcp = wifi.dhcpInfo
            fun littleEndianIpv4(value: Int): String = if (value == 0) "" else listOf(
                value and 0xff,
                (value shr 8) and 0xff,
                (value shr 16) and 0xff,
                (value shr 24) and 0xff
            ).joinToString(".")
            CurrentWifi(
                ssid = ssid,
                gateway = littleEndianIpv4(dhcp?.gateway ?: 0),
                localIp = littleEndianIpv4(dhcp?.ipAddress ?: 0),
                netmask = littleEndianIpv4(dhcp?.netmask ?: 0)
            )
        } catch (_: Exception) { CurrentWifi("", "") }
    }

    /**
     * Discovers WAPFire WebUI hosts on the phone's current Wi-Fi subnet.
     * It only probes TCP/80 and confirms the firmware's distinctive login-page title.
     */
    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun findWapFireOnLan(): List<String> = withContext(Dispatchers.IO) {
        val dhcp = try { wifi.dhcpInfo } catch (_: Exception) { null }
        val rawIp = dhcp?.ipAddress ?: 0
        if (rawIp == 0) return@withContext emptyList()
        val ip = Integer.reverseBytes(rawIp)
        val rawMask = dhcp?.netmask ?: 0
        val mask = if (rawMask == 0) -256 else Integer.reverseBytes(rawMask)
        var network = ip and mask
        var broadcast = network or mask.inv()
        // Avoid accidentally scanning very large corporate/VLAN subnets from a phone.
        if (broadcast - network > 512) {
            val mask24 = -256
            network = ip and mask24
            broadcast = network or mask24.inv()
        }
        val phoneIp = ip
        val candidates = (network + 1 until broadcast).filter { it != phoneIp }
        if (candidates.isEmpty()) return@withContext emptyList()

        coroutineScope {
            candidates.chunked(24).flatMap { batch ->
                batch.map { address ->
                    async(Dispatchers.IO) {
                        val host = InetAddress.getByAddress(byteArrayOf(
                            (address shr 24).toByte(),
                            (address shr 16).toByte(),
                            (address shr 8).toByte(),
                            address.toByte()
                        )).hostAddress ?: return@async null
                        try {
                            val connection = (URL("http://$host/").openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"
                                connectTimeout = 250
                                readTimeout = 250
                                instanceFollowRedirects = false
                                useCaches = false
                            }
                            val signature = try {
                                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                                    val buffer = CharArray(4096)
                                    val count = reader.read(buffer)
                                    if (count > 0) String(buffer, 0, count).lowercase() else ""
                                }
                            } finally { connection.disconnect() }
                            if (signature.contains("<title>wapfire - authentication</title>")) host else null
                        } catch (_: Exception) { null }
                    }
                }.awaitAll().filterNotNull()
            }
        }.distinct()
    }

    suspend fun findWapFireHost(network: Network, preferredHost: String): String? = withContext(Dispatchers.IO) {
        // Prefer the actual IPv4 gateway from LinkProperties, then try ESP-IDF's
        // standard SoftAP address. Some Android builds expose incomplete routes
        // briefly while DHCP is still completing.
        val candidates = listOf(preferredHost, "192.168.4.1").filter { it.isNotBlank() }.distinct()
        for (host in candidates) {
            repeat(3) { attempt ->
                try {
                    val connection = (network.openConnection(URL("http://$host/")) as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 2200
                        readTimeout = 2200
                        instanceFollowRedirects = false
                        useCaches = false
                        setRequestProperty("Cache-Control", "no-cache")
                    }
                    val page = try {
                        val code = connection.responseCode
                        val stream = if (code in 200..399) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(16_384) }.orEmpty()
                        code in 200..399 && body.contains("WAPFire - Authentication", ignoreCase = true)
                    } finally { connection.disconnect() }
                    if (page) return@withContext host
                } catch (_: Exception) { }
                if (attempt < 2) delay(450)
            }
        }
        null
    }

    companion object {
        fun requiredPermissions(): Array<String> = buildList {
            add(android.Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(android.Manifest.permission.NEARBY_WIFI_DEVICES)
        }.toTypedArray()
    }
}

class WifiConnector(context: Context) {
    private val appContext = context.applicationContext
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeCallback: ConnectivityManager.NetworkCallback? = null

    fun bindToCurrentWifi(): Boolean {
        return try {
            val network = connectivity.activeNetwork ?: return false
            val caps = connectivity.getNetworkCapabilities(network) ?: return false
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return false
            connectivity.bindProcessToNetwork(network)
            true
        } catch (_: Exception) { false }
    }

    private fun ipv4Gateway(properties: LinkProperties?): String? {
        return properties?.routes
            ?.firstOrNull { route -> route.isDefaultRoute && route.gateway is Inet4Address }
            ?.gateway?.hostAddress
    }

    fun connect(
        ssid: String,
        bssid: String,
        password: String,
        securityMode: String,
        onAvailable: (Network, String) -> Unit,
        onFailure: (String) -> Unit,
        onLost: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 29) {
            onFailure("Android 10 or newer is required for secure local Wi-Fi joining.")
            return
        }
        release()
        try {
            val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (bssid.isNotBlank()) specBuilder.setBssid(MacAddress.fromString(bssid))

            // WAPFire advertises ESP-IDF WIFI_AUTH_WPA2_WPA3_PSK (transition mode)
            // with PMF capable=true / required=false. Android 10+ uses SAE/WPA3
            // for WPA2/WPA3 transition APs, so use setWpa3Passphrase for that mode.
            when (securityMode) {
                "WPA2_WPA3", "WPA3" -> specBuilder.setWpa3Passphrase(password)
                "WPA2" -> specBuilder.setWpa2Passphrase(password)
                "OPEN" -> Unit
                else -> if (password.isNotBlank()) specBuilder.setWpa2Passphrase(password)
            }

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specBuilder.build())
                .build()

            val delivered = AtomicBoolean(false)
            fun reportAvailable(network: Network, properties: LinkProperties? = null) {
                if (!delivered.compareAndSet(false, true)) return
                val gateway = ipv4Gateway(properties)
                    ?: ipv4Gateway(connectivity.getLinkProperties(network))
                    ?: "192.168.4.1" // WAPFire SoftAP uses this IPv4 address.
                mainHandler.post { onAvailable.invoke(network, gateway) }
            }

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // Bind the app's HTTP client to the local-only WAPFire network;
                    // it intentionally has no Internet capability. Wait for DHCP/IPv4
                    // LinkProperties before falling back to the firmware's known AP IP.
                    connectivity.bindProcessToNetwork(network)
                    mainHandler.postDelayed({
                        if (!delivered.get()) reportAvailable(network, connectivity.getLinkProperties(network))
                    }, 1800)
                }

                override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                    if (!delivered.get() && ipv4Gateway(linkProperties) != null) {
                        reportAvailable(network, linkProperties)
                    }
                }

                override fun onUnavailable() {
                    mainHandler.post { onFailure.invoke("Android could not authenticate to $ssid using $securityMode. Check the WAPFire Wi-Fi password and retry.") }
                }

                override fun onLost(network: Network) {
                    connectivity.bindProcessToNetwork(null)
                    mainHandler.post { onLost.invoke() }
                }
            }
            activeCallback = callback
            connectivity.requestNetwork(request, callback, 60_000)
        } catch (e: Exception) {
            activeCallback = null
            onFailure(e.message ?: "Could not create the Wi-Fi connection request.")
        }
    }

    fun release() {
        try { connectivity.bindProcessToNetwork(null) } catch (_: Exception) { }
        activeCallback?.let {
            try { connectivity.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        activeCallback = null
    }
}
