# Resource Meter Theme Match

- Settings > DEVICE STATUS meters (CPU Core 0, CPU Core 1, Internal RAM, PSRAM) no longer use fixed teal/green/amber colours.
- Progress-bar track (the bar background) is now derived from the app Palette: an inset dark-indigo track in dark mode and a soft indigo track in light mode (the old track was a green-teal slate).
- Bar fills use theme gradients built from the Palette accent / blue / violet colours.
- The four cards use the same glass-style gradient surface and indigo rim as the rest of the app, and the value text uses the theme accent, in both dark and light themes.
- No telemetry bindings, layout breakpoints, firmware or API behaviour changed.
