package io.wapfire.mobile

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.LinkProperties
import android.net.MacAddress
import java.net.Inet4Address
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiInfo
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class WifiAccessPoint(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val secured: Boolean,
    val frequency: Int,
    val securityMode: String,
    val capabilities: String,
    val isCurrentConnection: Boolean = false
) {
    // WAPFire identity is carried by the SoftAP BSSID, not by its editable SSID.
    val isWapFire: Boolean get() = WifiDiscovery.isWapFireBssid(bssid)
}

data class CurrentWifi(
    val ssid: String,
    val gateway: String,
    val localIp: String = "",
    val netmask: String = "",
    val connected: Boolean = false,
    val bssid: String = "",
    val rssi: Int = -100,
    val frequency: Int = 0
)

class WifiDiscovery(context: Context) {
    private val appContext = context.applicationContext
    private val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun scan(): List<WifiAccessPoint> = withContext(Dispatchers.IO) {
        // Capture the active BSSID before/while scanning. Android may omit the
        // currently associated AP from scanResults on some devices.
        val activeWifi = current()
        try { wifi.startScan() } catch (_: Exception) { false }
        delay(1400)

        val discovered = try {
            wifi.scanResults
                .filter { it.SSID.isNotBlank() && isWapFireBssid(it.BSSID) }
                .distinctBy { it.BSSID.orEmpty().lowercase(Locale.ROOT) }
                .map { result ->
                    val caps = result.capabilities.orEmpty().uppercase(Locale.ROOT)
                    val hasSae = caps.contains("SAE")
                    val hasPsk = caps.contains("PSK")
                    val security = when {
                        hasSae && hasPsk -> "WPA2_WPA3"
                        hasSae -> "WPA3"
                        hasPsk -> "WPA2"
                        caps.contains("WEP") -> "WEP"
                        else -> "OPEN"
                    }
                    WifiAccessPoint(
                        ssid = result.SSID,
                        bssid = result.BSSID.orEmpty(),
                        rssi = result.level,
                        secured = security != "OPEN",
                        frequency = result.frequency,
                        securityMode = security,
                        capabilities = caps,
                        isCurrentConnection = result.BSSID.equals(activeWifi.bssid, ignoreCase = true)
                    )
                }
        } catch (_: SecurityException) { emptyList() }

        // Keep the connected WAPFire visible even when the platform's scan cache
        // omits the AP. Its normal SoftAP configuration uses WPA2/WPA3 transition mode.
        val currentBssid = activeWifi.bssid
        val currentSsid = activeWifi.ssid.ifBlank { "WAPFire Device" }
        val withCurrent = if (isWapFireBssid(currentBssid) &&
            discovered.none { it.bssid.equals(currentBssid, ignoreCase = true) }) {
            discovered + WifiAccessPoint(
                ssid = currentSsid,
                bssid = currentBssid,
                rssi = activeWifi.rssi.takeIf { it in -126..0 } ?: -100,
                secured = true,
                frequency = activeWifi.frequency,
                securityMode = "WPA2_WPA3",
                capabilities = "[WPA2-PSK-CCMP][SAE]",
                isCurrentConnection = true
            )
        } else discovered

        withCurrent.distinctBy { it.bssid.lowercase(Locale.ROOT) }
            .sortedWith(compareByDescending<WifiAccessPoint> { it.bssid.equals(activeWifi.bssid, ignoreCase = true) }
                .thenByDescending { it.rssi })
    }

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    fun current(): CurrentWifi {
        fun cleanSsid(raw: String?): String = raw.orEmpty()
            .removePrefix("\"").removeSuffix("\"")
            .takeIf { it.isNotBlank() && it != "<unknown ssid>" }
            .orEmpty()

        fun prefixMask(prefix: Int): String {
            val safePrefix = prefix.coerceIn(0, 32)
            val mask = if (safePrefix == 0) 0L else (0xffffffffL shl (32 - safePrefix)) and 0xffffffffL
            return (24 downTo 0 step 8).joinToString(".") { shift -> ((mask shr shift) and 0xff).toString() }
        }

        return try {
            // On Android 12+, WifiManager.connectionInfo can return <unknown ssid>
            // while DHCP information is still present. Use ConnectivityManager's
            // transport and LinkProperties as the authoritative connection state.
            val all = connectivity.allNetworks.toList()
            val ordered = (listOfNotNull(connectivity.activeNetwork) + all).distinct()
            for (network in ordered) {
                val caps = connectivity.getNetworkCapabilities(network) ?: continue
                if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
                val properties = connectivity.getLinkProperties(network)
                val ipv4 = properties?.linkAddresses
                    ?.mapNotNull { it.address as? Inet4Address }
                    ?.firstOrNull { !it.isLoopbackAddress && !it.isLinkLocalAddress }
                val gateway = properties?.routes
                    ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
                    ?.gateway?.hostAddress.orEmpty()
                val linkAddress = properties?.linkAddresses
                    ?.firstOrNull { it.address is Inet4Address && !(it.address as Inet4Address).isLoopbackAddress }
                val transportInfo = caps.transportInfo as? WifiInfo
                val legacyInfo = try { wifi.connectionInfo } catch (_: Exception) { null }
                val ssid = cleanSsid(transportInfo?.ssid).ifBlank { cleanSsid(legacyInfo?.ssid) }
                val bssid = transportInfo?.bssid?.takeIf { it.isNotBlank() }
                    ?: legacyInfo?.bssid.orEmpty()
                val signalInfo = transportInfo ?: legacyInfo
                return CurrentWifi(
                    ssid = ssid,
                    gateway = gateway,
                    localIp = ipv4?.hostAddress.orEmpty(),
                    netmask = linkAddress?.let { prefixMask(it.prefixLength) }.orEmpty(),
                    connected = true,
                    bssid = bssid,
                    rssi = signalInfo?.rssi ?: -100,
                    frequency = signalInfo?.frequency ?: 0
                )
            }

            // Compatibility fallback for Android builds which hide the Wi-Fi
            // Network object but still expose a populated Wi-Fi DHCP lease.
            val dhcp = wifi.dhcpInfo
            val ip = dhcp?.ipAddress ?: 0
            fun littleEndianIpv4(value: Int): String = if (value == 0) "" else listOf(
                value and 0xff,
                (value shr 8) and 0xff,
                (value shr 16) and 0xff,
                (value shr 24) and 0xff
            ).joinToString(".")
            val localIp = littleEndianIpv4(ip)
            val gateway = littleEndianIpv4(dhcp?.gateway ?: 0)
            val legacyInfo = try { wifi.connectionInfo } catch (_: Exception) { null }
            CurrentWifi(
                ssid = cleanSsid(legacyInfo?.ssid),
                gateway = gateway,
                localIp = localIp,
                netmask = littleEndianIpv4(dhcp?.netmask ?: 0),
                connected = localIp.isNotBlank() || gateway.isNotBlank(),
                bssid = legacyInfo?.bssid.orEmpty(),
                rssi = legacyInfo?.rssi ?: -100,
                frequency = legacyInfo?.frequency ?: 0
            )
        } catch (_: Exception) { CurrentWifi("", "") }
    }

    /**
     * Discovers WAPFire WebUI hosts on the phone's current Wi-Fi subnet.
     * It only probes TCP/80 and confirms the firmware's distinctive login-page title.
     */
    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun findWapFireOnLan(): List<String> = withContext(Dispatchers.IO) {
        val dhcp = try { wifi.dhcpInfo } catch (_: Exception) { null }
        val rawIp = dhcp?.ipAddress ?: 0
        if (rawIp == 0) return@withContext emptyList()
        val ip = Integer.reverseBytes(rawIp)
        val rawMask = dhcp?.netmask ?: 0
        val mask = if (rawMask == 0) -256 else Integer.reverseBytes(rawMask)
        var network = ip and mask
        var broadcast = network or mask.inv()
        // Avoid accidentally scanning very large corporate/VLAN subnets from a phone.
        if (broadcast - network > 512) {
            val mask24 = -256
            network = ip and mask24
            broadcast = network or mask24.inv()
        }
        val phoneIp = ip
        val candidates = (network + 1 until broadcast).filter { it != phoneIp }
        if (candidates.isEmpty()) return@withContext emptyList()

        coroutineScope {
            candidates.chunked(24).flatMap { batch ->
                batch.map { address ->
                    async(Dispatchers.IO) {
                        val host = InetAddress.getByAddress(byteArrayOf(
                            (address shr 24).toByte(),
                            (address shr 16).toByte(),
                            (address shr 8).toByte(),
                            address.toByte()
                        )).hostAddress ?: return@async null
                        try {
                            val connection = (URL("http://$host/").openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"
                                connectTimeout = 250
                                readTimeout = 250
                                instanceFollowRedirects = false
                                useCaches = false
                            }
                            val signature = try {
                                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                                    val buffer = CharArray(4096)
                                    val count = reader.read(buffer)
                                    if (count > 0) String(buffer, 0, count).lowercase() else ""
                                }
                            } finally { connection.disconnect() }
                            if (signature.contains("<title>wapfire - authentication</title>")) host else null
                        } catch (_: Exception) { null }
                    }
                }.awaitAll().filterNotNull()
            }
        }.distinct()
    }

    suspend fun findWapFireHost(network: Network, preferredHost: String): String? = withContext(Dispatchers.IO) {
        // Prefer the actual IPv4 gateway from LinkProperties, then try ESP-IDF's
        // standard SoftAP address. Some Android builds expose incomplete routes
        // briefly while DHCP is still completing.
        val candidates = listOf(preferredHost, "192.168.4.1").filter { it.isNotBlank() }.distinct()
        for (host in candidates) {
            repeat(3) { attempt ->
                try {
                    val connection = (network.openConnection(URL("http://$host/")) as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 2200
                        readTimeout = 2200
                        instanceFollowRedirects = false
                        useCaches = false
                        setRequestProperty("Cache-Control", "no-cache")
                    }
                    val page = try {
                        val code = connection.responseCode
                        val stream = if (code in 200..399) connection.inputStream else connection.errorStream
                        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(16_384) }.orEmpty()
                        code in 200..399 && body.contains("WAPFire - Authentication", ignoreCase = true)
                    } finally { connection.disconnect() }
                    if (page) return@withContext host
                } catch (_: Exception) { }
                if (attempt < 2) delay(450)
            }
        }
        null
    }

    companion object {
        // Locally administered, unicast SoftAP prefix assigned to WAPFire.
        // Firmware preserves the factory-derived lower three bytes per device.
        const val WAPFIRE_BSSID_PREFIX = "02:57:41"
        private val WAPFIRE_BSSID_PATTERN = Regex("^02:57:41(?::[0-9A-F]{2}){3}$")

        fun isWapFireBssid(value: String?): Boolean {
            val normalized = value.orEmpty().trim().uppercase(Locale.ROOT)
            return WAPFIRE_BSSID_PATTERN.matches(normalized)
        }

        fun requiredPermissions(): Array<String> = buildList {
            add(android.Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(android.Manifest.permission.NEARBY_WIFI_DEVICES)
        }.toTypedArray()
    }
}

class WifiConnector(context: Context) {
    private val appContext = context.applicationContext
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeCallback: ConnectivityManager.NetworkCallback? = null
    private var activeReadinessPoll: Runnable? = null

    fun bindToCurrentWifi(): Boolean {
        return try {
            val network = connectivity.activeNetwork ?: return false
            val caps = connectivity.getNetworkCapabilities(network) ?: return false
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return false
            connectivity.bindProcessToNetwork(network)
            true
        } catch (_: Exception) { false }
    }

    private fun ipv4Gateway(properties: LinkProperties?): String? {
        return properties?.routes
            ?.firstOrNull { route -> route.isDefaultRoute && route.gateway is Inet4Address }
            ?.gateway?.hostAddress
    }

    private fun hasUsableIpv4(properties: LinkProperties?): Boolean {
        return properties?.linkAddresses?.any { link ->
            val address = link.address as? Inet4Address
            address != null && !address.isLoopbackAddress && !address.isLinkLocalAddress
        } == true
    }

    fun connect(
        ssid: String,
        bssid: String,
        password: String,
        securityMode: String,
        onAvailable: (Network, String) -> Unit,
        onFailure: (String) -> Unit,
        onLost: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 29) {
            onFailure("Android 10 or newer is required for secure local Wi-Fi joining.")
            return
        }
        release()
        try {
            val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (bssid.isNotBlank()) specBuilder.setBssid(MacAddress.fromString(bssid))

            // WAPFire advertises ESP-IDF WIFI_AUTH_WPA2_WPA3_PSK (transition mode)
            // with PMF capable=true / required=false. Android 10+ uses SAE/WPA3
            // for WPA2/WPA3 transition APs, so use setWpa3Passphrase for that mode.
            when (securityMode) {
                "WPA2_WPA3", "WPA3" -> specBuilder.setWpa3Passphrase(password)
                "WPA2" -> specBuilder.setWpa2Passphrase(password)
                "OPEN" -> Unit
                else -> if (password.isNotBlank()) specBuilder.setWpa2Passphrase(password)
            }

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specBuilder.build())
                .build()

            val completed = AtomicBoolean(false)
            val connected = AtomicBoolean(false)
            var pendingNetwork: Network? = null
            var callbackRef: ConnectivityManager.NetworkCallback? = null
            var readinessPoll: Runnable? = null

            fun reportFailure(message: String) {
                // Ignore late callbacks from a request that has already been released/replaced.
                if (callbackRef != null && activeCallback !== callbackRef) return
                if (completed.compareAndSet(false, true)) {
                    readinessPoll?.let { pending ->
                        mainHandler.removeCallbacks(pending)
                        if (activeReadinessPoll === pending) activeReadinessPoll = null
                    }
                    callbackRef?.let { callback ->
                        if (activeCallback === callback) activeCallback = null
                        runCatching { connectivity.unregisterNetworkCallback(callback) }
                    }
                    mainHandler.post { onFailure.invoke(message) }
                }
            }

            fun reportAvailable(network: Network, properties: LinkProperties? = null) {
                if (callbackRef != null && activeCallback !== callbackRef) return
                if (!completed.compareAndSet(false, true)) return
                connected.set(true)
                readinessPoll?.let { pending ->
                    mainHandler.removeCallbacks(pending)
                    if (activeReadinessPoll === pending) activeReadinessPoll = null
                }
                val gateway = ipv4Gateway(properties)
                    ?: ipv4Gateway(connectivity.getLinkProperties(network))
                    ?: "192.168.4.1" // Standard WAPFire ESP32 SoftAP IPv4 address.
                mainHandler.post { onAvailable.invoke(network, gateway) }
            }

            // Some Android builds call onAvailable before DHCP has installed the
            // IPv4 address/default route. Poll LinkProperties for up to 10 seconds;
            // do not mistake a half-created Wi-Fi network for a usable WAPFire link.
            readinessPoll = object : Runnable {
                var waitedMs = 0
                override fun run() {
                    if (completed.get() || (callbackRef != null && activeCallback !== callbackRef)) return
                    val network = pendingNetwork ?: return
                    val properties = connectivity.getLinkProperties(network)
                    val gateway = ipv4Gateway(properties)
                    if (hasUsableIpv4(properties) && !gateway.isNullOrBlank()) {
                        reportAvailable(network, properties)
                        return
                    }
                    waitedMs += 250
                    if (waitedMs >= 10_000) {
                        if (hasUsableIpv4(properties)) {
                            // DHCP provided an address but not a default route. WAPFire's
                            // AP address is fixed at 192.168.4.1, so let HTTP verification
                            // decide whether the device is actually reachable.
                            reportAvailable(network, properties)
                        } else {
                            reportFailure("Android associated with $ssid but did not obtain an IPv4 address. Check that the WAPFire SoftAP/DHCP service is running, then retry.")
                        }
                        return
                    }
                    mainHandler.postDelayed(this, 250)
                }
            }
            activeReadinessPoll = readinessPoll

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (activeCallback !== this || completed.get()) return
                    pendingNetwork = network
                    // This is a local-only network with no Internet capability.
                    // Bind this app's HTTP traffic to the exact requested Wi-Fi.
                    connectivity.bindProcessToNetwork(network)
                    mainHandler.post { readinessPoll?.run() }
                }

                override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                    if (activeCallback === this && !completed.get() && hasUsableIpv4(linkProperties) && !ipv4Gateway(linkProperties).isNullOrBlank()) {
                        reportAvailable(network, linkProperties)
                    }
                }

                override fun onUnavailable() {
                    reportFailure("Android could not authenticate to $ssid using $securityMode. Check the WAPFire Wi-Fi password and retry.")
                }

                override fun onLost(network: Network) {
                    if (activeCallback !== this) return
                    connectivity.bindProcessToNetwork(null)
                    if (connected.get()) {
                        readinessPoll?.let { pending ->
                            mainHandler.removeCallbacks(pending)
                            if (activeReadinessPoll === pending) activeReadinessPoll = null
                        }
                        if (activeCallback === this) activeCallback = null
                        runCatching { connectivity.unregisterNetworkCallback(this) }
                        mainHandler.post { onLost.invoke() }
                    } else {
                        reportFailure("The selected Wi-Fi link was lost before Android received an IPv4 address. Re-scan and retry.")
                    }
                }
            }
            callbackRef = callback
            activeCallback = callback
            connectivity.requestNetwork(request, callback, 60_000)
        } catch (e: Exception) {
            activeReadinessPoll?.let { mainHandler.removeCallbacks(it) }
            activeReadinessPoll = null
            activeCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
            activeCallback = null
            onFailure(e.message ?: "Could not create the Wi-Fi connection request.")
        }
    }

    fun release() {
        activeReadinessPoll?.let { mainHandler.removeCallbacks(it) }
        activeReadinessPoll = null
        try { connectivity.bindProcessToNetwork(null) } catch (_: Exception) { }
        activeCallback?.let {
            try { connectivity.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        activeCallback = null
    }
}
