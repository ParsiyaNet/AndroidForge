# HTTPS connection and certificate trust

The app supports both WAPFire transports. It first verifies the WAPFire login page using a safe GET request, trying the saved/current scheme and then its alternative. Only after the device identifies as WAPFire does the app send login credentials.

For HTTPS, WAPFire generates a self-signed certificate with the subject `CN=WAPFire.local`. The app accepts only that self-signed WAPFire certificate, stores its SHA-256 fingerprint in private app preferences for the exact host, and rejects later fingerprint changes. It does not install a global trust-all certificate handler.

The first HTTPS connection is Trust-On-First-Use: connect to the intended WAPFire AP / trusted network for the initial pairing. If the certificate changes after a full SPIFFS erase or deliberate device identity replacement, the app will block the connection. Clear the app's stored data / certificate pins only after verifying that the certificate change is expected; then reconnect so the new fingerprint can be pinned.

When the user changes the WebUI protocol, only the read-only status heartbeat is automatically re-probed and retried. Mutating actions are not replayed to avoid duplicate settings changes, firmware uploads, or other writes.
