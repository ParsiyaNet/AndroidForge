package io.wapfire.mobile.network

import android.content.Context
import android.content.SharedPreferences
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.Locale

/**
 * Trusts WAPFire's locally generated self-signed TLS certificate using
 * Trust-On-First-Use (TOFU). The first successful HTTPS connection stores the
 * SHA-256 certificate fingerprint for that device host. A later certificate
 * change is rejected instead of silently accepting a replacement.
 *
 * This is intentionally not a global trust-all implementation. Only a
 * self-signed certificate identifying itself as WAPFire is eligible, and the
 * stored fingerprint is checked on every subsequent connection.
 */
internal object WapFireTlsTrust {
    private const val PREFS_NAME = "wapfire_tls_certificate_pins"
    private const val PREFIX = "sha256_"

    fun configure(connection: HttpsURLConnection, context: Context) {
        val host = connection.url.host.lowercase(Locale.ROOT)
        require(host.isNotBlank()) { "HTTPS endpoint has no hostname" }
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val pinKey = PREFIX + sha256(host.toByteArray(Charsets.UTF_8)).toHex()

        val trustManager = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()

            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
                throw CertificateException("WAPFire client certificates are not used")
            }

            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                if (chain.isEmpty()) throw CertificateException("The WAPFire HTTPS certificate chain is empty")
                val leaf = chain[0]
                try {
                    leaf.checkValidity()
                } catch (e: Exception) {
                    throw CertificateException("The WAPFire HTTPS certificate is outside its validity period", e)
                }

                // Firmware deliberately creates a self-signed WAPFire leaf. Do not
                // allow an arbitrary CA/website certificate to be pinned as WAPFire.
                if (leaf.subjectX500Principal != leaf.issuerX500Principal ||
                    !leaf.subjectX500Principal.name.contains("CN=WAPFire.local", ignoreCase = true)) {
                    throw CertificateException("The HTTPS certificate is not a WAPFire device certificate")
                }

                val fingerprint = sha256(leaf.encoded).toHex()
                synchronized(this@WapFireTlsTrust) {
                    val existing = prefs.getString(pinKey, null)
                    if (existing == null) {
                        if (!prefs.edit().putString(pinKey, fingerprint).commit()) {
                            throw CertificateException("Could not save the WAPFire HTTPS certificate fingerprint")
                        }
                    } else if (!MessageDigest.isEqual(
                            existing.toByteArray(Charsets.US_ASCII),
                            fingerprint.toByteArray(Charsets.US_ASCII)
                        )) {
                        throw CertificateException("The WAPFire HTTPS certificate changed. Clear the saved certificate pin only after verifying the device.")
                    }
                }
            }
        }

        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
        connection.sslSocketFactory = sslContext.socketFactory
        connection.hostnameVerifier = javax.net.ssl.HostnameVerifier { requestedHost, session ->
            if (!requestedHost.equals(host, ignoreCase = true)) return@HostnameVerifier false
            try {
                val peer = session.peerCertificates.firstOrNull() as? X509Certificate ?: return@HostnameVerifier false
                val expected = prefs.getString(pinKey, null) ?: return@HostnameVerifier false
                MessageDigest.isEqual(
                    expected.toByteArray(Charsets.US_ASCII),
                    sha256(peer.encoded).toHex().toByteArray(Charsets.US_ASCII)
                )
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun sha256(value: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(value)

    private fun ByteArray.toHex(): String = joinToString("") { byte -> "%02x".format(byte) }
}
