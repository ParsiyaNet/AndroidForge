# WAPFire Mobile 4.1.63 — HTTPS WebUI support

- Added automatic HTTP/HTTPS detection before credential submission and during the read-only status heartbeat.
- Added HTTPS support to API requests, settings backup, firmware upload and known-WAPFire SoftAP discovery.
- Added per-host SHA-256 Trust-On-First-Use certificate pinning for the device's self-signed `WAPFire.local` certificate. A changed certificate is rejected; arbitrary certificates are not trusted globally.
- Existing HTTP connections remain supported. Mutating requests are not automatically replayed when the protocol changes.

## Build validation

Source changes are included in this package. A Gradle APK build could not be completed in the editing environment because the Gradle wrapper could not resolve `services.gradle.org`; the Android SDK was not present in the environment. Build from Android Studio / a machine with the Android SDK and Gradle dependencies available before installing.
