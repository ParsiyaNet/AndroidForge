# WAPFire Mobile 4.1.65 – HTTPS/HTTP auto-detection

- The native HTTPS switch now reads its state from `/api/mobile_settings`, updates immediately after a successful change, and stays synchronized while the Settings screen is open.
- Each new connection starts from canonical HTTP, then follows only WAPFire's marked HTTPS redirect. A cookie-free port-80 probe runs periodically and recognizes both the marked HTTPS redirect and WAPFire's plain-HTTP authentication page, so WebUI changes in either direction are detected during an existing session without sending a saved session token during protocol detection.
- Canonicalized device host identity by removing default `:80` and `:443` ports, so HTTP sign-in no longer requires typing `:80` and an HTTPS redirect cannot accidentally retain port 80.
- Migrated saved per-device certificate pins to the canonical host key.

Version: 4.1.65 (versionCode 110).
