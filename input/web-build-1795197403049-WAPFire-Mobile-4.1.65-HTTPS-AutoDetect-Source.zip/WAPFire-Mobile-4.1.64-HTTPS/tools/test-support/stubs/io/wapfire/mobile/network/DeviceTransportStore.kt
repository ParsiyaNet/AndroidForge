package io.wapfire.mobile.network

/** JVM-test stand-in for the Android-backed transport preference store. */
object DeviceTransportStore {
    data class Entry(val https: Boolean, val fingerprint: String?)
    data class TrustRequest(val host: String, val fingerprint: String, val previousFingerprint: String?)

    private val entries = mutableMapOf<String, Entry>()

    fun normalizeHost(hostOrUrl: String): String = hostOrUrl.trim()
        .replaceFirst(Regex("(?i)^https?://"), "")
        .substringBefore('/').substringBefore('?').substringBefore('#')
        .removeSuffix(":80").removeSuffix(":443")

    fun hostKey(hostOrUrl: String): String = normalizeHost(hostOrUrl).lowercase()
    fun get(host: String): Entry? = entries[hostKey(host)]
    fun setHttps(host: String, https: Boolean) {
        val key = hostKey(host)
        entries[key] = Entry(https, entries[key]?.fingerprint)
    }
    fun trust(host: String, fingerprint: String): Boolean {
        val key = hostKey(host)
        entries[key] = Entry(true, fingerprint)
        return true
    }
    fun reportUntrusted(request: TrustRequest) = Unit
}
