# 4.1.64 – HTTPS support

Version 4.1.64 (versionCode 109).

* New **HTTPS (secure connection)** switch in Settings → Protection (below Self-protect), matching the
  firmware option (default HTTP).
* The app learns the transport per device (`DeviceTransportStore`): a device that answers plain HTTP with a
  redirect to `https://` is switched to HTTPS automatically and the request is repeated.
  The login probe runs first, so credentials are never sent over HTTP to a device that wants HTTPS.
* Certificates are self-signed, so trust is pinned to the SHA-256 fingerprint (`TlsPinning`):
  * enabling HTTPS from the app pins the fingerprint the device returns over the authenticated session;
  * otherwise the user is asked once to verify/trust the fingerprint (compare with the device's Settings page);
  * a changed certificate is blocked with a stronger warning until the user decides.
* Discovery recognises HTTPS-only devices (marked redirect on port 80 / login page over TLS).
* Background monitor and keep-alive services share the transport store.
* Not changed: cleartext traffic stays allowed in the manifest so HTTP devices keep working.
