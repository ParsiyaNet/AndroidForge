package io.wapfire.mobile.network

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Remembers, per device host, whether WAPFire is reached over HTTP or HTTPS and which
 * certificate fingerprint the user trusted for it.
 *
 * Fingerprints are public values, so plain SharedPreferences is sufficient; their integrity
 * matters more than their secrecy and the app's private storage already protects that.
 * The store works in memory only until [init] has been called (it is called from the
 * activity and from both foreground services, which share this process).
 */
object DeviceTransportStore {
    data class Entry(val https: Boolean, val fingerprint: String?)

    /** A certificate the user must accept or reject before the app talks to the device. */
    data class TrustRequest(val host: String, val fingerprint: String, val previousFingerprint: String?)

    private const val PREFS_NAME = "wapfire_device_transport"
    private const val KEY_PREFIX = "h:"

    private var prefs: SharedPreferences? = null
    private val entries = HashMap<String, Entry>()

    private val pending = MutableStateFlow<TrustRequest?>(null)
    val pendingTrust: StateFlow<TrustRequest?> = pending.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val stored = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = stored
        // Canonicalize persisted host keys as well as new ones. Older builds could
        // store the same WAPFire device twice when the user entered :80 or :443.
        val migrated = stored.edit()
        stored.all.forEach { (key, value) ->
            if (key.startsWith(KEY_PREFIX) && value is String) {
                val oldHost = key.removePrefix(KEY_PREFIX)
                val normalized = hostKey(oldHost)
                if (normalized.isNotBlank()) {
                    val decoded = decode(value)
                    val current = entries[normalized]
                    if (current == null || (current.fingerprint.isNullOrBlank() && !decoded.fingerprint.isNullOrBlank())) {
                        entries[normalized] = decoded
                    }
                    if (oldHost != normalized) migrated.remove(key)
                }
            }
        }
        entries.forEach { (host, entry) -> migrated.putString(KEY_PREFIX + host, encode(entry)) }
        migrated.apply()
    }

    /**
     * Returns the canonical WAPFire authority without scheme, path, or default ports.
     * HTTP :80 and HTTPS :443 are the same device identity; the transport is detected
     * from the device's HTTP redirect rather than encoded in the saved host string.
     */
    fun normalizeHost(hostOrUrl: String): String {
        val authority = hostOrUrl.trim()
            .replaceFirst(Regex("(?i)^https?://"), "")
            .substringBefore('/')
            .substringBefore('?')
            .substringBefore('#')
            .trim()
        return authority.removeSuffix(":80").removeSuffix(":443").trim()
    }

    /** "http://192.168.4.1/x" -> "192.168.4.1": lower-case per-device key. */
    fun hostKey(hostOrUrl: String): String = normalizeHost(hostOrUrl).lowercase(Locale.ROOT)

    @Synchronized
    fun get(host: String): Entry? = entries[hostKey(host)]

    @Synchronized
    fun setHttps(host: String, https: Boolean) {
        val key = hostKey(host)
        put(key, Entry(https, entries[key]?.fingerprint))
    }

    /** Pins [fingerprint] for [host] and marks it as an HTTPS device. */
    @Synchronized
    fun trust(host: String, fingerprint: String): Boolean {
        val normalized = TlsPinning.normalizeFingerprint(fingerprint) ?: return false
        val key = hostKey(host)
        put(key, Entry(true, normalized))
        if (pending.value?.host == key) pending.value = null
        return true
    }

    /** Forgets the pinned certificate (e.g. after a factory reset), keeping the transport choice. */
    @Synchronized
    fun forgetFingerprint(host: String) {
        val key = hostKey(host)
        entries[key]?.let { put(key, it.copy(fingerprint = null)) }
    }

    fun reportUntrusted(request: TrustRequest) {
        pending.value = request
    }

    fun dismissPending() {
        pending.value = null
    }

    private fun put(key: String, entry: Entry) {
        entries[key] = entry
        prefs?.edit()?.putString(KEY_PREFIX + key, encode(entry))?.apply()
    }

    private fun encode(entry: Entry): String = (if (entry.https) "https" else "http") + "|" + entry.fingerprint.orEmpty()

    private fun decode(value: String): Entry {
        val scheme = value.substringBefore('|')
        val fingerprint = TlsPinning.normalizeFingerprint(value.substringAfter('|', ""))
        return Entry(scheme == "https", fingerprint)
    }
}
