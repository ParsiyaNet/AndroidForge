package io.wapfire.mobile.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.net.SocketTimeoutException
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLException
import java.io.IOException
import java.util.Locale

/** HTTP failures retain the actual status code so callers never parse error text. */
class WapFireHttpException(
    val statusCode: Int,
    val endpoint: String,
    val responseBody: String,
    message: String
) : IOException(message)

/** Native HTTP client for the full WAPFire VF38 API.
 * Activity and foreground service instances share a host-scoped cookie because
 * VF38 maintains one active auth token per remote client IP.
 */
class WapFireApi(hostOrUrl: String) {
    /** Canonical host without scheme/path/default port. WAPFire uses :80 and :443. */
    private val hostPart: String = DeviceTransportStore.normalizeHost(hostOrUrl)
    /** Lower-case host: key for the session cookie and for the pinned HTTPS settings. */
    private val hostKey: String = DeviceTransportStore.hostKey(hostOrUrl)

    /**
     * Start with the normal HTTP endpoint on every new client. If HTTPS is enabled,
     * WAPFire's port-80 listener returns its marked 307 redirect and [request] switches
     * to HTTPS before credentials are sent. This also detects a device switched back
     * to HTTP in the WebUI, instead of blindly reusing a stale app-side preference.
     */
    @Volatile var baseUrl: String = initialBase(hostOrUrl)
        private set
    val isHttps: Boolean get() = baseUrl.startsWith("https://", ignoreCase = true)
    // Periodically inspect port 80 without a Cookie. This detects both directions of a
    // WebUI protocol change while ensuring that saved session tokens never leak during
    // the HTTP -> HTTPS redirect probe.
    @Volatile private var lastTransportProbeAtMs: Long = 0L

    // Trust manager of the HTTPS connection currently in use. All network work runs under
    // processRequestMutex, so a single slot is enough to explain a failed handshake.
    @Volatile private var activePin: TlsPinning.PinningTrustManager? = null
    // VF38 stores one active session token per client IP. Activity and background
    // service clients therefore share one in-process cookie and one request queue.
    private val requestMutex = processRequestMutex

    private suspend fun <T> serialized(path: String, block: () -> T): Result<T> =
        withContext(Dispatchers.IO) {
            requestMutex.withLock {
                runCatching(block).recoverCatching { cause ->
                    if (cause is SocketTimeoutException) {
                        throw IOException("WAPFire did not answer $path before the response timeout. The request was not retried to avoid duplicating changes.", cause)
                    }
                    throw translateTlsFailure(cause)
                }
            }
        }

    /**
     * A handshake that failed only because the certificate is unknown or changed is not a
     * network error: report it so the UI can ask the user to verify the fingerprint.
     */
    private fun translateTlsFailure(cause: Throwable): Throwable {
        val rejected = activePin?.rejectedFingerprint ?: return cause
        if (generateSequence(cause) { it.cause }.none { it is SSLException }) return cause
        val previous = DeviceTransportStore.get(hostKey)?.fingerprint
        DeviceTransportStore.reportUntrusted(DeviceTransportStore.TrustRequest(hostKey, rejected, previous))
        return CertificateTrustRequiredException(hostKey, rejected, previous)
    }

    private fun openConnection(path: String): HttpURLConnection {
        val connection = URL(baseUrl + path).openConnection() as HttpURLConnection
        if (connection is HttpsURLConnection) {
            val pin = TlsPinning.PinningTrustManager(DeviceTransportStore.get(hostKey)?.fingerprint)
            activePin = pin
            connection.sslSocketFactory = TlsPinning.socketFactory(pin)
            connection.hostnameVerifier = TlsPinning.pinnedHostnameVerifier
        } else {
            activePin = null
        }
        return connection
    }

    /** Switches this client (and the remembered device setting) to HTTPS or back to HTTP. */
    fun useTransport(https: Boolean) {
        DeviceTransportStore.setHttps(hostKey, https)
        baseUrl = (if (https) "https://" else "http://") + hostPart
        lastTransportProbeAtMs = System.nanoTime() / 1_000_000L
    }

    /**
     * Called right after the user enabled HTTPS from the app: the fingerprint arrives over the
     * already authenticated session, so it can be pinned without asking again.
     */
    fun adoptHttps(fingerprint: String?) {
        if (!fingerprint.isNullOrBlank()) DeviceTransportStore.trust(hostKey, fingerprint)
        useTransport(true)
    }

    private fun switchToHttpsIfRedirected(connection: HttpURLConnection): Boolean {
        if (isHttps) return false
        val location = connection.getHeaderField("Location").orEmpty()
        val marker = connection.getHeaderField("X-WAPFire").orEmpty()
        if (!location.startsWith("https://", ignoreCase = true) ||
            !marker.equals("https-redirect", ignoreCase = true)) return false
        // The firmware's Location contains the interface's current IP. Keep the exact
        // host chosen by the user (or discovered by Android) and change only transport.
        useTransport(true)
        return true
    }

    /**
     * Probes the unencrypted root page without cookies. WAPFire returns a marked 307
     * when HTTPS is active and its authentication page when plain HTTP is active.
     * This also lets an already-connected app follow a protocol change made in WebUI.
     */
    private fun probePlainHttpTransport(force: Boolean = false) {
        val now = System.nanoTime() / 1_000_000L
        if (!force && lastTransportProbeAtMs != 0L && now - lastTransportProbeAtMs < TRANSPORT_PROBE_INTERVAL_MS) return

        val connection = (URL("http://$hostPart/").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 2_500
            readTimeout = 3_500
            useCaches = false
            instanceFollowRedirects = false
            setRequestProperty("Connection", "close")
            setRequestProperty("Accept", "text/html, */*")
        }
        try {
            val code = connection.responseCode
            val location = connection.getHeaderField("Location").orEmpty()
            val marker = connection.getHeaderField("X-WAPFire").orEmpty()
            if (code in REDIRECT_CODES && location.startsWith("https://", ignoreCase = true) &&
                marker.equals("https-redirect", ignoreCase = true)) {
                useTransport(true)
                return
            }

            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val page = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val isWapFireLogin = code in 200..299 && page.contains("wapfire - authentication", ignoreCase = true) &&
                page.contains("<html", ignoreCase = true)
            if (isWapFireLogin) {
                useTransport(false)
                return
            }

            // Never downgrade a previously pinned HTTPS connection on an unknown HTTP
            // response. Keep using TLS and retry the plain-HTTP probe on the next interval.
            if (isHttps) {
                lastTransportProbeAtMs = now
                return
            }
            throw IOException("Could not verify the WAPFire HTTP endpoint at $hostPart")
        } catch (failure: Exception) {
            if (isHttps) {
                // Port 80 may be filtered while an already-pinned TLS endpoint still works.
                lastTransportProbeAtMs = now
                return
            }
            throw failure
        } finally {
            connection.disconnect()
        }
    }

    data class Reply(val code: Int, val body: String, val cookie: String? = null)

    private fun request(
        path: String,
        method: String = "GET",
        body: String? = null,
        contentType: String? = null,
        timeoutMs: Int = 30_000,
        connectTimeoutMs: Int = 10_000,
        includeCookie: Boolean = true,
        allowTransportSwitch: Boolean = true
    ): Reply {
        if (allowTransportSwitch) probePlainHttpTransport()
        val sentCookie = if (includeCookie) SharedSessionCookieStore.get(hostKey) else null
        val connection = openConnection(path).apply {
            requestMethod = method
            connectTimeout = connectTimeoutMs
            readTimeout = timeoutMs
            useCaches = false
            instanceFollowRedirects = false
            setRequestProperty("Connection", "close")
            setRequestProperty("Accept", "application/json, text/plain, */*")
            sentCookie?.let { setRequestProperty("Cookie", it) }
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType ?: "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            // The device redirects plain HTTP to https:// once its HTTPS option is on. It does
            // that before executing anything, so repeating the request over HTTPS is safe.
            if (allowTransportSwitch && code in REDIRECT_CODES && switchToHttpsIfRedirected(connection)) {
                return request(path, method, body, contentType, timeoutMs, connectTimeoutMs, includeCookie, allowTransportSwitch = false)
            }
            val cookie = connection.getHeaderField("Set-Cookie")
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code == 401 && sentCookie != null) {
                SharedSessionCookieStore.clearIfMatches(hostKey, sentCookie)
            }
            Reply(code, text, cookie)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun login(
        user: String,
        password: String,
        reuseExisting: Boolean = false
    ): Result<Unit> = loginMutex.withLock {
        if (reuseExisting && SharedSessionCookieStore.get(hostKey)?.startsWith("wg_auth=") == true) {
            return@withLock Result.success(Unit)
        }
        SharedSessionCookieStore.clear(hostKey)
        serialized("/login") {
            // Confirm the active transport on port 80 before credentials leave the phone.
            // The probe is cookie-free and recognizes both the marked HTTPS redirect and
            // the normal WAPFire login page served when plain HTTP is active.
            probePlainHttpTransport(force = true)
            val form = "user=${encode(user)}&pass=${encode(password)}"
            val reply = request(
                "/login", "POST", form, "application/x-www-form-urlencoded", includeCookie = false
            )
            if (reply.code !in 200..299) throw httpError(reply, "/login")
            val raw = reply.cookie ?: error("The device did not return an authentication session")
            val token = raw.substringBefore(';').trim()
            if (!token.startsWith("wg_auth=") || token.substringAfter('=').length < 32) {
                throw IOException("The device returned an invalid authentication session")
            }
            SharedSessionCookieStore.set(hostKey, token)
            Unit
        }
    }

    // Keep the lightweight heartbeat short so the UI can reflect a lost device link
    // promptly; this does not change timeouts for configuration or write operations.
    suspend fun status(): Result<JSONObject> = jsonGet("/api/status", timeoutMs = 7_000, connectTimeoutMs = 5_000)
    suspend fun mobileSettings(): Result<JSONObject> = jsonGet("/api/mobile_settings")
    suspend fun httpsInfo(): Result<JSONObject> = jsonGet("/api/https_info")
    suspend fun chart(): Result<JSONObject> = jsonGet("/api/chart_data")
    suspend fun firmwareInfo(): Result<JSONObject> = jsonGet("/api/firmware_info")
    suspend fun checkUpdate(): Result<JSONObject> = jsonGet("/api/check_update")
    suspend fun backupInfo(): Result<JSONObject> = jsonGet("/api/backup_info")
    suspend fun logs(
        timeoutMs: Int = 45_000,
        connectTimeoutMs: Int = 10_000
    ): Result<JSONArray> = arrayGet("/api/logs", timeoutMs = timeoutMs, connectTimeoutMs = connectTimeoutMs)
    suspend fun clients(): Result<JSONArray> = arrayGet("/api/tracked_clients", timeoutMs = 30_000)
    suspend fun ethernetSettings(): Result<JSONObject> = jsonGet("/api/ethernet_settings")
    suspend fun httpApiSettings(): Result<JSONObject> = jsonGet("/api/http_api_settings")
    suspend fun ntpSettings(): Result<JSONObject> = jsonGet("/api/ntp_settings")
    suspend fun mikrotikSettings(): Result<JSONObject> = jsonGet("/api/mikrotik_settings")
    suspend fun ledSettings(): Result<JSONObject> = jsonGet("/api/led_settings")
    suspend fun disconnectLedSettings(): Result<JSONObject> = jsonGet("/api/disconnect_led_settings")
    suspend fun scheduleSettings(): Result<JSONObject> = jsonGet("/api/schedule_settings")
    suspend fun whitelist(): Result<JSONObject> = jsonGet("/api/whitelist")
    suspend fun language(): Result<JSONObject> = jsonGet("/api/language")
    suspend fun ledMode(): Result<JSONObject> = jsonGet("/api/led_mode")

    suspend fun scan(): Result<JSONArray> = serialized("/api/scan") {
        val r = request("/api/scan", "POST", "", "application/json", timeoutMs = 45_000)
        if (r.code !in 200..299) throw httpError(r, "/api/scan")
        JSONArray(r.body)
    }

    suspend fun selectTarget(ssid: String, bssid: String, channel: Int): Result<JSONObject> = jsonPost(
        "/api/select_target", JSONObject().put("ssid", ssid).put("bssid", bssid).put("channel", channel)
    )
    suspend fun saveTarget(ssid: String, bssid: String, channel: Int): Result<JSONObject> = jsonPost(
        "/api/save_target", JSONObject().put("ssid", ssid).put("bssid", bssid).put("channel", channel)
    )
    suspend fun updateSettings(values: JSONObject): Result<JSONObject> = jsonPost("/api/settings", values, timeoutMs = 45_000)
    suspend fun saveEthernet(values: JSONObject) = jsonPost("/api/ethernet_settings", values)
    suspend fun saveHttpApi(values: JSONObject) = jsonPost("/api/http_api_settings", values)
    suspend fun saveNtp(values: JSONObject) = jsonPost("/api/ntp_settings", values)
    suspend fun saveMikrotik(values: JSONObject) = jsonPost("/api/mikrotik_settings", values)
    suspend fun saveLed(values: JSONObject) = jsonPost("/api/led_settings", values)
    suspend fun saveDisconnectLed(values: JSONObject) = jsonPost("/api/disconnect_led_settings", values)
    suspend fun saveSchedule(values: JSONObject) = jsonPost("/api/schedule_settings", values)
    suspend fun saveWhitelist(values: JSONObject) = jsonPost("/api/whitelist", values)
    suspend fun clearLogs(): Result<JSONObject> = jsonPost("/api/clear_logs", JSONObject())

    suspend fun testHttpApi(): Result<JSONObject> = jsonPost("/api/test_http_api", JSONObject())
    suspend fun testMikrotik(): Result<JSONObject> = jsonPost("/api/test_mikrotik", JSONObject())
    suspend fun syncNtpNow(): Result<JSONObject> = jsonPost("/api/ntp_sync_now", JSONObject())
    suspend fun syncNtpFromPhone(unixSeconds: Long): Result<JSONObject> = jsonPost(
        "/api/ntp_sync_browser", JSONObject().put("timestamp", unixSeconds)
    )

    suspend fun backupSettings(): Result<ByteArray> = serialized("/api/backup_settings") {
        val connection = openConnection("/api/backup_settings").apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 35_000
            useCaches = false
            setRequestProperty("Connection", "close")
            SharedSessionCookieStore.get(hostKey)?.let { setRequestProperty("Cookie", it) }
        }
        try {
            val code = connection.responseCode
            val bytes = (if (code in 200..299) connection.inputStream else connection.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) throw httpError(Reply(code, String(bytes, Charsets.UTF_8)), "/api/backup_settings")
            // Validate the downloaded document before returning it to the document picker.
            val json = JSONObject(String(bytes, Charsets.UTF_8))
            if (json.optString("device") != "WAPFire") error("Device returned an invalid backup file")
            bytes
        } finally { connection.disconnect() }
    }

    suspend fun restoreSettings(bytes: ByteArray): Result<JSONObject> = serialized("/api/restore_settings") {
        val json = JSONObject(String(bytes, Charsets.UTF_8))
        if (json.optString("device") != "WAPFire" || !json.has("version")) error("This is not a valid WAPFire backup")
        val r = request("/api/restore_settings", "POST", json.toString(), timeoutMs = 45_000)
        if (r.code !in 200..299) throw httpError(r, "/api/restore_settings")
        JSONObject(r.body).also { if (it.has("success") && !it.optBoolean("success")) error(it.optString("message", "Restore failed")) }
    }

    suspend fun uploadFirmware(filename: String, bytes: ByteArray): Result<String> = serialized("/update") {
            if (bytes.size > MAX_FIRMWARE_UPDATE_BYTES) error("Update file exceeds the 3 MB maximum")
            if (bytes.size < 1024 || bytes[0] != 0xE9.toByte()) error("Invalid WAPFire update file")
            val boundary = "----WAPFireNative${System.nanoTime()}"
            val header = "--$boundary\r\nContent-Disposition: form-data; name=\"firmware\"; filename=\"${safeFileName(filename)}\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray()
            val footer = "\r\n--$boundary--\r\n".toByteArray()
            val connection = openConnection("/update").apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 180_000
                doOutput = true
                useCaches = false
                instanceFollowRedirects = false
                setRequestProperty("Connection", "close")
                setRequestProperty("Accept", "text/plain, application/json")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                SharedSessionCookieStore.get(hostKey)?.let { setRequestProperty("Cookie", it) }
                setFixedLengthStreamingMode(header.size.toLong() + bytes.size.toLong() + footer.size.toLong())
            }
            try {
                connection.outputStream.use { out ->
                    out.write(header)
                    var offset = 0
                    while (offset < bytes.size) {
                        val size = minOf(32 * 1024, bytes.size - offset)
                        out.write(bytes, offset, size)
                        offset += size
                    }
                    out.write(footer)
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw httpError(Reply(code, body), "/update")
                body.ifBlank { "Update uploaded. The device will reboot." }
            } finally { connection.disconnect() }
    }

    suspend fun deviceAction(path: String): Result<String> = serialized(path) {
        require(path in setOf("/reboot", "/wifi_restart", "/factory_reset", "/force_setup")) { "Unsupported action" }
        val r = request(path, "POST", "", "application/x-www-form-urlencoded", timeoutMs = 25_000)
        if (r.code !in 200..299 && r.code !in 300..399) throw httpError(r, path)
        r.body.ifBlank { "Command accepted" }
    }

    suspend fun logout(): Result<Unit> = serialized("/logout") {
        val reply = request("/logout", "POST", "", "application/x-www-form-urlencoded")
        if (reply.code !in 200..399) throw httpError(reply, "/logout")
        SharedSessionCookieStore.clear(hostKey)
        Unit
    }

    private suspend fun jsonGet(path: String, timeoutMs: Int = 30_000, connectTimeoutMs: Int = 10_000): Result<JSONObject> = serialized(path) {
        val r = request(path, timeoutMs = timeoutMs, connectTimeoutMs = connectTimeoutMs)
        if (r.code !in 200..299) throw httpError(r, path)
        JSONObject(r.body)
    }
    private suspend fun arrayGet(
        path: String,
        timeoutMs: Int = 30_000,
        connectTimeoutMs: Int = 10_000
    ): Result<JSONArray> = serialized(path) {
        val r = request(path, timeoutMs = timeoutMs, connectTimeoutMs = connectTimeoutMs)
        if (r.code !in 200..299) throw httpError(r, path)
        JSONArray(r.body)
    }
    private suspend fun jsonPost(path: String, body: JSONObject, timeoutMs: Int = 30_000): Result<JSONObject> = serialized(path) {
        val r = request(path, "POST", body.toString(), timeoutMs = timeoutMs)
        if (r.code !in 200..299) throw httpError(r, path)
        JSONObject(r.body).also {
            if (it.has("success") && !it.optBoolean("success", true)) error(it.optString("message", "Operation failed"))
        }
    }
    private fun httpError(reply: Reply, endpoint: String = "request"): WapFireHttpException {
        val detail = try {
            JSONObject(reply.body).optString("message").takeIf { it.isNotBlank() }
                ?: reply.body.take(180)
        } catch (_: Exception) {
            reply.body.take(180)
        }.ifBlank { "No response details" }
        return WapFireHttpException(
            statusCode = reply.code,
            endpoint = endpoint,
            responseBody = reply.body,
            message = "HTTP ${reply.code} at $endpoint: $detail"
        )
    }

    /**
     * The VF38 root route serves the authentication page without a valid session.
     * This probe deliberately omits Cookie so it verifies the device, not the old session.
     */
    suspend fun verifyDeviceIdentity(): Result<Boolean> = serialized("/") {
        val reply = request(
            path = "/",
            timeoutMs = 5_000,
            connectTimeoutMs = 3_500,
            includeCookie = false
        )
        if (reply.code !in 200..299) return@serialized false
        val html = reply.body.lowercase(Locale.ROOT)
        html.contains("wapfire - authentication") && html.contains("<html")
    }

    fun clearSession() { SharedSessionCookieStore.clear(hostKey) }
    fun hasSession(): Boolean = SharedSessionCookieStore.get(hostKey)?.startsWith("wg_auth=") == true
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun safeFileName(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "firmware.bin" }

    companion object {
        const val MAX_FIRMWARE_UPDATE_BYTES = 3 * 1024 * 1024
        private val processRequestMutex = Mutex()
        private val loginMutex = Mutex()

        private object SharedSessionCookieStore {
            private val cookies = mutableMapOf<String, String>()

            @Synchronized fun get(host: String): String? = cookies[host]
            @Synchronized fun set(host: String, cookie: String) { cookies[host] = cookie }
            @Synchronized fun clear(host: String) { cookies.remove(host) }
            @Synchronized fun clearIfMatches(host: String, expected: String) {
                if (cookies[host] == expected) cookies.remove(host)
            }
        }

        private val REDIRECT_CODES = setOf(301, 302, 303, 307, 308)
        private const val TRANSPORT_PROBE_INTERVAL_MS = 5_000L

        private fun initialBase(input: String): String =
            "http://${DeviceTransportStore.normalizeHost(input)}"
    }
}
