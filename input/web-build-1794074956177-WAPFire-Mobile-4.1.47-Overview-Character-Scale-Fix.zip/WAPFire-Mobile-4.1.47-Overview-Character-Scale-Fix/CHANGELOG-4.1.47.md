# WAPFire Mobile 4.1.47

## Overview character viewport correction
- Removed legacy compact-mode bottom inset (78/84px) from the WebView character stage.
- Force the compact shell/stage to fill the entire measured WebView viewport before canvas sizing.
- The Overview speech panel remains a native Compose sibling directly below the WebView; no speech footer is reserved inside the HTML stage.
- Reduced compact camera zoom from 1.20 to 1.10 after restoring the missing viewport area, keeping the top of Sena visible while increasing her effective on-screen size.
- Assistant/full-screen rendering, offline assets, model package and textures are unchanged.
