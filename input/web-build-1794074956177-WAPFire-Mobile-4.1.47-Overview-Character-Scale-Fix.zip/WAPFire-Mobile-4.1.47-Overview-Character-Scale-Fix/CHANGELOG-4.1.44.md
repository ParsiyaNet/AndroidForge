# WAPFire Mobile 4.1.44 — Overview Character Frame Enlargement

- Increased the Overview character viewport from 218dp to 250dp so Sena renders larger while preserving the 4.1.43 camera zoom and framing.
- Reduced the gap between the character frame and the native speech panel from 3dp to 1dp.
- Reduced the inner card padding from 8dp to 6dp, giving both the character frame and speech panel more usable width.
- Tightened the Overview header-to-card spacing slightly.
- Left the Assistant screen, native state controls, offline asset loading, model package, and renderer initialization logic unchanged.
- Bumped app/build identifier to 4.1.44 (versionCode 85) and assigned a unique bootstrap filename to prevent stale-script collisions.
