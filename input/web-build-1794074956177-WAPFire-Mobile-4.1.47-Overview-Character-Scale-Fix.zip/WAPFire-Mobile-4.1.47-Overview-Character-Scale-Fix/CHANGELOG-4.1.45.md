# WAPFire Mobile 4.1.45 — Overview Frame Fill and Character Focus

- Enlarged the Overview native character viewport from 250dp to 300dp.
- Reduced the outer card inset from 6dp to 4dp and set the character/message separation to 0dp.
- Added a compact-mode viewport enforcement in CSS and the local bootstrap so the inner character frame always fills the WebView box; legacy reserved footer insets cannot create an empty band.
- Enabled the model head anchor only in compact Overview and raised its camera zoom from 1.18 to 1.24. This keeps the full crown visible while making Sena visibly larger; the Assistant tab camera remains unchanged.
- Kept the LivLiv package, model textures, local AssetLoader origin, and Assistant native controls unchanged.
- Bumped build to 4.1.45 / versionCode 86 with a unique bootstrap filename.
