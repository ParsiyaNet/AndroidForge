# WAPFire Mobile 4.1.46 — Overview renderer recovery

- Reverted the 4.1.45 compact-only inline viewport override and head-anchor camera experiment.
- Restored the compact renderer's stable CSS-driven viewport sizing path from 4.1.44.
- Kept the larger 300dp native Overview character viewport introduced in 4.1.45.
- Kept a modest 1.20 compact zoom while leaving full Assistant camera settings unchanged.
- Left the offline HTML, LivLiv engine, model package, textures, and native Assistant controls unchanged.
