import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 103
        versionName = "4.2.1"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// WAPFire 4.1.50: fetch the selected AndroidForge character package at build time.
// Source: https://github.com/ParsiyaNet/AndroidForge/blob/main/v06_clean.livliv
// The .livliv archive is embedded in the APK; runtime remains offline.
val downloadV06CleanCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val previewDir = file("src/main/assets/assistant/characters/v03")
    val expectedGitBlobSha1 = "112bbede0967362103ec297a368b881531bf00c5"
    val sourceUrl = "https://raw.githubusercontent.com/ParsiyaNet/AndroidForge/main/v06_clean.livliv"

    outputs.files(modelAsset, File(previewDir, "cover.webp"), File(previewDir, "avatar.webp"))
    outputs.upToDateWhen { false }

    doLast {
        fun gitBlobSha1(file: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
        }

        modelAsset.parentFile.mkdirs()
        previewDir.mkdirs()
        val tempModel = File(modelAsset.parentFile, "v06-clean.download.livliv")
        var lastFailure: Exception? = null
        var downloaded = false

        for (attempt in 1..3) {
            var activeConnection: HttpURLConnection? = null
            try {
                val connection = URL(sourceUrl).openConnection() as HttpURLConnection
                activeConnection = connection
                connection.connectTimeout = 30000
                connection.readTimeout = 120000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.50")
                connection.setRequestProperty("Accept", "application/octet-stream")
                val status = connection.responseCode
                if (status != HttpURLConnection.HTTP_OK) {
                    throw IOException("HTTP $status from $sourceUrl")
                }
                connection.inputStream.use { input ->
                    tempModel.outputStream().use { output -> input.copyTo(output) }
                }

                val actualSha = gitBlobSha1(tempModel)
                if (actualSha != expectedGitBlobSha1) {
                    throw GradleException("AndroidForge v06_clean.livliv changed: expected $expectedGitBlobSha1, received $actualSha")
                }

                val entries = linkedSetOf<String>()
                ZipFile(tempModel).use { archive ->
                    archive.entries().asSequence().filterNot { it.isDirectory }.forEach { entry ->
                        val name = entry.name.replace('\\', '/')
                        if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) {
                            throw GradleException("Unsafe path in v06_clean.livliv: ${entry.name}")
                        }
                        entries.add(name)
                    }
                    if (entries.none { it.substringAfterLast('/') == "model.json" }) {
                        throw GradleException("v06_clean.livliv does not contain model.json")
                    }
                    if (entries.none { it.substringAfterLast('/') == "avatar.webp" }) {
                        throw GradleException("v06_clean.livliv does not contain avatar.webp")
                    }
                    val imageCount = entries.count { it.substringAfterLast('.').lowercase() in setOf("webp", "png", "jpg", "jpeg") }
                    if (imageCount < 10) throw GradleException("v06_clean.livliv image set looks incomplete ($imageCount image files)")

                    listOf("cover.webp", "avatar.webp").forEach { wanted ->
                        val entry = archive.entries().asSequence().firstOrNull { !it.isDirectory && it.name.substringAfterLast('/') == wanted }
                        if (entry != null) {
                            val destination = File(previewDir, wanted)
                            archive.getInputStream(entry).use { input ->
                                destination.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                    }
                }

                Files.move(tempModel.toPath(), modelAsset.toPath(), StandardCopyOption.REPLACE_EXISTING)
                downloaded = true
                logger.lifecycle("Downloaded and verified AndroidForge v06_clean.livliv (Git blob SHA-1 $actualSha). Character assets are embedded; runtime remains offline.")
                break
            } catch (error: Exception) {
                lastFailure = error
                tempModel.delete()
                logger.warn("AndroidForge v06_clean.livliv download attempt $attempt failed: ${error.message}")
            } finally {
                activeConnection?.disconnect()
            }
        }
        tempModel.delete()
        if (!downloaded) {
            throw GradleException("Could not download and package AndroidForge v06_clean.livliv. Check GitHub access from the build runner.", lastFailure)
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(downloadV06CleanCharacter)
}

