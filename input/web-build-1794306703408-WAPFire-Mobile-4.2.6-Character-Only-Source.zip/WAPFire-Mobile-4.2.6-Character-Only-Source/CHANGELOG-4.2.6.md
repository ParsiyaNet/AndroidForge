# WAPFire Mobile 4.2.6 — Character Only

- Fully removed the Nara voice/TTS path, mute/speaker controls, speech panel, and Kokoro/Sherpa build/model dependencies.
- Kept the character renderer and original Live2D model assets.
- Expanded the standalone character preview to the available screen area; removed the decorative title header.
- Cleaned the legacy fallback HTML so it renders only the character canvas and minimal status/error affordances.
- Kept manual state selection for preview/testing and event-driven state changes in the dashboard.
- Removed the 28 Hz shake behavior from Attack; the angry state is a steady expressive pose with a brief damped forward reaction.
- Repeated detections retrigger even when the character is already in the same state.
