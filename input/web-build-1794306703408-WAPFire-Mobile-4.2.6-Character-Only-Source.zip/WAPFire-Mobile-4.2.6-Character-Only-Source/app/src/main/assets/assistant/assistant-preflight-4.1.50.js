(() => {
  'use strict';
  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const language = fa ? 'fa' : 'en';
  const $ = (id) => document.getElementById(id);
  const classAction = (element, action, ...args) => {
    const list = element && element.classList;
    if (list && typeof list[action] === 'function') list[action](...args);
  };
  const native = () => window.WapFireNative;
  const report = (message) => {
    try { native()?.reportStatus(message == null ? null : String(message).slice(0, 850)); }
    catch (e) { console.error('WAPFire native status bridge unavailable', e); }
  };
  const text = (faText, enText) => fa ? faText : enText;

  window.__wfPreflightStarted = true;
  window.__wfAssistantBuildVersion = '4.2.6';
  window.__wfAssistantDocumentExpected = 'assistant-live.html';
  document.documentElement.lang = language;
  document.documentElement.dir = fa ? 'rtl' : 'ltr';
  document.documentElement.style.direction = fa ? 'rtl' : 'ltr';
  if (document.body) {
    document.body.dir = fa ? 'rtl' : 'ltr';
    document.body.style.direction = fa ? 'rtl' : 'ltr';
    classAction(document.body, 'toggle', 'compact', q.get('compact') !== '0');
    classAction(document.body, 'toggle', 'full', q.get('compact') === '0');
  }

  // Recover a partial WebView document before attempting to create the LivLiv Player.
  // The packaged HTML normally contains all of these nodes. On the affected Android
  // WebView, however, the bootstrap ran while only the outer body/shell was present.
  // Build missing nodes locally instead of permanently aborting with canvas=null.
  function ensureAssistantDom() {
    const body = document.body;
    if (!body) return null;

    let shell = $('shell') || body.querySelector('.shell');
    if (!shell) {
      shell = document.createElement('div');
      shell.id = 'shell';
      shell.className = 'shell';
      shell.dataset.state = 'idle';
      body.replaceChildren(shell);
      window.__wfDomRebuilt = true;
    }
    shell.id = 'shell';
    shell.classList.add('shell');
    if (!shell.dataset.state) shell.dataset.state = 'idle';

    let stage = shell.querySelector('.stage');
    if (!stage) {
      stage = document.createElement('div');
      stage.className = 'stage';
      shell.appendChild(stage);
      window.__wfDomRebuilt = true;
    }

    let canvas = $('stage');
    if (canvas && canvas.tagName !== 'CANVAS') {
      canvas.remove();
      canvas = null;
      window.__wfDomRebuilt = true;
    }
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'stage';
      canvas.setAttribute('aria-label', 'WAPFire animated assistant');
      stage.appendChild(canvas);
      window.__wfDomRebuilt = true;
    } else if (canvas.parentElement !== stage) {
      stage.appendChild(canvas);
    }
    canvas.style.display = 'block';
    canvas.style.width = '100%';
    canvas.style.height = '100%';

    let poster = $('poster');
    if (!poster || poster.tagName !== 'IMG') {
      poster = document.createElement('img');
      poster.id = 'poster';
      poster.alt = '';
      poster.src = './characters/v03/cover.webp';
      stage.prepend(poster);
      window.__wfDomRebuilt = true;
    } else if (poster.parentElement !== stage) {
      stage.prepend(poster);
    }

    let stateBox = shell.querySelector('.state');
    if (!stateBox) {
      stateBox = document.createElement('div');
      stateBox.className = 'state';
      stateBox.innerHTML = '<span class="dot" id="dot"></span><span id="stateText"></span>';
      shell.appendChild(stateBox);
      window.__wfDomRebuilt = true;
    }
    if (!$('dot')) {
      const dot = document.createElement('span'); dot.id = 'dot'; dot.className = 'dot'; stateBox.prepend(dot);
      window.__wfDomRebuilt = true;
    }
    if (!$('stateText')) {
      const statusText = document.createElement('span'); statusText.id = 'stateText'; stateBox.appendChild(statusText);
      window.__wfDomRebuilt = true;
    }

    let loading = $('loading');
    if (!loading) {
      loading = document.createElement('div');
      loading.className = 'loading';
      loading.id = 'loading';
      loading.textContent = text('در حال بارگذاری مدل انیمه‌ای…', 'Loading animated character…');
      shell.appendChild(loading);
      window.__wfDomRebuilt = true;
    }

    if (!$('wf-runtime-recovery-style')) {
      const style = document.createElement('style');
      style.id = 'wf-runtime-recovery-style';
      style.textContent = `
        html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#071629}
        .shell{position:absolute;inset:0;overflow:hidden;background:radial-gradient(ellipse at 50% 45%,#12395e,#071426)}
        .stage{position:absolute;inset:0;overflow:hidden;display:flex;align-items:stretch;justify-content:center}
        #stage{display:block;position:relative;z-index:1;flex:1 1 auto;width:100%;height:100%;touch-action:pan-y}
        #poster{position:absolute;inset:0;z-index:0;width:100%;height:100%;object-fit:contain;pointer-events:none}
        .loading{position:absolute;z-index:5;left:12px;right:12px;bottom:12px;padding:8px 10px;background:#06162df0;color:#9ab2ca;border:1px solid #2b83bd;border-radius:12px;font-size:11px;text-align:center}
        .state{position:absolute;z-index:3;left:11px;bottom:10px;display:flex;align-items:center;gap:7px;padding:7px 10px;background:#06182be8;border:1px solid #3d90c6;border-radius:999px;color:#cfeeff;font-size:10px}
        .dot{width:7px;height:7px;border-radius:50%;background:#53e5b3}
        .controls{position:absolute;z-index:4;left:10px;right:10px;bottom:47px;display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
        .controls button{padding:6px 9px;border:1px solid #275b83;border-radius:999px;background:#071c32e8;color:#dff4ff;font:inherit;font-size:10px}
      `;
      (document.head || body).appendChild(style);
    }

    return { shell, stage, canvas, loading, poster };
  }

  // This script is loaded at the end of <body>; the normal document should already be
  // complete. Ensure required renderer nodes now, and again immediately before boot.
  const initialDom = ensureAssistantDom();
  if (q.get('compact') === '0') removeStrayIdleText();
  window.__wfDomRecoveryAttempted = true;
  window.__wfInitialState = q.get('state') || 'idle';
  window.__wfPendingState = window.__wfInitialState;
  window.__wfLanguage = language;

  window.wapfireSetState = (state, force = false) => {
    window.__wfPendingState = String(state || 'idle');
    if (typeof window.__wfApplyState === 'function') window.__wfApplyState(window.__wfPendingState, !!force);
  };
  window.wapfireSetLanguage = (nextLanguage) => {
    const next = nextLanguage === 'en' ? 'en' : 'fa';
    if (next !== language) {
      location.search = `?compact=${document.body.classList.contains('compact') ? '1' : '0'}&lang=${next}&state=${encodeURIComponent(window.__wfPendingState || 'idle')}`;
    }
  };

  window.addEventListener('error', (event) => {
    const detail = event.message || event.target?.src || event.target?.href || 'Unknown script/resource error';
    if (/favicon\.ico(?:$|[?#])/i.test(String(detail))) return;
    const stack = event.error?.stack ? ` | ${String(event.error.stack).slice(0, 420)}` : '';
    report(text('خطای JavaScript/Asset: ', 'JavaScript/asset error: ') + String(detail).slice(0, 160) + stack);
  }, true);
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const detail = reason?.stack || reason?.message || String(reason || 'Unhandled promise rejection');
    report(text('خطای اجرای دستیار: ', 'Assistant runtime error: ') + String(detail).slice(0, 600));
  });

  const controlLabels = {
    en: {idle:'Idle', scanning:'Scanning', connecting:'Connecting', success:'Connected', password_success:'Pass OK', password_warning:'Wrong pass', warning:'Warning', angry:'Attack', offline:'Offline', setup:'Setup'},
    fa: {idle:'آماده', scanning:'پایش', connecting:'اتصال', success:'متصل', password_success:'رمز صحیح', password_warning:'رمز اشتباه', warning:'هشدار', angry:'حمله', offline:'آفلاین', setup:'راه‌اندازی'}
  };
  for (const button of document.querySelectorAll('[data-state]')) {
    button.textContent = controlLabels[language][button.dataset.state] || button.textContent;
  }

  const labels = {
    idle: {en:'Ready',fa:'آماده‌به‌کار',expr:null,action:null},
    scanning:{en:'Monitoring',fa:'در حال پایش',expr:null,action:'tilt'},
    connecting:{en:'Connecting',fa:'در حال اتصال',expr:'shy',action:'nod'},
    success:{en:'Connected',fa:'متصل شد',expr:'smile',action:'hop'},
    password_success:{en:'Password accepted',fa:'رمز صحیح',expr:'smile',action:'hop'},
    password_warning:{en:'Wrong password',fa:'رمز اشتباه',expr:'shy',action:'tilt'},
    warning:{en:'Threat detected',fa:'هشدار امنیتی',expr:'shy',action:'nod'},
    angry:{en:'Attack detected',fa:'حمله شناسایی شد',expr:'angry',action:null},
    offline:{en:'Device offline',fa:'دستگاه در دسترس نیست',expr:'sad',action:'tilt'},
    setup:{en:'Setup required',fa:'نیازمند راه‌اندازی',expr:'shy',action:'tilt'}
  };

  let player = null;
  let activeState = '';
  let ready = false;
  let pendingState = window.__wfPendingState;
  let stageObserver = null;
  let resizeRaf = 0;

  function showState(name, force=false) {
    const state = labels[name] ? name : 'idle';
    pendingState = state;
    window.__wfPendingState = state;
    if (!ready || !player || (!force && activeState === state)) return;
    const shell = $('shell');
    const stateText = $('stateText');
    const dot = $('dot');
    if (!shell || !stateText || !dot) {
      report(text('ساختار وضعیت کاراکتر ناقص است.', 'Character state elements are incomplete.'));
      return;
    }
    activeState = state;
    const row = labels[state];
    shell.dataset.state = state;
    stateText.textContent = fa ? row.fa : row.en;
    const isDanger = state === 'angry';
    const isWarning = state === 'warning' || state === 'password_warning';
    const isSuccess = state === 'success' || state === 'password_success';
    dot.style.color = isDanger ? 'var(--red)' : isWarning ? 'var(--amber)' : isSuccess ? 'var(--green)' : state === 'offline' ? 'var(--amber)' : 'var(--blue)';
    for (const button of document.querySelectorAll('[data-state]')) classAction(button, 'toggle', 'active', button.dataset.state === state);
    try {
      player.setAway(false);
      player.setExpression(row.expr);
      player.lookAt(state === 'scanning' ? -0.4 : (state === 'warning' || state === 'password_warning' || state === 'angry') ? 0.25 : null, state === 'scanning' ? 0.18 : 0);
      if (row.action) player.act(row.action);
      if (state === 'success' || state === 'password_success') player.blink();
    } catch (error) {
      console.error('LivLiv state reaction failed:', error);
      report(text('واکنش کاراکتر اجرا نشد: ', 'Character reaction failed: ') + String(error?.stack || error).slice(0, 420));
    }
  }
  window.__wfApplyState = (state, force = false) => { try { showState(String(state), !!force); } catch (error) { console.error('Assistant state update failed:', error); report(String(error?.stack || error).slice(0, 600)); } };
  for (const button of document.querySelectorAll('[data-state]')) button.addEventListener('click', () => { try { showState(button.dataset.state, true); } catch (error) { console.error('Assistant control failed:', error); report(String(error?.stack || error).slice(0, 600)); } });

  async function probeAsset(path) {
    try {
      const response = await fetch(path, {cache:'no-store'});
      const type = response.headers.get('content-type') || '(no content-type)';
      const bytes = await response.arrayBuffer();
      return `${path}: HTTP ${response.status}, ${type}, ${bytes.byteLength} bytes`;
    } catch (error) {
      return `${path}: FETCH FAILED (${error?.message || error})`;
    }
  }

  async function diagnose(error, phase) {
    const probes = await Promise.all([
      probeAsset('./dist/index.js'),
      probeAsset('./dist/chunks/base-p0Sx5Qp5.js'),
      probeAsset('./characters/v03.livliv')
    ]);
    const detail = `${phase}: ${error?.message || error}; ${probes.join(' | ')}`;
    console.error('WAPFire LivLiv diagnostic:', detail);
    const loading = $('loading');
    if (loading) {
      classAction(loading, 'add', 'error');
      loading.textContent = text('خطای موتور: ', 'Renderer error: ') + detail.slice(0, 320);
    }
    report(detail);
  }

  const nextFrame = () => new Promise(resolve => requestAnimationFrame(() => resolve()));

  async function waitForCanvasLayout(canvas) {
    if (!canvas) throw new Error('Canvas element #stage is missing from assistant-live.html.');
    // Compose's WebView is hosted inside a LazyColumn item. Some Android WebView builds resolve
    // percentage heights to zero on the first layout pass even though the native View is measured.
    // Give the HTML stage its own minimum block size, then let the normal parent size take over.
    const compactMode = q.get('compact') !== '0';
    const fallbackHeight = compactMode ? 200 : Math.max(320, Math.min(window.innerHeight || 480, 1200));
    const shell = $('shell');
    const stage = canvas.parentElement || canvas;
    for (const element of [document.documentElement, document.body, shell, stage]) {
      if (element && element.getBoundingClientRect().height < 32) {
        element.style.minHeight = `${fallbackHeight}px`;
      }
    }
    // Do not force a 200px minimum inside the compact Overview card: that made
    // the canvas overflow its measured stage and left a dark empty strip below it.
    // Use the real measured stage height whenever Compose has already sized it.
    const measuredStageHeight = stage.getBoundingClientRect().height;
    canvas.style.minHeight = `${measuredStageHeight >= 32 ? 0 : fallbackHeight}px`;
    canvas.style.width = '100%';
    canvas.style.height = '100%';

    // Allow Compose/WebView and Chromium to complete their layout before creating WebGL.
    for (let i = 0; i < 24; i++) {
      await nextFrame();
      const r = canvas.getBoundingClientRect();
      if (r.width >= 32 && r.height >= 32) return r;
    }
    const r = canvas.getBoundingClientRect();
    const shellRect = shell.getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    throw new Error(`Canvas layout failed (canvas ${Math.round(r.width)}x${Math.round(r.height)}, stage ${Math.round(stageRect.width)}x${Math.round(stageRect.height)}, shell ${Math.round(shellRect.width)}x${Math.round(shellRect.height)}).`);
  }

  function verifyFirstFrame(canvas, player) {
    const gl = canvas.getContext('webgl2');
    if (!gl || gl.isContextLost()) throw new Error('WebGL2 context was lost before the first frame.');
    // Force the renderer to draw synchronously after the model is installed. LivLiv normally starts
    // requestAnimationFrame in its constructor; in WebView we deliberately start paused and draw once
    // with the final measured canvas dimensions.
    player.resize();
    gl.finish();
    const w = canvas.width, h = canvas.height;
    if (w < 32 || h < 32) throw new Error(`WebGL drawing buffer is too small (${w}x${h}).`);
    const pixels = new Uint8Array(w * h * 4);
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const glError = gl.getError();
    // Ignore the corner watermark: count only the central character area, so a lone logo
    // cannot be mistaken for a successfully rendered avatar.
    let visiblePixels = 0;
    const x0 = Math.floor(w * 0.10), x1 = Math.ceil(w * 0.90);
    const y0 = Math.floor(h * 0.08), y1 = Math.ceil(h * 0.92);
    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) if (pixels[(y * w + x) * 4 + 3] > 12) visiblePixels++;
    }
    const centralArea = (x1 - x0) * (y1 - y0);
    const threshold = Math.max(350, Math.floor(centralArea * 0.005));
    const result = {width:w,height:h,visiblePixels,threshold,glError};
    console.info('WAPFire first-frame verification:', JSON.stringify(result));
    report(`First frame check: ${w}x${h}, alpha pixels ${visiblePixels}/${threshold}, GL error ${glError}`);
    if (glError !== gl.NO_ERROR) throw new Error(`WebGL draw error 0x${glError.toString(16)} after first frame.`);
    if (visiblePixels < threshold) throw new Error(`Model loaded but first frame is blank (${visiblePixels} visible pixels at ${w}x${h}).`);
    return result;
  }

  // Build 95: the immersive Assistant has native Close + state controls. Nothing in the web
  // layer may show a state label (the stray "Idle" at the upper-left corner).
  function removeStrayIdleText() {
    if (!document.body) return;
    document.querySelectorAll('.full-title,.controls,#controls').forEach((node) => node.remove());
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const doomed = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const value = String(node.nodeValue || '').trim().toLowerCase();
      if ((value === 'idle' || value === 'آماده') && !(node.parentElement && node.parentElement.closest('#stateText'))) doomed.push(node);
    }
    doomed.forEach((node) => node.remove());
  }

  // Build 95 character framing.
  // Full Assistant: the model's cut-off hem sits exactly on the lower edge of the character
  // frame (no dark gap under Nara). Overview framing is unchanged.
  // Clip-space bottom of the model = 2*y - scale*modelHeight/viewHeight - panY, so y is solved
  // for a bottom edge 0.3% below the frame edge (rounding can never leave a hairline gap).
  function applyFraming() {
    if (!player || !player.view) return;
    const canvas = $('stage');
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 32 || rect.height < 32) return;
    player.view.x = 0;
    if (document.body.classList.contains('compact')) {
      player.view.y = -0.025;
      player.view.zoom = 1.00;
      return;
    }
    const aspect = rect.width / rect.height;
    const zoom = aspect < 0.55 ? 0.99 : aspect < 0.72 ? 0.97 : 0.94;
    const puppet = player.puppet;
    const modelSize = (puppet && puppet.model && puppet.model.canvas) || [1024, 1536];
    const fit = Math.min(rect.width / modelSize[0], rect.height / modelSize[1]) * ((puppet && puppet.zoom) || 1);
    const panY = (puppet && puppet.panY) || 0;
    const BOTTOM_CLIP = -1.006;
    player.view.zoom = zoom;
    player.view.y = (BOTTOM_CLIP + (fit * zoom * modelSize[1]) / rect.height + panY) / 2;
  }

  async function boot(Player) {
    window.__wfEngineBooted = true;
    report(text('ماژول LivLiv بارگذاری شد؛ در حال آماده‌سازی Canvas…', 'LivLiv module loaded; preparing canvas…'));
    const compactMode = q.get('compact') !== '0';
    if (document.body) {
      classAction(document.body, 'toggle', 'compact', compactMode);
      classAction(document.body, 'toggle', 'full', !compactMode);
    }
    const loading = $('loading');
    try {
      const canvas = $('stage');
      if (!canvas) throw new Error('Canvas element #stage is missing from assistant-live.html.');
      const rect = await waitForCanvasLayout(canvas);
      // Render close to the device's native pixel density. The previous 1.2x cap made
      // the avatar visibly soft on modern high-density Android displays.
      const ratio = Math.min(window.devicePixelRatio || 1, 2.0);
      canvas.width = Math.max(1, Math.round(rect.width * ratio));
      canvas.height = Math.max(1, Math.round(rect.height * ratio));
      report(text('Canvas آماده است؛ در حال ساخت موتور گرافیکی…', 'Canvas has a valid size; creating the graphics engine…'));
      // Do not start the animation loop until the canvas has its final WebView/Compose size.
      player = new Player(canvas, {idle:true,followPointer:'canvas',maxPixelRatio:ratio,lang:language,autoplay:false});
      applyFraming();
      if (!compactMode) removeStrayIdleText();
      player.onContextLost = () => {
        ready=false;
        if (loading) {
          classAction(loading, 'remove', 'hide');
          classAction(loading, 'add', 'error');
          loading.textContent = text('شتاب‌دهندهٔ گرافیکی متوقف شد؛ صفحه را دوباره باز کن.', 'Graphics context lost. Reopen this screen.');
        }
        report(text('شتاب‌دهندهٔ گرافیکی متوقف شد؛ صفحه را دوباره باز کن.', 'Graphics context lost. Reopen this screen.'));
      };
      report(text('در حال دریافت مدل و تکسچرهای محلی…', 'Loading local character package and textures…'));
      await player.load('./characters/v03.livliv', {
        poster:'./characters/v03/cover.webp',
        onProgress:(progress) => {
          if (progress.step === 'download') {
            const message = text(`بارگذاری کاراکتر… ${Math.round(progress.progress*100)}٪`, `Loading character… ${Math.round(progress.progress*100)}%`);
            if (loading) loading.textContent = message;
            report(message);
          }
        }
      });
      // Respect watermark metadata supplied by the model package. This purchased package
      // declares no runtime watermark; the separate app poster is built from clean layers.
      // Character attribution remains available in Settings > Credits.
      if (compactMode && player.mark && typeof player.mark.set === 'function') {
        try { player.mark.set('none', null, false); player.resize(); }
        catch (markError) { console.warn('LivLiv Overview mark styling skipped:', markError); }
      }
      report(text('مدل بارگذاری شد؛ در حال رسم اولین فریم…', 'Model loaded; drawing the first frame…'));
      // The Compose-hosted WebView may finish loading before its final layout pass. Re-measure and
      // resize after load, then force one synchronous frame and inspect the real WebGL framebuffer.
      await nextFrame();
      await nextFrame();
      const finalRect = canvas.getBoundingClientRect();
      if (finalRect.width < 32 || finalRect.height < 32) throw new Error(`Canvas became unavailable after model load (${Math.round(finalRect.width)}x${Math.round(finalRect.height)}).`);
      canvas.width = Math.max(1, Math.round(finalRect.width * ratio));
      canvas.height = Math.max(1, Math.round(finalRect.height * ratio));
      applyFraming();
      verifyFirstFrame(canvas, player);
      // Keep the backing buffer in sync with the real Compose/WebView size (rotation, split-screen,
      // Overview card re-layout). Ignore transient zero-size callbacks while LazyColumn is moving.
      if (typeof ResizeObserver !== 'undefined') {
        stageObserver?.disconnect();
        stageObserver = new ResizeObserver(() => {
          if (!ready || !player) return;
          const r = canvas.getBoundingClientRect();
          if (r.width < 32 || r.height < 32) return;
          cancelAnimationFrame(resizeRaf);
          resizeRaf = requestAnimationFrame(() => { try { applyFraming(); player?.resize(); } catch (e) { console.error('LivLiv resize failed', e); } });
        });
        stageObserver.observe(canvas.parentElement || canvas);
      }
      player.play();
      // Keep a low-opacity, blurred ambient layer behind the transparent model canvas.
      const poster = $('poster');
      if (poster) poster.style.opacity = compactMode ? '.34' : '.28';
      if (loading && loading.isConnected) loading.remove();
      ready=true;
      activeState='';
      showState(pendingState,true);
      window.__wfRendererReady=true;
      native()?.reportReady();
      console.info('WAPFire LivLiv renderer ready:', player.model?.name);
    } catch (error) {
      const failure = text(`کاراکتر بارگذاری نشد: ${error?.message || error}`, `Character could not load: ${error?.message || error}`);
      if (loading) { classAction(loading, 'add', 'error'); loading.textContent = failure; }
      report(`${failure}${error?.stack ? ` | ${String(error.stack).slice(0, 420)}` : ''}`);
      console.error('WAPFire LivLiv assistant:', error);
      // Leave the cover visible as a useful fallback rather than removing it over a blank canvas.
      const poster = $('poster');
      if (poster) { poster.style.opacity = '.82'; poster.style.filter = 'none'; poster.style.transform = 'none'; }
      try { player?.dispose(); } catch (_) {}
      player = null;
    }
  }

  let rendererStartRequested = false;
  let domRecoveryRetries = 0;
  function startRendererWhenDomReady() {
    if (rendererStartRequested || window.__wfEngineBooted || window.__wfRendererReady) return;
    const dom = ensureAssistantDom();
    if (!dom || !dom.canvas || !dom.loading || !dom.canvas.isConnected) {
      if (domRecoveryRetries++ < 20) {
        console.warn('Assistant DOM not ready; retrying local DOM recovery.', {
          readyState: document.readyState,
          bodyChildren: document.body?.children.length || 0,
          hasShell: !!$('shell'), hasStage: !!document.querySelector('.stage'),
          hasCanvas: !!$('stage'), hasLoading: !!$('loading')
        });
        setTimeout(startRendererWhenDomReady, 100);
        return;
      }
      const message = 'Assistant DOM recovery failed: ' +
        ['stage','loading','poster','shell'].filter(id => !$(id)).join(', ');
      report(text('بازیابی ساختار صفحه دستیار ناموفق بود: ', 'Assistant DOM recovery failed: ') + message);
      console.error(message, { readyState: document.readyState, url: location.href, body: document.body?.innerHTML?.slice(0, 500) });
      return;
    }

    rendererStartRequested = true;
    report(text('راه‌انداز 4.1.50 فعال است؛ در حال واردکردن موتور LivLiv…', 'WAPFire assistant bootstrap 4.1.50 is active; importing LivLiv engine…'));
    window.__wfPreflightStartedAt = Date.now();
    window.__wfEngineBooted = false;
    window.__wfRendererReady = false;
    requestAnimationFrame(() => {
      import('./dist/index.js?build=4.1.50')
        .then((module) => {
          if (!module?.Player) throw new Error('dist/index.js loaded but did not export Player.');
          return boot(module.Player);
        })
        .catch((error) => diagnose(error, 'LivLiv ES module import failed'));
    });
  }

  // The bootstrap script is physically placed after the complete assistant shell at
  // the end of <body>. Do not wait for DOMContentLoaded here: some Android WebView builds
  // exposed a partial document to a deferred head script and the old one-shot guard then
  // returned permanently. A frame boundary now gives layout a chance to settle, while the
  // local DOM recovery above guarantees canvas#stage and #loading exist before import().
  requestAnimationFrame(startRendererWhenDomReady);

  window.addEventListener('pagehide', () => { stageObserver?.disconnect(); cancelAnimationFrame(resizeRaf); try { player?.dispose(); } catch (_) {} });
})();
