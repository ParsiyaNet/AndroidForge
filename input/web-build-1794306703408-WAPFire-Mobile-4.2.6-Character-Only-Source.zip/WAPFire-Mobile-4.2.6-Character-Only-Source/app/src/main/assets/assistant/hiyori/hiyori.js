/* WAPFire 4.2.6 - Hiyori Momose (Live2D Cubism 4) character renderer.
 * Same native contract as the previous page: window.wapfireSetState(state),
 * WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg).
 * 4.2.6: voice-free character-only screen and event-driven natural Live2D reactions. */
(function () {
  'use strict';
  const BUILD = '4.2.6';
  window.__wfPreflightStarted = true;
  window.__wfAssistantBuildVersion = BUILD;
  window.__wfAssistantDocumentExpected = true;

  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const compact = q.get('compact') !== '0';
  const $ = (id) => document.getElementById(id);
  const bridge = window.WapFireNative;
  document.documentElement.lang = fa ? 'fa' : 'en';
  document.body.className = compact ? 'compact' : 'full';

  let ready = false;
  let model = null;
  let app = null;
  let rawModel = null;
  let pendingState = q.get('state') || 'idle';
  const userZoom = parseFloat(q.get('zoom') || '1') || 1;
  const userDy = parseFloat(q.get('dy') || '0') || 0;

  function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
  function fatal(message) {
    const text = String(message).slice(0, 400);
    console.error(text);
    const box = $('loading');
    if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
    report(text);
    try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
  }
  window.addEventListener('error', (e) => { if (!ready) fatal('Hiyori error: ' + (e.message || e)); });
  window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('Hiyori error: ' + ((e.reason && e.reason.message) || e.reason)); });

  /* ---------- states ---------- */
  const PILL = {
    idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
    success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
    warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
    setup: ['Setup required', 'نیازمند راه‌اندازی']
  };
  // Hiyori has no separate expression files. These restrained parameter poses
  // are blended over her authored Live2D idle motions and physics.
  const DEFAULT_POSE = {
    mouthForm: 0, mouthOpen: 0, eyeOpen: 1, eyeSmile: 0, cheek: 0,
    browY: 0, browAngle: 0, angleX: 0, angleY: 0, angleZ: 0,
    bodyX: 0, bodyY: 0, bodyZ: 0, gazeX: 0, gazeY: 0,
    scan: 0, scanSpeed: 0.8
  };
  const POSES = {
    idle: {},
    scanning: { browY: 0.13, angleY: 1.1, scan: 0.92, scanSpeed: 0.72, bodyX: 0.25 },
    connecting: { mouthForm: 0.03, eyeOpen: 0.98, browY: 0.18, angleZ: 4.0, gazeX: -0.22, gazeY: 0.1, bodyX: -0.35 },
    success: { mouthForm: 0.78, mouthOpen: 0.04, eyeSmile: 0.48, cheek: 0.58, browY: 0.12, angleY: 0.8 },
    password_success: { mouthForm: 0.68, mouthOpen: 0.03, eyeSmile: 0.36, cheek: 0.42, browY: 0.08 },
    password_warning: { mouthForm: -0.38, eyeOpen: 0.93, browY: -0.1, browAngle: 0.22, angleZ: -3.2, angleY: -1.4, gazeX: 0.2 },
    warning: { mouthForm: -0.18, eyeOpen: 0.9, browY: 0.34, angleY: 2.0, scan: 0.34, scanSpeed: 0.95, gazeX: 0.18 },
    // Alert stance: focused eyes, lowered brows, slight forward set. Deliberately
    // no sinusoidal shake; the one-shot reaction is supplied by the event envelope.
    angry: { mouthForm: -0.86, mouthOpen: 0.018, eyeOpen: 0.70, browY: -0.46, browAngle: -0.28, angleX: 1.2, angleY: -3.5, angleZ: -1.8, bodyX: -1.25, bodyY: -0.35, bodyZ: -1.35, gazeX: 0.34, gazeY: -0.06 },
    offline: { mouthForm: -0.24, eyeOpen: 0.7, browY: -0.13, angleY: -5.2, angleZ: -3.0, gazeY: -0.16, bodyX: -0.45 },
    setup: { mouthForm: 0.5, eyeSmile: 0.14, browY: 0.18, angleZ: 2.4, gazeX: -0.16, gazeY: 0.08 }
  };
  const cur = Object.assign({}, DEFAULT_POSE);
  let tgt = Object.assign({}, DEFAULT_POSE);
  let activeState = '';
  let reactionStartedAt = performance.now();
  let reactionKind = 'none';

  function triggerReaction(kind) {
    reactionKind = kind;
    reactionStartedAt = performance.now();
  }

  function showState(name, force = false) {
    const state = POSES[name] ? name : 'idle';
    const changed = state !== activeState;
    pendingState = state;
    $('shell').dataset.state = state;
    $('stateText').textContent = PILL[state][fa ? 1 : 0];
    tgt = Object.assign({}, DEFAULT_POSE, POSES[state]);
    if (changed || force) {
      activeState = state;
      triggerReaction(state);
    }
  }
  window.wapfireSetState = (state, force = false) => { try { showState(String(state), !!force); } catch (e) { report(String(e)); } };

  /* ---------- parameter access (raw Cubism Core model) ---------- */
  const paramIndex = {};
  function bindParameters() {
    const ids = rawModel.parameters.ids;
    for (let i = 0; i < ids.length; i++) paramIndex[ids[i]] = i;
  }
  function put(id, value, mode) {
    const i = paramIndex[id];
    if (i === undefined) return;
    const p = rawModel.parameters;
    const now = p.values[i];
    const v = mode === 'add' ? now + value : mode === 'min' ? Math.min(now, value) : value;
    p.values[i] = Math.max(p.minimumValues[i], Math.min(p.maximumValues[i], v));
  }

  let lastTime = performance.now();
  function applyPose() {
    if (!rawModel) return;
    const nowMs = performance.now();
    const dt = Math.min(0.08, Math.max(0.001, (nowMs - lastTime) / 1000));
    lastTime = nowMs;
    const t = nowMs / 1000;
    const stateBlend = 1 - Math.exp(-dt * 3.9);
    for (const key in cur) cur[key] += (tgt[key] - cur[key]) * stateBlend;

    const elapsed = Math.max(0, (nowMs - reactionStartedAt) / 1000);
    // A smooth, damped response that happens once on a state change rather than
    // a continuous vibration. Each event has its own small, physically plausible accent.
    const rise = 1 - Math.exp(-elapsed * 9.0);
    const decay = Math.exp(-elapsed * 2.25);
    const impulse = rise * decay;
    const settleWave = Math.sin(elapsed * 4.2) * Math.exp(-elapsed * 2.8);
    const alertBeat = Math.exp(-Math.pow((elapsed - 0.13) / 0.17, 2));

    // Small layered life in the neutral state: slow eye drift and a barely visible
    // head sway. Live2D's original Idle motions, blink and physics remain enabled.
    const idleMotion = cur.scan > 0.18 ? 0.28 : 1;
    const idleLookX = (Math.sin(t * 0.19) * 0.105 + Math.sin(t * 0.43 + 1.15) * 0.035) * idleMotion;
    const idleLookY = (Math.sin(t * 0.16 + 0.85) * 0.045 + Math.sin(t * 0.31) * 0.018) * idleMotion;
    const idleHeadX = Math.sin(t * 0.13 + 0.5) * 0.58 * idleMotion;
    const idleHeadY = Math.sin(t * 0.11 + 1.7) * 0.34 * idleMotion;
    const scanSweep = Math.sin(t * Math.max(0.4, cur.scanSpeed) * 0.92) * cur.scan;
    const gazeX = cur.gazeX + scanSweep * 0.62 + idleLookX;
    const scanHeadFollow = scanSweep * 0.34;
    const gazeY = cur.gazeY + idleLookY;

    let reactionHeadX = 0;
    let reactionHeadY = 0;
    let reactionRoll = 0;
    let reactionBodyY = 0;
    let reactionBodyZ = 0;
    let reactionShoulder = 0;
    let reactionArm = 0;
    let eyeReaction = 0;
    if (reactionKind === 'angry') {
      // A deliberate attack response: brief alert beat, measured forward lean,
      // then a steady angry expression. No high-frequency shake or looping jitter.
      reactionHeadY = -2.0 * impulse;
      reactionRoll = -0.65 * impulse;
      reactionBodyY = -2.15 * impulse;
      reactionBodyZ = -0.8 * impulse;
      reactionShoulder = 0.32 * impulse;
      reactionArm = -0.65 * impulse;
      eyeReaction = 0.12 * alertBeat;
    } else if (reactionKind === 'warning' || reactionKind === 'password_warning') {
      reactionHeadX = 1.1 * impulse;
      reactionRoll = (reactionKind === 'warning' ? 0.55 : -0.75) * impulse;
      reactionBodyY = -0.8 * impulse;
      eyeReaction = 0.10 * alertBeat;
    } else if (reactionKind === 'success' || reactionKind === 'password_success') {
      // One gentle, damped celebratory bounce; the smile remains as the state pose.
      reactionBodyY = -1.05 * settleWave;
      reactionHeadY = -0.55 * settleWave;
    } else if (reactionKind === 'connecting' || reactionKind === 'setup') {
      reactionHeadX = -0.95 * impulse;
      reactionRoll = 0.8 * impulse;
      reactionBodyY = -0.55 * impulse;
    } else if (reactionKind === 'offline') {
      reactionHeadY = 0.75 * impulse;
      reactionRoll = -0.45 * impulse;
    } else if (reactionKind === 'tap') {
      reactionHeadY = -0.9 * impulse;
      reactionRoll = 0.48 * impulse;
    }

    put('ParamMouthForm', cur.mouthForm, 'set');
    put('ParamMouthOpenY', cur.mouthOpen, 'set');
    put('ParamEyeLOpen', Math.min(1, cur.eyeOpen + eyeReaction), 'min');
    put('ParamEyeROpen', Math.min(1, cur.eyeOpen + eyeReaction), 'min');
    put('ParamEyeLSmile', cur.eyeSmile, 'set');
    put('ParamEyeRSmile', cur.eyeSmile, 'set');
    put('ParamCheek', cur.cheek, 'set');
    put('ParamBrowLY', cur.browY, 'add');
    put('ParamBrowRY', cur.browY, 'add');
    put('ParamBrowLAngle', cur.browAngle, 'add');
    put('ParamBrowRAngle', cur.browAngle, 'add');
    put('ParamEyeBallX', gazeX, 'set');
    put('ParamEyeBallY', gazeY, 'set');
    put('ParamAngleX', cur.angleX + gazeX * 6 + idleHeadX + scanHeadFollow + reactionHeadX, 'add');
    put('ParamAngleY', cur.angleY + idleHeadY + reactionHeadY, 'add');
    put('ParamAngleZ', cur.angleZ + reactionRoll, 'add');
    put('ParamBodyAngleX', cur.bodyX + gazeX * 1.5, 'add');
    put('ParamBodyAngleY', cur.bodyY + reactionBodyY, 'add');
    put('ParamBodyAngleZ', cur.bodyZ + reactionBodyZ, 'add');
    put('ParamShoulder', reactionShoulder, 'add');
    put('ParamArmLA', reactionArm, 'add');
    put('ParamArmRA', reactionArm, 'add');
  }

  /* ---------- framing ---------- */
  // Measured from Hiyori.moc3 with Cubism Core 4.2.2 (rest pose, canvas pixels):
  // canvas 2976x4175, hair/ahoge top y=303, chin y=1014, character x-range 922..2126.
  const M = { canvasW: 2976, top: 303, chin: 1014, left: 922, right: 2126 };
  // Targets taken from the Nara screenshots: where the head starts and how tall the head is,
  // as a fraction of the stage height (the body is cropped by the stage bottom like Nara's).
  const FRAME = {
    full: { top: 0.188, head: 0.32, maxW: 0.92 },
    compact: { top: 0.022, head: 0.41, maxW: 0.92 }
  };
  function fit() {
    if (!app || !model) return;
    const box = $('stageBox');
    const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
    app.renderer.resize(W, H);
    const cfg = compact ? FRAME.compact : FRAME.full;
    const baseW = model.width / model.scale.x;          // should be the 2976px canvas
    const unit = baseW > 0 ? M.canvasW / baseW : 1;
    let s = (cfg.head * H) / (M.chin - M.top);
    s = Math.min(s, (cfg.maxW * W) / (M.right - M.left)) * userZoom;
    model.scale.set(s * unit);
    model.x = W / 2 - ((M.left + M.right) / 2) * s;
    model.y = H * (cfg.top + userDy) - M.top * s;
  }
  window.wapfireFrame = (zoom, dy) => { /* debugging aid: window.wapfireFrame(1.1, 0.02) */ fit(); return { zoom, dy }; };

  /* ---------- boot ---------- */
  async function boot() {
    if (!window.Live2DCubismCore) throw new Error('Live2D Cubism Core did not load.');
    if (!window.PIXI || !PIXI.live2d) throw new Error('Pixi / Live2D plugin did not load.');
    window.__wfEngineBooted = true;
    try { PIXI.live2d.Live2DModel.registerTicker(PIXI.Ticker); } catch (e) { /* already registered */ }

    const canvas = $('stage');
    app = new PIXI.Application({
      view: canvas, autoStart: true, antialias: true, backgroundAlpha: 0,
      resolution: Math.min(window.devicePixelRatio || 1, 2), autoDensity: true,
      width: Math.max(40, canvas.clientWidth || 300), height: Math.max(40, canvas.clientHeight || 300)
    });
    model = await PIXI.live2d.Live2DModel.from('./model/Hiyori.model3.json', { autoInteract: true });
    app.stage.addChild(model);

    // autoInteract handles pointer/touch gaze; react to a real model hit with
    // Hiyori's authored TapBody motion instead of triggering it on empty space.
    model.on('hit', () => {
      triggerReaction('tap');
      try {
        const motion = model.motion('TapBody');
        if (motion && typeof motion.catch === 'function') motion.catch(() => {});
      } catch (e) { /* the default idle motion remains active */ }
    });

    const core = model.internalModel.coreModel;
    rawModel = core._model || (core.getModel && core.getModel());
    if (!rawModel || !rawModel.parameters) throw new Error('Unexpected Live2D model structure.');
    bindParameters();
    model.internalModel.on('beforeModelUpdate', applyPose);

    fit();
    if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
    window.addEventListener('resize', () => requestAnimationFrame(fit));
    showState(pendingState, true);
    // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    fit();
    ready = true;
    window.__wfRendererReady = true;
    $('loading').style.display = 'none';
    try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
  }
  showState(pendingState);
  boot().catch((error) => fatal('Hiyori failed to start: ' + ((error && error.message) || error)));
})();
