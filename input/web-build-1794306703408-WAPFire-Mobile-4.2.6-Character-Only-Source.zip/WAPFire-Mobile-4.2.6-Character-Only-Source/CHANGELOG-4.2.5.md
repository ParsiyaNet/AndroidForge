# WAPFire Mobile 4.2.5 — Character-only Nara

- Removed all Nara voice/TTS implementation, controls, native audio playback, Sherpa-ONNX and Kokoro model dependencies/assets.
- Removed the Nara text/speech panel so the character receives the full visual area. State selector remains available for manual testing.
- Preserved Live2D Hiyori, authored Idle/TapBody motions, eye blinking and physics.
- Replaced attack vibration with a smooth, damped angry reaction and state-specific reactions for warning, password results, connection/setup, scanning and offline.
- Propagated detection event sequence so repeated detections retrigger reactions even when the state label stays unchanged.
