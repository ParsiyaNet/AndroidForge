# WAPFire Mobile 4.2.4

## Offline Nara voice fix
- Added the official Sherpa-ONNX English lexicon frontend (`lexicon-en-us.txt`) with SHA-256 verification.
- Set Kokoro language hint to `eng`; removed reliance on the deprecated `dataDir`/eSpeak frontend in Sherpa-ONNX 2.x.
- Kept `af_bella` speaker ID 1 for `kokoro-en-v0_19`.
- Added runtime diagnostics for engine initialization, generated sample count/peak, and AudioTrack playback. Empty/silent synthesis now reports an explicit error instead of silently returning.
- Nara continues to speak English only, independent of the app UI language.
- Enabled the same offline voice and mouth-sync path in the standalone Discovery preview, not only the dashboard Nara tab; added a speaker toggle there.
