# 4.1.68 – Restore 3-second chart refresh

* Restore Overview chart refresh to the original 3-second cadence, matching live status polling.
* Keep the 4.1.67 VF38 compatibility and startup improvements: reuse firmware version from `/api/status`, publish Status before requesting chart data, and retain sequential close-after-request transport.
* Manual Refresh continues to fetch chart data immediately.
* No UI layout, RF monitoring, authentication, certificate pinning, or settings behavior changes.
