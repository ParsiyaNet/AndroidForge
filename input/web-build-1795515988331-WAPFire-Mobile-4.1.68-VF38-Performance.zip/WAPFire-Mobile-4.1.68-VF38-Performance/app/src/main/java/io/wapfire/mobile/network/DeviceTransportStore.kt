package io.wapfire.mobile.network

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Remembers, per device host, whether WAPFire is reached over HTTP or HTTPS and which
 * certificate fingerprint the user trusted for it.
 *
 * Fingerprints are public values, so plain SharedPreferences is sufficient; their integrity
 * matters more than their secrecy and the app's private storage already protects that.
 * The store works in memory only until [init] has been called (it is called from the
 * activity and from both foreground services, which share this process).
 */
object DeviceTransportStore {
    data class Entry(val https: Boolean, val fingerprint: String?)

    /** A certificate the user must accept or reject before the app talks to the device. */
    data class TrustRequest(val host: String, val fingerprint: String, val previousFingerprint: String?)

    private const val PREFS_NAME = "wapfire_device_transport"
    private const val KEY_PREFIX = "h:"

    private var prefs: SharedPreferences? = null
    private val entries = HashMap<String, Entry>()

    private val pending = MutableStateFlow<TrustRequest?>(null)
    val pendingTrust: StateFlow<TrustRequest?> = pending.asStateFlow()

    /** HTTPS is unreachable but the device answers on plain HTTP: ask before downgrading. */
    data class HttpFallbackRequest(val host: String)
    private val pendingFallback = MutableStateFlow<HttpFallbackRequest?>(null)
    val pendingHttpFallback: StateFlow<HttpFallbackRequest?> = pendingFallback.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val stored = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = stored
        // Entries created before init (in-memory only) stay; persisted ones fill the gaps.
        stored.all.forEach { (key, value) ->
            if (key.startsWith(KEY_PREFIX) && value is String) {
                entries.putIfAbsent(key.removePrefix(KEY_PREFIX), decode(value))
            }
        }
        entries.forEach { (host, entry) -> stored.edit().putString(KEY_PREFIX + host, encode(entry)).apply() }
    }

    /** "http://192.168.4.1/x" -> "192.168.4.1": the bare, lower-case host used as the key. */
    fun hostKey(hostOrUrl: String): String =
        hostOrUrl.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').lowercase(Locale.ROOT)

    @Synchronized
    fun get(host: String): Entry? = entries[hostKey(host)]

    @Synchronized
    fun setHttps(host: String, https: Boolean) {
        val key = hostKey(host)
        put(key, Entry(https, entries[key]?.fingerprint))
    }

    /** Pins [fingerprint] for [host] and marks it as an HTTPS device. */
    @Synchronized
    fun trust(host: String, fingerprint: String): Boolean {
        val normalized = TlsPinning.normalizeFingerprint(fingerprint) ?: return false
        val key = hostKey(host)
        put(key, Entry(true, normalized))
        if (pending.value?.host == key) pending.value = null
        return true
    }

    /** Forgets the pinned certificate (e.g. after a factory reset), keeping the transport choice. */
    @Synchronized
    fun forgetFingerprint(host: String) {
        val key = hostKey(host)
        entries[key]?.let { put(key, it.copy(fingerprint = null)) }
    }

    fun reportUntrusted(request: TrustRequest) {
        pending.value = request
    }

    fun dismissPending() {
        pending.value = null
    }

    fun reportHttpFallback(host: String) {
        pendingFallback.value = HttpFallbackRequest(hostKey(host))
    }

    fun dismissHttpFallback() {
        pendingFallback.value = null
    }

    /** The user agreed: use plain HTTP for this device. Every WapFireApi follows the store. */
    fun acceptHttpFallback(host: String) {
        setHttps(host, false)
        pendingFallback.value = null
    }

    private fun put(key: String, entry: Entry) {
        entries[key] = entry
        prefs?.edit()?.putString(KEY_PREFIX + key, encode(entry))?.apply()
    }

    private fun encode(entry: Entry): String = (if (entry.https) "https" else "http") + "|" + entry.fingerprint.orEmpty()

    private fun decode(value: String): Entry {
        val scheme = value.substringBefore('|')
        val fingerprint = TlsPinning.normalizeFingerprint(value.substringAfter('|', ""))
        return Entry(scheme == "https", fingerprint)
    }
}
