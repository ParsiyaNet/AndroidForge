package io.wapfire.mobile.network

import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.Locale
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * WAPFire generates its own self-signed certificate, so there is no certificate authority
 * the phone could validate it against. Trust is therefore anchored in the certificate's
 * SHA-256 fingerprint instead: the first time a device is used the fingerprint is shown to
 * the user (it is also shown on the device's own Settings page) and, once accepted, every
 * later connection must present exactly that certificate. This module is pure JVM code so
 * it can be unit-tested without Android.
 */
object TlsPinning {

    /** "AA:BB:..." (upper case) SHA-256 of the DER-encoded certificate. */
    fun fingerprintOf(certificate: X509Certificate): String =
        formatFingerprint(MessageDigest.getInstance("SHA-256").digest(certificate.encoded))

    fun formatFingerprint(digest: ByteArray): String =
        digest.joinToString(":") { String.format(Locale.ROOT, "%02X", it.toInt() and 0xFF) }

    /** Normalises user/firmware supplied fingerprints so they can be compared safely. */
    fun normalizeFingerprint(value: String?): String? {
        val hex = value.orEmpty().filter { it.isLetterOrDigit() }.uppercase(Locale.ROOT)
        if (hex.length != 64 || !hex.all { it in '0'..'9' || it in 'A'..'F' }) return null
        return hex.chunked(2).joinToString(":")
    }

    /**
     * Accepts the server only when the leaf certificate matches [expected]. When there is no
     * pinned fingerprint yet, or it differs, the handshake is aborted and [rejectedFingerprint]
     * tells the caller which fingerprint the server presented so the user can be asked.
     */
    class PinningTrustManager(expected: String?) : X509TrustManager {
        private val expectedNormalized: String? = normalizeFingerprint(expected)

        @Volatile var observedFingerprint: String? = null
            private set
        @Volatile var rejectedFingerprint: String? = null
            private set

        /** Clears the verdict of a previous attempt (the instance is shared between requests). */
        fun beginAttempt() {
            rejectedFingerprint = null
        }

        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
            throw CertificateException("Client certificates are not supported")
        }

        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
            val leaf = chain?.firstOrNull() ?: throw CertificateException("The device did not present a certificate")
            val actual = fingerprintOf(leaf)
            observedFingerprint = actual
            if (expectedNormalized == null || expectedNormalized != actual) {
                rejectedFingerprint = actual
                throw CertificateException(
                    if (expectedNormalized == null) "Device certificate is not trusted yet"
                    else "Device certificate changed"
                )
            }
            rejectedFingerprint = null
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    /** Records the presented fingerprint and accepts it. Only for GETs that carry no secrets. */
    class ObservingTrustManager : X509TrustManager {
        @Volatile var observedFingerprint: String? = null
            private set

        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
            throw CertificateException("Client certificates are not supported")
        }

        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
            val leaf = chain?.firstOrNull() ?: throw CertificateException("The device did not present a certificate")
            observedFingerprint = fingerprintOf(leaf)
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    class PinnedClient(val trustManager: PinningTrustManager, val factory: SSLSocketFactory)

    private val pinnedClients = java.util.concurrent.ConcurrentHashMap<String, PinnedClient>()

    /**
     * One SSL context per pinned fingerprint, reused by every request. The context owns the TLS
     * session cache, so later requests resume the earlier session (one round trip instead of a
     * full ECDHE/ECDSA handshake, which is expensive on the ESP32). Without a pin the handshake
     * is rejected anyway, so a throw-away context is fine.
     */
    fun clientFor(expected: String?): PinnedClient {
        val key = normalizeFingerprint(expected)
        if (key == null) {
            val tm = PinningTrustManager(null)
            return PinnedClient(tm, socketFactory(tm))
        }
        return pinnedClients.getOrPut(key) {
            val tm = PinningTrustManager(key)
            PinnedClient(tm, socketFactory(tm))
        }
    }

    fun socketFactory(trustManager: TrustManager): SSLSocketFactory =
        SSLContext.getInstance("TLS").apply { init(null, arrayOf(trustManager), SecureRandom()) }.socketFactory

    /**
     * The certificate carries no usable host name (devices are reached by IP address), so name
     * matching is skipped. This is only safe together with [PinningTrustManager], which has
     * already pinned the exact certificate.
     */
    val pinnedHostnameVerifier: HostnameVerifier = HostnameVerifier { _, _ -> true }
}

/** The device presented a certificate the user has not trusted yet, or a different one than before. */
class CertificateTrustRequiredException(
    val host: String,
    val fingerprint: String,
    val previousFingerprint: String?
) : IOException(
    if (previousFingerprint == null)
        "WAPFire is using HTTPS with a certificate you have not trusted yet. Verify the fingerprint and trust it to continue."
    else
        "The WAPFire HTTPS certificate changed. Connection blocked until you verify the new fingerprint."
)

/** HTTPS stopped answering but the device still answers on HTTP (HTTPS was probably turned off). */
class HttpsUnavailableException(val host: String, val switched: Boolean) : IOException(
    if (switched)
        "HTTPS is turned off on this WAPFire; the app switched to HTTP. Try again."
    else
        "HTTPS is turned off on this WAPFire (it only answers on HTTP). Confirm switching this device to HTTP to continue."
)
