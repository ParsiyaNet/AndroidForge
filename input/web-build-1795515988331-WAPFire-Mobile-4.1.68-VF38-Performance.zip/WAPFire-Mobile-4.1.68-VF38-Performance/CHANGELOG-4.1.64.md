# 4.1.64 – 4.1.66 – HTTPS support

Version 4.1.64 (versionCode 109).

* New **HTTPS (secure connection)** switch in Settings → Protection (below Self-protect), matching the
  firmware option (default HTTP).
* The app learns the transport per device (`DeviceTransportStore`): a device that answers plain HTTP with a
  redirect to `https://` is switched to HTTPS automatically and the request is repeated.
  The login probe runs first, so credentials are never sent over HTTP to a device that wants HTTPS.
* Certificates are self-signed, so trust is pinned to the SHA-256 fingerprint (`TlsPinning`):
  * enabling HTTPS from the app pins the fingerprint the device returns over the authenticated session;
  * otherwise the user is asked once to verify/trust the fingerprint (compare with the device's Settings page);
  * a changed certificate is blocked with a stronger warning until the user decides.
* Discovery recognises HTTPS-only devices (marked redirect on port 80 / login page over TLS).
* Background monitor and keep-alive services share the transport store.
* Not changed: cleartext traffic stays allowed in the manifest so HTTP devices keep working.

## 4.1.65 fixes
* The HTTPS switch in Settings now follows the device: telemetry only reads `/api/status`, which did not carry
  `https_enabled` (firmware now adds it; the app also falls back to the transport it is using).
* If HTTPS stops answering while the device still answers on plain HTTP (HTTPS turned off on the device), the
  app asks once "Use HTTP?" instead of failing - no more typing `:80`. It does not downgrade silently, because
  anybody on the Wi-Fi could block port 443 to push the app onto HTTP. `AUTO_HTTP_FALLBACK` in `WapFireApi`
  switches to silent fallback if you prefer convenience.
* All clients of one device (screen, background monitor) now follow the same remembered transport.

## 4.1.66
* One SSL context per pinned certificate is reused for all requests, so the TLS session cache works and later requests
  resume the earlier session (one round trip, far cheaper for the ESP32 than a full handshake). Previously every request
  created a new context and therefore always did a full handshake.
