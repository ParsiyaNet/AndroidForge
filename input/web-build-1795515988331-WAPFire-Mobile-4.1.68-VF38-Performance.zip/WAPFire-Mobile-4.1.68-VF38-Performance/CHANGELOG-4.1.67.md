# 4.1.67 – VF38 Performance Optimized compatibility

* Use the firmware version already included in `/api/status` during sign-in and remembered-session restore, avoiding a separate `/api/firmware_info` round trip on startup. The detailed firmware-info endpoint remains available in Advanced Settings.
* Publish `/api/status` to the dashboard before requesting chart data, so live status is not held behind the second TLS request.
* Keep status polling at its existing 3-second cadence while refreshing chart history every 6 seconds. The manual Refresh action still fetches the chart immediately.
* Preserve the sequential, close-after-request transport required by the VF38 TLS front-end; no unsafe parallel requests or keep-alive assumption was introduced.
* No UI layout, RF monitoring, authentication, certificate pinning, or settings behavior changes.
