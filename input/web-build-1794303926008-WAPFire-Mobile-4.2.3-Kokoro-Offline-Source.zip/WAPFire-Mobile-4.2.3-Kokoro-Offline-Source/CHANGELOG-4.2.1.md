# WAPFire Mobile 4.2.1

## Assistant voice
- Replaced Android system `TextToSpeech` with bundled Sherpa-ONNX Offline TTS and Kokoro `kokoro-en-v0_19`.
- Fixed the voice to `af_bella` (speaker ID 1), English-only; Persian UI text is not sent to speech.
- The Kokoro model, tokens, voices and eSpeak data are embedded as APK assets at build time. App runtime speech is fully offline and does not ask the user to install voices in Android Settings.
- Voice synthesis runs off the UI thread and streams 24 kHz mono PCM through `AudioTrack`.
- Live2D mouth opening now follows the actual audio RMS envelope.

## Character motion
- Enabled Live2D pointer/touch look tracking.
- Wired the model-authored `TapBody` motion to taps.
- Added low-amplitude, slow idle eye/head drift while keeping the existing Cubism idle motion, blink and physics systems intact.
- Kept all existing Nara/Hiyori character assets and state poses.

## Build note
The first build downloads the official Kokoro English model archive (the ONNX model itself is about 330 MB) and embeds it in the APK. The build machine therefore needs GitHub access and a `tar` executable. The installed app does not need network access for voice synthesis. Sherpa-ONNX Android runtime: 2.0.1.
