package io.wapfire.mobile.ui.screens

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import java.io.File
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

/**
 * 4.2.1: fully bundled, offline English speech using Sherpa-ONNX Kokoro.
 * Speaker ID 1 is af_bella. No Android TextToSpeech service or downloaded phone voice is used.
 * Synthesis and playback run on a dedicated worker; mouth level follows real audio RMS.
 */
internal class AssistantVoice(
    context: Context,
    private val onProgress: (speaking: Boolean, mouthLevel: Float) -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "WAPFire-Kokoro-TTS").apply { isDaemon = true }
    }
    private val generation = AtomicLong(0L)

    @Volatile private var engine: OfflineTts? = null
    @Volatile private var activeTrack: AudioTrack? = null
    @Volatile private var closed = false

    fun speak(text: String) {
        // Nara's voice is deliberately English-only; Persian text is never sent to Kokoro.
        val source = text.trim()
        // Reject non-English letters, but normalize typographic punctuation used by the
        // English UI copy (for example the ellipsis and non-breaking hyphen in Wi-Fi).
        if (closed || source.isBlank() || source.any { it.isLetter() && it.code > 0x7f }) return
        val spoken = source
            .replace("…", "...")
            .replace("‑", "-")
            .replace("–", "-")
            .replace("—", "-")
            .replace("’", "'")
            .replace("“", "\"")
            .replace("”", "\"")
            .map { ch -> if (ch.code in 0x20..0x7e || ch == '\n' || ch == '\t') ch else ' ' }
            .joinToString("")
            .trim()
        if (spoken.isBlank() || spoken.none { it.isLetter() }) return

        val request = generation.incrementAndGet()
        // Clear the previous utterance while the next sentence is being synthesized.
        postProgress(request, false, 0f)
        try {
            worker.execute {
                try {
                    if (!isCurrent(request)) return@execute
                    val audio = getEngine().generate(spoken, sid = BELLA_SPEAKER_ID, speed = SPEECH_SPEED)
                    if (!isCurrent(request) || audio.samples.isEmpty() || audio.sampleRate <= 0) return@execute
                    play(audio.samples, audio.sampleRate, request)
                } catch (error: Throwable) {
                    if (isCurrent(request)) {
                        Log.e(TAG, "Bundled Kokoro speech failed", error)
                        main.post {
                            if (isCurrent(request)) {
                                Toast.makeText(appContext, "Nara's built-in English voice couldn't start.", Toast.LENGTH_SHORT).show()
                            }
                        }
                        postProgress(request, false, 0f)
                    }
                }
            }
        } catch (_: RejectedExecutionException) {
            // The screen was closed between the state check and queue submission.
        }
    }

    private fun getEngine(): OfflineTts {
        engine?.let { return it }
        val modelDir = MODEL_ASSET_DIR
        // Sherpa-ONNX reads Kokoro's eSpeak data directory from a filesystem path.
        // Copy the bundled APK assets once into this app's private storage (no network/TTS settings).
        val espeakData = ensureEspeakData().absolutePath
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                kokoro = OfflineTtsKokoroModelConfig(
                    model = "$modelDir/model.onnx",
                    voices = "$modelDir/voices.bin",
                    tokens = "$modelDir/tokens.txt",
                    dataDir = espeakData
                ),
                numThreads = MODEL_THREADS,
                debug = false,
                provider = "cpu"
            ),
            maxNumSentences = 1
        )
        return OfflineTts(assetManager = appContext.assets, config = config).also { engine = it }
    }


    private fun ensureEspeakData(): File {
        val modelStorage = File(appContext.filesDir, "kokoro-en-v0_19")
        val destination = File(modelStorage, "espeak-ng-data")
        val marker = File(destination, ".wapfire-complete")
        if (marker.isFile) return destination

        modelStorage.mkdirs()
        val temporary = File(modelStorage, "espeak-ng-data.tmp")
        temporary.deleteRecursively()
        copyAssetTree(ESPEAK_ASSET_DIR, temporary)
        File(temporary, ".wapfire-complete").writeText("WAPFire Kokoro assets v1")
        destination.deleteRecursively()
        if (!temporary.renameTo(destination)) {
            temporary.copyRecursively(destination, overwrite = true)
            temporary.deleteRecursively()
        }
        if (!File(destination, ".wapfire-complete").isFile) {
            throw IllegalStateException("Could not prepare bundled Kokoro eSpeak data")
        }
        return destination
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = appContext.assets.list(assetPath)
            ?: throw IllegalStateException("Missing bundled voice asset: $assetPath")
        if (children.isEmpty()) {
            destination.parentFile?.mkdirs()
            appContext.assets.open(assetPath).use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            }
            return
        }
        destination.mkdirs()
        for (child in children) {
            copyAssetTree("$assetPath/$child", File(destination, child))
        }
    }

    private fun play(samples: FloatArray, sampleRate: Int, request: Long) {
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(0)
        val bufferBytes = maxOf(minBuffer, 4096)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufferBytes)
            .build()

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            throw IllegalStateException("Could not initialize audio output")
        }
        activeTrack = track
        try {
            if (!isCurrent(request)) return
            postProgress(request, true, 0f)
            track.play()

            // ~50 ms chunks keep lip movement in sync without overloading the WebView bridge.
            val chunkSize = maxOf(1, sampleRate / 20)
            var offset = 0
            while (offset < samples.size && isCurrent(request)) {
                val count = minOf(chunkSize, samples.size - offset)
                val pcm = ShortArray(count)
                var energy = 0.0
                for (i in 0 until count) {
                    val sample = samples[offset + i].coerceIn(-1f, 1f)
                    pcm[i] = (sample * 32767f).toInt().toShort()
                    energy += sample.toDouble() * sample.toDouble()
                }
                val written = track.write(pcm, 0, count, AudioTrack.WRITE_BLOCKING)
                if (written < 0) throw IllegalStateException("AudioTrack write failed: $written")
                if (written == 0) {
                    Thread.sleep(5L)
                    continue
                }
                if (isCurrent(request)) {
                    val rms = sqrt(energy / count.toDouble()).toFloat()
                    val mouth = ((rms - 0.012f) * 7.0f).coerceIn(0f, 1f)
                    postProgress(request, true, mouth)
                }
                offset += written
            }

            // Let the final buffered phonemes finish before the character closes her mouth.
            while (isCurrent(request) && track.playState == AudioTrack.PLAYSTATE_PLAYING &&
                track.playbackHeadPosition.toLong() < samples.size.toLong()) {
                Thread.sleep(12L)
            }
        } finally {
            runCatching { if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop() }
            runCatching { track.release() }
            if (activeTrack === track) activeTrack = null
            postProgress(request, false, 0f)
        }
    }

    fun stop() {
        val request = generation.incrementAndGet()
        runCatching { activeTrack?.pause() }
        postProgress(request, false, 0f)
    }

    fun shutdown() {
        if (closed) return
        stop()
        closed = true
        try {
            worker.execute {
                runCatching { engine?.free() }
                engine = null
            }
            worker.shutdown()
        } catch (_: RejectedExecutionException) {
            runCatching { engine?.free() }
            engine = null
        }
    }

    private fun isCurrent(request: Long): Boolean = !closed && generation.get() == request

    private fun postProgress(request: Long, speaking: Boolean, mouthLevel: Float) {
        main.post {
            // Ignore late callbacks from an interrupted utterance.
            if (generation.get() == request) onProgress(speaking, mouthLevel.coerceIn(0f, 1f))
        }
    }

    private companion object {
        const val TAG = "WAPFireAssistantVoice"
        const val MODEL_ASSET_DIR = "assistant/tts/kokoro-en-v0_19"
        const val ESPEAK_ASSET_DIR = "$MODEL_ASSET_DIR/espeak-ng-data"
        const val BELLA_SPEAKER_ID = 1 // af_bella in kokoro-en-v0_19
        const val MODEL_THREADS = 4
        const val SPEECH_SPEED = 0.96f
    }
}
