# Build fix 4.2.2 — Sherpa-ONNX Android runtime

AndroidForge 42791720007 failed while resolving `:app:debugRuntimeClasspath` because `com.github.k2-fsa:sherpa-onnx:2.0.1` is not a published Maven/JitPack module.

Sherpa-ONNX v2.0.1 publishes an official Android AAR at:

`https://github.com/k2-fsa/sherpa-onnx/releases/download/v2.0.1/sherpa-onnx-2.0.1.aar`

The Gradle build now downloads that AAR to `app/libs/` on first compile/runtime classpath resolution. It validates:

- Expected size: `49,441,341` bytes
- SHA-256: `a8d09d1d32f3eb8520482c6d3d43fae674681c5b050385967c70a3c2c9bf0ee7`
- `classes.jar` exists
- At least one ARM64 JNI `.so` exists under `jni/arm64-v8a/`

The download is build-time only. The app's Kokoro model remains packaged in APK assets for offline runtime use.
