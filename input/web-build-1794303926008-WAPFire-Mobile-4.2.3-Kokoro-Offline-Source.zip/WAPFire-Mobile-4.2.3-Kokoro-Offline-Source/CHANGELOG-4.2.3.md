# WAPFire Mobile 4.2.3

## AndroidForge Kotlin DSL build fix

- Fixed Kotlin DSL compilation errors in both build-time HTTP downloaders.
- Keep the non-null `HttpURLConnection` in a local `val` for request configuration and I/O; retain the nullable reference only for safe cleanup in `finally`.
- Preserved the verified Sherpa-ONNX v2.0.1 AAR download and Kokoro `af_bella` model packaging flow.
- App version updated to 4.2.3 (versionCode 105).
