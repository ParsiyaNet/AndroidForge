# Build fix 4.2.3 — Kotlin DSL connection smart casts

AndroidForge run 42792724364 failed during Gradle script compilation in `app/build.gradle.kts`. The Kokoro model downloader assigned a nullable `connection` variable and then dereferenced it inside a Gradle task closure. Kotlin rejected those dereferences because the mutable variable was captured by a changing closure.

Both the Sherpa-ONNX AAR downloader and Kokoro model downloader now create a non-null local `openedConnection` value and use it for configuration, response handling, and stream I/O. The nullable `connection` variable is retained only so `finally` can call `disconnect()` safely.

No runtime TTS or Live2D behavior was changed by this build-only fix.
