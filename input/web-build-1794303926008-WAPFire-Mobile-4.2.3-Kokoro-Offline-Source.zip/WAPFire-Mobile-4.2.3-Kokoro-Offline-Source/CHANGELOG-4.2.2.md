# WAPFire Mobile 4.2.2

## AndroidForge / Sherpa-ONNX build fix

- Replaced the invalid `com.github.k2-fsa:sherpa-onnx:2.0.1` dependency with the official Sherpa-ONNX v2.0.1 Android AAR release asset.
- Added on-demand AAR retrieval immediately before Android compile/runtime classpath resolution, so AndroidForge's early `map*SourceSetPaths` tasks do not resolve a missing file.
- Verified the downloaded AAR against the upstream release SHA-256 and expected byte size; checked that `classes.jar` and ARM64 JNI libraries exist before Gradle uses it.
- Preserved the existing Kokoro `af_bella` offline model packaging, English-only Nara voice, and Live2D lip-sync changes.
