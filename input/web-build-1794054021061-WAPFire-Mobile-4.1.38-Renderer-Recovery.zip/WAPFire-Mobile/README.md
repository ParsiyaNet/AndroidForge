# WAPFire Mobile 4.1.35 — Android Companion App

## 4.1.35 Overview and Assistant refinement
- The Overview character frame now matches the speech panel width, with only a 3dp gap between them.
- Sena's Overview zoom is tuned to keep the full top of her head visible.
- Corrected reversed Persian/English message selection; Persian speech is right-aligned and the header is localized.
- Removed the language switch from the Assistant screen. Use the app's regular language setting instead.
- Assistant state controls are inset farther from the screen edges and their labels follow the selected language.
- See `CHANGELOG-4.1.35.md` and `VALIDATION-4.1.35.txt` for details.


## 4.1.30 Overview assistant speech bubble
- The Overview assistant speech bubble is restored and placed in its own full-width frame below Sena, not over the character.
- The Overview keeps the same 218dp character canvas area; the card grows only to make room for the message frame.
- Live message changes and detection-driven facial reactions remain connected to the existing assistant state logic.
- The full Assistant tab's separate status/control footer is unchanged.
- See `CHANGELOG-4.1.30.md` and `VALIDATION-4.1.30.txt` for the exact changes and validation scope.

## 4.1.6 native Location Accuracy flow
- Tapping **Scan nearby devices** checks runtime Wi-Fi/location permissions first. Choosing **Only this time** remains supported.
- On Google Play services devices, `SettingsClient` requests the standard Android/Google Location Accuracy resolution prompt (the system dialog with **No thanks** / **Turn on**).
- After the user accepts, WAPFire re-checks the settings and automatically resumes the pending nearby-device scan.
- Canceling the prompt never starts a scan. Devices without a usable Google Play services resolution retain the Android Location Settings fallback.
- This is a settings check only: WAPFire does not request, collect, or store a GPS coordinate. Manual IP entry remains available.

# Background + foreground Detection Breakdown Alerts

The seven Detection Breakdown security notifications now work in both modes:

- **While the app is open:** the Activity polls `/api/status` every 3–5 seconds and posts detection notifications even when **Settings → Background Alerts** is OFF. This foreground-only path pauses when the app leaves the foreground.
- **When the app is in the background or closed:** switch **Settings → Background Alerts** ON to run the optional connected-device Foreground Service. Android keeps its required low-priority silent service notification visible while it runs.

Both paths share one notification center and one persisted Detection Breakdown counter baseline, and the service pauses its own polling while the Activity is resumed. This avoids concurrent requests and duplicate alerts.

## Alert categories

Only these seven `/api/status` Detection Breakdown counters can notify: Auth Attack, Deauth Attack, Deauth Airplay, WPS Pixie Reaver, WPS Pixie Bully, Evil Twin, and WPA Wrong Password. **WPA Correct Password is excluded.** The Events timeline and `/api/logs` do not create notifications. A first response establishes a silent baseline; only later counter increases generate alerts.

Android 13+ notification permission is requested independently for foreground alerts. If permission is denied or notifications are disabled in Android settings, Android will suppress the alerts.

## Quick start

1. For nearby Wi-Fi discovery, follow `QUICKSTART-4.1.6-FA.md`; the app uses the native Location Accuracy resolution prompt when Google Play services is available.
2. Install/build the app and sign in to WAPFire once.
2. Grant Android notification permission so detection alerts can appear while the app is open.
3. To receive alerts after leaving/closing the app, also enable **Settings → Background Alerts**. Leave it OFF when you only want alerts while using the app.
4. For reliable background monitoring, open **Battery settings** from that Settings card and choose Unrestricted / Don't optimize where available.

## Validation scope

See `VALIDATION-4.1.6.txt` for the checks actually executed. Full Gradle/APK build and physical phone + VF38 runtime validation still require Android SDK Platform 35/JDK 17/Gradle 8.9 and a device.

## Base architecture

The 4.0.0 source split the app into application/UI, model, networking, and credential-storage modules while preserving the 3.2.13 workflows and encrypted credential format. The app ID remains `io.wapfire.mobile`, minimum Android remains API 29, and no BLE transport or firmware source is included.
