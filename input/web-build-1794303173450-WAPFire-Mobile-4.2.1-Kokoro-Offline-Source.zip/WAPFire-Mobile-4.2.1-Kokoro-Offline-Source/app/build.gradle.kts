import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "io.wapfire.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.wapfire.mobile"
        minSdk = 29
        targetSdk = 35
        versionCode = 103
        versionName = "4.2.1"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    androidResources {
        // ONNX must remain an uncompressed APK asset so AssetManager can map it efficiently.
        noCompress += "onnx"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.gms:play-services-location:21.4.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.github.k2-fsa:sherpa-onnx:2.0.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// WAPFire 4.1.50: fetch the selected AndroidForge character package at build time.
// Source: https://github.com/ParsiyaNet/AndroidForge/blob/main/v06_clean.livliv
// The .livliv archive is embedded in the APK; runtime remains offline.
val downloadV06CleanCharacter by tasks.registering {
    val modelAsset = file("src/main/assets/assistant/characters/v03.livliv")
    val previewDir = file("src/main/assets/assistant/characters/v03")
    val expectedGitBlobSha1 = "112bbede0967362103ec297a368b881531bf00c5"
    val sourceUrl = "https://raw.githubusercontent.com/ParsiyaNet/AndroidForge/main/v06_clean.livliv"

    outputs.files(modelAsset, File(previewDir, "cover.webp"), File(previewDir, "avatar.webp"))
    outputs.upToDateWhen { false }

    doLast {
        fun gitBlobSha1(file: File): String {
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
            file.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
            return digest.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
        }

        modelAsset.parentFile.mkdirs()
        previewDir.mkdirs()
        val tempModel = File(modelAsset.parentFile, "v06-clean.download.livliv")
        var lastFailure: Exception? = null
        var downloaded = false

        for (attempt in 1..3) {
            var activeConnection: HttpURLConnection? = null
            try {
                val connection = URL(sourceUrl).openConnection() as HttpURLConnection
                activeConnection = connection
                connection.connectTimeout = 30000
                connection.readTimeout = 120000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "WAPFire-AndroidForge/4.1.50")
                connection.setRequestProperty("Accept", "application/octet-stream")
                val status = connection.responseCode
                if (status != HttpURLConnection.HTTP_OK) {
                    throw IOException("HTTP $status from $sourceUrl")
                }
                connection.inputStream.use { input ->
                    tempModel.outputStream().use { output -> input.copyTo(output) }
                }

                val actualSha = gitBlobSha1(tempModel)
                if (actualSha != expectedGitBlobSha1) {
                    throw GradleException("AndroidForge v06_clean.livliv changed: expected $expectedGitBlobSha1, received $actualSha")
                }

                val entries = linkedSetOf<String>()
                ZipFile(tempModel).use { archive ->
                    archive.entries().asSequence().filterNot { it.isDirectory }.forEach { entry ->
                        val name = entry.name.replace('\\', '/')
                        if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) {
                            throw GradleException("Unsafe path in v06_clean.livliv: ${entry.name}")
                        }
                        entries.add(name)
                    }
                    if (entries.none { it.substringAfterLast('/') == "model.json" }) {
                        throw GradleException("v06_clean.livliv does not contain model.json")
                    }
                    if (entries.none { it.substringAfterLast('/') == "avatar.webp" }) {
                        throw GradleException("v06_clean.livliv does not contain avatar.webp")
                    }
                    val imageCount = entries.count { it.substringAfterLast('.').lowercase() in setOf("webp", "png", "jpg", "jpeg") }
                    if (imageCount < 10) throw GradleException("v06_clean.livliv image set looks incomplete ($imageCount image files)")

                    listOf("cover.webp", "avatar.webp").forEach { wanted ->
                        val entry = archive.entries().asSequence().firstOrNull { !it.isDirectory && it.name.substringAfterLast('/') == wanted }
                        if (entry != null) {
                            val destination = File(previewDir, wanted)
                            archive.getInputStream(entry).use { input ->
                                destination.outputStream().use { output -> input.copyTo(output) }
                            }
                        }
                    }
                }

                Files.move(tempModel.toPath(), modelAsset.toPath(), StandardCopyOption.REPLACE_EXISTING)
                downloaded = true
                logger.lifecycle("Downloaded and verified AndroidForge v06_clean.livliv (Git blob SHA-1 $actualSha). Character assets are embedded; runtime remains offline.")
                break
            } catch (error: Exception) {
                lastFailure = error
                tempModel.delete()
                logger.warn("AndroidForge v06_clean.livliv download attempt $attempt failed: ${error.message}")
            } finally {
                activeConnection?.disconnect()
            }
        }
        tempModel.delete()
        if (!downloaded) {
            throw GradleException("Could not download and package AndroidForge v06_clean.livliv. Check GitHub access from the build runner.", lastFailure)
        }
    }
}



// Kokoro is downloaded only by the build, then embedded into the APK assets.
// The installed app never downloads a voice and never uses Android's system TTS.
val kokoroAssetDir = file("src/main/assets/assistant/tts/kokoro-en-v0_19")
val kokoroArchive = layout.buildDirectory.file("downloads/kokoro-en-v0_19.tar.bz2")
val downloadKokoroAssets by tasks.registering {
    outputs.dir(kokoroAssetDir)
    outputs.upToDateWhen {
        File(kokoroAssetDir, "model.onnx").let { it.isFile && it.length() > 300L * 1024L * 1024L } &&
            File(kokoroAssetDir, "voices.bin").let { it.isFile && it.length() > 4L * 1024L * 1024L } &&
            File(kokoroAssetDir, "tokens.txt").let { it.isFile && it.length() > 500L } &&
            File(kokoroAssetDir, "espeak-ng-data").isDirectory
    }

    doLast {
        val modelFile = File(kokoroAssetDir, "model.onnx")
        val voicesFile = File(kokoroAssetDir, "voices.bin")
        val tokensFile = File(kokoroAssetDir, "tokens.txt")
        val espeakDir = File(kokoroAssetDir, "espeak-ng-data")
        val valid = modelFile.isFile && modelFile.length() > 300L * 1024L * 1024L &&
            voicesFile.isFile && voicesFile.length() > 4L * 1024L * 1024L &&
            tokensFile.isFile && tokensFile.length() > 500L && espeakDir.isDirectory
        if (valid) {
            logger.lifecycle("Kokoro English assets already present; keeping the offline voice bundled.")
            return@doLast
        }

        val archive = kokoroArchive.get().asFile
        archive.parentFile.mkdirs()
        val extractDir = layout.buildDirectory.dir("tmp/kokoro-en-v0_19").get().asFile
        extractDir.deleteRecursively()
        extractDir.mkdirs()
        val sourceUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2"
        var lastFailure: Exception? = null
        var downloaded = false

        for (attempt in 1..3) {
            var connection: HttpURLConnection? = null
            try {
                logger.lifecycle("Downloading official Kokoro English model (about 330 MB)... attempt $attempt/3")
                connection = URL(sourceUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 30000
                connection.readTimeout = 300000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "WAPFire-Mobile/4.2.1")
                connection.setRequestProperty("Accept", "application/octet-stream")
                val status = connection.responseCode
                if (status != HttpURLConnection.HTTP_OK) throw IOException("HTTP $status from $sourceUrl")
                connection.inputStream.use { input -> archive.outputStream().use { output -> input.copyTo(output) } }
                if (archive.length() < 100L * 1024L * 1024L) throw IOException("Kokoro archive is unexpectedly small (${archive.length()} bytes)")
                downloaded = true
                break
            } catch (error: Exception) {
                lastFailure = error
                archive.delete()
                logger.warn("Kokoro download attempt $attempt failed: ${error.message}")
            } finally {
                connection?.disconnect()
            }
        }
        if (!downloaded) throw GradleException("Could not download the official Kokoro English model. Check GitHub access from the build runner.", lastFailure)

        // Windows 10/11 and common Linux/macOS build hosts provide tar in PATH.
        val tar = ProcessBuilder("tar", "xf", archive.absolutePath, "-C", extractDir.absolutePath)
            .redirectErrorStream(true)
            .start()
        val tarOutput = tar.inputStream.bufferedReader().use { it.readText() }
        val tarExit = tar.waitFor()
        if (tarExit != 0) throw GradleException("Could not extract Kokoro archive (tar exit $tarExit): $tarOutput")

        val extractedModel = extractDir.walkTopDown().firstOrNull {
            it.isFile && it.name == "model.onnx" && it.parentFile.name == "kokoro-en-v0_19"
        } ?: throw GradleException("Kokoro archive did not contain kokoro-en-v0_19/model.onnx")
        val extractedRoot = extractedModel.parentFile
        val expected = listOf("model.onnx", "voices.bin", "tokens.txt")
        for (name in expected) {
            val source = File(extractedRoot, name)
            if (!source.isFile) throw GradleException("Kokoro model is missing $name")
            source.copyTo(File(kokoroAssetDir, name).apply { parentFile.mkdirs() }, overwrite = true)
        }
        val sourceEspeak = File(extractedRoot, "espeak-ng-data")
        if (!sourceEspeak.isDirectory) throw GradleException("Kokoro archive is missing espeak-ng-data")
        espeakDir.deleteRecursively()
        sourceEspeak.copyRecursively(espeakDir, overwrite = true)
        File(extractedRoot, "LICENSE").takeIf { it.isFile }?.copyTo(File(kokoroAssetDir, "LICENSE"), overwrite = true)

        if (modelFile.length() <= 300L * 1024L * 1024L || voicesFile.length() <= 4L * 1024L * 1024L || tokensFile.length() <= 500L) {
            throw GradleException("Kokoro files failed size validation; refusing to package an incomplete voice model")
        }
        archive.delete()
        extractDir.deleteRecursively()
        logger.lifecycle("Kokoro model packaged: speaker af_bella (sid=1), English-only, offline at runtime.")
    }
}


tasks.named("preBuild").configure {
    dependsOn(downloadV06CleanCharacter, downloadKokoroAssets)
}

