# WAPFire Mobile 4.4.2 — On-device text-to-motion

- Adds SprongMotion-14M 1.1.0 as a pinned Android NDK/CMake native CPU runtime.
- Downloads the 33.3 MB GGUF model on first use, verifies its SHA-256, and stores it in app-private files for later offline use.
- Generates 22-joint motion clips from English prompts and retargets local joint quaternions to the existing Nara VRM humanoid rig.
- Replaces autonomous procedural arm gestures with model-generated arm/body motion; preserves VRM facial expressions, eye gaze and fingers.
- Idle/scanning loops compare two deterministic seeds and select the lower arm-activity candidate to reduce unexplained raised hands.
- One-shot event clips crossfade into a relaxed looping follow-up.
- Model weights are not bundled in the APK; the first successful download requires internet.
