#include <jni.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sprongmotion.h"

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
} json_buffer;

static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;
static sm_model g_model;
static char *g_model_path;

static bool reserve(json_buffer *b, size_t extra) {
    if (extra > SIZE_MAX - b->length - 1) return false;
    const size_t need = b->length + extra + 1;
    if (need <= b->capacity) return true;
    size_t cap = b->capacity ? b->capacity : 4096;
    while (cap < need) {
        if (cap > SIZE_MAX / 2) { cap = need; break; }
        cap *= 2;
    }
    char *next = (char *)realloc(b->data, cap);
    if (!next) return false;
    b->data = next;
    b->capacity = cap;
    return true;
}

static bool appendf(json_buffer *b, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    va_list copy;
    va_copy(copy, ap);
    const int n = vsnprintf(NULL, 0, fmt, copy);
    va_end(copy);
    if (n < 0 || !reserve(b, (size_t)n)) { va_end(ap); return false; }
    (void)vsnprintf(b->data + b->length, b->capacity - b->length, fmt, ap);
    va_end(ap);
    b->length += (size_t)n;
    return true;
}

static char *error_json(const char *message) {
    json_buffer b = {0};
    if (!appendf(&b, "{\"error\":\"")) return NULL;
    const char *s = message ? message : "Unknown native motion error";
    for (; *s; ++s) {
        if (*s == '"' || *s == '\\') {
            if (!appendf(&b, "\\%c", *s)) goto fail;
        } else if (*s == '\n' || *s == '\r') {
            if (!appendf(&b, " ")) goto fail;
        } else if ((unsigned char)*s >= 0x20) {
            if (!appendf(&b, "%c", *s)) goto fail;
        }
    }
    if (!appendf(&b, "\"}")) goto fail;
    return b.data;
fail:
    free(b.data);
    return NULL;
}

static bool load_model_locked(const char *path) {
    if (g_model_path && strcmp(g_model_path, path) == 0 && sm_is_model_valid(g_model)) return true;
    if (sm_is_model_valid(g_model)) sm_unload_model(g_model);
    free(g_model_path);
    g_model_path = NULL;
    memset(&g_model, 0, sizeof(g_model));

    // Two worker threads avoid oversubscribing older Android CPUs.
    sm_set_thread_count(2);
    g_model = sm_load_model(path);
    if (!sm_is_model_valid(g_model)) return false;
    const size_t path_size = strlen(path) + 1u;
    g_model_path = (char *)malloc(path_size);
    if (g_model_path) memcpy(g_model_path, path, path_size);
    if (!g_model_path) {
        sm_unload_model(g_model);
        memset(&g_model, 0, sizeof(g_model));
        return false;
    }
    if (g_model.joint_count != 22 || !g_model.joint_names || !g_model.joint_parents) {
        sm_unload_model(g_model);
        free(g_model_path);
        g_model_path = NULL;
        memset(&g_model, 0, sizeof(g_model));
        return false;
    }
    return true;
}

static int find_joint(const sm_model *model, const char *name) {
    for (int i = 0; i < model->joint_count; ++i)
        if (model->joint_names[i] && strcmp(model->joint_names[i], name) == 0) return i;
    return -1;
}

/* Idle/scanning clips must not randomly lift the arms. Compare two deterministic seeds and
   keep the candidate with the least shoulder/elbow/wrist rotation away from neutral. */
static double arm_activity_score(sm_motion motion, const sm_model *model) {
    static const char *const names[] = {
        "l_shoulder", "r_shoulder", "l_elbow", "r_elbow", "l_wrist", "r_wrist"
    };
    static const double weights[] = {1.0, 1.0, 0.65, 0.65, 0.25, 0.25};
    int indices[sizeof names / sizeof names[0]];
    for (size_t i = 0; i < sizeof names / sizeof names[0]; ++i)
        indices[i] = find_joint(model, names[i]);
    double score = 0.0;
    size_t samples = 0;
    for (int frame = 0; frame < motion.frame_count; ++frame) {
        for (size_t k = 0; k < sizeof indices / sizeof indices[0]; ++k) {
            const int joint = indices[k];
            if (joint < 0) continue;
            const float *q = motion.rotations + ((size_t)frame * (size_t)model->joint_count + (size_t)joint) * 4u;
            const double w = fmin(1.0, fabs((double)q[3]));
            const double angle = 2.0 * acos(w);
            score += weights[k] * angle * angle;
            ++samples;
        }
    }
    return samples ? score / (double)samples : HUGE_VAL;
}

JNIEXPORT jstring JNICALL
Java_io_wapfire_mobile_ui_screens_SprongMotionNative_nativeGenerateMotion(
        JNIEnv *env, jclass clazz, jstring model_path, jstring prompt,
        jfloat seconds, jint seed, jboolean loop) {
    (void)clazz;
    if (!model_path || !prompt) return (*env)->NewStringUTF(env, "{\"error\":\"Missing model path or prompt\"}");

    const char *path = (*env)->GetStringUTFChars(env, model_path, NULL);
    const char *text = (*env)->GetStringUTFChars(env, prompt, NULL);
    if (!path || !text) {
        if (path) (*env)->ReleaseStringUTFChars(env, model_path, path);
        if (text) (*env)->ReleaseStringUTFChars(env, prompt, text);
        return NULL;
    }

    pthread_mutex_lock(&g_mutex);
    if (!load_model_locked(path)) {
        char *err = error_json(sm_get_error()[0] ? sm_get_error() : "Could not load SprongMotion model");
        pthread_mutex_unlock(&g_mutex);
        (*env)->ReleaseStringUTFChars(env, model_path, path);
        (*env)->ReleaseStringUTFChars(env, prompt, text);
        jstring result = (*env)->NewStringUTF(env, err ? err : "{\"error\":\"Model load failed\"}");
        free(err);
        return result;
    }

    sm_options options = sm_default_options(g_model);
    options.seconds = seconds < 0.5f ? 0.5f : (seconds > 10.0f ? 10.0f : seconds);
    options.seed = seed < 0 ? -seed : seed;
    options.steps = 8;
    options.residual_layers = 4;
    options.foot_lock = true;
    options.in_place = true;
    options.loop = loop == JNI_TRUE;

    sm_motion motion = sm_generate_motion_ex(g_model, text, options);
    if (loop == JNI_TRUE && sm_is_motion_valid(motion)) {
        const int original_seed = options.seed;
        options.seed = original_seed > 2147378918 ? 1 : original_seed + 104729;
        sm_motion alternate = sm_generate_motion_ex(g_model, text, options);
        options.seed = original_seed;
        if (sm_is_motion_valid(alternate)) {
            if (arm_activity_score(alternate, &g_model) < arm_activity_score(motion, &g_model)) {
                sm_unload_motion(motion);
                motion = alternate;
            } else {
                sm_unload_motion(alternate);
            }
        }
    }
    if (!sm_is_motion_valid(motion)) {
        char *err = error_json(sm_get_error()[0] ? sm_get_error() : "Motion generation failed");
        pthread_mutex_unlock(&g_mutex);
        (*env)->ReleaseStringUTFChars(env, model_path, path);
        (*env)->ReleaseStringUTFChars(env, prompt, text);
        jstring result = (*env)->NewStringUTF(env, err ? err : "{\"error\":\"Motion generation failed\"}");
        free(err);
        return result;
    }

    json_buffer b = {0};
    bool ok = appendf(&b, "{\"fps\":%d,\"frameCount\":%d,\"jointCount\":%d,\"jointNames\":[",
                      motion.fps, motion.frame_count, g_model.joint_count);
    for (int j = 0; ok && j < g_model.joint_count; ++j) {
        const char *name = g_model.joint_names[j] ? g_model.joint_names[j] : "joint";
        ok = appendf(&b, "%s\"%s\"", j ? "," : "", name);
    }
    if (ok) ok = appendf(&b, "],\"jointParents\":[");
    for (int j = 0; ok && j < g_model.joint_count; ++j)
        ok = appendf(&b, "%s%d", j ? "," : "", g_model.joint_parents[j]);
    if (ok) ok = appendf(&b, "],\"rotations\":[");
    const size_t rotation_count = (size_t)motion.frame_count * (size_t)g_model.joint_count * 4u;
    for (size_t i = 0; ok && i < rotation_count; ++i) {
        const float value = motion.rotations[i];
        ok = isfinite(value) && appendf(&b, "%s%.7g", i ? "," : "", (double)value);
    }
    if (ok) ok = appendf(&b, "],\"rootY\":[");
    for (int frame = 0; ok && frame < motion.frame_count; ++frame) {
        const float y = motion.root ? motion.root[(size_t)frame * 3u + 1u] : 0.0f;
        ok = isfinite(y) && appendf(&b, "%s%.7g", frame ? "," : "", (double)y);
    }
    if (ok) ok = appendf(&b, "]}");

    sm_unload_motion(motion);
    pthread_mutex_unlock(&g_mutex);
    (*env)->ReleaseStringUTFChars(env, model_path, path);
    (*env)->ReleaseStringUTFChars(env, prompt, text);

    if (!ok) {
        free(b.data);
        b.data = error_json("Not enough memory to serialize generated motion");
    }
    if (!b.data) return (*env)->NewStringUTF(env, "{\"error\":\"Native motion serialization failed\"}");
    jstring result = (*env)->NewStringUTF(env, b.data);
    free(b.data);
    return result;
}
