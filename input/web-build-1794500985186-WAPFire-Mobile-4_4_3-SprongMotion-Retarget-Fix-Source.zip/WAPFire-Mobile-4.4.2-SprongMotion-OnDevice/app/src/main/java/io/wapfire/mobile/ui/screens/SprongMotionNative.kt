package io.wapfire.mobile.ui.screens

/** JNI entry for the pinned SprongMotion 1.1.0 CPU runtime. */
internal object SprongMotionNative {
    init {
        System.loadLibrary("wapfire_motion")
    }

    @JvmStatic
    external fun nativeGenerateMotion(
        modelPath: String,
        prompt: String,
        seconds: Float,
        seed: Int,
        loop: Boolean
    ): String
}
