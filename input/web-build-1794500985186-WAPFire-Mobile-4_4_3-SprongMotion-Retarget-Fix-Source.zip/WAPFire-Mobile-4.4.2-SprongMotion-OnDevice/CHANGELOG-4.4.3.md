# WAPFire Mobile 4.4.3 — VRM Retarget Stability Fix

- Capture the immutable normalized VRM bind/rest pose immediately after humanoid calibration and before the render loop or pose engine starts.
- Build the SprongMotion retarget rig only from that saved bind pose; never sample a live idle or gesture frame as a rest transform.
- Clamp excessive generated joint deltas per humanoid bone to prevent extreme rotations from folding the avatar.
- Reduce root vertical displacement to a conservative 16 cm maximum.
- Preserve the 22-joint SprongMotion pipeline, CPU inference, offline-after-download model storage, and the existing facial expression/look-at engine.
- Increase Android versionCode to 109 so 4.4.3 upgrades 4.4.2.

The motion model's output still needs a physical-device visual check against Nara's specific VRM rig; no measured device FPS or final visual-quality claim is made here.
