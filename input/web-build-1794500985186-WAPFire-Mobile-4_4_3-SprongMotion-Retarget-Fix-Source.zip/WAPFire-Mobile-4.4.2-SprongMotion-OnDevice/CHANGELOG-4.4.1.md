# WAPFire Mobile 4.4.1 — Expressive natural character motion

- Expanded the Nara VRM idle behaviour with more varied, low-amplitude gaze, breathing, posture, hair-touch and stretch gestures.
- Fixed the smooth value-noise interpolation used by breathing, posture and organic secondary motion; the old interpolation collapsed to zero at each noise lattice point.
- Added distinct entrance performances: a cheerful open-arm connection celebration, a smaller one-hand password-success celebration, a disappointed head shake for a rejected password, and a defensive forward jab/guard reaction for attack detections.
- Repeated detections of the same type now replay the matching entrance animation instead of being ignored while the state string remains unchanged.
- Added weighted event selection that prevents the same idle gesture from being selected twice in a row.
- Preserved the existing Nara VRM model, three.js renderer, local/offline asset setup, and Android dashboard event-counter source.
