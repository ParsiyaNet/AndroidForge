# Third-party motion engine notice

WAPFire Mobile 4.4.2 integrates SprongMotion runtime 1.1.0 from Seger Endendijk, pinned to commit `e11fe9ae04cefdf964345670eea0427e4d0049a3`. The Android build fetches the upstream C source at that exact commit with CMake FetchContent.

The model file `SprongMotion-14M-v1.0-Q8_0.gguf` is fetched on first use from the official Hugging Face repository. Expected size: 33,337,824 bytes. SHA-256: `68fbd311a0d7d75f60508b35254171583c85880e7e124140457b57ac84c5de9d`. It is verified before being cached in private app storage.

The upstream runtime and model are published under Apache-2.0. Model card: https://huggingface.co/SegerEnd/SprongMotion-14M. Runtime: https://github.com/SegerEnd/sprongmotion-runtime. The model publisher requests that SprongMotion not be used for military, warfare, nuclear or espionage purposes; follow the upstream model card and bundled third-party notices.

The model produces English-prompted motion for a 22-joint human skeleton at 20 FPS. It has no finger joints. VRM face expressions, eye gaze and finger posing remain handled by WAPFire's existing pose engine.
