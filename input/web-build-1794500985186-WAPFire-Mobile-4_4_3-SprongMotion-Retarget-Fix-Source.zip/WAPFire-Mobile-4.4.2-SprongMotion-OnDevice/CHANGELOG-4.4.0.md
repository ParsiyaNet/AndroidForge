# WAPFire Mobile 4.4.0 — natural character motion

Problem reported: only the character's movement was not natural, it kept repeating one thing.

## Why it looked robotic (measured on 4.3.0)
- Every state was ONE fixed pose plus a few sine waves with fixed periods. The head-yaw signal of 4.3.0 repeats perfectly
  (autocorrelation 1.00 at 12 s in idle / setup / offline, 15 s in scanning) — the same loop forever.
- Gestures (nod, wave, hop, startle) played once when a state began and never again, so after ~2 s the character froze.
- The head never nodded or tilted by itself (pitch standard deviation 0.00° in idle); hips, upper chest, shoulders, wrists and
  thumbs never moved; fingers were poker-straight.
- Blends were a plain exponential lerp: no inertia, no overshoot, every joint arriving at the same moment.
- Eye pitch was inverted (offline looked up, connecting looked down) and the eye movement asked of three-vrm was ~10x too small to see
  (this model maps 90° of lookAt input to only 8-12° of eye rotation).
- Angry used a 6 Hz "tremor" (looked like shivering, not anger).

## What 4.4.0 does (vrm/vrm-pose.js rewritten, vrm/vrm.js updated)
1. **Layered motion, all randomised** — breathing (asymmetric inhale/exhale, rate and depth drift, occasional sigh), slow weight
   shifting (hips / spine / shoulders counter-rotate), smooth organic noise on head, neck, torso, arms, wrists, fingers.
   Noise uses incommensurate rates, so it never loops (autocorrelation peak 0.17-0.40 in every state, vs 1.00 before).
2. **Gaze director** — eyes saccade first, the head follows a moment later, eyes counter-rotate while the head catches up.
   Each state has its own way of looking: viewer (eye contact + glances), sweep (scanning), think (looks up/aside while thinking),
   down (offline), worry, dart (warning), lock (angry glare, snaps to the side and back).
3. **Three independent event slots (body / arms / face)** with a weighted menu per state and random amplitude, duration and side:
   nod, tilt, shrug, sigh, lean, neck roll, giggle, hop, bounce, startle, flinch, head shake, scoff, lunge, collapse, hand fidget,
   hand adjust, wave, beckon, cheer pump, chin tap, hand wringing, fist clench, smile, smirk, curious brow, grin, worry, glare.
   The same gesture never plays twice in a row; the enter gesture of each state (hop, startle, wave...) still plays once.
4. **Under-damped springs on every channel** — the head lags and overshoots slightly, hips are heavy, hands are light.
   Alarm states react faster, offline slower.
5. **Natural blinking** — random interval (state dependent), double blinks, blink on big gaze shifts, eyelids follow gaze pitch.
6. **Hands** — relaxed finger curl gradient (little finger curls most), independent finger drift, thumbs tuck into fists,
   wrist flex and forearm twist.
7. **Poses re-aimed with a screen probe** (`window.wapfireProbe`): connecting = hand at the chin, success = hands up beside the face,
   password_warning = hands at the chest, angry = lowered fists, wave/beckon stay inside the framed picture.
8. **No more tremor**; angry is heavy controlled breathing, lowered head, glare from under the brows, slow scoffs and side glances.
9. **Same state again never restarts its gestures** (guard in `showState`).
10. **Smoother frames on weak phones** — render capped at ~60 fps, and if the average frame time stays above ~26 ms the render
    resolution is lowered once or twice (choppy animation never looks natural).
11. The axis signs (pitch, yaw, roll, hips x/z, arms) are all measured at runtime. Measured on this model: pitch -1, yaw +1, roll -1.

## Developer aids (browser console / DevTools remote debugging)
- `wapfireTrigger('arm','wave')` plays one gesture now (slots: body, arm, face).  `wapfireMotionInfo()` shows the running events and gaze target.
- `wapfireProbe('R', down, fwd, elbowF, elbowU)` returns where the hand lands on screen (-1..1).

## Build
- The four pinned library files (three@0.170.0, @pixiv/three-vrm@3.3.3) are now INCLUDED in `assets/assistant/vrm/lib/`, so the
  build no longer needs internet for them (`fetchVrmLibs` skips files that exist).
- versionCode/versionName: 105 / 4.4.0.

## Verified here
- The real page (three.js + three-vrm + nara.vrm) was rendered in headless Chromium (software WebGL): all ten states, gestures, compact and
  full framing, no page errors, state switching, 31 different state/gesture combinations seen in 40 s.
- Pose engine in node: no NaN, 15-120 fps stable, smooth state switches, non-periodic.
- NOT verified: a real Android build / on-device feel (no Android SDK in the packaging environment). If something looks too strong or too weak
  on the phone, the amounts are at the top of `vrm-pose.js` (BEHAVIOUR: `noise`, `breath`, `shift`, `speed`).
