# WAPFire Mobile 3.0.9 — Native Glass Control Center

## 3.0.6 visual theme selector refinement
- Replaced the moon/sun Unicode text characters with actual vector-style Compose Canvas icons.
- Moon is a crescent drawn from layered circles; sun is drawn from a center disc and eight rays.
- Both halves remain permanently visible in the split Dark/Light control, with the active half highlighted.

## 3.0.4 visual telemetry refinement
- The first screen title is **WAPFire**; the same sun/moon theme control is available on Discovery, Login, Setup and Control pages.
- Sign in includes an optional **Remember password** checkbox. A saved password is AES-GCM encrypted with an Android Keystore key and is bound to the device host. Unchecking it deletes the saved credential. Android backup is disabled for the app.
- Detection Breakdown always renders all eight VF38 detection categories, including zero-count rows.
- Network Telemetry shows traffic frames, packets, Target AP RX, and filtered frames. Free heap remains in Device Status, not Network Telemetry.
- WS2812 custom color controls are shown only for effects that actually consume them. Secondary color is only shown for Alternate.

Standalone native Android companion for the modular WAPFire VF38 firmware. The interface is Kotlin + Jetpack Compose. It does not embed the firmware WebUI and does not use a WebView.

## App structure

The main navigation has four destinations: **Overview**, **Clients**, **Events**, and **Settings**. Target selection and clearing are grouped at the top of Settings under **Monitoring & Target**. Device settings are organized into expandable functional groups instead of separate tabs.

The visual system uses layered translucent surfaces, softly lit ambient background elements, glass-like borders, restrained gradients, consistent spacing, and both light and dark themes. A single compact sun/moon action button matching the original 3.0.3 Welcome Back control is shared across all main screens. English and Persian RTL layouts are supported.

## Exact event labels

The app displays these exact names as the primary event titles:

- Auth Attack
- Deauth Attack
- Deauth Airplay
- WPS Pixie Reaver
- WPS Pixie Bully
- Evil Twin
- WPA Correct Password
- WPA Wrong Password

Raw firmware identifiers are not used as primary titles. Correct/wrong password entries are driven by the firmware's actual `correct_password` and `wrong_password` event types. RF detections are resolved from the actual event label/message/details.

## Firmware capabilities exposed by the native app

| Capability | Firmware API / action | App location |
|---|---|---|
| Discovery, login, initial setup, logout | `/login`, `/logout`, `/api/status`, setup via `/api/settings` | Connection / Setup / Session |
| Live status and RF telemetry | `/api/status`, `/api/chart_data` | Overview |
| Tracked clients | `/api/tracked_clients` | Clients |
| Event timeline and clearing | `/api/logs`, `/api/clear_logs` | Events |
| Target scan, exact selection, persistent save, clear | `/api/scan`, `/api/select_target`, `/api/save_target` | Settings → Monitoring & Target |
| Self-protect, automatic channel tracking | `/api/settings` | Settings → Protection |
| Status LED, smart LED, sound, SoftAP | `/api/settings` | Settings → Device Feedback / Connectivity |
| Beacon mode, AP SSID/password, admin password | `/api/mobile_settings`, `/api/settings` | Settings → Device security |
| Ethernet DHCP/static IP/DNS/gateway/subnet/hostname and diagnostics | `/api/ethernet_settings` | Settings → Network · Ethernet |
| HTTP event forwarding and test event | `/api/http_api_settings`, `/api/test_http_api` | Settings → Network · HTTP event API |
| NTP server, interval, timezone list, sync now, phone-time sync | `/api/ntp_settings`, `/api/ntp_sync_now`, `/api/ntp_sync_browser` | Settings → Time |
| MikroTik RouterOS integration and connection test | `/api/mikrotik_settings`, `/api/test_mikrotik` | Settings → MikroTik |
| WS2812 effect, colors, speed and brightness | `/api/led_settings` | Settings → Lighting |
| Client-initiated disconnect LED alert | `/api/disconnect_led_settings` | Settings → Lighting |
| Weekly scheduler and quiet-hours action | `/api/schedule_settings` | Settings → Automation |
| Deauth whitelist, up to 32 MAC entries | `/api/whitelist` | Settings → Access control |
| Device language | `/api/language` | Settings → App experience |
| Backup, restore and backup metadata | `/api/backup_settings`, `/api/restore_settings`, `/api/backup_info` | Settings → Firmware / Maintenance |
| Device, chip, memory, PSRAM and build information | `/api/firmware_info` | Settings → Firmware / Maintenance |
| Manual ESP32 OTA | `/update` multipart upload, form field `firmware` | Settings → Firmware / Maintenance |
| Update capability status | `/api/check_update` | Settings → Firmware / Maintenance |
| Reboot, Wi-Fi restart, factory reset, return to setup | `/reboot`, `/wifi_restart`, `/factory_reset`, `/force_setup` | Settings → Firmware / Maintenance |

The app loads advanced configuration modules sequentially to avoid opening many simultaneous HTTP connections to the ESP32 WebServer. The advanced settings forms are not overwritten by the regular telemetry polling while the user is editing them. A failed module load is reported rather than silently replacing values with defaults.

## Firmware compatibility and security changes

The matching source is in the sibling `WAPFireVF38/` folder of the full compatibility package.

- The app uploads OTA images with the exact `firmware` multipart field expected by VF38.
- The MikroTik settings read API no longer returns the saved router password. It returns `password_set`; blank or omitted password updates preserve the stored credential.
- The original `/api/settings` endpoint remains compatible with the existing WebUI. The new authenticated `/api/mobile_settings` endpoint is a mobile-safe read endpoint and omits AP/admin passwords.
- `beacon_mode` is now included in `/api/settings` and `/api/mobile_settings` responses.
- The app includes the firmware's `/force_setup` operation.
- The supplied firmware baseline retains the verified WPA2 retry / WPA3 SAE Status Code 1 behavior and the client-originated-only disconnect LED behavior.
- The firmware build tag is exposed in `/api/firmware_info` so the installed build can be identified from the app.

## Update service note

This VF38 source has no configured online release manifest/provider. Its `/api/check_update` endpoint reports that automatic update checking is not configured. The native app states this explicitly. Manual OTA using a local ESP32 `.bin` image is implemented.

## Build requirements

- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 (wrapper)
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

Open this folder in Android Studio and run **app → Tasks → build → assembleDebug**. On Windows, run `build-apk.bat`.

Application ID: `io.wapfire.mobile`  
Version: `3.0.6` (versionCode 13)  
Minimum Android: 10 (API 29)

## Operational cautions

- Backup files contain administrator, WAPFire Wi-Fi, MikroTik and device settings. Store them privately.
- During OTA, keep the board powered. Use a firmware image built for the exact ESP32 target and matching partition layout.
- Factory reset erases saved configuration. Return to initial setup changes the configured/setup state while retaining the saved credentials and advanced settings.
- The Android app uses the device's authenticated local HTTP session. Do not expose the firmware web server to an untrusted network.


## 3.0.1 settings refinement

See `CHANGELOG-3.0.1.md` for the settings UX changes and the VF38 `WAPFIRE_BUILD_TAG` include-order correction. Beacon mode is shown as a Self-Protect-managed state, not an independent credential toggle.
