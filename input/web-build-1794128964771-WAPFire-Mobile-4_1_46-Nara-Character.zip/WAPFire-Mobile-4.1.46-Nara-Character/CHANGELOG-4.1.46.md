# WAPFire Mobile 4.1.46

## Character
- Replaced Mira (`v03`) with Nara, a custom character created with livliv.ai (`characters/nara.livliv` + `characters/nara/cover.webp`). The `.livliv` package is used exactly as downloaded.
- Removed `v03.livliv`, `v03/cover.webp` and `characters-LICENSE.md` (the featured-characters license only covered the featured models).
- Nara uses the same 1024x1536 canvas, so the 1.18 zoom and the 300dp Overview frame are unchanged.
- Renamed labels: "Nara is watching your network" / "NARA · WAPFIRE ASSISTANT" and Persian equivalents.
- Settings credit now reads "Nara · Made with LivLiv (livliv.ai)"; NOTICE.txt and ATTRIBUTION.txt describe a custom AI-generated model under the LivLiv terms (https://livliv.ai/terms).

## Known limitation
- Nara's package contains only the `smile` expression. The app asks for `shy`, `angry` and `sad` in some states; the engine ignores unknown expression ids (setExpression returns false), so in those states the face stays as it was (smile) while the motion (tilt/nod/hop/shake) still plays.

## Build metadata
- Version name: 4.1.46, version code: 87, bootstrap `assistant-preflight-4.1.46.js`.

## Verification limits
- Static checks only. No Android device/SDK here; build and check the Overview and Assistant tab on a device.
