package io.wapfire.mobile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Native HTTP client for the full WAPFire VF38 API. */
class WapFireApi(hostOrUrl: String) {
    val baseUrl: String = normalizeBase(hostOrUrl)
    @Volatile private var authCookie: String? = null

    data class Reply(val code: Int, val body: String, val cookie: String? = null)

    private fun request(
        path: String,
        method: String = "GET",
        body: String? = null,
        contentType: String? = null,
        timeoutMs: Int = 12_000
    ): Reply {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 7_000
            readTimeout = timeoutMs
            useCaches = false
            instanceFollowRedirects = false
            setRequestProperty("Accept", "application/json, text/plain, */*")
            authCookie?.let { setRequestProperty("Cookie", it) }
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType ?: "application/json; charset=utf-8")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val cookie = connection.getHeaderField("Set-Cookie")
            val stream = if (code in 200..399) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            Reply(code, text, cookie)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun login(user: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            authCookie = null
            val form = "user=${encode(user)}&pass=${encode(password)}"
            val reply = request("/login", "POST", form, "application/x-www-form-urlencoded")
            if (reply.code !in 200..299) error(reply.body.ifBlank { "Login rejected (${reply.code})" })
            val raw = reply.cookie ?: error("The device did not return an authentication session")
            val token = raw.substringBefore(';').trim()
            if (!token.startsWith("wg_auth=") || token.substringAfter('=').length < 32) {
                error("The device returned an invalid authentication session")
            }
            authCookie = token
        }
    }

    suspend fun status(): Result<JSONObject> = jsonGet("/api/status")
    suspend fun mobileSettings(): Result<JSONObject> = jsonGet("/api/mobile_settings")
    suspend fun chart(): Result<JSONObject> = jsonGet("/api/chart_data")
    suspend fun firmwareInfo(): Result<JSONObject> = jsonGet("/api/firmware_info")
    suspend fun checkUpdate(): Result<JSONObject> = jsonGet("/api/check_update")
    suspend fun backupInfo(): Result<JSONObject> = jsonGet("/api/backup_info")
    suspend fun logs(): Result<JSONArray> = arrayGet("/api/logs")
    suspend fun clients(): Result<JSONArray> = arrayGet("/api/tracked_clients")
    suspend fun ethernetSettings(): Result<JSONObject> = jsonGet("/api/ethernet_settings")
    suspend fun httpApiSettings(): Result<JSONObject> = jsonGet("/api/http_api_settings")
    suspend fun ntpSettings(): Result<JSONObject> = jsonGet("/api/ntp_settings")
    suspend fun mikrotikSettings(): Result<JSONObject> = jsonGet("/api/mikrotik_settings")
    suspend fun ledSettings(): Result<JSONObject> = jsonGet("/api/led_settings")
    suspend fun disconnectLedSettings(): Result<JSONObject> = jsonGet("/api/disconnect_led_settings")
    suspend fun scheduleSettings(): Result<JSONObject> = jsonGet("/api/schedule_settings")
    suspend fun whitelist(): Result<JSONObject> = jsonGet("/api/whitelist")
    suspend fun language(): Result<JSONObject> = jsonGet("/api/language")
    suspend fun ledMode(): Result<JSONObject> = jsonGet("/api/led_mode")

    suspend fun scan(): Result<JSONArray> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request("/api/scan", "POST", "", "application/json")
            if (r.code !in 200..299) error(r.body.ifBlank { "Network scan failed (${r.code})" })
            JSONArray(r.body)
        }
    }

    suspend fun selectTarget(ssid: String, bssid: String, channel: Int): Result<JSONObject> = jsonPost(
        "/api/select_target", JSONObject().put("ssid", ssid).put("bssid", bssid).put("channel", channel)
    )
    suspend fun saveTarget(ssid: String, bssid: String, channel: Int): Result<JSONObject> = jsonPost(
        "/api/save_target", JSONObject().put("ssid", ssid).put("bssid", bssid).put("channel", channel)
    )
    suspend fun updateSettings(values: JSONObject): Result<JSONObject> = jsonPost("/api/settings", values)
    suspend fun saveEthernet(values: JSONObject) = jsonPost("/api/ethernet_settings", values)
    suspend fun saveHttpApi(values: JSONObject) = jsonPost("/api/http_api_settings", values)
    suspend fun saveNtp(values: JSONObject) = jsonPost("/api/ntp_settings", values)
    suspend fun saveMikrotik(values: JSONObject) = jsonPost("/api/mikrotik_settings", values)
    suspend fun saveLed(values: JSONObject) = jsonPost("/api/led_settings", values)
    suspend fun saveDisconnectLed(values: JSONObject) = jsonPost("/api/disconnect_led_settings", values)
    suspend fun saveSchedule(values: JSONObject) = jsonPost("/api/schedule_settings", values)
    suspend fun saveWhitelist(values: JSONObject) = jsonPost("/api/whitelist", values)
    suspend fun setLanguage(language: String) = jsonPost("/api/language", JSONObject().put("language", language))
    suspend fun clearLogs(): Result<JSONObject> = jsonPost("/api/clear_logs", JSONObject())

    suspend fun testHttpApi(): Result<JSONObject> = jsonPost("/api/test_http_api", JSONObject())
    suspend fun testMikrotik(): Result<JSONObject> = jsonPost("/api/test_mikrotik", JSONObject())
    suspend fun syncNtpNow(): Result<JSONObject> = jsonPost("/api/ntp_sync_now", JSONObject())
    suspend fun syncNtpFromPhone(unixSeconds: Long): Result<JSONObject> = jsonPost(
        "/api/ntp_sync_browser", JSONObject().put("timestamp", unixSeconds)
    )

    suspend fun backupSettings(): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(baseUrl + "/api/backup_settings").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7_000
                readTimeout = 20_000
                useCaches = false
                authCookie?.let { setRequestProperty("Cookie", it) }
            }
            try {
                val code = connection.responseCode
                val bytes = (if (code in 200..299) connection.inputStream else connection.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
                if (code !in 200..299) error(String(bytes).ifBlank { "Backup failed ($code)" })
                // Validate the downloaded document before returning it to the document picker.
                val json = JSONObject(String(bytes, Charsets.UTF_8))
                if (json.optString("device") != "WAPFire") error("Device returned an invalid backup file")
                bytes
            } finally { connection.disconnect() }
        }
    }

    suspend fun restoreSettings(bytes: ByteArray): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val json = JSONObject(String(bytes, Charsets.UTF_8))
            if (json.optString("device") != "WAPFire" || !json.has("version")) error("This is not a valid WAPFire backup")
            val r = request("/api/restore_settings", "POST", json.toString(), timeoutMs = 25_000)
            if (r.code !in 200..299) error(httpError(r))
            JSONObject(r.body).also { if (it.has("success") && !it.optBoolean("success")) error(it.optString("message", "Restore failed")) }
        }
    }

    suspend fun uploadFirmware(filename: String, bytes: ByteArray): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (bytes.size < 1024 || bytes[0] != 0xE9.toByte()) error("Invalid ESP32 firmware image")
            val boundary = "----WAPFireNative${System.nanoTime()}"
            val header = "--$boundary\r\nContent-Disposition: form-data; name=\"firmware\"; filename=\"${safeFileName(filename)}\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray()
            val footer = "\r\n--$boundary--\r\n".toByteArray()
            val connection = (URL(baseUrl + "/update").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 180_000
                doOutput = true
                useCaches = false
                instanceFollowRedirects = false
                setRequestProperty("Accept", "text/plain, application/json")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                authCookie?.let { setRequestProperty("Cookie", it) }
                setFixedLengthStreamingMode(header.size.toLong() + bytes.size.toLong() + footer.size.toLong())
            }
            try {
                connection.outputStream.use { out ->
                    out.write(header)
                    var offset = 0
                    while (offset < bytes.size) {
                        val size = minOf(32 * 1024, bytes.size - offset)
                        out.write(bytes, offset, size)
                        offset += size
                    }
                    out.write(footer)
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) error(body.ifBlank { "Firmware update failed ($code)" })
                body.ifBlank { "Firmware uploaded. The device will reboot." }
            } finally { connection.disconnect() }
        }
    }

    suspend fun deviceAction(path: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(path in setOf("/reboot", "/wifi_restart", "/factory_reset", "/force_setup")) { "Unsupported action" }
            val r = request(path, "POST", "", "application/x-www-form-urlencoded", timeoutMs = 15_000)
            if (r.code !in 200..299 && r.code !in 300..399) error(httpError(r))
            r.body.ifBlank { "Command accepted" }
        }
    }

    suspend fun logout(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val reply = request("/logout", "POST", "", "application/x-www-form-urlencoded")
            if (reply.code !in 200..399) error(httpError(reply))
            authCookie = null
        }
    }

    private suspend fun jsonGet(path: String): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path)
            if (r.code !in 200..299) error(httpError(r))
            JSONObject(r.body)
        }
    }
    private suspend fun arrayGet(path: String): Result<JSONArray> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path)
            if (r.code !in 200..299) error(httpError(r))
            JSONArray(r.body)
        }
    }
    private suspend fun jsonPost(path: String, body: JSONObject): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val r = request(path, "POST", body.toString())
            if (r.code !in 200..299) error(httpError(r))
            JSONObject(r.body).also {
                if (it.has("success") && !it.optBoolean("success", true)) error(it.optString("message", "Operation failed"))
            }
        }
    }
    private fun httpError(reply: Reply): String = try {
        JSONObject(reply.body).optString("message").takeIf { it.isNotBlank() } ?: reply.body.take(180)
    } catch (_: Exception) { reply.body.take(180).ifBlank { "Request failed (${reply.code})" } }
    fun clearSession() { authCookie = null }
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun safeFileName(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "firmware.bin" }

    companion object {
        private fun normalizeBase(input: String): String {
            var value = input.trim().removeSuffix("/")
            if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://$value"
            return value
        }
    }
}
