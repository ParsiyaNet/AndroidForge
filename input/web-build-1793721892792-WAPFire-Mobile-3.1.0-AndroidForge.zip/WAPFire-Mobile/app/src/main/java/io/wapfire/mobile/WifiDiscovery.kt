package io.wapfire.mobile

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

 data class WifiAccessPoint(
    val ssid: String,
    val rssi: Int,
    val secured: Boolean,
    val frequency: Int
) {
    val isWapFire: Boolean get() = ssid.contains("wapfire", ignoreCase = true)
}

data class CurrentWifi(val ssid: String, val gateway: String, val localIp: String = "", val netmask: String = "")

class WifiDiscovery(context: Context) {
    private val appContext = context.applicationContext
    private val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun scan(): List<WifiAccessPoint> = withContext(Dispatchers.IO) {
        try { wifi.startScan() } catch (_: Exception) { false }
        delay(1400)
        try {
            wifi.scanResults
                .filter { it.SSID.isNotBlank() }
                .distinctBy { it.SSID }
                .sortedByDescending { it.level }
                .map {
                    val caps = it.capabilities.orEmpty()
                    WifiAccessPoint(
                        ssid = it.SSID,
                        rssi = it.level,
                        secured = caps.contains("WPA") || caps.contains("WEP") || caps.contains("SAE"),
                        frequency = it.frequency
                    )
                }
        } catch (_: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    fun current(): CurrentWifi {
        return try {
            val info = wifi.connectionInfo
            val raw = info?.ssid.orEmpty()
            val ssid = raw.removePrefix("\"").removeSuffix("\"").takeIf { it != "<unknown ssid>" }.orEmpty()
            val dhcp = wifi.dhcpInfo
            fun littleEndianIpv4(value: Int): String = if (value == 0) "" else listOf(
                value and 0xff,
                (value shr 8) and 0xff,
                (value shr 16) and 0xff,
                (value shr 24) and 0xff
            ).joinToString(".")
            CurrentWifi(
                ssid = ssid,
                gateway = littleEndianIpv4(dhcp?.gateway ?: 0),
                localIp = littleEndianIpv4(dhcp?.ipAddress ?: 0),
                netmask = littleEndianIpv4(dhcp?.netmask ?: 0)
            )
        } catch (_: Exception) { CurrentWifi("", "") }
    }

    /**
     * Discovers WAPFire WebUI hosts on the phone's current Wi-Fi subnet.
     * It only probes TCP/80 and confirms the firmware's distinctive login-page title.
     */
    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    suspend fun findWapFireOnLan(): List<String> = withContext(Dispatchers.IO) {
        val dhcp = try { wifi.dhcpInfo } catch (_: Exception) { null }
        val rawIp = dhcp?.ipAddress ?: 0
        if (rawIp == 0) return@withContext emptyList()
        val ip = Integer.reverseBytes(rawIp)
        val rawMask = dhcp?.netmask ?: 0
        val mask = if (rawMask == 0) -256 else Integer.reverseBytes(rawMask)
        var network = ip and mask
        var broadcast = network or mask.inv()
        // Avoid accidentally scanning very large corporate/VLAN subnets from a phone.
        if (broadcast - network > 512) {
            val mask24 = -256
            network = ip and mask24
            broadcast = network or mask24.inv()
        }
        val phoneIp = ip
        val candidates = (network + 1 until broadcast).filter { it != phoneIp }
        if (candidates.isEmpty()) return@withContext emptyList()

        coroutineScope {
            candidates.chunked(24).flatMap { batch ->
                batch.map { address ->
                    async(Dispatchers.IO) {
                        val host = InetAddress.getByAddress(byteArrayOf(
                            (address shr 24).toByte(),
                            (address shr 16).toByte(),
                            (address shr 8).toByte(),
                            address.toByte()
                        )).hostAddress ?: return@async null
                        try {
                            val connection = (URL("http://$host/").openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"
                                connectTimeout = 250
                                readTimeout = 250
                                instanceFollowRedirects = false
                                useCaches = false
                            }
                            val signature = try {
                                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                                    val buffer = CharArray(4096)
                                    val count = reader.read(buffer)
                                    if (count > 0) String(buffer, 0, count).lowercase() else ""
                                }
                            } finally { connection.disconnect() }
                            if (signature.contains("<title>wapfire - authentication</title>")) host else null
                        } catch (_: Exception) { null }
                    }
                }.awaitAll().filterNotNull()
            }
        }.distinct()
    }

    companion object {
        fun requiredPermissions(): Array<String> = buildList {
            add(android.Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(android.Manifest.permission.NEARBY_WIFI_DEVICES)
        }.toTypedArray()
    }
}

class WifiConnector(context: Context) {
    private val appContext = context.applicationContext
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeCallback: ConnectivityManager.NetworkCallback? = null

    fun bindToCurrentWifi(): Boolean {
        return try {
            val network = connectivity.activeNetwork ?: return false
            val caps = connectivity.getNetworkCapabilities(network) ?: return false
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return false
            connectivity.bindProcessToNetwork(network)
            true
        } catch (_: Exception) { false }
    }

    fun connect(
        ssid: String,
        password: String,
        onAvailable: (Network) -> Unit,
        onUnavailable: () -> Unit,
        onLost: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 29) {
            onUnavailable()
            return
        }
        release()
        val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (password.isNotBlank()) specBuilder.setWpa2Passphrase(password)
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specBuilder.build())
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                connectivity.bindProcessToNetwork(network)
                mainHandler.post { onAvailable.invoke(network) }
            }
            override fun onUnavailable() { mainHandler.post { onUnavailable.invoke() } }
            override fun onLost(network: Network) {
                connectivity.bindProcessToNetwork(null)
                mainHandler.post { onLost.invoke() }
            }
        }
        activeCallback = callback
        try {
            connectivity.requestNetwork(request, callback)
        } catch (_: Exception) {
            activeCallback = null
            onUnavailable()
        }
    }

    fun release() {
        try { connectivity.bindProcessToNetwork(null) } catch (_: Exception) { }
        activeCallback?.let {
            try { connectivity.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        activeCallback = null
    }
}
