# 4.1.61 — New midnight-indigo theme + liquid-glass UI (dark and light)

## Theme
- The green/teal dark theme is gone. Dark is now a deep midnight-indigo theme with a periwinkle accent;
  light is a cool-white theme with the same indigo accent, so both read as one design.
- Green / orange / red are kept ONLY as status colours (online, warning, attack), never as the theme colour.
- `Palette` gained `dark`, `onAccent` and `violet`; text on accent buttons / the brand mark follows `onAccent`.
- Status bar / navigation bar colours and the Material colour scheme (switches, text fields) follow the new palette.

## Liquid glass
- New shared `Modifier.liquidGlass(...)` (UiComponents.kt): translucent body, accent→sky light bleed,
  specular sheen, bright glint on the top edge, and a refracting rim (white top-left, tinted bottom-right).
- New `GlassBackdrop`: opaque gradient + three soft coloured lights (accent / sky / violet) that the glass picks up.
- Applied to: section cards, Settings cards, metric tiles, event cards, the floating bottom tab bar, the
  theme/language buttons, secondary buttons (primary buttons are a lit accent→sky gradient), the Overview
  status card, the character frame and speech card, and the Nara tab (close button, speech card, state chips).
- Pure Compose drawing: no extra library, no real backdrop blur (not available natively in Compose).

## Overview
- "Monitoring status" card: was a fixed dark-teal card in both themes; now themed glass with theme text colours
  (so it is light and readable in the light theme). The threat ring uses the theme's status colours.
- Character frame: was a fixed navy/blue frame; now themed glass with a soft lit pocket behind the character.
- Character WebView is transparent (native WebView background + web page), so the glass card is the frame.
  The web layer follows the app theme live (`window.wapfireSetTheme`, `?theme=`), without reloading the model.
- Selected-network glow on the discovery screen uses the theme accent instead of fixed neon blue.

## Unchanged
Character states / movement, preloading, framing, language handling, tabs, networking and monitoring logic.
