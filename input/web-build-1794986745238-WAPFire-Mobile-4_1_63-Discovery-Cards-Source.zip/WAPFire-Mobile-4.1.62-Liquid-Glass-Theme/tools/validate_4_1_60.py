#!/usr/bin/env python3
"""Source-level checks for WAPFire 4.1.60 character preload (no loading screen for Nara)."""
from pathlib import Path
import json, re, zipfile
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets/assistant"
KT = ROOT / "app/src/main/java/io/wapfire/mobile/ui"
JS = (ASSETS / "assistant-preflight-4.1.60.js").read_text(encoding="utf-8")
HTML = (ASSETS / "assistant-live.html").read_text(encoding="utf-8")
APP = (KT / "WapFireApp.kt").read_text(encoding="utf-8")
DASH = (KT / "screens/DashboardScreens.kt").read_text(encoding="utf-8")
VIEW = (KT / "screens/LivLivAssistantView.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
with zipfile.ZipFile(ASSETS / "characters/v03.livliv") as z:
    expr_ids = {e["id"] for e in json.loads(z.read("model.json"))["expressions"]}

# --- version alignment -------------------------------------------------------------------
assert "window.__wfAssistantBuildVersion = '4.1.60';" in JS
assert 'assistant-preflight-4.1.60.js?build=4.1.60' in HTML and 'content="4.1.60"' in HTML
assert 'assistant/assistant-preflight-4.1.60.js' in VIEW and 'ASSISTANT_BUILD = "4.1.60"' in VIEW
assert 'versionCode = 106' in GRADLE and 'versionName = "4.1.60"' in GRADLE

# --- cache is owned by the app root and warmed at launch ----------------------------------
assert "AssistantWebViewCache(context, isFa)" in APP, "root must own the WebView cache"
assert "assistantWebViews.warmUp(assistantStartCompact)" in APP
assert "assistantWebViews.warmUp(!assistantStartCompact)" in APP
assert "withFrameNanos" in APP, "warm-up must wait for the first frame"
assert "LocalAssistantWebViews provides assistantWebViews" in APP
assert "AssistantWebViewParking(assistantWebViews)" in APP
# the hidden host must be drawn BEFORE (under) the opaque gradient background
park_at = APP.index("AssistantWebViewParking(assistantWebViews)")
bg_at = APP.index("Brush.verticalGradient(listOf(p.bg, p.bg2, p.bg))")
assert park_at < bg_at, "parking host must sit under the opaque app background"
# ControlCenter no longer creates its own cache when the root provides one
assert "LocalAssistantWebViews.current" in DASH
assert "sharedAssistantWebViews == null" in DASH
assert not re.search(r"val assistantWebViews = remember\([^)]*\) \{ AssistantWebViewCache", DASH)

# --- startup gate + splash ----------------------------------------------------------------
assert "assistantGateDone" in APP and "7_000L" in APP
assert "StartupSplash(p, isFa, host)" in APP and "private fun StartupSplash" in APP

# --- parking / pause logic ----------------------------------------------------------------
for token in ("class AssistantParkingFrame", "override fun dispatchTouchEvent", "fun attachParkingFrame",
              "fun warmUp", "fun release", "private fun park", "var onRendererReady", "val isRendererReady",
              "if (!entry.adopted) view.onPause()", "DIAGNOSTICS_GRACE_MS", "entry.adopted = true",
              "cache.release(entry)", "fun readyState"):
    assert token in VIEW, f"missing {token}"
assert "remember(context) { AssistantParkingFrame(context) }" in VIEW, "parking frame must survive cache replacement"
assert ".loading:not(.error){display:none!important}" in HTML

# --- no regressions in earlier behaviour --------------------------------------------------
assert "packet_inactivity_ms" in (ROOT / "app/src/main/java/io/wapfire/mobile/model/AppModels.kt").read_text(encoding="utf-8")
assert "assistantEventSequence++" in DASH and "> 60_000L" in DASH
for required in ("smile", "x_expr_03637e", "x_expr_0cfa09", "x_expr_7d048e"):
    assert required in expr_ids, required
# brace balance of the three edited Kotlin files (cheap structural sanity check)
for name, src in (("WapFireApp.kt", APP), ("DashboardScreens.kt", DASH), ("LivLivAssistantView.kt", VIEW)):
    stripped = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', src)
    stripped = re.sub(r'//[^\n]*', '', stripped)
    stripped = re.sub(r'/\*.*?\*/', '', stripped, flags=re.S)
    assert stripped.count("{") == stripped.count("}"), f"unbalanced braces in {name}"
    assert stripped.count("(") == stripped.count(")"), f"unbalanced parentheses in {name}"

print("PASS: Nara WebViews are owned by the app root and warmed up right after the first frame")
print("PASS: preloading views live in a hidden, touch-proof host drawn under the opaque background")
print("PASS: views are paused once ready while parked, resumed when a screen adopts them")
print("PASS: loading/progress text is suppressed; diagnostics appear only if the character is still not ready after 4 s")
print("PASS: splash holds the control screens (max 7 s) if the character is not ready yet")
print("PASS: build metadata aligned at 4.1.60; earlier Standby/Idle and reaction logic untouched")
