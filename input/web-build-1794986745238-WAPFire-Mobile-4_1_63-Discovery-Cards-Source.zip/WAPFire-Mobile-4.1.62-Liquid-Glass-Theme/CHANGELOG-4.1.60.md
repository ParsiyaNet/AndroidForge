# 4.1.60 — Nara is preloaded; no character loading when entering the app

- The Nara WebViews are now owned by the app root (`WapFireNativeApp`) instead of `ControlCenter`.
  They are created right after the first frame and start loading while the user is still on the
  restore / discovery / sign-in screens. Previously they were created lazily the first time the
  Overview (or Nara tab) opened, so the user watched the model load.
- Preloading views live in a hidden, touch-proof host (`AssistantWebViewParking`) that is drawn
  under the opaque app background. A WebView must be attached to the window with a real size for
  LivLiv to measure its canvas and create WebGL, so merely creating it earlier would not have worked.
- The tab the user will see first (last used tab) loads first; the other one (Overview / Nara tab)
  loads right after, so switching tabs for the first time is instant too.
- Once a parked view has drawn its first frame it is paused (no battery use) and resumed the moment a
  screen shows it. Leaving a tab parks the view again instead of detaching it.
- If the user reaches the control screens before the character is ready (for example a remembered
  session restores very fast) the branded splash stays up for a short time instead of showing an
  empty/loading card. Hard limit: 7 s after launch, so a broken renderer can never block the app.
- "Preparing assistant…" / "Opening… 40%" progress texts and the web-layer "loading model" pill are
  no longer shown. Diagnostics still appear if the character is not ready 4 s after launch
  (real failures stay visible, as before).
- The cache now survives logging out and signing in again, so the character is not reloaded either.
- Unchanged: character states, Standby/Idle logic, reactions, framing, language handling
  (changing the interface language still rebuilds the character once, as before).
