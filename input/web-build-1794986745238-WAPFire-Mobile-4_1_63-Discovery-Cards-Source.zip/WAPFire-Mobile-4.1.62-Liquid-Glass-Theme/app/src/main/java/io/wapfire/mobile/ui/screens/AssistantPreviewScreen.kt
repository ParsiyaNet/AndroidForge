package io.wapfire.mobile.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import io.wapfire.mobile.model.Palette
import io.wapfire.mobile.ui.components.liquidGlass
import io.wapfire.mobile.model.tx

@Composable
internal fun AssistantPreviewScreen(
    p: Palette,
    fa: Boolean,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    embedded: Boolean = false,
    state: String = "idle"
) {
    if (embedded) {
        // Android-native controls sit outside the WebView. This avoids WebView/Canvas
        // hit-testing conflicts and guarantees taps reach the state controller.
        var selectedState by remember(state) { mutableStateOf(state) }
        val assistantStates: List<Pair<String, String>> = listOf(
            "idle" to tx(fa, "Idle", "آماده"),
            "standby" to tx(fa, "Standby / Away", "آماده‌باش / استراحت"),
            "scanning" to tx(fa, "Scanning", "پایش"),
            "connecting" to tx(fa, "Connecting", "اتصال"),
            "success" to tx(fa, "Connected", "متصل"),
            "password_success" to tx(fa, "Pass OK", "رمز صحیح"),
            "password_warning" to tx(fa, "Wrong pass", "رمز اشتباه"),
            "warning" to tx(fa, "Warning", "هشدار"),
            "angry" to tx(fa, "Attack", "حمله"),
            "offline" to tx(fa, "Device offline", "دستگاه آفلاین"),
            "target_offline" to tx(fa, "Target AP offline", "AP هدف آفلاین"),
            "setup" to tx(fa, "Setup", "راه‌اندازی")
        )
        Column(
            // 4.1.61: transparent; the app's glass backdrop (dark or light) shows through.
            modifier = modifier.fillMaxSize()
        ) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                LivLivAssistantWebView(
                    fa = fa,
                    state = selectedState,
                    compact = false,
                    modifier = Modifier.fillMaxSize()
                )
                // Keep a clear exit affordance after hiding the normal app toolbar/tab bar.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(18.dp)
                        .size(42.dp)
                        .liquidGlass(p, CircleShape, strength = 1.1f, elevation = 6.dp)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("×", color = p.text, fontSize = 25.sp, lineHeight = 26.sp, fontWeight = FontWeight.Light)
                }
            }
            CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .liquidGlass(p, RoundedCornerShape(18.dp), strength = 1.0f, elevation = 8.dp)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        if (fa) "گفت‌وگو با نارا" else "NARA · WAPFIRE ASSISTANT",
                        modifier = Modifier.fillMaxWidth(),
                        color = p.accent,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = if (fa) 0.sp else 0.8.sp,
                        maxLines = 1
                    )
                    Text(
                        overviewAssistantMessage(fa, selectedState),
                        modifier = Modifier.fillMaxWidth(),
                        color = p.text,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 2
                    )
                }
            }
            CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .height(44.dp)
                        .liquidGlass(p, RoundedCornerShape(18.dp), strength = 1.0f, elevation = 8.dp)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    assistantStates.forEach { (key, label) ->
                        val selected = selectedState == key
                        Box(
                            modifier = Modifier
                                .height(34.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(
                                    if (selected) Brush.linearGradient(listOf(p.accent, p.blue))
                                    else Brush.linearGradient(listOf(p.panelAlt.copy(alpha = .55f), p.panelAlt.copy(alpha = .35f)))
                                )
                                .border(
                                    1.dp,
                                    if (selected) Color.White.copy(alpha = if (p.dark) .35f else .55f) else p.border.copy(alpha = .70f),
                                    RoundedCornerShape(13.dp)
                                )
                                .clickable { selectedState = key }
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (selected) p.onAccent else p.text,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .then(Modifier.windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars)))
                .background(Color.Transparent)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(p.panelAlt)
                        .border(1.dp, p.border, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("‹", color = p.text, fontSize = 27.sp, lineHeight = 28.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("WAPFIRE · LIVE 2.5D CHARACTER", color = p.accent, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    Text(tx(fa, "Animated assistant", "دستیار متحرک"), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            LivLivAssistantWebView(
                fa = fa,
                state = state,
                compact = false,
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp))
            )
        }
    }
}
