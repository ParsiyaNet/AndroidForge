# 4.1.62 — Glass tiles: no dark rectangle; near-opaque bottom tab bar

## Fixed
- Dark sharp-edged rectangle visible inside every glass tile/card (metric tiles, Monitoring status card,
  section cards, event cards...). Cause: `Modifier.shadow()` in `liquidGlass` is a platform elevation shadow
  that shows through a translucent body. It is replaced by `glassOuterShadow`, a soft drop shadow drawn
  ONLY outside the shape (the shape is cut out with `ClipOp.Difference`), so nothing is painted under the glass.

## Changed
- Floating bottom tab bar: glass body opacity is now 98.5% (`liquidGlass(..., bodyAlpha = .985f)`), so
  content scrolling behind it no longer mixes into the tab labels in dark mode.
- `liquidGlass` gained an optional `bodyAlpha` parameter (null = previous behaviour for all other surfaces).

## Unchanged
Everything else (character, networking, monitoring, other surfaces' opacity).
