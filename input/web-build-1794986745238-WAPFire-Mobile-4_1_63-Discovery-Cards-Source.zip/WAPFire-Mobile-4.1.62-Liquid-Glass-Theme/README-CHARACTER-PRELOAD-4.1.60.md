# WAPFire Mobile 4.1.60 — Character preload

Nara now loads in the background from the moment the app starts, so Overview (and the Nara tab)
open with the character already drawn.

Flow: app start → first frame → `warmUp()` creates the Overview WebView (or the Nara-tab one if that
was the last tab) in a hidden host → renderer finishes and the view pauses → screen shows it and
resumes it. The second WebView is warmed up as soon as the first is ready.

Run `python tools/validate_4_1_60.py` for source-contract checks. Build with Android Studio or
`gradlew.bat assembleDebug`.
