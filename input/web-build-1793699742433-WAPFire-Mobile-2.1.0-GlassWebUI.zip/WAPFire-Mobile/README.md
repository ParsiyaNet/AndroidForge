# WAPFire Mobile 2.1

A polished Android companion for WAPFire VF38. It combines a native Jetpack Compose app shell (device discovery, connection, glass UI, language/theme controls and navigation) with the **actual WebUI served by the firmware** inside a hardened WebView. This keeps every existing firmware control and live chart available instead of maintaining a second, incomplete copy of the WebUI in the app.

## What's new in 2.1

- Replaced the incomplete native mock settings/dashboard with the real VF38 WebUI pages and APIs.
- Native glassmorphism shell with dark and light themes, English default, Persian/RTL support, connection identity, refresh, sign-out and bottom navigation.
- Full native navigation to Overview, Target AP, Setup, Settings and Activity.
- Firmware's real five-step initial setup wizard, including target AP scan/selection in step 2.
- Full Settings page from the firmware: system/AP settings, target management, LEDs and disconnect alert, whitelist/aliases, Ethernet, HTTP API, NTP, schedules, MikroTik, firmware update, backup/restore, quick actions and system information.
- Original live Dashboard with its charts, packet metrics, threat status and tracked-client panels.
- Original Logs/Activity page with filtering, search, export/copy and clear actions.
- Real firmware responses for save operations: success/error states come from the device API; the app does not display a synthetic "saved" message.
- WebView upload chooser and authenticated downloads for firmware `.bin` files and backup `.json` files.
- Improved mobile layouts and glass styling for firmware panels, charts, forms, setup wizard and log cards.
- Persistent app theme/language preferences. WebUI language changes are applied immediately and saved through the firmware language endpoint when the user changes the language.

## Connection and discovery

1. Scan nearby Wi-Fi networks and identify SSIDs containing `WAPFire`.
2. Request a direct local-only Wi-Fi connection using Android's system Wi-Fi consent flow (Android 10+). The default SoftAP address is `192.168.4.1`.
3. When already connected to the same LAN, scan the current subnet for the firmware's distinctive login page. This scan is bounded to the current subnet and falls back to a `/24` for unusually large subnets.
4. Choose a discovered WAPFire IP or enter an IP/hostname manually for Ethernet, custom subnets or routed deployments.

The device login, first-time setup and session cookie are handled by the firmware's own WebUI. WAPFire sessions are bound to the client's IP as well as the HTTP cookie, so Android's local Wi-Fi route is kept bound while the console is open. If Android changes networks, reconnect and retry.

## Firmware compatibility

This app targets the supplied `WAPFireVF38-WPA3-No-AP-Disconnect-LED` firmware tree. That firmware already exposes the required routes and pages (`/`, `/setup`, `/home`, `/settings`, `/logs`, and the associated APIs), so **no firmware change or reflash is required for the current feature set**. The app uses those real pages and endpoints, including chart/status polling, target scanning/selection, settings, logs, backup/restore and firmware upload.

For future builds, optional mDNS service discovery (for example `_wapfire._tcp`) could make LAN discovery more efficient, but it is not required: the current app supports Wi-Fi discovery, bounded LAN verification and manual IP fallback.

## Android compatibility

- `minSdk = 29` (Android 10)
- `targetSdk = 35`
- `compileSdk = 35`
- JDK 17 / Android Gradle Plugin 8.7.3 / Kotlin 2.0.21

Android 11 (API 30) is supported. Nearby Wi-Fi scanning requires Android runtime permissions; manual IP entry remains available when scan permission is declined.

## Build

1. Open this `WAPFire-Mobile` folder in Android Studio.
2. Install Android SDK Platform 35 and JDK 17.
3. Sync Gradle.
4. Build with **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `build-apk.bat` on Windows.
5. The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Security and behavior notes

- The firmware currently serves its WebUI over HTTP, so cleartext is enabled only for local device communication. Do not expose the WAPFire WebUI directly to the public Internet.
- Authentication and save confirmations are supplied by the device; credentials are not stored by the app.
- The firmware update and restore flows remain destructive operations and retain the confirmations shown by the firmware UI.
