# WAPFire Mobile 4.2.0 — Live2D Cubism Preview

This is an isolated preview branch based on the supplied 4.2.0 Dark Matte Glass source. The original source ZIP is unchanged.

## Preview changes
- Keeps Live2D Cubism 4 + PixiJS and the bundled Hiyori sample model.
- Explicitly enables Hiyori's built-in `Idle` motion group and preloads its idle motions.
- Adds a restrained, slowly varying gaze / head / torso idle layer and subtle breathing parameter.
- Enables the supplied `TapBody` motion when the character is tapped.
- Preserves the existing Compose UI, dark matte glass styling, Overview framing, WebView asset loading, offline asset policy, state poses, and Nara fallback.
- No voice, TTS, speech recognition, Unity, or network runtime dependency is added.

## Important model note
The preview uses Live2D's Hiyori sample character. The existing Iru `.vrm` is a 3D VRM model and cannot be loaded directly by Cubism; an independently rigged Live2D model is required to use that character in Live2D.

## Validation limits
JavaScript syntax and bundled asset paths should be checked before a device build. This environment does not contain the Android SDK/Gradle distribution needed to produce and install a verified APK. AndroidForge can build this source ZIP.

## Attribution
The Hiyori model and Cubism Core notices in `app/src/main/assets/assistant/hiyori/LICENSES.txt` remain included. The bundled Cubism Core file is marked there as originating from an unofficial npm mirror; replace it with the official redistributable SDK file before public distribution, following Live2D's license terms.
