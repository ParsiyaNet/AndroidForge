package io.wapfire.mobile.ui.screens

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.widget.Toast
import java.util.Locale

/**
 * 4.2.0: offline-only voice for the assistant, built on the phone's own text-to-speech engine.
 * Only voices that are installed on the phone and do not need a network connection are used,
 * because the phone is normally joined to the WAPFire access point and has no Internet.
 * [onSpeaking] may be called from a binder thread; callers must hop to the main thread themselves.
 */
internal class AssistantVoice(
    private val context: Context,
    private val onSpeaking: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var queued: Pair<String, Boolean>? = null
    private var counter = 0
    private var warnedFor = HashSet<String>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) { onSpeaking(true) }
                        override fun onDone(utteranceId: String?) { onSpeaking(false) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { onSpeaking(false) }
                        override fun onError(utteranceId: String?, errorCode: Int) { onSpeaking(false) }
                        override fun onStop(utteranceId: String?, interrupted: Boolean) { onSpeaking(false) }
                    })
                    queued?.let { (text, fa) -> queued = null; speak(text, fa) }
                } else {
                    failed = true
                }
            }
        }
    }

    fun speak(text: String, fa: Boolean) {
        val engine = tts ?: return
        if (failed || text.isBlank()) return
        if (!ready) { queued = text to fa; return }
        val voices = runCatching { engine.voices }.getOrNull().orEmpty()
        if (voices.isNotEmpty()) {
            val voice = pickOfflineVoice(voices, fa)
            if (voice == null) {
                engine.stop()
                warnOnce(fa)
                return
            }
            engine.setVoice(voice)
        } else {
            // Some engines do not list their voices; trust the language check for those.
            val result = engine.setLanguage(Locale(if (fa) "fa" else "en"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                warnOnce(fa)
                return
            }
        }
        counter++
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wf-$counter")
    }

    private fun pickOfflineVoice(voices: Set<Voice>, fa: Boolean): Voice? {
        val language = if (fa) "fa" else "en"
        val preferredCountry = if (fa) "IR" else "US"
        return voices
            .filter { voice ->
                voice.locale.language.equals(language, ignoreCase = true) &&
                    !voice.isNetworkConnectionRequired &&
                    !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
            }
            .sortedWith(
                compareByDescending<Voice> { it.locale.country.equals(preferredCountry, ignoreCase = true) }
                    .thenByDescending { it.quality }
            )
            .firstOrNull()
    }

    private fun warnOnce(fa: Boolean) {
        val key = if (fa) "fa" else "en"
        if (!warnedFor.add(key)) return
        val message = if (fa) {
            "صدای آفلاین فارسی روی این گوشی نصب نیست. از تنظیمات گوشی › تبدیل متن به گفتار، یک صدای فارسی دانلود کن."
        } else {
            "No offline English voice is installed on this phone. Install one in Settings › Text-to-speech."
        }
        main.post { Toast.makeText(context.applicationContext, message, Toast.LENGTH_LONG).show() }
    }

    fun stop() {
        queued = null
        runCatching { tts?.stop() }
        onSpeaking(false)
    }

    fun shutdown() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
        ready = false
    }
}
