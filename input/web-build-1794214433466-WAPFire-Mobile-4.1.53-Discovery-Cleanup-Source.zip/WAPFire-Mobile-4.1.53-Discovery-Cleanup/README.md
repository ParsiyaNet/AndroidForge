# WAPFire Mobile 4.1.53 — Discovery Cleanup & Post-Setup Overview

Based on `WAPFire Mobile 4.1.52 – Dark Matte Glass`.

This release removes the MEET NARA and CURRENT NETWORK cards from the initial discovery screen, removes CHARACTER CREDITS from Settings, removes the decorative icon above AUTHENTICATION on Sign in, and persists Overview as the landing tab after successful initial setup (including a SoftAP restart/reconnect).

See `CHANGELOG-4.1.53.md` and `README-4.1.53-FA.md` for details.
