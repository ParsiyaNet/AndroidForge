# WAPFire Mobile 4.1.53

### Discovery, sign-in, and setup navigation cleanup

- Removed the MEET NARA promotional card from the initial device discovery screen.
- Removed the CURRENT NETWORK card; DEVICE DISCOVERY remains the single discovery/connect entry point.
- Removed the CHARACTER CREDITS section from Settings. Internal license and notice files remain packaged.
- Removed the decorative icon above the AUTHENTICATION heading on the sign-in screen to reduce unnecessary vertical space.
- After a successful initial setup, reset the selected tab to Overview and persist `last_tab=OVERVIEW` before handling a possible SoftAP restart, so the next sign-in opens Overview instead of a previously selected Settings tab.
- Kept the 4.1.52 Dark Matte Glass UI, device discovery behavior, sign-in logic, setup flow, and monitoring logic otherwise unchanged.

## Version
- Android `versionCode`: 99
- Android `versionName`: 4.1.53
- Baseline: WAPFire-Mobile-4.1.52-Dark-Matte-Glass-Source
