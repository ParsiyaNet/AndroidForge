package io.wapfire.mobile

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WapFireRoot() }
    }
}

private enum class AppStage { DISCOVER, LOGIN, FIRST_SETUP, MAIN }

@Composable
private fun WapFireRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val discovery = remember { WifiDiscovery(context) }
    val connector = remember { WifiConnector(context) }
    val api = remember { WapFireApi() }
    val userPrefs = remember { context.getSharedPreferences("wapfire_mobile", Context.MODE_PRIVATE) }

    var stage by remember { mutableStateOf(AppStage.DISCOVER) }
    var host by remember { mutableStateOf(userPrefs.getString("last_host", "192.168.4.1") ?: "192.168.4.1") }
    var manualHost by remember { mutableStateOf("192.168.4.1") }
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("admin") }
    var isFa by remember { mutableStateOf(userPrefs.getBoolean("persian", false)) }
    var busy by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var wifiPassword by remember { mutableStateOf("secure1234") }
    var wifiResults by remember { mutableStateOf<List<WifiAccessPoint>>(emptyList()) }
    var lanDevices by remember { mutableStateOf<List<String>>(emptyList()) }
    var currentWifi by remember { mutableStateOf(discovery.current()) }
    var status by remember { mutableStateOf(JSONObject()) }
    var settings by remember { mutableStateOf(JSONObject()) }
    var chart by remember { mutableStateOf(JSONObject()) }
    var clients by remember { mutableStateOf(JSONArray()) }
    var logs by remember { mutableStateOf(JSONArray()) }
    var ledSettings by remember { mutableStateOf(JSONObject()) }
    var disconnectLedSettings by remember { mutableStateOf(JSONObject()) }
    var ntpSettings by remember { mutableStateOf(JSONObject()) }
    var scheduleSettings by remember { mutableStateOf(JSONObject()) }
    var httpSettings by remember { mutableStateOf(JSONObject()) }
    var ethernetSettings by remember { mutableStateOf(JSONObject()) }
    var mikrotikSettings by remember { mutableStateOf(JSONObject()) }
    var firmwareInfo by remember { mutableStateOf(JSONObject()) }
    var activeTab by remember { mutableIntStateOf(0) }
    var setupSsid by remember { mutableStateOf("WAPFire Network") }
    var setupWifiPassword by remember { mutableStateOf("secure1234") }
    var setupAdminPassword by remember { mutableStateOf("") }

    fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    fun toggleLanguage() {
        isFa = !isFa
        userPrefs.edit().putBoolean("persian", isFa).apply()
    }

    suspend fun loadBaseData() {
        status = api.getJson("api/status")
        clients = api.getArray("api/tracked_clients")
        logs = api.getArray("api/logs")
        chart = api.getJson("api/chart_data")
    }

    suspend fun refreshAll() {
        try {
            loadBaseData()
            error = ""
        } catch (e: ApiException) {
            if (e.code == 401) {
                try {
                    api.clearSession()
                    api.login(username, password)
                    loadBaseData()
                    error = ""
                } catch (retry: Exception) {
                    error = retry.message ?: "Session expired. Please sign in again."
                    stage = AppStage.LOGIN
                }
            } else {
                error = e.message
            }
        } catch (e: Exception) {
            error = e.message ?: "Connection lost"
        }
    }

    suspend fun loadAdvancedSettings() {
        try { ledSettings = api.getJson("api/led_settings") } catch (_: Exception) { }
        try { disconnectLedSettings = api.getJson("api/disconnect_led_settings") } catch (_: Exception) { }
        try { ntpSettings = api.getJson("api/ntp_settings") } catch (_: Exception) { }
        try { scheduleSettings = api.getJson("api/schedule_settings") } catch (_: Exception) { }
        try { httpSettings = api.getJson("api/http_api_settings") } catch (_: Exception) { }
        try { ethernetSettings = api.getJson("api/ethernet_settings") } catch (_: Exception) { }
        try { mikrotikSettings = api.getJson("api/mikrotik_settings") } catch (_: Exception) { }
    }

    fun tryManualHost(value: String) {
        val cleaned = value.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
        if (cleaned.isBlank()) {
            error = if (isFa) "نشانی IP یا میزبان را وارد کن." else "Enter a device IP or host name."
            return
        }
        host = cleaned
        manualHost = cleaned
        userPrefs.edit().putString("last_host", cleaned).apply()
        api.setHost(cleaned)
        error = ""
        stage = AppStage.LOGIN
    }

    fun connectToWifi(ssid: String, pass: String) {
        if (Build.VERSION.SDK_INT < 29) {
            error = if (isFa) "اتصال درون‌برنامه‌ای به Wi‑Fi به Android 10 یا بالاتر نیاز دارد." else "In-app Wi-Fi connection requires Android 10 or newer. Connect in Android Settings, then enter the device IP."
            return
        }
        connecting = true
        error = ""
        connector.connect(
            ssid = ssid,
            password = pass,
            onAvailable = {
                connecting = false
                currentWifi = discovery.current()
                host = "192.168.4.1"
                manualHost = host
                api.setHost(host)
                stage = AppStage.LOGIN
                notice = if (isFa) "به شبکه $ssid متصل شدی. حالا وارد WAPFire شو." else "Connected to $ssid. Sign in to WAPFire."
            },
            onUnavailable = {
                connecting = false
                error = if (isFa) "اتصال به $ssid انجام نشد. رمز را بررسی کن یا از تنظیمات Android وصل شو." else "Could not connect to $ssid. Check the password or connect from Android Settings."
            },
            onLost = {
                connecting = false
                error = if (isFa) "اتصال Wi‑Fi قطع شد." else "Wi-Fi connection was lost."
            }
        )
    }

    fun doLogin() {
        scope.launch {
            busy = true
            error = ""
            try {
                api.setHost(host)
                api.clearSession()
                api.login(username, password)
                status = api.getJson("api/status")
                settings = api.getJson("api/settings")
                setupSsid = settings.optString("ap_ssid", "WAPFire Network")
                setupWifiPassword = settings.optString("ap_pass", "secure1234").ifBlank { "secure1234" }
                if (status.has("configured") && !status.optBoolean("configured", true)) {
                    stage = AppStage.FIRST_SETUP
                } else {
                    stage = AppStage.MAIN
                    activeTab = 0
                    loadBaseData()
                }
                notice = if (isFa) "اتصال امن به WAPFire برقرار شد." else "Secure session established with WAPFire."
            } catch (e: Exception) {
                error = e.message ?: if (isFa) "ورود ناموفق بود." else "Unable to sign in."
            } finally { busy = false }
        }
    }

    fun completeFirstSetup() {
        scope.launch {
            busy = true
            error = ""
            try {
                if (setupAdminPassword.length !in 8..64) throw IllegalArgumentException("Administrator password must be 8–64 characters.")
                if (setupWifiPassword.length !in 8..63) throw IllegalArgumentException("Wi-Fi password must be 8–63 characters.")
                val payload = JSONObject()
                    .put("adminpass", setupAdminPassword)
                    .put("ap_ssid", setupSsid)
                    .put("ap_pass", setupWifiPassword)
                    .put("led", true)
                    .put("smart_led", false)
                    .put("auto_channel", true)
                    .put("self_protect", false)
                    .put("softap_enabled", true)
                    .put("sound", true)
                val response = api.postJson("api/settings", payload)
                password = setupAdminPassword
                status = try { api.getJson("api/status") } catch (_: Exception) { status }
                settings = try { api.getJson("api/settings") } catch (_: Exception) { settings }
                if (response.optBoolean("wifi_restart_needed", false)) {
                    wifiPassword = setupWifiPassword
                    stage = AppStage.DISCOVER
                    manualHost = "192.168.4.1"
                    notice = if (isFa) "تنظیمات ذخیره شد. به شبکه جدید WAPFire وصل شو." else "Setup saved. Reconnect to WAPFire using the new access-point credentials."
                    connector.release()
                } else {
                    stage = AppStage.MAIN
                    loadBaseData()
                }
            } catch (e: Exception) {
                error = e.message ?: "Setup could not be completed."
            } finally { busy = false }
        }
    }

    fun saveBaseSettings(payload: JSONObject) {
        scope.launch {
            busy = true
            error = ""
            try {
                val response = api.postJson("api/settings", payload)
                settings = api.getJson("api/settings")
                status = api.getJson("api/status")
                notice = response.optString("message", if (isFa) "تنظیمات ذخیره شد." else "Settings saved.")
                if (response.optBoolean("wifi_restart_needed", false)) {
                    if (payload.has("ap_pass")) wifiPassword = payload.optString("ap_pass", wifiPassword)
                    stage = AppStage.DISCOVER
                    manualHost = "192.168.4.1"
                    connector.release()
                }
            } catch (e: Exception) { error = e.message ?: "Could not save settings." }
            finally { busy = false }
        }
    }

    fun scanTargetNetworks() {
        scope.launch {
            busy = true
            error = ""
            try {
                val result = api.postEmpty("api/scan")
                notice = "TARGET_SCAN_RESULT:$result"
            } catch (e: Exception) { error = e.message ?: "Target scan failed." }
            finally { busy = false }
        }
    }

    fun selectTarget(item: JSONObject?) {
        scope.launch {
            busy = true
            error = ""
            try {
                val payload = if (item == null) JSONObject().put("ssid", "") else JSONObject()
                    .put("ssid", item.optString("ssid"))
                    .put("bssid", item.optString("bssid"))
                    .put("channel", item.optInt("channel"))
                val selected = api.postJson("api/select_target", payload)
                if (item != null && selected.optBoolean("success", false)) {
                    api.postJson("api/save_target", payload)
                }
                status = api.getJson("api/status")
                settings = api.getJson("api/settings")
                notice = if (item == null) "Target cleared." else "Target selected: ${item.optString("ssid")}"
            } catch (e: Exception) { error = e.message ?: "Could not change target." }
            finally { busy = false }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) {
            scope.launch {
                busy = true
                connector.bindToCurrentWifi()
                currentWifi = discovery.current()
                wifiResults = discovery.scan()
                lanDevices = discovery.findWapFireOnLan()
                busy = false
            }
        } else {
            error = if (isFa) "مجوز Wi‑Fi Scan داده نشد؛ می‌توانی IP را دستی وارد کنی." else "Wi-Fi scan permission was not granted. You can still enter the IP manually."
        }
    }

    fun scanWifi() {
        val missing = WifiDiscovery.requiredPermissions().filter {
            ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
        else scope.launch {
            busy = true
            error = ""
            connector.bindToCurrentWifi()
            currentWifi = discovery.current()
            wifiResults = discovery.scan()
            lanDevices = discovery.findWapFireOnLan()
            busy = false
            if (wifiResults.isEmpty() && lanDevices.isEmpty()) error = if (isFa) "دستگاهی در Wi-Fi یا شبکه محلی پیدا نشد؛ IP را دستی وارد کن." else "No WAPFire device found on nearby Wi-Fi or the local subnet. Enter its IP manually."
        }
    }

    LaunchedEffect(Unit) {
        currentWifi = discovery.current()
        connector.bindToCurrentWifi()
        if (currentWifi.ssid.contains("wapfire", true)) {
            host = "192.168.4.1"
            manualHost = host
        } else if (currentWifi.gateway.isNotBlank()) {
            host = currentWifi.gateway
            manualHost = currentWifi.gateway
        }
        scanWifi()
    }

    LaunchedEffect(stage) {
        if (stage == AppStage.MAIN) {
            while (true) {
                refreshAll()
                delay(2500)
            }
        }
    }

    LaunchedEffect(stage, activeTab) {
        if (stage == AppStage.MAIN && activeTab == 3) loadAdvancedSettings()
        if (stage == AppStage.MAIN && activeTab == 4) {
            try { firmwareInfo = api.getJson("api/firmware_info") } catch (_: Exception) { }
        }
    }

    WapFireTheme {
        when (stage) {
            AppStage.DISCOVER -> DiscoverScreen(
                isFa = isFa,
                currentWifi = currentWifi,
                networks = wifiResults,
                lanDevices = lanDevices,
                manualHost = manualHost,
                onManualHostChange = { manualHost = it },
                wifiPassword = wifiPassword,
                onWifiPasswordChange = { wifiPassword = it },
                busy = busy,
                connecting = connecting,
                notice = notice,
                error = error,
                onScan = { scanWifi() },
                onConnectWifi = { ap -> connectToWifi(ap.ssid, if (ap.secured) wifiPassword else "") },
                onUseLanDevice = { ip -> tryManualHost(ip) },
                onTryCurrent = {
                    currentWifi = discovery.current()
                    connector.bindToCurrentWifi()
                    val candidate = when {
                        currentWifi.ssid.contains("wapfire", true) -> "192.168.4.1"
                        lanDevices.size == 1 -> lanDevices.first()
                        else -> currentWifi.gateway.ifBlank { "192.168.4.1" }
                    }
                    tryManualHost(candidate)
                },
                onManualContinue = { tryManualHost(manualHost) },
                onLanguage = { toggleLanguage() }
            )
            AppStage.LOGIN -> LoginScreen(
                isFa = isFa, host = host, username = username, password = password,
                busy = busy, notice = notice, error = error,
                onHost = { host = it; api.setHost(it) },
                onUsername = { username = it }, onPassword = { password = it },
                onLogin = { doLogin() }, onBack = { stage = AppStage.DISCOVER },
                onLanguage = { toggleLanguage() }
            )
            AppStage.FIRST_SETUP -> FirstSetupScreen(
                isFa = isFa, ssid = setupSsid, wifiPassword = setupWifiPassword,
                adminPassword = setupAdminPassword, busy = busy, error = error,
                onSsid = { setupSsid = it }, onWifiPassword = { setupWifiPassword = it },
                onAdminPassword = { setupAdminPassword = it }, onComplete = { completeFirstSetup() }
            )
            AppStage.MAIN -> MainShell(
                isFa = isFa, activeTab = activeTab, onTab = { activeTab = it },
                host = host, status = status, settings = settings, chart = chart,
                clients = clients, logs = logs, error = error, notice = notice, busy = busy,
                ledSettings = ledSettings, disconnectLedSettings = disconnectLedSettings,
                ntpSettings = ntpSettings, scheduleSettings = scheduleSettings,
                httpSettings = httpSettings, ethernetSettings = ethernetSettings,
                mikrotikSettings = mikrotikSettings, firmwareInfo = firmwareInfo,
                onLanguage = { toggleLanguage() }, onRefresh = { scope.launch { refreshAll() } },
                onSaveBase = { saveBaseSettings(it) }, onTargetScan = { scanTargetNetworks() },
                onSelectTarget = { selectTarget(it) },
                onAdvancedRefresh = { scope.launch { loadAdvancedSettings() } },
                onAdvancedSave = { endpoint, payload ->
                    scope.launch {
                        busy = true
                        try {
                            if (endpoint == "api/ntp_sync_now" || endpoint == "api/test_http_api" || endpoint == "api/test_mikrotik") {
                                val result = api.postEmpty(endpoint)
                                notice = result.ifBlank { if (isFa) "درخواست ارسال شد." else "Command sent." }
                            } else {
                                api.postJson(endpoint, payload)
                                notice = if (isFa) "تنظیمات ذخیره شد." else "Settings saved."
                            }
                            loadAdvancedSettings()
                        } catch (e: Exception) { error = e.message ?: "Save failed." }
                        finally { busy = false }
                    }
                },
                onSystemAction = { endpoint ->
                    scope.launch {
                        busy = true
                        try {
                            val result = api.postEmpty(endpoint)
                            notice = result.ifBlank { if (isFa) "درخواست ارسال شد." else "Command sent." }
                            if (endpoint == "wifi_restart" || endpoint == "reboot" || endpoint == "factory_reset") {
                                delay(900)
                                connector.release()
                                stage = AppStage.DISCOVER
                                manualHost = "192.168.4.1"
                            }
                        } catch (e: Exception) {
                            if (endpoint == "reboot" || endpoint == "factory_reset") {
                                connector.release(); stage = AppStage.DISCOVER; manualHost = "192.168.4.1"
                            } else error = e.message ?: "Command failed."
                        }
                        finally { busy = false }
                    }
                },
                onLoadFirmware = { scope.launch { try { firmwareInfo = api.getJson("api/firmware_info") } catch (e: Exception) { error = e.message ?: "Firmware info unavailable." } } },
                onOpenWebUi = {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(WapFireApi.normalizeHost(host) + "/home")))
                    } catch (_: Exception) { toast("No browser available") }
                },
                onBackup = {
                    scope.launch {
                        try {
                            val backup = api.getJson("api/backup_settings").toString(2)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("WAPFire backup", backup))
                            notice = if (isFa) "پشتیبان تنظیمات در کلیپ‌بورد کپی شد." else "Settings backup copied to clipboard."
                        } catch (e: Exception) { error = e.message ?: "Backup failed." }
                    }
                },
                onLogout = {
                    api.clearSession()
                    connector.release()
                    stage = AppStage.LOGIN
                }
            )
        }
    }
}
