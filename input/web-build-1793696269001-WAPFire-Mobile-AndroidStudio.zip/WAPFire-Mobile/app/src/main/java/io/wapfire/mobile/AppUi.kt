package io.wapfire.mobile

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

private val Ink = Color(0xFF080D16)
private val Panel = Color(0xFF111A28)
private val Panel2 = Color(0xFF162235)
private val Line = Color(0xFF27364A)
private val Mint = Color(0xFF53E0C1)
private val Blue = Color(0xFF8196FF)
private val Amber = Color(0xFFFFC56B)
private val Red = Color(0xFFFF6B7A)
private val TextMain = Color(0xFFEAF1FA)
private val TextMuted = Color(0xFF91A0B5)

@Composable
fun WapFireTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Mint,
        secondary = Blue,
        tertiary = Amber,
        background = Ink,
        surface = Panel,
        surfaceVariant = Panel2,
        onPrimary = Ink,
        onBackground = TextMain,
        onSurface = TextMain,
        onSurfaceVariant = TextMuted,
        outline = Line,
        error = Red
    )
    MaterialTheme(colorScheme = colors, content = content)
}

private fun tx(isFa: Boolean, en: String, fa: String) = if (isFa) fa else en

@Composable
private fun WapBackground(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Ink).windowInsetsPadding(WindowInsets.safeDrawing),
        content = content
    )
}

@Composable
private fun BrandHeader(
    title: String,
    subtitle: String,
    isFa: Boolean,
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Mint.copy(alpha = 0.13f))
                .border(1.dp, Mint.copy(alpha = 0.35f), RoundedCornerShape(15.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.GraphicEq, null, tint = Mint, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp)
            Text(subtitle, color = TextMuted, fontSize = 11.sp, letterSpacing = 1.3.sp)
        }
        trailing?.invoke()
    }
}

@Composable
private fun LanguageButton(isFa: Boolean, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 5.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain),
        modifier = Modifier.height(36.dp)
    ) {
        Text(if (isFa) "EN" else "FA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NoticeBanner(text: String, isError: Boolean = false) {
    if (text.isBlank()) return
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background((if (isError) Red else Mint).copy(alpha = 0.10f))
            .border(1.dp, (if (isError) Red else Mint).copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (isError) Icons.Rounded.WarningAmber else Icons.Rounded.CheckCircle, null,
            tint = if (isError) Red else Mint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(9.dp))
        Text(text, color = TextMain, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (!subtitle.isNullOrBlank()) Text(subtitle, color = TextMuted, fontSize = 11.sp)
        }
        trailing?.invoke()
    }
}

@Composable
private fun WapCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = androidx.compose.foundation.BorderStroke(1.dp, Line.copy(alpha = 0.75f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink, disabledContainerColor = Mint.copy(alpha = .28f))
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector? = null) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.heightIn(min = 44.dp), shape = RoundedCornerShape(13.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)
    ) {
        if (icon != null) { Icon(icon, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(7.dp)) }
        Text(text, fontSize = 12.sp)
    }
}

@Composable
private fun WapTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    placeholder: String = ""
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label, fontSize = 12.sp) },
        placeholder = { if (placeholder.isNotBlank()) Text(placeholder, fontSize = 12.sp) },
        modifier = modifier.fillMaxWidth(), singleLine = singleLine,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Mint, unfocusedBorderColor = Line,
            focusedLabelColor = Mint, unfocusedLabelColor = TextMuted,
            focusedTextColor = TextMain, unfocusedTextColor = TextMain,
            cursorColor = Mint, focusedContainerColor = Panel2, unfocusedContainerColor = Panel2
        )
    )
}

@Composable
fun DiscoverScreen(
    isFa: Boolean,
    currentWifi: CurrentWifi,
    networks: List<WifiAccessPoint>,
    lanDevices: List<String>,
    manualHost: String,
    onManualHostChange: (String) -> Unit,
    wifiPassword: String,
    onWifiPasswordChange: (String) -> Unit,
    busy: Boolean,
    connecting: Boolean,
    notice: String,
    error: String,
    onScan: () -> Unit,
    onConnectWifi: (WifiAccessPoint) -> Unit,
    onUseLanDevice: (String) -> Unit,
    onTryCurrent: () -> Unit,
    onManualContinue: () -> Unit,
    onLanguage: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        WapBackground {
            BrandHeader("WAPFIRE", tx(isFa, "WIRELESS INTELLIGENCE · MOBILE CONTROL", "مدیریت هوشمند بی‌سیم · اپلیکیشن موبایل"), isFa) {
                LanguageButton(isFa, onLanguage)
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Spacer(Modifier.height(2.dp))
                Text(tx(isFa, "Connect to your device", "به دستگاه متصل شو"), color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Find WAPFire on your local network or connect directly to its setup access point.", "دستگاه WAPFire را در شبکه محلی پیدا کن یا مستقیم به شبکه راه‌اندازی آن وصل شو."), color = TextMuted, fontSize = 13.sp, lineHeight = 20.sp)
                NoticeBanner(notice)
                NoticeBanner(error, true)

                WapCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.WifiTethering, null, tint = Mint, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(9.dp))
                        Text(tx(isFa, "Nearby WAPFire access points", "شبکه‌های WAPFire اطراف"), color = TextMain, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        GhostButton(tx(isFa, "Scan", "جستجو"), onScan, icon = Icons.Rounded.Refresh)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (networks.isEmpty()) {
                        Text(tx(isFa, "No scan results yet. Allow Wi-Fi scan permission and tap Scan.", "هنوز نتیجه‌ای نیست. مجوز جستجوی Wi‑Fi را بده و جستجو را بزن."), color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                    } else {
                        val ordered = networks.sortedByDescending { it.isWapFire }
                        ordered.take(7).forEach { ap ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(13.dp)).background(Panel2).padding(11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(if (ap.isWapFire) Icons.Rounded.Router else Icons.Rounded.Wifi, null, tint = if (ap.isWapFire) Mint else Blue)
                                Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(ap.ssid, color = TextMain, fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${ap.rssi} dBm  ·  ${ap.frequency} MHz${if (ap.secured) "  ·  secured" else "  ·  open"}", color = TextMuted, fontSize = 10.sp)
                                }
                                if (ap.isWapFire) {
                                    TextButton(onClick = { onConnectWifi(ap) }, enabled = !connecting) {
                                        Text(tx(isFa, "Connect", "اتصال"), color = Mint, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        if (ordered.none { it.isWapFire }) {
                            Text(tx(isFa, "No SSID containing “WAPFire” was found. You can still connect manually.", "شبکه‌ای با نام WAPFire پیدا نشد؛ می‌توانی دستی وصل شوی."), color = Amber, fontSize = 11.sp)
                        }
                    }
                    if (connecting || busy) {
                        Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint, trackColor = Line)
                    }
                    if (networks.any { it.isWapFire }) {
                        Spacer(Modifier.height(9.dp))
                        WapTextField(wifiPassword, onWifiPasswordChange, tx(isFa, "WAPFire Wi-Fi password", "رمز شبکه WAPFire"), password = true, placeholder = "secure1234")
                        Text(tx(isFa, "Factory default is secure1234 unless it was changed.", "رمز پیش‌فرض secure1234 است، مگر اینکه قبلاً عوض شده باشد."), color = TextMuted, fontSize = 10.sp)
                    }
                }

                if (lanDevices.isNotEmpty()) {
                    WapCard {
                        SectionTitle(tx(isFa, "WAPFire found on this network", "دستگاه‌های WAPFire در شبکه پیدا شدند"), tx(isFa, "Detected by the WAPFire login-page signature on your local subnet.", "با شناسایی صفحه ورود اختصاصی WAPFire در زیرشبکه محلی پیدا شدند."))
                        Spacer(Modifier.height(8.dp))
                        lanDevices.forEach { ip ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Router, null, tint = Mint)
                                Spacer(Modifier.width(9.dp))
                                Text(ip, color = TextMain, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { onUseLanDevice(ip) }) { Text(tx(isFa, "Connect", "اتصال"), color = Mint) }
                            }
                        }
                    }
                }

                WapCard {
                    SectionTitle(tx(isFa, "Already connected?", "قبلاً متصل شده‌ای؟"), tx(isFa, "Use the current Wi-Fi gateway as a discovery hint.", "از Gateway شبکه فعلی برای پیدا کردن دستگاه استفاده کن."))
                    Spacer(Modifier.height(10.dp))
                    Text(tx(isFa, "Wi-Fi network", "شبکه Wi‑Fi"), color = TextMuted, fontSize = 10.sp)
                    Text(currentWifi.ssid.ifBlank { tx(isFa, "Not available", "نامشخص") }, color = TextMain, fontWeight = FontWeight.SemiBold)
                    Text(tx(isFa, "Gateway", "گیت‌وی") + ": " + currentWifi.gateway.ifBlank { "—" }, color = TextMuted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton(tx(isFa, "Use current connection", "استفاده از اتصال فعلی"), onTryCurrent, modifier = Modifier.fillMaxWidth())
                }

                WapCard {
                    SectionTitle(tx(isFa, "Manual connection", "اتصال دستی"), tx(isFa, "For Ethernet, a custom subnet, or a renamed access point.", "برای اترنت، رنج IP سفارشی یا نام شبکه تغییرکرده."))
                    Spacer(Modifier.height(10.dp))
                    WapTextField(manualHost, onManualHostChange, tx(isFa, "Device IP or hostname", "IP یا نام میزبان دستگاه"), placeholder = "192.168.4.1")
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton(tx(isFa, "Continue to sign in", "ادامه برای ورود"), onManualContinue, modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun LoginScreen(
    isFa: Boolean, host: String, username: String, password: String, busy: Boolean,
    notice: String, error: String,
    onHost: (String) -> Unit, onUsername: (String) -> Unit, onPassword: (String) -> Unit,
    onLogin: () -> Unit, onBack: () -> Unit, onLanguage: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        WapBackground {
            BrandHeader("WAPFIRE", tx(isFa, "SECURE DEVICE ACCESS", "دسترسی امن به دستگاه"), isFa) { LanguageButton(isFa, onLanguage) }
            Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Spacer(Modifier.height(28.dp))
                Box(Modifier.size(64.dp).clip(RoundedCornerShape(20.dp)).background(Mint.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Shield, null, tint = Mint, modifier = Modifier.size(35.dp))
                }
                Text(tx(isFa, "Welcome back", "خوش آمدی"), color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Sign in to your WAPFire controller.", "برای ورود به کنترلر WAPFire اطلاعات را وارد کن."), color = TextMuted, fontSize = 13.sp)
                NoticeBanner(notice)
                NoticeBanner(error, true)
                WapCard {
                    WapTextField(host, onHost, tx(isFa, "Device address", "نشانی دستگاه"), placeholder = "192.168.4.1")
                    Spacer(Modifier.height(10.dp))
                    WapTextField(username, onUsername, tx(isFa, "Username", "نام کاربری"))
                    Spacer(Modifier.height(10.dp))
                    WapTextField(password, onPassword, tx(isFa, "Password", "رمز عبور"), password = true)
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(tx(isFa, "Sign in", "ورود"), onLogin, enabled = !busy, modifier = Modifier.fillMaxWidth())
                    if (busy) { Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint, trackColor = Line) }
                }
                Text(tx(isFa, "Factory credentials on an untouched device: admin / admin. The first-run wizard will ask you to replace the password.", "اطلاعات ورود دستگاهی که هنوز راه‌اندازی نشده: admin / admin. در راه‌اندازی اول رمز مدیر را تغییر می‌دهی."), color = TextMuted, fontSize = 11.sp, lineHeight = 17.sp)
                GhostButton(tx(isFa, "Back to device discovery", "بازگشت به جستجوی دستگاه"), onBack, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.ArrowBack)
            }
        }
    }
}

@Composable
fun FirstSetupScreen(
    isFa: Boolean, ssid: String, wifiPassword: String, adminPassword: String,
    busy: Boolean, error: String, onSsid: (String) -> Unit,
    onWifiPassword: (String) -> Unit, onAdminPassword: (String) -> Unit, onComplete: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        WapBackground {
            BrandHeader("WAPFIRE", tx(isFa, "FIRST-RUN CONFIGURATION", "پیکربندی اولیه"), isFa)
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Text(tx(isFa, "Make it yours.", "دستگاه را ایمن‌سازی کن."), color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Set a private administrator password and the Wi-Fi credentials used to access this WAPFire device.", "یک رمز مدیریت مطمئن و اطلاعات شبکه Wi‑Fi اختصاصی WAPFire را تنظیم کن."), color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                NoticeBanner(error, true)
                WapCard {
                    SectionTitle(tx(isFa, "Administrator", "مدیریت دستگاه"), tx(isFa, "This protects the WebUI and mobile app session.", "این رمز از WebUI و نشست اپلیکیشن محافظت می‌کند."))
                    Spacer(Modifier.height(10.dp))
                    WapTextField(adminPassword, onAdminPassword, tx(isFa, "New admin password (8–64 characters)", "رمز جدید مدیر (۸ تا ۶۴ نویسه)"), password = true)
                }
                WapCard {
                    SectionTitle(tx(isFa, "Device access point", "شبکه اختصاصی دستگاه"), tx(isFa, "Your phone connects directly to this Wi-Fi network.", "گوشی برای دسترسی مستقیم به این شبکه متصل می‌شود."))
                    Spacer(Modifier.height(10.dp))
                    WapTextField(ssid, onSsid, "Wi-Fi SSID")
                    Spacer(Modifier.height(10.dp))
                    WapTextField(wifiPassword, onWifiPassword, tx(isFa, "Wi-Fi password (8–63 characters)", "رمز Wi‑Fi (۸ تا ۶۳ نویسه)"), password = true)
                    Text(tx(isFa, "Default access point: WAPFire Network · 192.168.4.1", "شبکه پیش‌فرض: WAPFire Network · 192.168.4.1"), color = TextMuted, fontSize = 10.sp)
                }
                PrimaryButton(tx(isFa, "Save and initialize WAPFire", "ذخیره و راه‌اندازی WAPFire"), onComplete, enabled = !busy, modifier = Modifier.fillMaxWidth())
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint, trackColor = Line)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun MainShell(
    isFa: Boolean, activeTab: Int, onTab: (Int) -> Unit, host: String,
    status: JSONObject, settings: JSONObject, chart: JSONObject, clients: JSONArray, logs: JSONArray,
    error: String, notice: String, busy: Boolean,
    ledSettings: JSONObject, disconnectLedSettings: JSONObject, ntpSettings: JSONObject,
    scheduleSettings: JSONObject, httpSettings: JSONObject, ethernetSettings: JSONObject,
    mikrotikSettings: JSONObject, firmwareInfo: JSONObject,
    onLanguage: () -> Unit, onRefresh: () -> Unit,
    onSaveBase: (JSONObject) -> Unit, onTargetScan: () -> Unit, onSelectTarget: (JSONObject?) -> Unit,
    onAdvancedRefresh: () -> Unit, onAdvancedSave: (String, JSONObject) -> Unit,
    onSystemAction: (String) -> Unit, onLoadFirmware: () -> Unit, onOpenWebUi: () -> Unit,
    onBackup: () -> Unit, onLogout: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides if (isFa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Scaffold(
            modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            containerColor = Ink,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Mint.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.GraphicEq, null, tint = Mint, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("WAPFIRE", color = TextMain, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, fontSize = 15.sp)
                        Text(tx(isFa, "WIRELESS INTELLIGENCE", "هوشمندی شبکه بی‌سیم"), color = TextMuted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(if (error.isBlank()) Mint else Amber))
                        Spacer(Modifier.width(6.dp))
                        Text(if (error.isBlank()) tx(isFa, "LIVE", "زنده") else tx(isFa, "RETRY", "تلاش مجدد"), color = if (error.isBlank()) Mint else Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    LanguageButton(isFa, onLanguage)
                    IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null, tint = TextMuted) }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = TextMain, tonalElevation = 0.dp) {
                    val tabs = listOf(
                        Triple(Icons.Rounded.SpaceDashboard, tx(isFa, "Overview", "نمای کلی"), 0),
                        Triple(Icons.Rounded.Devices, tx(isFa, "Clients", "کلاینت‌ها"), 1),
                        Triple(Icons.Rounded.ReceiptLong, tx(isFa, "Activity", "رویدادها"), 2),
                        Triple(Icons.Rounded.Tune, tx(isFa, "Configure", "تنظیمات"), 3),
                        Triple(Icons.Rounded.Memory, tx(isFa, "System", "سیستم"), 4)
                    )
                    tabs.forEach { (icon, label, index) ->
                        NavigationBarItem(
                            selected = activeTab == index,
                            onClick = { onTab(index) },
                            icon = { Icon(icon, null, modifier = Modifier.size(21.dp)) },
                            label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Mint, selectedTextColor = Mint,
                                indicatorColor = Mint.copy(alpha = .12f), unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (error.isNotBlank()) NoticeBanner(error, true)
                when (activeTab) {
                    0 -> OverviewScreen(status, chart, clients.length(), isFa, busy, onRefresh)
                    1 -> ClientsScreen(clients, isFa)
                    2 -> ActivityScreen(logs, isFa, busy, onClear = { onSystemAction("api/clear_logs") })
                    3 -> ConfigureScreen(
                        isFa, settings, status, ledSettings, disconnectLedSettings, ntpSettings,
                        scheduleSettings, httpSettings, ethernetSettings, mikrotikSettings,
                        busy, notice, onSaveBase, onTargetScan, onSelectTarget,
                        onAdvancedRefresh, onAdvancedSave, onOpenWebUi
                    )
                    else -> SystemScreen(
                        isFa, status, firmwareInfo, busy, notice, host,
                        onSystemAction, onLoadFirmware, onOpenWebUi, onBackup, onLogout
                    )
                }
            }
        }
    }
}

@Composable
private fun OverviewScreen(status: JSONObject, chart: JSONObject, clientCount: Int, isFa: Boolean, busy: Boolean, onRefresh: () -> Unit) {
    val threat = status.optJSONObject("threat_assessment") ?: JSONObject()
    val level = threat.optString("level", "UNKNOWN").uppercase()
    val score = (threat.optInt("score_tenths", 0) / 10f).coerceIn(0f, 10f)
    val target = status.optString("target", "").ifBlank { tx(isFa, "No target selected", "شبکه هدف انتخاب نشده") }
    val targetAvailable = status.optBoolean("target_available", false)
    val rssi = status.optInt("target_rssi", 0)
    val packets = status.optLong("packets", 0)
    val traffic = status.optLong("traffic", 0)
    val clientsCount = clientsCountSafe(status)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx(isFa, "Network overview", "نمای کلی شبکه"), color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Live radio telemetry and threat intelligence", "تله‌متری زنده رادیو و تحلیل تهدید"), color = TextMuted, fontSize = 11.sp)
            }
            StatusPill(if (status.optString("promiscuous") == "ACTIVE") "MONITORING" else "INACTIVE", status.optString("promiscuous") == "ACTIVE")
        }
        WapCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tx(isFa, "THREAT ASSESSMENT", "ارزیابی تهدید"), color = TextMuted, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text(level.ifBlank { "UNKNOWN" }, color = levelColor(level), fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text(threat.optString("last_event_label").ifBlank { tx(isFa, "No recent security event", "رویداد امنیتی اخیر وجود ندارد") }, color = TextMuted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Box(Modifier.size(96.dp).clip(CircleShape).background(Panel2).border(1.dp, levelColor(level).copy(alpha = .4f), CircleShape), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${score.toInt()}", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("/ 10", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(13.dp))
            val progress by animateFloatAsState(score / 10f, label = "threat-progress")
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = levelColor(level), trackColor = Line)
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SmallMeta(tx(isFa, "Recent events", "رویدادهای اخیر"), threat.optInt("recent_events").toString())
                SmallMeta(tx(isFa, "Last event", "آخرین رویداد"), ageLabel(threat.optLong("last_event_age_ms", -1), isFa))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(tx(isFa, "Captured packets", "بسته‌های دریافت‌شده"), packets.pretty(), tx(isFa, "All radio callbacks", "کل دریافت رادیویی"), Icons.Rounded.Bolt, Modifier.weight(1f))
            MetricCard(tx(isFa, "Network traffic", "ترافیک شبکه"), traffic.pretty(), tx(isFa, "Valid frames", "فریم‌های معتبر"), Icons.Rounded.Equalizer, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(tx(isFa, "Target RSSI", "قدرت سیگنال هدف"), if (targetAvailable) "$rssi dBm" else "—", if (targetAvailable) tx(isFa, "Target online", "هدف در دسترس") else tx(isFa, "Not detected", "شناسایی نشد"), Icons.Rounded.NetworkWifi, Modifier.weight(1f))
            MetricCard(tx(isFa, "Tracked clients", "کلاینت‌های ردیابی‌شده"), clientCount.toString(), tx(isFa, "Live + recent history", "زنده و تاریخچه اخیر"), Icons.Rounded.Devices, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(tx(isFa, "Free heap", "حافظه آزاد"), "${(status.optLong("free_heap", 0) / 1024)} KB", tx(isFa, "ESP32 memory", "حافظه ESP32"), Icons.Rounded.Memory, Modifier.weight(1f))
            MetricCard(tx(isFa, "Recent detection", "تشخیص اخیر"), if (status.optBoolean("has_recent_detections")) tx(isFa, "ACTIVE", "فعال") else tx(isFa, "CLEAR", "بدون رویداد"), status.optString("last_attack_label", "—").ifBlank { "—" }, Icons.Rounded.Security, Modifier.weight(1f))
        }
        WapCard {
            SectionTitle(tx(isFa, "Radio activity", "فعالیت رادیویی"), tx(isFa, "Last 30 sampling intervals", "۳۰ بازه نمونه‌برداری اخیر"))
            Spacer(Modifier.height(12.dp))
            RadioChart(chart)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Mint)); Spacer(Modifier.width(6.dp)); Text(tx(isFa, "All radio", "کل رادیو"), color = TextMuted, fontSize = 10.sp)
                Spacer(Modifier.width(15.dp)); Box(Modifier.size(8.dp).clip(CircleShape).background(Blue)); Spacer(Modifier.width(6.dp)); Text(tx(isFa, "Target AP", "اکسس‌پوینت هدف"), color = TextMuted, fontSize = 10.sp)
            }
        }
        WapCard {
            SectionTitle(tx(isFa, "Current target", "شبکه هدف فعلی"), tx(isFa, "Selected access point", "اکسس‌پوینت انتخاب‌شده"))
            Spacer(Modifier.height(7.dp))
            Text(target, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("${status.optString("target_mac", "—")}   ·   CH ${status.optInt("target_ch", 0)}", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(if (targetAvailable) "AVAILABLE" else "NOT SEEN", targetAvailable)
                StatusPill("WIFI CH ${status.optInt("wifi_channel", 0)}", true)
                if (status.optBoolean("self_protect_active")) StatusPill("SELF-PROTECT", true)
            }
        }
        WapCard {
            SectionTitle(tx(isFa, "Capture pipeline", "مسیر دریافت فریم"), tx(isFa, "Radio callback counters", "شمارنده‌های دریافت رادیویی"))
            CounterRow("Management", status.optLong("rx_mgmt"), Blue)
            CounterRow("Control", status.optLong("rx_ctrl"), Mint)
            CounterRow("Data", status.optLong("rx_data"), Amber)
            CounterRow("Dropped / filtered", status.optLong("dropped"), Red)
            CounterRow("Filtered", status.optLong("filtered"), TextMuted)
        }
        val labelStats = status.optJSONArray("labels").objects()
        if (labelStats.isNotEmpty()) WapCard {
            SectionTitle(tx(isFa, "Detection distribution", "توزیع تشخیص‌ها"), tx(isFa, "Current model labels", "برچسب‌های مدل فعلی"))
            labelStats.forEach { CounterRow(it.optString("name", "Unknown"), it.optLong("count"), Blue) }
        }
        Spacer(Modifier.height(14.dp))
    }
}

private fun clientsCountSafe(status: JSONObject): Int = status.optInt("tracked_clients", 0)

@Composable
private fun ClientsScreen(clients: JSONArray, isFa: Boolean) {
    var query by remember { mutableStateOf("") }
    val all = clients.objects()
    val filtered = all.filter {
        it.optString("mac").contains(query, true) || it.optString("state").contains(query, true) || it.optString("bssid").contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        SectionTitle(tx(isFa, "Tracked clients", "کلاینت‌های تحت ردیابی"), "${filtered.size} ${tx(isFa, "observations", "مورد")}")
        Spacer(Modifier.height(10.dp))
        WapTextField(query, { query = it }, tx(isFa, "Search MAC or state", "جستجوی MAC یا وضعیت"), placeholder = "AA:BB:CC:DD:EE:FF")
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            EmptyState(tx(isFa, "No tracked clients yet", "هنوز کلاینتی ثبت نشده"), tx(isFa, "Client observations will appear here when WAPFire sees activity on the selected target.", "با مشاهده فعالیت روی شبکه هدف، وضعیت کلاینت‌ها اینجا نمایش داده می‌شود."), Icons.Rounded.Devices)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(filtered, key = { it.optString("mac") + it.optLong("state_age_sec") }) { item -> ClientRow(item, isFa) }
            }
        }
    }
}

@Composable
private fun ClientRow(item: JSONObject, isFa: Boolean) {
    val state = item.optString("state", "UNKNOWN").replace('_', ' ')
    val stateColor = when {
        state.contains("DISCONNECT") -> Amber
        state.contains("POWER") -> Blue
        state.contains("CONNECTED") || state.contains("ACTIVE") -> Mint
        else -> TextMuted
    }
    WapCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Smartphone, null, tint = stateColor)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.optString("mac"), color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(item.optString("bssid", tx(isFa, "BSSID not reported", "BSSID گزارش نشده")), color = TextMuted, fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${item.optInt("rssi")} dBm", color = rssiColor(item.optInt("rssi")), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("${item.optLong("age_sec")}s", color = TextMuted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            StatusPill(state, stateColor == Mint || stateColor == Blue)
            Spacer(Modifier.weight(1f))
            Text("${tx(isFa, "Reason", "علت")}: ${item.optInt("reason_code")} · ${item.optString("reason_text", "—")}", color = TextMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ActivityScreen(logs: JSONArray, isFa: Boolean, busy: Boolean, onClear: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = logs.objects().filter {
        it.optString("message").contains(query, true) || it.optString("details").contains(query, true) || it.optString("event_type").contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx(isFa, "Activity feed", "گزارش رویدادها"), color = TextMain, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text(tx(isFa, "Security events, attempts and system logs", "رویدادهای امنیتی، تلاش‌ها و گزارش‌های سیستم"), color = TextMuted, fontSize = 10.sp)
            }
            TextButton(onClick = onClear, enabled = !busy) { Text(tx(isFa, "Clear", "پاک‌کردن"), color = Red, fontSize = 11.sp) }
        }
        Spacer(Modifier.height(10.dp))
        WapTextField(query, { query = it }, tx(isFa, "Filter activity", "فیلتر رویدادها"))
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) EmptyState(tx(isFa, "No matching events", "رویدادی پیدا نشد"), tx(isFa, "New device events will appear automatically.", "رویدادهای جدید دستگاه به‌طور خودکار نمایش داده می‌شوند."), Icons.Rounded.ReceiptLong)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(filtered, key = { "${it.optInt("index")}-${it.optLong("timestamp")}" }) { EventRow(it, isFa) }
        }
    }
}

@Composable
private fun EventRow(item: JSONObject, isFa: Boolean) {
    val type = item.optString("event_type", "system").uppercase()
    val color = when {
        type.contains("ATTACK") -> Red
        type.contains("WRONG") || type.contains("ATTEMPT") -> Amber
        type.contains("CORRECT") -> Mint
        type.contains("DISCONNECT") -> Blue
        else -> TextMuted
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(15.dp)).padding(12.dp)) {
        Box(Modifier.width(3.dp).heightIn(min = 52.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(type.replace('_', ' '), color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                Spacer(Modifier.weight(1f))
                Text(item.optString("formatted_time", "—"), color = TextMuted, fontSize = 9.sp)
            }
            Spacer(Modifier.height(4.dp))
            Text(item.optString("message", "—"), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (item.optString("details").isNotBlank()) Text(item.optString("details"), color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun ConfigureScreen(
    isFa: Boolean, settings: JSONObject, status: JSONObject, led: JSONObject, disconnectLed: JSONObject,
    ntp: JSONObject, schedule: JSONObject, http: JSONObject, ethernet: JSONObject, mikrotik: JSONObject,
    busy: Boolean, notice: String, onSaveBase: (JSONObject) -> Unit, onTargetScan: () -> Unit,
    onSelectTarget: (JSONObject?) -> Unit, onAdvancedRefresh: () -> Unit,
    onAdvancedSave: (String, JSONObject) -> Unit, onOpenWebUi: () -> Unit
) {
    var ledEnabled by remember(settings) { mutableStateOf(settings.optBoolean("led", true)) }
    var smartLed by remember(settings) { mutableStateOf(settings.optBoolean("smart_led", false)) }
    var autoChannel by remember(settings) { mutableStateOf(settings.optBoolean("auto_channel", true)) }
    var selfProtect by remember(settings) { mutableStateOf(settings.optBoolean("self_protect", false)) }
    var softAp by remember(settings) { mutableStateOf(settings.optBoolean("softap_enabled", true)) }
    var sound by remember(settings) { mutableStateOf(settings.optBoolean("sound", true)) }
    var apSsid by remember(settings) { mutableStateOf(settings.optString("ap_ssid", "WAPFire Network")) }
    var apPassword by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var targetScanJson by remember { mutableStateOf(JSONArray()) }
    var targetScanMessage by remember { mutableStateOf("") }
    var advancedOpen by remember { mutableStateOf(false) }

    LaunchedEffect(notice) {
        if (notice.startsWith("TARGET_SCAN_RESULT:")) {
            val raw = notice.removePrefix("TARGET_SCAN_RESULT:")
            try { targetScanJson = JSONArray(raw); targetScanMessage = "" }
            catch (_: Exception) { targetScanMessage = raw }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx(isFa, "Device configuration", "پیکربندی دستگاه"), color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(tx(isFa, "Core controls and target network", "کنترل‌های اصلی و شبکه هدف"), color = TextMuted, fontSize = 10.sp)
            }
            IconButton(onClick = onAdvancedRefresh) { Icon(Icons.Rounded.Sync, null, tint = Mint) }
        }
        NoticeBanner(notice.takeUnless { it.startsWith("TARGET_SCAN_RESULT:") }.orEmpty())
        WapCard {
            SectionTitle(tx(isFa, "Target access point", "اکسس‌پوینت هدف"), tx(isFa, "Scan nearby APs with the WAPFire radio", "جستجوی APهای اطراف با رادیوی WAPFire"))
            Spacer(Modifier.height(10.dp))
            Text(status.optString("target").ifBlank { tx(isFa, "No target selected", "هدف انتخاب نشده") }, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("${status.optString("target_mac", "—")}   ·   CH ${status.optInt("target_ch", 0)}", color = TextMuted, fontSize = 10.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton(tx(isFa, "Scan networks", "جستجوی شبکه‌ها"), onTargetScan, enabled = !busy, modifier = Modifier.weight(1f))
                GhostButton(tx(isFa, "Clear target", "پاک‌کردن هدف"), { onSelectTarget(null) }, modifier = Modifier.weight(1f))
            }
            if (targetScanMessage.isNotBlank()) Text(targetScanMessage, color = Amber, fontSize = 10.sp)
            targetScanJson.objects().take(12).forEach { item ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp)).background(Panel2).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.optString("ssid", "Hidden network"), color = TextMain, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                        Text("${item.optString("bssid")} · CH ${item.optInt("channel")} · ${item.optInt("rssi")} dBm", color = TextMuted, fontSize = 9.sp)
                    }
                    TextButton(onClick = { onSelectTarget(item) }) { Text(tx(isFa, "Select", "انتخاب"), color = Mint, fontSize = 11.sp) }
                }
            }
        }
        WapCard {
            SectionTitle(tx(isFa, "Protection & behavior", "حفاظت و رفتار"), tx(isFa, "Apply changes together", "اعمال هم‌زمان تغییرات"))
            Spacer(Modifier.height(5.dp))
            SettingSwitch(tx(isFa, "LED alerts", "هشدارهای LED"), ledEnabled, { ledEnabled = it })
            SettingSwitch(tx(isFa, "Smart LED behavior", "رفتار هوشمند LED"), smartLed, { smartLed = it })
            SettingSwitch(tx(isFa, "Automatic channel", "انتخاب خودکار کانال"), autoChannel, { autoChannel = it })
            SettingSwitch(tx(isFa, "Self-protection", "حفاظت خودکار"), selfProtect, { selfProtect = it })
            SettingSwitch(tx(isFa, "Device SoftAP", "شبکه SoftAP دستگاه"), softAp, { softAp = it })
            SettingSwitch(tx(isFa, "Audio alerts", "هشدار صوتی"), sound, { sound = it })
            Spacer(Modifier.height(9.dp))
            PrimaryButton(tx(isFa, "Save core settings", "ذخیره تنظیمات اصلی"), {
                val body = JSONObject().put("led", ledEnabled).put("smart_led", smartLed)
                    .put("auto_channel", autoChannel).put("self_protect", selfProtect)
                    .put("softap_enabled", softAp).put("sound", sound)
                if (adminPassword.isNotBlank()) body.put("adminpass", adminPassword)
                if (apSsid != settings.optString("ap_ssid")) body.put("ap_ssid", apSsid)
                if (apPassword.isNotBlank()) body.put("ap_pass", apPassword)
                onSaveBase(body)
                adminPassword = ""; apPassword = ""
            }, enabled = !busy, modifier = Modifier.fillMaxWidth())
        }
        WapCard {
            SectionTitle(tx(isFa, "Device Wi-Fi access", "دسترسی Wi‑Fi دستگاه"), tx(isFa, "Leave password fields empty to keep them unchanged", "برای حفظ رمز فعلی، فیلد رمز را خالی بگذار"))
            Spacer(Modifier.height(10.dp))
            WapTextField(apSsid, { apSsid = it }, "SoftAP SSID")
            Spacer(Modifier.height(9.dp))
            WapTextField(apPassword, { apPassword = it }, tx(isFa, "New SoftAP password", "رمز جدید SoftAP"), password = true)
            Spacer(Modifier.height(9.dp))
            WapTextField(adminPassword, { adminPassword = it }, tx(isFa, "Change administrator password", "تغییر رمز مدیر"), password = true)
            Text(tx(isFa, "Changing SSID or Wi-Fi password restarts the wireless interface. The app will ask you to reconnect.", "تغییر SSID یا رمز Wi‑Fi باعث راه‌اندازی مجدد رابط بی‌سیم می‌شود و باید دوباره متصل شوی."), color = TextMuted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        WapCard {
            SectionTitle(tx(isFa, "Advanced configuration", "تنظیمات پیشرفته"), tx(isFa, "LED, NTP, schedule, Ethernet and integrations", "LED، زمان، زمان‌بندی، اترنت و یکپارچه‌سازی‌ها"), trailing = {
                IconButton(onClick = { advancedOpen = !advancedOpen }) { Icon(if (advancedOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = Mint) }
            })
            if (advancedOpen) {
                Spacer(Modifier.height(8.dp))
                AdvancedSettings(
                    isFa, led, disconnectLed, ntp, schedule, http, ethernet, mikrotik,
                    onAdvancedSave
                )
            } else {
                Text(tx(isFa, "Tap to edit LED effects, disconnect alerts, NTP, schedule, Ethernet, HTTP API and MikroTik integration.", "برای ویرایش افکت LED، هشدار قطع اتصال، NTP، برنامه زمانی، اترنت، HTTP API و MikroTik لمس کن."), color = TextMuted, fontSize = 11.sp, lineHeight = 17.sp)
            }
        }
        WapCard {
            SectionTitle(tx(isFa, "Full WebUI", "رابط کامل وب"), tx(isFa, "Open every firmware page in your browser", "تمام صفحات Firmware را در مرورگر باز کن"))
            Spacer(Modifier.height(8.dp))
            GhostButton(tx(isFa, "Open WAPFire WebUI", "بازکردن WebUI دستگاه"), onOpenWebUi, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.OpenInBrowser)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun AdvancedSettings(
    isFa: Boolean, led: JSONObject, disconnectLed: JSONObject, ntp: JSONObject,
    schedule: JSONObject, http: JSONObject, ethernet: JSONObject, mikrotik: JSONObject,
    onSave: (String, JSONObject) -> Unit
) {
    var effect by remember(led) { mutableIntStateOf(led.optInt("effect", 12)) }
    var color1 by remember(led) { mutableStateOf(led.optString("color1", "#FF0000")) }
    var color2 by remember(led) { mutableStateOf(led.optString("color2", "#00FF00")) }
    var speed by remember(led) { mutableFloatStateOf(led.optInt("speed", 10).toFloat()) }
    var brightness by remember(led) { mutableFloatStateOf(led.optInt("brightness", 250).toFloat()) }
    var disconnectEnabled by remember(disconnectLed) { mutableStateOf(disconnectLed.optBoolean("enabled", true)) }
    var ntpEnabled by remember(ntp) { mutableStateOf(ntp.optBoolean("ntp_enabled", false)) }
    var ntpServer by remember(ntp) { mutableStateOf(ntp.optString("ntp_server", "pool.ntp.org")) }
    var ntpInterval by remember(ntp) { mutableStateOf(ntp.optInt("ntp_interval", 3600).toString()) }
    var timezone by remember(ntp) { mutableStateOf(ntp.optString("timezone", "UTC+0")) }
    var scheduleEnabled by remember(schedule) { mutableStateOf(schedule.optBoolean("enabled", false)) }
    var scheduleStart by remember(schedule) { mutableStateOf(schedule.optString("start", "22:00")) }
    var scheduleEnd by remember(schedule) { mutableStateOf(schedule.optString("end", "06:00")) }
    var scheduleDays by remember(schedule) { mutableStateOf(schedule.optInt("days", 127).toString()) }
    var scheduleAction by remember(schedule) { mutableStateOf(schedule.optInt("action", 2).toString()) }
    var httpEnabled by remember(http) { mutableStateOf(http.optBoolean("enabled", false)) }
    var httpUrl by remember(http) { mutableStateOf(http.optString("url", "")) }
    var httpPort by remember(http) { mutableStateOf(http.optInt("port", 8080).toString()) }
    var useDhcp by remember(ethernet) { mutableStateOf(ethernet.optBoolean("use_dhcp", true)) }
    var ethIp by remember(ethernet) { mutableStateOf(ethernet.optString("static_ip", "192.168.1.200")) }
    var ethDns by remember(ethernet) { mutableStateOf(ethernet.optString("static_dns", "1.1.1.1")) }
    var ethGateway by remember(ethernet) { mutableStateOf(ethernet.optString("static_gateway", "192.168.1.1")) }
    var ethSubnet by remember(ethernet) { mutableStateOf(ethernet.optString("static_subnet", "255.255.255.0")) }
    var ethHostname by remember(ethernet) { mutableStateOf(ethernet.optString("ethernet_hostname", "WAPFire")) }
    var mikrotikEnabled by remember(mikrotik) { mutableStateOf(mikrotik.optBoolean("enabled", false)) }
    var mikrotikUrl by remember(mikrotik) { mutableStateOf(mikrotik.optString("url", "")) }
    var mikrotikUser by remember(mikrotik) { mutableStateOf(mikrotik.optString("username", "")) }
    var mikrotikPass by remember { mutableStateOf("") }
    var mikrotikInterface by remember(mikrotik) { mutableStateOf(mikrotik.optString("interface", "wlan1")) }
    var mikrotikReenable by remember(mikrotik) { mutableStateOf(mikrotik.optBoolean("reenable", true)) }
    var mikrotikDelay by remember(mikrotik) { mutableStateOf(mikrotik.optInt("reenable_delay", 60).toString()) }

    Text(tx(isFa, "LED EFFECTS", "افکت‌های LED"), color = Mint, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
    WapTextField(effect.toString(), { effect = it.toIntOrNull() ?: effect }, tx(isFa, "Effect ID (firmware range)", "شناسه افکت (طبق Firmware)"), keyboardType = KeyboardType.Number)
    WapTextField(color1, { color1 = it }, "Color 1 · #RRGGBB")
    WapTextField(color2, { color2 = it }, "Color 2 · #RRGGBB")
    Text("Speed · ${speed.toInt()} ms", color = TextMuted, fontSize = 11.sp)
    Slider(speed, { speed = it }, valueRange = 10f..1000f)
    Text("Brightness · ${brightness.toInt()}", color = TextMuted, fontSize = 11.sp)
    Slider(brightness, { brightness = it }, valueRange = 0f..255f)
    PrimaryButton(tx(isFa, "Save LED effects", "ذخیره افکت LED"), {
        onSave("api/led_settings", JSONObject().put("effect", effect).put("color1", color1).put("color2", color2).put("speed", speed.toInt()).put("brightness", brightness.toInt()))
    }, modifier = Modifier.fillMaxWidth())
    SettingSwitch(tx(isFa, "Client disconnect LED alert", "هشدار LED قطع اتصال کلاینت"), disconnectEnabled, { disconnectEnabled = it })
    GhostButton(tx(isFa, "Save disconnect alert", "ذخیره هشدار قطع اتصال"), { onSave("api/disconnect_led_settings", JSONObject().put("enabled", disconnectEnabled).put("color", disconnectLed.optString("color", "#00FFFF"))) }, Modifier.fillMaxWidth())

    HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 7.dp))
    Text("TIME & SCHEDULE", color = Mint, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
    SettingSwitch("NTP", ntpEnabled, { ntpEnabled = it })
    WapTextField(ntpServer, { ntpServer = it }, "NTP server")
    WapTextField(ntpInterval, { ntpInterval = it }, "NTP interval (60–86400 seconds)", keyboardType = KeyboardType.Number)
    WapTextField(timezone, { timezone = it }, "Timezone · e.g. UTC+1")
    GhostButton(tx(isFa, "Save time settings", "ذخیره تنظیمات زمان"), {
        onSave("api/ntp_settings", JSONObject().put("ntp_enabled", ntpEnabled).put("ntp_server", ntpServer).put("ntp_interval", ntpInterval.toIntOrNull() ?: 3600).put("timezone", timezone))
    }, Modifier.fillMaxWidth())
    GhostButton(tx(isFa, "Sync device clock now", "همگام‌سازی ساعت دستگاه"), { onSave("api/ntp_sync_now", JSONObject()) }, Modifier.fillMaxWidth())
    SettingSwitch(tx(isFa, "Scheduled quiet mode", "حالت سکوت زمان‌بندی‌شده"), scheduleEnabled, { scheduleEnabled = it })
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        WapTextField(scheduleStart, { scheduleStart = it }, "Start · HH:MM", modifier = Modifier.weight(1f))
        WapTextField(scheduleEnd, { scheduleEnd = it }, "End · HH:MM", modifier = Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        WapTextField(scheduleDays, { scheduleDays = it }, "Days mask · 0–127", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
        WapTextField(scheduleAction, { scheduleAction = it }, "Action · 0 LED / 1 sound / 2 both", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Number)
    }
    GhostButton(tx(isFa, "Save schedule", "ذخیره برنامه زمانی"), {
        onSave("api/schedule_settings", JSONObject().put("enabled", scheduleEnabled).put("start", scheduleStart).put("end", scheduleEnd).put("days", scheduleDays.toIntOrNull() ?: 127).put("action", scheduleAction.toIntOrNull() ?: 2))
    }, Modifier.fillMaxWidth())

    HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 7.dp))
    Text("CONNECTIVITY & INTEGRATIONS", color = Mint, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
    SettingSwitch("HTTP event API", httpEnabled, { httpEnabled = it })
    WapTextField(httpUrl, { httpUrl = it }, "HTTP API URL", placeholder = "http://10.0.0.10/event")
    WapTextField(httpPort, { httpPort = it }, "HTTP API port", keyboardType = KeyboardType.Number)
    GhostButton(tx(isFa, "Save HTTP API", "ذخیره HTTP API"), {
        onSave("api/http_api_settings", JSONObject().put("enabled", httpEnabled).put("url", httpUrl).put("port", httpPort.toIntOrNull() ?: 8080))
    }, Modifier.fillMaxWidth())
    GhostButton(tx(isFa, "Test HTTP event API", "آزمایش HTTP Event API"), { onSave("api/test_http_api", JSONObject()) }, Modifier.fillMaxWidth())

    SettingSwitch(tx(isFa, "Ethernet DHCP", "DHCP اترنت"), useDhcp, { useDhcp = it })
    AnimatedVisibility(!useDhcp) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            WapTextField(ethIp, { ethIp = it }, "Static IP")
            WapTextField(ethDns, { ethDns = it }, "DNS")
            WapTextField(ethGateway, { ethGateway = it }, "Gateway")
            WapTextField(ethSubnet, { ethSubnet = it }, "Subnet")
        }
    }
    WapTextField(ethHostname, { ethHostname = it }, "Ethernet hostname")
    GhostButton(tx(isFa, "Save Ethernet", "ذخیره اترنت"), {
        onSave("api/ethernet_settings", JSONObject().put("use_dhcp", useDhcp).put("static_ip", ethIp).put("static_dns", ethDns).put("static_gateway", ethGateway).put("static_subnet", ethSubnet).put("ethernet_hostname", ethHostname))
    }, Modifier.fillMaxWidth())

    SettingSwitch("MikroTik integration", mikrotikEnabled, { mikrotikEnabled = it })
    WapTextField(mikrotikUrl, { mikrotikUrl = it }, "Router URL", placeholder = "http://192.168.88.1")
    WapTextField(mikrotikUser, { mikrotikUser = it }, "Router username")
    WapTextField(mikrotikPass, { mikrotikPass = it }, "Router password · blank keeps current", password = true)
    WapTextField(mikrotikInterface, { mikrotikInterface = it }, "Wireless interface")
    SettingSwitch("Re-enable after attack window", mikrotikReenable, { mikrotikReenable = it })
    WapTextField(mikrotikDelay, { mikrotikDelay = it }, "Re-enable delay · seconds", keyboardType = KeyboardType.Number)
    GhostButton(tx(isFa, "Save MikroTik", "ذخیره MikroTik"), {
        // The endpoint overwrites the password, so an empty field is populated from the GET result.
        onSave("api/mikrotik_settings", JSONObject().put("enabled", mikrotikEnabled).put("url", mikrotikUrl).put("username", mikrotikUser)
            .put("password", mikrotikPass.ifBlank { mikrotik.optString("password", "") }).put("interface", mikrotikInterface)
            .put("reenable", mikrotikReenable).put("reenable_delay", mikrotikDelay.toIntOrNull() ?: 60))
        mikrotikPass = ""
    }, Modifier.fillMaxWidth())
    GhostButton(tx(isFa, "Test MikroTik action", "آزمایش اتصال MikroTik"), { onSave("api/test_mikrotik", JSONObject()) }, Modifier.fillMaxWidth())
}

@Composable
private fun SystemScreen(
    isFa: Boolean, status: JSONObject, firmware: JSONObject, busy: Boolean, notice: String,
    host: String, onSystemAction: (String) -> Unit, onLoadFirmware: () -> Unit,
    onOpenWebUi: () -> Unit, onBackup: () -> Unit, onLogout: () -> Unit
) {
    var showFactoryConfirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(8.dp))
        Text(tx(isFa, "Device & diagnostics", "دستگاه و عیب‌یابی"), color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(tx(isFa, "Firmware health, maintenance and access", "سلامت Firmware، نگهداری و دسترسی"), color = TextMuted, fontSize = 10.sp)
        NoticeBanner(notice)
        WapCard {
            SectionTitle(tx(isFa, "Firmware information", "اطلاعات Firmware"), "WAPFire · ${firmware.optString("version", "—")}")
            Spacer(Modifier.height(7.dp))
            InfoRow("Chip", firmware.optString("esp_model", "—"))
            InfoRow("CPU", firmware.optString("cpu_freq", "—"))
            InfoRow("Flash", firmware.optString("flash", "—"))
            InfoRow("PSRAM", firmware.optString("psram", "—"))
            InfoRow("Free heap", firmware.optString("free_heap", "—"))
            InfoRow("Free OTA space", firmware.optString("free_space", "—"))
            InfoRow("SDK", firmware.optString("sdk", "—"))
            Spacer(Modifier.height(8.dp))
            GhostButton(tx(isFa, "Refresh firmware info", "به‌روزرسانی اطلاعات Firmware"), onLoadFirmware, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
        }
        WapCard {
            SectionTitle(tx(isFa, "Runtime diagnostics", "وضعیت اجرا"))
            InfoRow("Promiscuous mode", status.optString("promiscuous", "—"))
            InfoRow("Wi-Fi channel", status.optInt("wifi_channel").toString())
            InfoRow("Uptime", durationLabel(status.optLong("uptime"), isFa))
            InfoRow("Packet inactivity", "${status.optLong("packet_inactivity_ms")} ms")
            InfoRow("Dropped frames", status.optLong("dropped").pretty())
            InfoRow("Filtered frames", status.optLong("filtered").pretty())
            InfoRow("Ethernet IP", status.optString("ethernet_ip", "—"))
            InfoRow("Device AP IP", status.optString("ap_ip", "192.168.4.1"))
            InfoRow("Connected host", host)
        }
        WapCard {
            SectionTitle(tx(isFa, "Maintenance", "نگهداری دستگاه"), tx(isFa, "Commands may temporarily disconnect this app", "این دستورات ممکن است اتصال اپ را موقتاً قطع کنند"))
            Spacer(Modifier.height(8.dp))
            GhostButton(tx(isFa, "Create settings backup", "ساخت پشتیبان تنظیمات"), onBackup, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Backup)
            GhostButton(tx(isFa, "Restart Wi-Fi", "راه‌اندازی مجدد Wi‑Fi"), { onSystemAction("wifi_restart") }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Wifi)
            GhostButton(tx(isFa, "Reboot device", "راه‌اندازی مجدد دستگاه"), { onSystemAction("reboot") }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.RestartAlt)
            GhostButton(tx(isFa, "Open full WebUI", "بازکردن WebUI کامل"), onOpenWebUi, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.OpenInBrowser)
            TextButton(onClick = { showFactoryConfirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text(tx(isFa, "Factory reset", "بازنشانی کارخانه‌ای"), color = Red, fontWeight = FontWeight.Bold)
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint, trackColor = Line)
        }
        GhostButton(tx(isFa, "Sign out", "خروج از حساب"), onLogout, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Logout)
        Spacer(Modifier.height(18.dp))
    }
    if (showFactoryConfirm) {
        AlertDialog(
            onDismissRequest = { showFactoryConfirm = false },
            title = { Text(tx(isFa, "Reset WAPFire?", "WAPFire بازنشانی شود؟")) },
            text = { Text(tx(isFa, "This erases saved configuration and restarts the device. You will need to run first-time setup again.", "این کار تنظیمات ذخیره‌شده را پاک می‌کند و دستگاه را راه‌اندازی مجدد می‌کند. باید راه‌اندازی اولیه را دوباره انجام دهی.")) },
            confirmButton = { TextButton(onClick = { showFactoryConfirm = false; onSystemAction("factory_reset") }) { Text(tx(isFa, "Reset device", "بازنشانی دستگاه"), color = Red) } },
            dismissButton = { TextButton(onClick = { showFactoryConfirm = false }) { Text(tx(isFa, "Cancel", "لغو")) } },
            containerColor = Panel, titleContentColor = TextMain, textContentColor = TextMuted
        )
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TextMain, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Switch(checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Mint, uncheckedTrackColor = Panel2, uncheckedBorderColor = Line))
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    WapCard(modifier) {
        Icon(icon, null, tint = Mint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(title, color = TextMain, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = TextMuted, fontSize = 9.sp)
    }
}

@Composable
private fun StatusPill(label: String, active: Boolean) {
    val c = if (active) Mint else TextMuted
    Text(label, modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(c.copy(alpha = .11f)).border(1.dp, c.copy(alpha = .25f), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 5.dp), color = c, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp, maxLines = 1)
}

@Composable
private fun SmallMeta(label: String, value: String) {
    Column {
        Text(label.uppercase(), color = TextMuted, fontSize = 8.sp, letterSpacing = .7.sp)
        Text(value, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CounterRow(label: String, count: Long, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(count.pretty(), color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun RadioChart(data: JSONObject) {
    val radio = data.optJSONArray("radioRxRates").toFloatList()
    val target = data.optJSONArray("targetApRxRates").toFloatList()
    Canvas(Modifier.fillMaxWidth().height(130.dp)) {
        val maxValue = max(1f, (radio + target).maxOrNull() ?: 1f)
        val minValue = 0f
        fun drawSeries(values: List<Float>, color: Color) {
            if (values.size < 2) return
            val path = Path()
            values.forEachIndexed { index, value ->
                val x = size.width * index / (values.size - 1)
                val y = size.height - ((value - minValue) / (maxValue - minValue)) * (size.height - 12.dp.toPx()) - 6.dp.toPx()
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
        }
        for (i in 1..3) {
            val y = size.height * i / 4f
            drawLine(Line.copy(alpha = .7f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
        }
        drawSeries(radio, Mint)
        drawSeries(target, Blue)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(vertical = 38.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Panel2), contentAlignment = Alignment.Center) { Icon(icon, null, tint = TextMuted, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(12.dp))
        Text(title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = TextMuted, fontSize = 11.sp, lineHeight = 17.sp)
    }
}

private fun JSONArray?.objects(): List<JSONObject> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { optJSONObject(it) }
}

private fun JSONArray?.toFloatList(): List<Float> {
    if (this == null) return emptyList()
    return (0 until length()).map { optDouble(it, 0.0).toFloat() }
}

private fun Long.pretty(): String = when {
    this >= 1_000_000 -> "%.1fM".format(this / 1_000_000.0)
    this >= 1_000 -> "%.1fK".format(this / 1_000.0)
    else -> toString()
}

private fun levelColor(level: String): Color = when (level.uppercase()) {
    "CRITICAL", "HIGH", "SEVERE" -> Red
    "ELEVATED", "MEDIUM", "WARNING" -> Amber
    "LOW", "GUARDED" -> Blue
    "NORMAL", "SAFE", "CLEAR" -> Mint
    else -> TextMuted
}

private fun rssiColor(rssi: Int): Color = when {
    rssi >= -55 -> Mint
    rssi >= -70 -> Amber
    else -> Red
}

private fun ageLabel(ms: Long, isFa: Boolean): String = when {
    ms < 0 -> "—"
    ms < 1000 -> tx(isFa, "just now", "همین الان")
    ms < 60_000 -> "${ms / 1000}s"
    else -> "${ms / 60_000}m"
}

private fun durationLabel(ms: Long, isFa: Boolean): String {
    val seconds = ms / 1000
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    return if (hours > 0) "${hours}h ${minutes}m" else if (minutes > 0) "${minutes}m ${seconds % 60}s" else "${seconds}s"
}
