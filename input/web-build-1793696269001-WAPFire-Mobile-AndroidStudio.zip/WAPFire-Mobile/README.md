# WAPFire Mobile

A native Android companion app for the WAPFire VF38 firmware. The app is written in Kotlin + Jetpack Compose; it is not a WebView wrapper.

## What is included

- **Device discovery:** Android Wi-Fi scan results are filtered for SSIDs containing `WAPFire`. On Android 10+, the app can request a direct local-only Wi-Fi connection through the Android system consent dialog. The default firmware access point is `WAPFire Network` with `192.168.4.1`; its factory password is `secure1234` unless it has been changed.
- **LAN discovery:** on the current Wi-Fi subnet, the app checks HTTP port 80 and confirms WAPFire by its distinctive firmware login-page title. Scanning is limited to the phone's subnet (and capped to a /24 if the detected subnet is unusually large).
- **Fallback connection:** use the current Wi-Fi gateway as a hint or enter an IP/hostname manually. This supports devices reached through Ethernet or a different LAN address.
- **First-run wizard:** logs in with the firmware's factory account (`admin` / `admin` on an untouched device), then configures a new administrator password and the WAPFire access-point SSID/password through the real firmware setup API.
- **Live monitoring:** threat assessment, target status/RSSI, captured packets, valid network frames, packet pipeline counters, radio-rate charts, tracked client states, and activity logs.
- **Target management:** runs the firmware's radio scan, selects an exact SSID/BSSID/channel, saves the selected target, and can clear it.
- **Native settings:** core behavior toggles, access-point credentials, LED effects, disconnect LED, NTP, schedule, Ethernet, HTTP event API, and MikroTik integration.
- **Device maintenance:** firmware information, backup-to-clipboard, Wi-Fi restart, reboot, factory reset confirmation, and opening the complete built-in WebUI for any firmware page not represented natively.
- **Languages:** English is the default. Persian can be selected from the language control; the app switches to RTL layout.

## Firmware API integration

The app is mapped to the endpoints present in the supplied `WAPFireVF38-WPA3-No-AP-Disconnect-LED` source:

- `POST /login` (form URL encoded; receives the `wg_auth` cookie)
- `GET /api/status`, `/api/settings`, `/api/chart_data`, `/api/tracked_clients`, `/api/logs`
- `POST /api/scan`, `/api/select_target`, `/api/save_target`
- `POST /api/settings`, `/api/led_settings`, `/api/disconnect_led_settings`, `/api/ntp_settings`, `/api/schedule_settings`, `/api/ethernet_settings`, `/api/http_api_settings`, `/api/mikrotik_settings`
- `GET /api/firmware_info`, `GET /api/backup_settings`
- `POST /api/clear_logs`, `/wifi_restart`, `/reboot`, `/factory_reset`

The firmware binds authenticated sessions to the source IP address as well as the `wg_auth` cookie. The app therefore keeps its local Wi-Fi route bound while connected, and it reauthenticates when the device reports an expired session.

## Discovery behavior and firmware limitation

The supplied firmware exposes `ap_ip = 192.168.4.1` in status but does not expose a separate unauthenticated device-discovery or mDNS endpoint. Discovery therefore combines the methods available to the Android app: scan nearby Wi-Fi names for WAPFire; connect through Android's approved local-only Wi-Fi flow and use `192.168.4.1`; and, when already on Wi-Fi, probe only the current subnet's HTTP port 80 and confirm the WAPFire login-page signature. The subnet scan is bounded and does not sweep arbitrary networks. For Ethernet adapters or routed networks whose address range is not visible through Android's Wi-Fi DHCP data, use the manual IP field. A future firmware addition such as `_wapfire._tcp` mDNS or an unauthenticated `/discover` endpoint would provide discovery without subnet probing.

## Build

1. Install Android Studio (a recent stable release), Android SDK Platform 35, and JDK 17.
2. Open this `WAPFire-Mobile` folder in Android Studio.
3. Allow Gradle to resolve the AndroidX, Compose and OkHttp dependencies.
4. On Windows, run `build-apk.bat`, or build from Android Studio using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The included `gradlew` scripts bootstrap Gradle 8.9 on first use if it is not already cached.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on Android 10 or later.

The build container used for authoring did not include Android SDK/Gradle, so an APK was not compiled here. This deliverable is the full Android Studio project source; the project is configured for `compileSdk 35`, `targetSdk 35`, `minSdk 29`.

## Permissions

- Internet and network state: HTTP communication with the ESP32.
- Wi-Fi state/change: scanning and requesting connection to WAPFire's SoftAP.
- Fine location / Nearby Wi-Fi devices: Android requires these runtime permissions for nearby Wi-Fi scan results on supported OS versions. The app uses them only to show nearby SSID/RSSI data; it does not request GPS location.

## Security notes

- The initial firmware factory password is only a documented convenience; replace it during first setup.
- Credentials are kept in app memory for the active session and are not persisted in app preferences.
- The app uses cleartext HTTP because the supplied firmware WebServer uses HTTP on port 80. Use the device on a trusted local network and do not expose its WebUI directly to the public Internet.
- Backup data contains sensitive configuration; the app copies it only when you explicitly request a backup.
