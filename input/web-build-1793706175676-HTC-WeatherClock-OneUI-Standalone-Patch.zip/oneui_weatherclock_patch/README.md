# HTC Weather Clock — One UI / standalone-location patch

This patch targets the public `main` source of `BuksaPC/htc-honor-weather-flip-clock` (v1.2.9-breezy, November 2026 checkout).
It makes the existing HTC flip/weather widget less dependent on Breezy Weather and improves the unlock path for Samsung One UI.

## What changes

- **Standalone weather source:** removes the runtime dependency on the Breezy Weather app/provider. The widget fetches current conditions, hourly data and a 7-day forecast directly from Open-Meteo.
- **Automatic current location:** on first setup, the settings screen asks once for Android's approximate-location permission and then obtains a one-shot fix. When the settings screen is opened later, it refreshes an old/missing location only if permission was already granted. The user can also press **Set current location** at any time. Coordinates are saved locally and reused for weather updates. There is no background-location permission and no always-on GPS.
- **Offline resilience:** keeps the last successful Open-Meteo response for each coordinate and falls back to it when the network is unavailable. The existing saved city coordinates are retained.
- **One UI unlock animation:** replaces the short 150/400/800 ms fixed check with a bounded five-second foreground-launcher retry loop. An attempt is considered successful only after the overlay window is actually attached.
- **Widget/provider resilience:** catches provider-query exceptions and returns a valid empty cursor rather than allowing an exception to propagate into the launcher; serializes sync scheduling and preserves a forced refresh requested during another sync.
- **Manifest permissions:** adds `INTERNET` and `ACCESS_COARSE_LOCATION`; it does not request fine or background location. Removes the Breezy provider permission and notifier receiver. The patch also increments `versionCode` to `663091324` and sets version name `1.3.0-oneui`.

Open-Meteo's forecast API accepts latitude/longitude and can return current, hourly and daily forecast arrays; its `timeformat=unixtime` option makes time-zone conversion explicit. Android's `LocationManager.getCurrentLocation()` is available from API 30 and accepts coarse or fine location permission, which covers One UI 3 / Android 11 and newer. See the official docs: <https://open-meteo.com/en/docs> and <https://developer.android.com/reference/android/location/LocationManager>.

## Apply to the repository

```bash
git clone https://github.com/BuksaPC/htc-honor-weather-flip-clock.git
cd htc-honor-weather-flip-clock
python3 /path/to/oneui_weatherclock_patch/apply_oneui_patch.py .
```

The script checks its expected source anchors before writing anything. It creates `*.oneui-backup` copies beside each source file it changes. Review the changes before building.

## Build limitation

This is a **source patch, not a signed APK**. The public repository's `source/build-breezy.sh` expects `source/apktool-project-124/`, `source/apktool-project-breezy/`, `source/tools/apktool.jar`, `source/tools/signer.jar`, and Android SDK Build Tools / platform 36. Those base APK decode assets and signing tools are not included in the repository tree I could inspect, and this environment has no Android SDK installation. Therefore I could not honestly produce or device-test an APK here. Once those original build inputs are available, run the repository's `source/build-breezy.sh` in that build environment; this patch changes the output name to `HTC-WeatherClock-v1.3.0-oneui.apk`.

## First run on Samsung

1. Install the built APK and add the weather widget.
2. Open the widget settings. On first setup it asks for approximate-location permission; allow it. The app then gets a one-shot location fix while the settings screen is in front. Later, it automatically refreshes a stale location when you open settings; you can also press **Set current location** manually.
3. Enable **Play the weather animation** (or flip + weather) under **After unlocking**.
4. Tap **Allow** for **Display over other apps** and **Usage access**. These are required for the unlock overlay and for ensuring it plays only over the launcher.
5. If Samsung still suspends the process aggressively, set the app's battery usage to **Unrestricted** or add it to **Never sleeping apps**. This is optional troubleshooting, not a permission the patch silently enables.

## Important limitations / validation

- The patch preserves previously saved city coordinates, but the new automatic-location control manages the device's current position; it is not a full replacement city-search/geocoding UI.
- The location label is currently **Current location** rather than a reverse-geocoded city name.
- Open-Meteo requires internet access. With no network, the widget uses the last successful cached response; on a brand-new offline install there is no weather payload to display yet.
- The five-second unlock retry fixes the timing race visible in source, but the actual Samsung launcher/One UI animation and overlay policy still need testing on a physical Samsung device.
- The Android launcher message **Problem loading widget** can also be caused by a crash in the original HTC widget/RemoteViews code, not just this provider. This patch hardens provider queries, but a remaining failure needs `adb logcat` from the affected device to identify the actual exception.

For a useful log capture on Windows:

```powershell
adb logcat -c
adb logcat -v time | findstr /i "AndroidRuntime RemoteViews AppWidgetProvider OpenMeteoBridge UnlockWeather"
```

Reproduce the black widget or unlock issue, stop the capture, and inspect the first exception/stack trace around the failure. Do not post a full bugreport publicly without checking it for personal data.
