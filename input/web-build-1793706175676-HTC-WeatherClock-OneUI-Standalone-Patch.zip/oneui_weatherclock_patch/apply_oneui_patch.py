#!/usr/bin/env python3
"""Apply the One UI / standalone-location patch to a checkout of BuksaPC/htc-honor-weather-flip-clock.

Usage:
  python3 apply_oneui_patch.py /path/to/htc-honor-weather-flip-clock

The script is intentionally strict: it stops rather than silently patching an unknown source version.
"""
from __future__ import annotations
import argparse
import re
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = Path("source/breezybridge/src/com/htc/widget/weatherclock/openmeteo")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit("PATCH ABORTED: " + message)


def replace_method(src: str, signature: str, replacement: str, file_label: str) -> str:
    # Java method's outer closing brace is the only line with exactly four spaces before '}'.
    pattern = re.compile(r"(?ms)^    " + re.escape(signature) + r" \{.*?^    \}")
    out, n = pattern.subn(replacement.rstrip(), src, count=1)
    require(n == 1, f"could not find exactly one method {signature!r} in {file_label}")
    return out


def replace_between(src: str, start: str, end: str, replacement: str, file_label: str) -> str:
    a = src.find(start)
    require(a >= 0, f"start marker not found in {file_label}: {start}")
    b = src.find(end, a + len(start))
    require(b >= 0, f"end marker not found in {file_label}: {end}")
    return src[:a] + replacement.rstrip() + "\n\n" + src[b:]


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="checkout of BuksaPC/htc-honor-weather-flip-clock")
    args = parser.parse_args()
    root = args.repo.resolve()
    require((root / ".git").exists() and (root / "source/breezybridge/src").is_dir(),
            "the target does not look like a checkout of htc-honor-weather-flip-clock")

    files = {name: root / PKG / name for name in [
        "StandaloneWeather.java", "UnlockWeather.java", "WeatherAnim.java",
        "BreezyWeather.java", "OpenMeteoBridge.java", "WeatherSettingsActivity.java"]}
    for p in files.values():
        if p.exists():
            shutil.copy2(p, p.with_suffix(p.suffix + ".oneui-backup"))

    # Stage all edits in memory first. Nothing is written until every expected source anchor is found.
    pending: dict[Path, str] = {
        files["StandaloneWeather.java"]: (HERE / "files/StandaloneWeather.java").read_text(encoding="utf-8"),
        files["UnlockWeather.java"]: (HERE / "files/UnlockWeather.java").read_text(encoding="utf-8"),
    }

    # WeatherAnim: return success/failure so unlock retry stops only after addView succeeds.
    p = files["WeatherAnim.java"]
    s = p.read_text(encoding="utf-8")
    overlay = r'''    /**
     * The animation over the home screen in an overlay window. Returns true only when the overlay
     * was successfully attached; UnlockWeather uses false to retry during the launcher transition.
     */
    static boolean playOverlay(Context app) {
        try {
            if (sOverlay != null) return true;
            int code = sShown >= 0 ? sShown : app.getSharedPreferences("breezy", 0).getInt("shown_condition", -1);
            if (code < 0) {
                org.json.JSONObject row = BreezyWeather.mainRow(app);
                code = row == null ? -1 : row.optInt("curConditionId", -1);
            }
            if (code < 0) {
                ClockLog.tick(app, "UNLOCK_WEATHER no weather yet");
                return false;
            }
            BreezyWeather.loadSunPlace(app);
            code = BreezyWeather.isDay(code < 33) ? toDay(code) : toNight(code);
            String name = sceneFor(app, code);
            if (name == null) return false;

            Display d = ((android.hardware.display.DisplayManager) app.getSystemService(Context.DISPLAY_SERVICE))
                    .getDisplay(Display.DEFAULT_DISPLAY);
            if (d == null) return false;
            final Context ctx = Build.VERSION.SDK_INT >= 30
                    ? app.createWindowContext(d, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null) : app;
            final WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return false;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            preferFastestRefresh(d, lp);
            final Player[] self = new Player[1];
            self[0] = new Player(ctx, null, BreezyWeather.animationSound(app) ? soundFor(code) : null,
                    tapped -> removeOverlay(wm, self[0]));
            wm.addView(self[0], lp);
            sOverlay = self[0];
            load(ctx, name, self[0], () -> removeOverlay(wm, self[0]));
            return true;
        } catch (Throwable th) {
            android.util.Log.w(BreezyWeather.TAG, "unlock animation failed", th);
            sOverlay = null;
            return false;
        }
    }'''
    s = replace_method(s, "static void playOverlay(Context app)", overlay, str(p))
    setup = r'''    /** Open the app's own weather/location settings (the standalone build has no Breezy dependency). */
    private static void setup(Activity a) {
        try {
            a.startActivity(new Intent(a, WeatherSettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
        a.finish();
        a.overridePendingTransition(0, 0);
    }'''
    s = replace_method(s, "private static void setup(Activity a)", setup, str(p))
    s = s.replace('Breezy " + state', 'weather source " + state')
    pending[p] = s

    # BreezyWeather becomes a compatibility adapter over the local Open-Meteo provider.
    p = files["BreezyWeather.java"]
    s = p.read_text(encoding="utf-8")
    s = replace_method(s, "static boolean installed(Context ctx)",
        '''    static boolean installed(Context ctx) { return true; }''', str(p))
    s = replace_method(s, "static boolean permitted(Context ctx)",
        '''    static boolean permitted(Context ctx) { return true; }''', str(p))
    s = replace_method(s, "static State state(Context ctx)",
        '''    static State state(Context ctx) {
        return StandaloneWeather.hasLocation(ctx) ? State.READY : State.NO_LOCATION;
    }''', str(p))
    s = replace_method(s, "static State quickState(Context ctx)",
        '''    static State quickState(Context ctx) {
        return StandaloneWeather.hasLocation(ctx) ? State.READY : State.NO_LOCATION;
    }''', str(p))
    hint = r'''    /** Shows a local setup hint when no location has been saved yet. */
    public static void setupHint(Context ctx, android.widget.RemoteViews rv) {
        try {
            State state = quickState(ctx);
            if (state == State.READY) {
                WeatherChange.apply(ctx, rv);
                alertLine(ctx, rv);
                dateClick(ctx, rv);
                WidgetForecast.apply(ctx, rv);
                return;
            }
            WidgetForecast.apply(ctx, rv);
            String pkg = ctx.getPackageName();
            int date = ctx.getResources().getIdentifier("week_date", "id", pkg);
            int block = ctx.getResources().getIdentifier("temp_info_block", "id", pkg);
            if (date != 0) rv.setTextViewText(date, "Tap to set your current location");
            Intent intent = new Intent().setClassName(ctx, WeatherSettingsActivity.class.getName())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(ctx, 0x8eef, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            if (block != 0) rv.setOnClickPendingIntent(block, pi);
            if (date != 0) rv.setOnClickPendingIntent(date, pi);
        } catch (Throwable t) {
            Log.w(TAG, "setup hint failed", t);
        }
    }'''
    s = replace_method(s, "public static void setupHint(Context ctx, android.widget.RemoteViews rv)", hint, str(p))
    s = replace_method(s, "static boolean open(Activity a)",
        '''    static boolean open(Activity a) {
        try {
            a.startActivity(new Intent(a, WeatherSettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return true;
        } catch (Exception e) { return false; }
    }''', str(p))
    s = replace_method(s, "static List<Place> places(Context ctx)",
        '''    static List<Place> places(Context ctx) { return StandaloneWeather.places(ctx); }''', str(p))
    s = replace_method(s, "static JSONObject weather(Context ctx, Place p)",
        '''    static JSONObject weather(Context ctx, Place p) { return StandaloneWeather.weather(ctx, p); }''', str(p))
    s = replace_method(s, "public static Cursor searchCities(Context ctx, String term)", r'''    public static Cursor searchCities(Context ctx, String term) {
        String[] cols = {"_id", "code", "name", "state", "country", "latitude", "longitude", "timezoneId"};
        MatrixCursor out = new MatrixCursor(cols);
        if (ctx == null) return out;
        List<Place> all = places(ctx), hits = new ArrayList<>();
        String query = term == null ? "" : term.trim().toLowerCase(Locale.ROOT);
        for (Place p : all) {
            String hay = (p.name + " " + p.state + " " + p.country).toLowerCase(Locale.ROOT);
            if (query.isEmpty() || hay.contains(query)) hits.add(p);
        }
        int id = 0;
        for (Place p : hits.isEmpty() ? all : hits) {
            out.addRow(new Object[]{id++, p.code(), p.name, p.state, p.country,
                    OpenMeteoBridge.formatCoord(p.lat), OpenMeteoBridge.formatCoord(p.lon), p.timezone});
        }
        return out;
    }''', str(p))
    s = s.replace('Breezy location', 'saved location').replace('Breezy Weather', 'Open-Meteo')
    pending[p] = s

    # The settings screen requests only foreground approximate location; no background location permission.
    p = files["WeatherSettingsActivity.java"]
    s = p.read_text(encoding="utf-8")
    old_resume = """    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshUnlockWeather();
    }"""
    new_resume = """    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshUnlockWeather();
        // Ask once on first setup, then refresh a stale fix only while this screen is foregrounded.
        if (StandaloneWeather.shouldRequestLocationPermission(this)) startLocationSetup();
        else if (StandaloneWeather.shouldAutoRefreshLocation(this)) refreshCurrentLocation();
    }"""
    require(old_resume in s, "WeatherSettingsActivity.onResume() was not found")
    s = s.replace(old_resume, new_resume, 1)
    s = s.replace('private static final String CURRENT_CITY = "Current City";',
                  'private static final String CURRENT_CITY = "Current City";\n    private static final int REQUEST_LOCATION = 2;')
    s = replace_method(s, "public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results)",
        '''    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (requestCode == REQUEST_LOCATION) {
            if (results != null && results.length > 0 && results[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                refreshCurrentLocation();
            } else {
                refreshStatus();
            }
            return;
        }
        WeatherNotification.update(this);
        RainWarning.check(this);
    }''', str(p))
    s = s.replace('header("Weather source");', 'header("Weather & location");')
    old_row = '''        mStatusAction = button("Set up", v -> startActivity(new Intent(this, ClockSetupActivity.class)));
        row.addView(mStatusAction);
        row.addView(button("Breezy settings", v -> openBreezySettings()));
        mList.addView(row);'''
    new_row = '''        mStatusAction = button("Set current location", v -> startLocationSetup());
        row.addView(mStatusAction);
        row.addView(button("Refresh weather", v -> {
            OpenMeteoBridge.requestSync(this, true);
            android.widget.Toast.makeText(this, "Weather refresh requested", android.widget.Toast.LENGTH_SHORT).show();
        }));
        mList.addView(row);'''
    require(old_row in s, "weather settings source row was not found")
    s = s.replace(old_row, new_row, 1)
    old_updates = '''        TextView upd = text("The widget follows Breezy. Set how often Breezy refreshes in Breezy → Settings → "
                + "Background updates. For instant updates, turn on Weather Clock Widget in Breezy → Settings → "
                + "External modules → Data sharing → Send Breezy Weather Location Update Notifier data. If Breezy says \\\"No "
                + "compatible packages found\\\", first allow the widget to read Breezy (Set up above) and open Breezy "
                + "from here once, then look again.", 14, false);'''
    new_updates = '''        TextView upd = text("Weather data is fetched directly from Open-Meteo (no account or API key). "
                + "Location is requested only when you press Set current location while this screen is open. "
                + "The coordinates are stored locally; background updates use the saved coordinates and cached "
                + "weather. No background-location permission or always-on GPS is used.", 14, false);'''
    require(old_updates in s, "Breezy update instructions were not found")
    s = s.replace(old_updates, new_updates, 1)
    s = s.replace('"Open Breezy Weather"', '"Open weather settings"')
    s = s.replace('Tapping the temperature always opens Breezy Weather.',
                  'Tapping the temperature opens the weather settings.')
    refresh = r'''    private void refreshStatus() {
        if (mStatus == null) return;
        BreezyWeather.State state = BreezyWeather.state(this);
        if (state == BreezyWeather.State.NO_LOCATION) {
            mStatus.setText("No location saved. Set your current location to start the weather widget.");
        } else {
            long at = BreezyWeather.lastSync(this);
            long ago = System.currentTimeMillis() - at;
            mStatus.setText("Open-Meteo · " + StandaloneWeather.locationSummary(this)
                    + (at <= 0 ? "" : ago < DateUtils.MINUTE_IN_MILLIS ? " · updated just now"
                    : " · updated " + DateUtils.getRelativeTimeSpanString(at, System.currentTimeMillis(),
                    DateUtils.MINUTE_IN_MILLIS)));
        }
        mStatusAction.setText(StandaloneWeather.hasCurrentLocation(this) ? "Refresh location" : "Set current location");
        mStatusAction.setOnClickListener(v -> startLocationSetup());
    }

    private void startLocationSetup() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            StandaloneWeather.markLocationPermissionPrompted(this);
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
            return;
        }
        refreshCurrentLocation();
    }

    private void refreshCurrentLocation() {
        if (mStatus != null) mStatus.setText("Finding current location…");
        StandaloneWeather.requestCurrentLocation(this, (success, message) -> {
            if (success) OpenMeteoBridge.requestSync(this, true);
            refreshStatus();
            if (!success) android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show();
        });
    }'''
    s = replace_method(s, "private void refreshStatus()", refresh, str(p))
    pending[p] = s

    # OpenMeteoBridge: catch provider-query failures and serialize sync scheduling to prevent the cold-start race.
    p = files["OpenMeteoBridge.java"]
    s = p.read_text(encoding="utf-8")
    s = s.replace('    private static volatile boolean sSyncing;\n',
                  '    private static final Object SYNC_STATE_LOCK = new Object();\n'
                  '    private static volatile boolean sSyncing;\n'
                  '    private static volatile boolean sSyncScheduled;\n', 1)
    query = r'''    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        String path = uri == null ? "" : pathOf(uri);
        try {
            if (path.startsWith("locationlist")) return queryLocationList(projection, selection);
            if ("setting".equals(path)) return querySettings(projection, selection, args);
            if ("location".equals(path)) return toCursor(loadArray(KEY_LOCS), locationColumns(), projection, selection, args);
            if ("data".equals(path) || (uri != null && SYNC_AUTHORITY.equals(uri.getAuthority()))) {
                if (System.currentTimeMillis() - sLastSyncMs > STALE_MS) requestSync(ctx());
                return toCursor(loadArray(KEY_DATA), dataColumns(), projection, selection, args);
            }
            return toCursor(loadArray(KEY_LOCS), locationColumns(), projection, selection, args);
        } catch (Throwable t) {
            // Never let a transient source/provider error escape a launcher widget query. Return a valid,
            // empty cursor so the launcher can keep the existing RemoteViews instead of replacing it black.
            Log.w(TAG, "provider query failed for " + path, t);
            String[] columns = projection != null && projection.length > 0 ? projection.clone()
                    : "setting".equals(path) ? settingColumns()
                    : "location".equals(path) || path.startsWith("locationlist") ? locationColumns() : dataColumns();
            for (int i = 0; i < columns.length; i++) if (columns[i] == null) columns[i] = "_empty_" + i;
            return new MatrixCursor(columns);
        }
    }'''
    s = replace_method(s, "public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort)", query, str(p))
    request = r'''    static void requestSync(Context context, boolean force) {
        if (context == null) return;
        long now = System.currentTimeMillis();
        synchronized (SYNC_STATE_LOCK) {
            if (sSyncing || sSyncScheduled) {
                if (force) sSyncAgain = true;
                return;
            }
            if (!force && now - sLastSyncMs < MIN_SYNC_INTERVAL_MS) return;
            sLastSyncMs = now;
            sSyncScheduled = true;
        }
        final Context app = context.getApplicationContext() != null ? context.getApplicationContext() : context;
        try {
            new Thread(() -> syncAll(app), "weather-sync").start();
        } catch (Throwable t) {
            synchronized (SYNC_STATE_LOCK) { sSyncScheduled = false; }
            Log.w(TAG, "could not start weather sync", t);
        }
    }'''
    s = replace_method(s, "static void requestSync(Context context, boolean force)", request, str(p))
    syncall = r'''    static void syncAll(Context context) {
        if (context == null) return;
        synchronized (SYNC_STATE_LOCK) {
            if (sSyncing) {
                sSyncScheduled = false;
                sSyncAgain = true;
                return;
            }
            sSyncScheduled = false;
            sSyncing = true;
        }
        try {
            synchronized (SYNC_LOCK) {
                OpenMeteoBridge bridge = new OpenMeteoBridge();
                bridge.mAttached = context;
                bridge.syncFromBreezy();
            }
        } catch (Throwable t) {
            Log.w(TAG, "weather sync failed: " + t.getClass().getSimpleName());
            synchronized (SYNC_STATE_LOCK) { sLastSyncMs = 0L; }
        } finally {
            synchronized (SYNC_STATE_LOCK) { sSyncing = false; }
        }
        boolean again;
        synchronized (SYNC_STATE_LOCK) {
            again = sSyncAgain;
            sSyncAgain = false;
        }
        if (again) requestSync(context, true);
    }'''
    s = replace_method(s, "static void syncAll(Context context)", syncall, str(p))
    s = s.replace('new Thread(() -> syncAll(app), "breezy-sync")', 'new Thread(() -> syncAll(app), "weather-sync")')
    s = s.replace('Breezy Weather not ', 'weather source not ').replace('Breezy Weather has no locations', 'No saved weather locations')
    s = s.replace('synced " + out.length() + " rows from Breezy:', 'synced " + out.length() + " rows from Open-Meteo:')
    pending[p] = s

    # Manifest: internet + foreground approximate location; no Breezy provider permission/receiver.
    manifest_tool = root / "source/tools/breezy_manifest.py"
    ms = manifest_tool.read_text(encoding="utf-8")
    # Bump package versionCode so Android accepts this as an upgrade over v1.2.9-breezy.
    backup_line = "set_bool(a.find('application')[0], 'allowBackup', False)\n"
    require(backup_line in ms, "allowBackup manifest patch anchor was not found")
    version_code_patch = backup_line + "\n# Standalone One UI release: increment past the v1.2.9-breezy package version.\n" + \
        "def set_int(i, attr_name, value):\n" + \
        "    for at in a.nodes[i].attrs:\n" + \
        "        if a.s(at[1]) == attr_name:\n" + \
        "            at[2], at[5], at[6] = 0xFFFFFFFF, 0x10, value  # TYPE_INT_DEC\n" + \
        "            return\n" + \
        "    raise KeyError(attr_name)\n\n" + \
        "set_int(a.find('manifest')[0], 'versionCode', 663091324)\n"
    ms = ms.replace(backup_line, version_code_patch, 1)
    ms = ms.replace("    'android.permission.INTERNET',\n    'android.permission.ACCESS_COARSE_LOCATION',\n", "")
    ms = ms.replace("rename('com.hihonor.android.totemweather', 'org.breezyweather')\n", "")
    read_perm = '''perm = a.element('uses-permission', [('name', 'org.breezyweather.READ_PROVIDER')])
last = a.find('uses-permission')[-1]
a.nodes[a.end_of(last) + 1:a.end_of(last) + 1] = perm

'''
    require(read_perm in ms, "Breezy READ_PROVIDER manifest block was not found")
    ms = ms.replace(read_perm, "", 1)
    notifier = '''receiver = a.element('receiver', [('name', OPENMETEO + 'BreezyUpdateReceiver'), ('exported', True)], [
    a.element('intent-filter', [], [a.element('action', [('name', 'org.breezyweather.ACTION_UPDATE_NOTIFIER')])])])
a.insert_before_end(a.find('application')[0], receiver)

'''
    require(notifier in ms, "Breezy update notifier manifest block was not found")
    ms = ms.replace(notifier, "", 1)
    marker = "for perm in DROP_PERMISSIONS:\n    for i in a.find('uses-permission', name=perm):\n        a.remove(i)\n"
    additions = marker + '''
# Breezy is no longer queried; remove its package-visibility entry.
for package_name in ['com.hihonor.android.totemweather', 'org.breezyweather']:
    for node in a.find('package', name=package_name):
        a.remove(node)

# Standalone Open-Meteo source: network plus approximate foreground location only.
for name in ['android.permission.INTERNET', 'android.permission.ACCESS_COARSE_LOCATION']:
    if not a.find('uses-permission', name=name):
        perm = a.element('uses-permission', [('name', name)])
        last = a.find('uses-permission')[-1]
        a.nodes[a.end_of(last) + 1:a.end_of(last) + 1] = perm
'''
    require(marker in ms, "permission insertion point was not found")
    ms = ms.replace(marker, additions, 1)
    ms = ms.replace("rename('10.10.1059527-android36-v1.2.4', '10.10.1059527-android36-v1.2.9-breezy')",
                "rename('10.10.1059527-android36-v1.2.4', '10.10.1059527-android36-v1.3.0-oneui')")
    pending[manifest_tool] = ms

    build = root / "source/build-breezy.sh"
    bs = build.read_text(encoding="utf-8")
    bs = bs.replace("HTC-WeatherClock-v1.2.9-breezy$SUFFIX.apk", "HTC-WeatherClock-v1.3.0-oneui$SUFFIX.apk")
    pending[build] = bs

    for target, content in pending.items():
        write(target, content)

    print("One UI patch applied.")
    print("Backups are saved next to each changed Java source as *.oneui-backup.")
    print("Next: inspect the changes, then run source/build-breezy.sh in the original build environment.")

if __name__ == "__main__":
    main()
