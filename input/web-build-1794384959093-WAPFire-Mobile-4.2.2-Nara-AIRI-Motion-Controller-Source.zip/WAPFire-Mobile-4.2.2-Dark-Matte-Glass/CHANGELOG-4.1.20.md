# WAPFire Mobile 4.1.20 — AndroidForge Kotlin Build Fix

- Fixed the Compose `border` import in `AssistantPreviewScreen`.
- Replaced the invalid WebSettings `supportZoom` property assignment with `setSupportZoom(false)`.
- Kept the offline LivLiv renderer, model assets, Overview assistant card, and state mapping unchanged.
- Version code: 61.
