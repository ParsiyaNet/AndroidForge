# WAPFire Mobile 4.1.17 — Anime Assistant Prototype

## Added
- Added a dedicated Assistant Preview screen, accessible from the initial discovery screen and from a persistent Assistant dashboard tab after login/session restore.
- Added five original, locally bundled character poses: Idle, Scanning, Connecting, Success, and Warning.
- Added cross-fade expression changes, a subtle breathing motion, animated accent colors, speech text per state, manual state selectors, and an Auto Demo mode.
- Added English and Persian UI text for the preview.
- Character art is bundled in the APK; the preview requires no network, camera, or microphone access.

## Preserved
- Existing Wi-Fi discovery, Smart Join, remembered credentials, Wi-Fi Keep Alive, and device dashboard flows are not intentionally changed.

## Prototype scope
This is a native Compose visual/interaction prototype using original generated character poses. It does not yet embed the LivLiv WebGL2 renderer or use a rigged `.livliv` model. The purpose is to validate the character direction, state mapping, and screen layout on the target phone before committing to the WebView/LivLiv integration.
