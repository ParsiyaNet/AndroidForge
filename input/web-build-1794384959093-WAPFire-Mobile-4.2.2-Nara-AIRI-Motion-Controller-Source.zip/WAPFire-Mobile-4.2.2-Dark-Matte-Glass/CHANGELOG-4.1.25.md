# WAPFire Mobile 4.1.25

## LivLiv first-frame rendering fix
- Start LivLiv with autoplay disabled while the Compose-hosted WebView settles its layout.
- Wait for a non-zero canvas size before creating WebGL.
- Re-measure the canvas after the model finishes loading.
- Force a synchronous first render with `player.resize()` and `gl.finish()`.
- Verify the WebGL framebuffer contains visible alpha pixels before reporting READY to Android.
- Start the animation loop only after the first frame is verified.
- Keep the cover image visible as fallback if first-frame rendering fails.
- Put the WebGL canvas explicitly above the fallback poster.

Version: 4.1.25 (versionCode 66).
