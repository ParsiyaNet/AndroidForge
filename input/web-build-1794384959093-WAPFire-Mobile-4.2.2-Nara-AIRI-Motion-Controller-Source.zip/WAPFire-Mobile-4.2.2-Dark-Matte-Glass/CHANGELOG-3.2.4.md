# WAPFire Mobile 3.2.4

- Reworked global success/error notices into a detached Compose Popup. The notification is width-bounded, limited to three lines, and cannot affect scrollable page measurement.
- Tightened target AP selection to exact BSSID matching. Setup and Settings prune stale / sibling AP scan results after selection; choosing another AP or clearing the target resets the scan list deliberately. Settings also prevents repeated target-selection taps from racing each other.
- Added BSSID format and supported-channel validation before target selection.
- Kept equal-width 24-hour native time selectors for Schedule Start / End and clarified that the picker supports direct keyboard entry.
- Added app-side Schedule validation: an enabled schedule requires at least one weekday, and Start / End must differ (the supplied VF38 scheduler treats equal times as an always-active interval).
- Added an in-app warning for overnight schedules because the supplied firmware checks the weekday mask again after midnight.
- Cleaned up the Android Wi-Fi network request and readiness polling after connection failures or link loss, preventing stale callbacks from lingering across retries.
- Improved weekday abbreviations and time field labels for a more consistent compact layout.
- No firmware source, RF detection, WPA2, WPA3, or radio behavior was modified.

Build status: source edits and static checks completed. A full Android Gradle build and physical-device validation could not be performed in this environment because the Gradle wrapper distribution cannot be downloaded and no Android SDK is configured.
