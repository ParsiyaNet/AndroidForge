# WAPFire Mobile 4.1.52 — Dark Bottom Navigation Matte Refinement

The dark-theme bottom navigation pill is slightly more opaque for improved label readability while retaining its frosted-glass appearance. The light theme and all other app behavior remain unchanged. See `CHANGELOG-4.1.52.md` and `VALIDATION-4.1.52.txt`.
