# WAPFire Mobile 4.1.8 — AndroidForge Kotlin DSL build fix

## Diagnosis

AndroidForge run 41995405329 failed while compiling the app Gradle Kotlin DSL, before Kotlin source compilation. Kotlin 2.3.0 rejects the old `android.kotlinOptions { jvmTarget = "17" }` setter and requires the typed `compilerOptions` DSL.

## Fix

- Imported `org.jetbrains.kotlin.gradle.dsl.JvmTarget`.
- Removed the legacy `android.kotlinOptions` block.
- Added `kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }`.
- Kept Java source and target compatibility at 17 so Java and Kotlin bytecode targets remain aligned.
- Bumped app version to 4.1.8 / versionCode 49.

## Verification scope

Static checks confirm the old DSL is absent, the typed Kotlin compiler option is present, both Java compatibility values remain 17, and the Kotlin Android/Compose plugins remain on 2.3.0. The Android SDK and Gradle executable are not installed in this container, so a full Gradle/APK build is not claimed. AndroidForge remains the definitive build check.
