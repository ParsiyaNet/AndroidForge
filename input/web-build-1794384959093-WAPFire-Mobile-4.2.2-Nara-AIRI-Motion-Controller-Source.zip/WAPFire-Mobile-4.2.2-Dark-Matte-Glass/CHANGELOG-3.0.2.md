# WAPFire Mobile 3.0.2

## Build fix
- Fixed the color-picker composable call in `ColorPickerDialog`: the call now uses the actual `SaturationValueColorPicker` function declared in `MainActivity.kt`.
- This resolves the reported `Unresolved reference: BoxWithConstraintsColorPicker` Kotlin compiler error and the cascading lambda parameter inference errors at the same call site.
- No firmware/API behavior was changed in this Android-only build fix.

Build version: `3.0.2` (versionCode `9`).
