# WAPFire Mobile 3.2.12 — Focused code review

## Root cause addressed
The 3.2.11 join path retained its first `WifiNetworkSpecifier` callback, but did not reliably rebuild the request if Android removed it after the phone Wi-Fi radio was toggled. In addition, the Current Network watcher depended on BSSID data that Android 12+ redacts from callback `NetworkCapabilities` unless `FLAG_INCLUDE_LOCATION_INFO` is requested.

## Implementation
- `WifiDiscovery.kt` now owns a cancellable reconnect scheduler for the WifiNetworkSpecifier path. After a lost link it allows a short grace period for Android to restore the original request; if not, it unregisters the stale callback and re-submits the exact SSID+BSSID request.
- While phone Wi-Fi is disabled, the scheduler waits; once enabled, it submits a pending local-only request without an arbitrary timeout. `onUnavailable` after a previously established connection enters recovery with backoff rather than treating the session as a first-join failure.
- The Current Network watcher opts into location-sensitive transport info on API 31+ and matches the returned BSSID. Its request accepts local-only Wi-Fi and processes callback-provided capabilities.
- `release()` cancels both callback types and all pending timers.

## Scope
Only the Android Wi-Fi discovery/connection module and app version metadata changed. Firmware source is byte-for-byte unchanged.

## Verification
Static source checks and archive integrity checks performed. No full Gradle build, APK build, or physical phone test was available in this environment.
