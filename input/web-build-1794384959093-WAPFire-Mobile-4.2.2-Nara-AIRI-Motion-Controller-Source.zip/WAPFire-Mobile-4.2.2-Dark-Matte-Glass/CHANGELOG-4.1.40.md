# WAPFire Mobile 4.1.40

## Main-document loading recovery
- The 4.1.39 on-device screenshot showed the new bootstrap marker but no `#stage` or `#loading` elements in the active document.
- The native WebView now reads `assistant/assistant-live.html` directly from APK assets and loads it with `loadDataWithBaseURL` under the existing `https://appassets.androidplatform.net/assets/assistant/assistant-live.html` base URL.
- ES modules, the LivLiv package and textures remain same-origin local resources served by `WebViewAssetLoader`.
- The packaged HTML is checked for both required DOM elements before loading.
- Removed global WebView cache clearing; `LOAD_NO_CACHE` remains enabled.
- Added document path, DOM-child count and HTML build metadata to native startup diagnostics.
- Existing UI, Overview speech/RTL, Assistant full-screen layout, and model assets are preserved.

## Build metadata
- Version name: 4.1.40
- Version code: 81
