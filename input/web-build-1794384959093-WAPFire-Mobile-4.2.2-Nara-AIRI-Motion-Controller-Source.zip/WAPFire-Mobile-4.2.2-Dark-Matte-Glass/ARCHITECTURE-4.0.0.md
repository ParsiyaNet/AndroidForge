# WAPFire Mobile 4.0.0 — source architecture

```text
app/src/main/java/io/wapfire/mobile/
├── MainActivity.kt                 Android entry point only
├── model/
│   └── AppModels.kt                UI models, telemetry parsing, labels, helpers
├── network/
│   ├── WapFireApi.kt               Serialized HTTP client and typed HTTP errors
│   ├── WapFireSessionManager.kt    Identity verification and bounded session recovery
│   ├── WifiDiscovery.kt            Scan, current-network and device-host discovery
│   └── WifiConnector.kt            Network binding, join callbacks and reconnect lifecycle
├── security/
│   └── DeviceLoginVault.kt         Android Keystore AES-GCM saved credentials
└── ui/
    ├── WapFireApp.kt               App composition and action orchestration
    ├── components/
    │   └── UiComponents.kt         Shared visual primitives
    └── screens/
        ├── DiscoveryAndSetupScreens.kt
        ├── DashboardScreens.kt
        └── SettingsScreens.kt
```

## Session recovery sequence

1. A normal authenticated `/api/status` request fails.
2. Only a typed HTTP `401` starts session recovery; a timeout or other HTTP status is treated as a connectivity/server problem and does not sign the user out.
3. The app requests `/` without sending the old cookie. VF38 serves the `WAPFire - Authentication` page when the current remote-IP session is not valid.
4. Only after this identity check succeeds does the app submit the existing in-memory credentials to `/login`.
5. It retries `/api/status` once. If successful, the same tab and cached UI remain active. If credentials are rejected/rate-limited, the app shows Login.
6. Write operations are not replayed because an ambiguous timeout/401 must not duplicate a configuration change, restore, OTA, or device action.

## Important firmware constraint

VF38 maps `activeSessions` and `sessionTokens` by `server.client().remoteIP().toString()`. A changed phone-side IP can therefore invalidate an otherwise unchanged cookie. The mobile app handles this by verifying the device and establishing a fresh session; this release does not change firmware authentication semantics.
