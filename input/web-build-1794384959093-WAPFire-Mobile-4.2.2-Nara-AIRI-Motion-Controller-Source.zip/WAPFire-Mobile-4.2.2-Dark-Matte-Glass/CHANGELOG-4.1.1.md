# WAPFire Mobile 4.1.1 — AndroidForge compile hotfix

This patch release fixes the Kotlin compile blocker reported by AndroidForge for 4.1.0 and removes duplicate test-only JSON stub declarations.

## Build fixes

- Removed the invalid standalone `androidx.compose.runtime.onDispose` import. `onDispose { ... }` remains correctly used inside the `DisposableEffect` receiver scope.
- Consolidated the test-only `org.json` stubs into one shared source file so AndroidForge no longer detects duplicate `JSONObject` declarations.
- Updated both JVM test runners to use the shared stub.
- Updated Android version metadata to `4.1.1` / `versionCode 42`.

## Background monitor


## Background attack notifications

- Added an explicitly user-started Android foreground service (`connectedDevice`) so monitoring continues after the Activity is closed or swiped from Recents.
- Added a persistent, low-importance monitoring notification with a Stop action, plus a separate high-importance security-alert channel.
- The service polls only the authenticated VF38 `/api/status` and `/api/logs` endpoints; it does not refresh the dashboard or issue configuration writes in the background.
- Security events are deduplicated by a persisted SHA-256 signature. Firmware event IDs are combined with timestamp/type/context so an ID reused after a reboot does not suppress a new event.
- The first log snapshot is used as a baseline. Existing historical entries are not replayed as fresh notifications when monitoring starts.
- Threat notifications cover the existing WAPFire event families: Auth Attack, Deauth Attack, Deauth Airplay, WPS Pixie Reaver, WPS Pixie Bully, Evil Twin, and WPA Wrong Password. WPA Correct Password and ordinary client disconnect/system records do not generate threat notifications.
- A connected Wi-Fi `Network` must first serve the WAPFire VF38 authentication page before stored credentials are sent. The monitor binds its API traffic to that verified Wi-Fi network and can rediscover the SoftAP after a network loss.
- The Activity and foreground service share one process-wide VF38 session cookie and a single API request queue. The firmware stores one active token per client IP; independent Activity/service logins would otherwise invalidate each other. Recovery login reuses a still-present shared cookie and performs a single new login only after a 401 clears the stale token.
- Saved credentials remain AES-GCM encrypted with the Android Keystore. If secure saving is not enabled, the app asks for consent before enabling background sign-in.
- Explicit app logout, disabling Remember Password, the Overview switch, or the notification Stop action stops the service.
- Android 13+ notification permission is requested before monitoring starts. `FOREGROUND_SERVICE_CONNECTED_DEVICE` and `WAKE_LOCK` declarations were added. While opted in, the service holds a partial CPU wake lock and a Wi-Fi low-latency lock to reduce screen-off suspension; both are released when monitoring stops.
- The Overview page now links to Android's battery-optimization settings. For reliable polling during idle, set WAPFire to Unrestricted / Don't optimize. Doze can suspend background network access even when a foreground service is running; vendor-specific battery managers may impose additional limits.

## Implementation details

- `monitor/BackgroundMonitorService.kt`: foreground service, Wi-Fi network tracking, identity verification, session renewal, bounded event polling, status and threat notifications.
- `monitor/MonitorEventPolicy.kt`: threat classification, human-readable notification labels, stable event signatures.
- `monitor/MonitorStopReceiver.kt`: explicit Stop action from the ongoing notification.
- `WapFireApi.logs()` now accepts a separate connection timeout as well as a read timeout; existing call sites retain their prior defaults.
- The monitor polls at a nominal five-second interval, with an 8-second event-log read timeout and 3.5-second connection timeout.

## Limitations

- This release does not start the service automatically after a phone reboot. The user must reopen WAPFire and start monitoring again.
- Android Force stop, user stopping the app from Android's Active Apps/Task Manager screen, revoked notification permission, Wi-Fi disconnection, and manufacturer-specific power controls can stop or delay monitoring.
- The monitor can only notify about events that remain available from the firmware `/api/logs` endpoint. Events lost from the firmware's rolling log while the phone is disconnected cannot be reconstructed by the mobile app.
- This is a source release. A full Android APK build and physical VF38/phone acceptance test were not possible in the build environment; see `VALIDATION-4.1.1.txt`.
