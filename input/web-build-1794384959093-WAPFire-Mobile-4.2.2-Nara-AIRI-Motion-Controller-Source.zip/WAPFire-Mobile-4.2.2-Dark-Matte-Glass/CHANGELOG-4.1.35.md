# WAPFire Mobile 4.1.35

## Refine Sena Overview and Assistant layout / language

- Overview character frame now fills the same inner width as the native speech panel.
- Reduced the vertical gap between Sena and the speech panel from 8dp to 3dp.
- Adjusted Overview model zoom from 1.52 to 1.38 so the top of Sena's hair/head remains fully visible in the short landscape preview frame. The model aspect ratio is unchanged.
- Fixed reversed English/Persian arguments in `overviewAssistantMessage`; the speech now follows the app language correctly.
- Added explicit end alignment for Persian speech/header text, with a localized Persian header.
- Removed the EN/FA language switch from the full-screen Assistant; language remains controlled from the app's regular language setting.
- Kept the theme toggle and exit action, with greater inset from the edges.
- Increased the Assistant state-control strip side insets from 12px to 22px (16px on narrow screens).
- Localized Assistant state-control labels in Persian and English.

Version: 4.1.35 (versionCode 76).
