# WAPFire Mobile 2.3.0

## Interface and navigation
- Removed the standalone Target navigation tab.
- Moved target status, scan, select and clear actions into Settings → Monitoring & Target.
- Reorganized settings into Monitoring & Target, Protection, Device Feedback, Connectivity, Device Status, App Experience and Session groups.
- Replaced flat opaque cards with translucent layered glass-style panels, subtle edge highlights, soft shadows and ambient background lighting.
- Applied the same surface treatment to dashboard cards, event rows, client cards, settings panels and navigation.

## Threat labels
The display names are mapped from VF38 firmware labels and log event types:
- `auth_attack` → **Auth Attack**
- `deauth` / `deauth_attack` → **Deauth Attack**
- `deauth_airplay` → **Deauth Airplay**
- `wps_pixie_reaver` → **WPS Pixie Reaver**
- `wps_pixie_bully` → **WPS Pixie Bully**
- `evil_twin` → **Evil Twin**
- `correct_password` → **WPA Correct Password**
- `wrong_password` → **WPA Wrong Password**

Event titles, dashboard labels and visible detail strings are humanized; technical IDs are not used as the primary event title.

## Behavior fixes
- Added automatic expiry for transient success and error banners; the close action now clears both active message states.
- Added a real firmware `/logout` request and cleared the in-memory cookie, passwords, loaded logs/clients/targets and local network binding at logout.
- Target selection now performs both `/api/select_target` and `/api/save_target`, so the chosen SSID/BSSID/channel is persisted instead of only applied to the current runtime.
- Target clearing continues to use the firmware's empty-SSID branch of `/api/select_target`, which also removes saved target preferences.
- Network scan failures are surfaced as errors instead of silently presenting an empty result.

## Scope note
This version improves the native core monitoring workflow. It does not claim that advanced firmware tools (Ethernet/NTP/schedule/MikroTik/whitelist/backup/OTA) have native forms yet.
