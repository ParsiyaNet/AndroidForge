# WAPFire Mobile 4.1.24

## LivLiv renderer startup fix
- Load the main HTML document through the real `appassets.androidplatform.net` WebViewAssetLoader HTTPS origin.
- Serve APK assets with explicit MIME types, including `text/javascript` for `.js` and `.mjs` ES modules.
- Replace static top-level ES module startup with a catchable dynamic import so module fetch, MIME, syntax, and dependency failures are reported.
- Add asset probes for the LivLiv engine bundle, its first chunk, and the character package.
- Explicitly request a hardware-accelerated WebView layer for WebGL2.
- Preserve external-network blocking; only the packaged `/assets/` path on the appassets origin is served.

Version: 4.1.24 (versionCode 65).
