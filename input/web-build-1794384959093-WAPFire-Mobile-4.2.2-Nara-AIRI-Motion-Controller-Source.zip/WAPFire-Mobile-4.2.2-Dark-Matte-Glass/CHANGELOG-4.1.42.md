# WAPFire Mobile 4.1.42

## LivLiv DOM recovery
- Moved the assistant bootstrap script to the end of the HTML body, so the shell, stage, canvas and loading node are parsed before the renderer bootstrap runs.
- Added local DOM recovery: if WebView exposes a partial body/shell without `canvas#stage` or `#loading`, the bootstrap reconstructs the missing nodes from bundled HTML/CSS without a network request.
- Added a bounded retry and direct requestAnimationFrame startup before importing the local LivLiv module; it no longer relies on a one-shot DOMContentLoaded listener.
- Native WebView callbacks now ignore non-assistant navigations such as `about:blank`, preventing disposal/navigation events from being mistaken for assistant page readiness.
- Kept `loadUrl()` on the `appassets.androidplatform.net` virtual HTTPS origin; HTML, JavaScript, `.livliv` model and texture assets remain APK-local.

## Build metadata
- Version name: 4.1.42
- Version code: 83

## Verification limits
- APK contents and all local assistant assets were inspected from the supplied 4.1.41 APK.
- JavaScript syntax and HTML structure checks are run for this source package.
- A new APK and on-device Android WebView runtime test were not performed in this environment.
