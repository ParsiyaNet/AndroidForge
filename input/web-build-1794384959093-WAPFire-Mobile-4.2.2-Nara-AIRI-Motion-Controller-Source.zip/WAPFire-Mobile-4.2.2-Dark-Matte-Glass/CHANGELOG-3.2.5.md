# WAPFire Mobile 3.2.5

- Updated Discovery to a single-selected-AP flow: after an AP is selected, the remaining nearby AP list is hidden and only the selected network remains visible.
- Automatically scrolls the selected Wi-Fi connection card into view; secured networks focus the password field and open the keyboard. A dedicated “Choose another network” action clears the selection and restores the scan list.
- Replaced the translucent Toast/notice fill with an opaque theme surface and a higher-contrast status border for improved readability.
- Added the FA / EN language switch to the Initial Setup header.
- Matched the language and Dark / Light controls at exactly 36 × 36 dp.
- No WAPFireVF38 firmware, radio scanning, RF detection, or WPA behavior was changed.

Build status: source-level updates and static structure checks completed. A full Android Gradle build and physical-device validation were not available in this environment because no Android SDK is configured and the Gradle 8.9 wrapper distribution is not cached.
