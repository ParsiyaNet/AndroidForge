# WAPFire Mobile 4.1.41

## Offline Assistant document-load recovery
- Reverted the main Assistant document loading path to the known working 4.1.34 pattern: `loadUrl(https://appassets.androidplatform.net/assets/assistant/assistant-live.html...)`.
- Removed `loadDataWithBaseURL`. On the affected Android WebView, that API surfaced a `data:text/html` main document, while the app's strict request interceptor correctly rejected all non-`appassets.androidplatform.net` URLs. This caused the WebView error page shown in the 4.1.40 screenshot.
- Kept the strict allow-list: only the virtual HTTPS appassets origin is served; non-local requests are rejected.
- Kept the HTML, ES module, engine chunks, `.livliv` model package and cover image inside APK assets.
- Added a uniquely named local bootstrap file `assistant-preflight-4.1.41.js` and cache-versioned module URL.
- Added an explicit preflight check for the packaged HTML, bootstrap, engine, model and cover before loading the page.
- Retained the UI, speech panel, RTL/LTR selection and Assistant controls from 4.1.40.

## Offline guarantee
The character renderer does not need Internet access. Its HTML, JavaScript, LivLiv package and textures are loaded from APK assets through `WebViewAssetLoader` on the local virtual HTTPS origin. The app still retains its Internet permission for unrelated network/device functions, but external WebView requests are rejected.

## Build metadata
- Version name: 4.1.41
- Version code: 82
