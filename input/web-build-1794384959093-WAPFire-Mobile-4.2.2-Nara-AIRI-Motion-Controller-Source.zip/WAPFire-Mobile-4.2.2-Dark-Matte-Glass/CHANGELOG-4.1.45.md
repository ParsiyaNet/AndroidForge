# WAPFire Mobile 4.1.45

## Character
- Replaced Sena (`k01`) with Mira (`v03`) from livliv-dev/player (LivLiv featured character).
- Packaged `characters/v03.livliv` (same package layout as before) and `characters/v03/cover.webp`; removed `k01.livliv` and `k01/cover.webp` from the APK assets.
- Mira uses the same 1024x1536 canvas and the same expression set (smile, shy, angry, sad) as Sena, so the state/expression mapping, zoom (1.18) and the 300dp Overview frame are unchanged.
- Renamed UI labels: "Mira is watching your network" / "MIRA · WAPFIRE ASSISTANT" and the Persian equivalents.
- Updated Settings > Character credits, NOTICE.txt and ATTRIBUTION.txt to Mira (v03). Same LivLiv Featured Characters License: personal, non-commercial use with credit "Characters: LivLiv (livliv.ai)".

## Build metadata
- Version name: 4.1.45
- Version code: 86
- Bootstrap renamed to `assistant-preflight-4.1.45.js`.

## Verification limits
- Static checks only (all texture references in Mira's model.json exist, package zip integrity, version/asset references). No Android device or SDK here; build and check the Overview and Assistant tab on a device. Mira's hair/ribbon framing at zoom 1.18 was judged from her cover image, not rendered.
