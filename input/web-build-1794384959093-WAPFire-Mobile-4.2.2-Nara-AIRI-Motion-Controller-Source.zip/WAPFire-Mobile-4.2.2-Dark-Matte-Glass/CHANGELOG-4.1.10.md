# WAPFire Mobile 4.1.10 — Remembered SoftAP Wi-Fi password

- Scan Nearby Devices now checks for a previously saved WAPFire SoftAP passphrase by BSSID.
- If found, the password is prefilled and no password re-entry is needed. If absent, the password field remains empty and the user is prompted as before.
- The passphrase is saved only after Android joins the selected WAPFire AP and the app verifies the WAPFire WebUI endpoint.
- SoftAP credentials are encrypted with AES-256-GCM; the encryption key is held in Android Keystore. Plaintext passphrases are never written to preferences.
- A remembered passphrase is cleared when Android explicitly reports an authentication failure, allowing the user to enter the updated password.
- Existing 4.1.9 remembered device-login/session restore behavior and all other app features are retained.
