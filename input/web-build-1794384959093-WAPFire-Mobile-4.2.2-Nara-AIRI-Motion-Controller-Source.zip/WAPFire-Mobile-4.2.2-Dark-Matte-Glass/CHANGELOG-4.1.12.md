# WAPFire Mobile 4.1.12 — Android Saved Wi-Fi Auto-Join First

- Changed the Join flow to give Android's own saved-network auto-connect behavior first priority.
- The app now waits for the exact selected WAPFire BSSID to become the active Wi-Fi connection and then proceeds to the WebUI without creating a `WifiNetworkSpecifier` request.
- The Wi-Fi password field and keyboard remain hidden during this first attempt.
- If Android does not auto-join within 15 seconds, the app reveals a password fallback. A password remembered by the app is tried automatically; otherwise the user enters it once and it is saved with the existing Android Keystore-backed vault after WAPFire identity verification.
- Existing direct `WifiNetworkSpecifier` joining remains as the explicit-password fallback for Android versions that do not auto-connect the saved network.
- Version code: 53.

## Platform limitation
Android 10+ does not let ordinary apps list saved Wi-Fi profiles or call the legacy `enableNetwork()` / `addNetwork()` APIs. This release therefore relies on Android's own auto-connect policy for phone-saved credentials, rather than attempting to extract them.
