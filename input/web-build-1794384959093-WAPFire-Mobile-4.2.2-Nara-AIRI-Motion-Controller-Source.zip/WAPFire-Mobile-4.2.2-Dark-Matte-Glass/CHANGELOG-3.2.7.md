# WAPFire Mobile 3.2.7 — Compose build compatibility

- Added `@OptIn(ExperimentalFoundationApi::class)` to `DiscoveryScreen`, covering its `BringIntoViewRequester`, `bringIntoView()` and `bringIntoViewRequester()` usages.
- Fixes the six Kotlin compiler diagnostics reported by AndroidForge at MainActivity.kt lines 1189, 1196 and 1263.
- No functional UI, Wi-Fi, API, scheduling, or Firmware behavior was changed.
- Android version metadata: `3.2.7`, versionCode `25`.
