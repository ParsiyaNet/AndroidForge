# WAPFire Mobile 4.1.0 — Background monitor architecture

```text
app/src/main/java/io/wapfire/mobile/
├── MainActivity.kt
├── model/
├── monitor/
│   ├── BackgroundMonitorService.kt  User-started connectedDevice foreground service
│   ├── MonitorEventPolicy.kt        Threat filtering and persistent event signatures
│   └── MonitorStopReceiver.kt       Stop action for the ongoing notification
├── network/
│   ├── WapFireApi.kt                Serialized API, typed HTTP errors, short log timeouts
│   ├── WapFireSessionManager.kt     Verified, bounded session recovery
│   ├── WifiDiscovery.kt             WAPFire authentication-page discovery
│   └── WifiConnector.kt             UI Wi-Fi join and reconnect handling
├── security/
│   └── DeviceLoginVault.kt          Android Keystore AES-GCM credential storage
└── ui/
    ├── WapFireApp.kt                Runtime permissions, consent, service controls
    ├── components/
    └── screens/
```

## Runtime ownership

- The Activity owns navigation and foreground UI refreshes. It does not own the background polling job.
- `BackgroundMonitorService` is the only component polling `/api/logs` for background alerts.
- The service starts only after an explicit user action. It immediately enters the foreground and publishes an ongoing notification.
- The service tracks Wi-Fi `Network` objects. Before sending a saved username/password, it makes a cookie-free GET to `/` on that exact network and requires the VF38 `WAPFire - Authentication` page signature.
- After identity verification it creates its own `WapFireApi` client object, but that object uses the host-scoped process-wide cookie store shared with the Activity. VF38 maintains one token per client IP; independent cookies would invalidate one another.
- If the Wi-Fi network is lost, the service unbinds the process network and waits for a Wi-Fi candidate without discarding the shared cookie. After reconnect, a surviving cookie is reused; a real 401 clears only the rejected token and invokes verified session recovery.
- API status is checked before each event-log poll. A 401 may trigger the existing bounded identity-verified session recovery. A rejected saved password pauses monitoring and posts a user-visible alert; transport failures retry without clearing saved credentials.
- `/api/logs` is read-only. The service never replays setting changes, scans, reset commands, OTA, restore or reboot operations.

## Event deduplication

The first successful log response is persisted as a baseline and does not produce notifications for historical records. Subsequent unseen security events are notified once. A bounded list of the latest 256 signatures is retained in app preferences. The signature incorporates an optional firmware ID plus timestamp, event type and contextual fields; without an ID it hashes stable event fields.

## Power and Android restrictions

The service declares the `connectedDevice` foreground-service type with the matching permission and network-state permissions. A partial CPU wake lock and a Wi-Fi low-latency lock are held while the opt-in monitor is active so the polling coroutine and Wi-Fi radio can remain responsive during ordinary screen-off time. Both are released when monitoring stops. This increases battery use. Android Doze can still suspend network access and ignore wake locks unless the user exempts WAPFire from battery optimization. The Overview page opens the system battery-optimization settings; it does not request a direct exemption or change system settings silently.

Android Force stop and some OEM battery managers can stop the service. The service is not automatically relaunched after a reboot in this release. A continuous local monitor also depends on the WAPFire Wi-Fi link remaining available.
