# WAPFire Mobile 4.1.43

## Overview character framing
- Reduced compact Overview camera zoom from 1.38 to 1.18 so Sena's full hairline and top of head remain inside the character frame.
- Kept the character's aspect ratio and original model assets unchanged.

## Overview speech RTL
- Changed Persian speech-card labels and messages to physical right alignment while retaining explicit RTL paragraph direction.
- English speech remains left aligned with LTR paragraph direction.

## Assistant controls
- Replaced the in-WebView Assistant state buttons in the dashboard's immersive Assistant tab with native Compose buttons below the WebView.
- Native controls call the same state update path by updating the WebView's state parameter; this avoids Android WebView/Canvas pointer hit-testing issues.
- The WebView's duplicate HTML control strip is hidden in full Assistant mode; state indicator and character rendering remain inside the WebView.
- The native button row is horizontally scrollable and translated in both English and Persian.

## Offline/runtime integrity
- Kept the 4.1.42 DOM recovery and local HTTPS AssetLoader path intact.
- Created a uniquely versioned `assistant-preflight-4.1.43.js`; the `.livliv` model, cover image, engine and texture files remain packaged locally.

## Build metadata
- Version name: 4.1.43
- Version code: 84

## Verification limits
- JavaScript syntax, HTML structure, local asset presence, and ZIP integrity are checked in this package.
- No Android device is attached to this environment; an on-device touch test and signed APK install test remain to be performed.
