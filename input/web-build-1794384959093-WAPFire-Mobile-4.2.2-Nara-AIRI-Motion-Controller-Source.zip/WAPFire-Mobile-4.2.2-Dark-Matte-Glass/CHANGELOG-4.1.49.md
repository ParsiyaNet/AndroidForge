# WAPFire Mobile 4.1.49

- Assistant character source set to `v06_clean.livliv` from `ParsiyaNet/AndroidForge`.
- The Gradle pre-build task downloads the exact GitHub file, verifies its Git blob SHA-1 (`112bbede0967362103ec297a368b881531bf00c5`), validates the archive contents, and embeds it in the APK assets.
- The character is bundled for offline runtime; the installed app does not need a network connection to load it.
- Removed the 54px bottom reserve from the Assistant character stage because native Compose controls already live outside the WebView.
- Preserved the 4.1.48 Renderer and native Assistant controls.
- App version remains `4.1.49` (versionCode `90`).
