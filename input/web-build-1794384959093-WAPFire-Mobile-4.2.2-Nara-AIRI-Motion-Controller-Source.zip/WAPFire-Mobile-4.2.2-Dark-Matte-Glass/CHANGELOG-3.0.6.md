# WAPFire Mobile 3.0.6

- Replaced Unicode moon/sun characters in the persistent split Dark/Light switch with drawn vector-style Compose icons.
- Both halves remain visible in both themes; the selected half remains highlighted.
- No firmware changes.
