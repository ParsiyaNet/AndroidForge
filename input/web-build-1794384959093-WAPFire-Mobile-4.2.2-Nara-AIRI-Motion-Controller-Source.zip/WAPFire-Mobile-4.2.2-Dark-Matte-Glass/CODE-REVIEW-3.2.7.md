# WAPFire Mobile 3.2.7 — Build failure correction

## Root cause
AndroidForge run 41797582752 failed during Kotlin compilation because Compose Foundation APIs used by `DiscoveryScreen` are experimental. The exact diagnostics pointed to the `BringIntoViewRequester` declaration, `bringIntoView()` call, and `bringIntoViewRequester()` modifier.

## Fix
Imported `ExperimentalFoundationApi` and added a function-level `@OptIn(ExperimentalFoundationApi::class)` annotation to `DiscoveryScreen`. This is a compile-time opt-in only and does not change runtime behavior.

## Scope
- Android app source and release metadata only.
- Firmware files untouched.
- Version: 3.2.7 / versionCode 25.

## Verification limits
The source patch and archive integrity were checked. A real APK build and on-device test remain to be confirmed by AndroidForge.
