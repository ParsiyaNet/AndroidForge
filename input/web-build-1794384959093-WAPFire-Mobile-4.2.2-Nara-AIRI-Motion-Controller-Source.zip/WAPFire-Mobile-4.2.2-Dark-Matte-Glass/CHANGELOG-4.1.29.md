# WAPFire Mobile 4.1.29

## Assistant character layout and rendering quality

- Raise the LivLiv WebGL pixel-ratio cap from 1.2x to up to 2.0x (bounded by the device's actual display density) for a sharper character on high-density Android screens.
- Adapt the full-screen character zoom to the measured viewport aspect ratio and zoom out in portrait layouts so Sena has more room in the frame.
- Remove speech, state, title, and test-control overlays from the compact Overview character card. Event-driven facial expressions and animations remain active.
- Reserve a dedicated footer below the character in the Assistant tab. Move the current state indicator and state-selection buttons into that footer so they no longer cover the model.
- Widen the state-control strip, improve button sizing/selection contrast, and retain horizontal scrolling for all reaction states on smaller phones.

Version: 4.1.29 (versionCode 70).
