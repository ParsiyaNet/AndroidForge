# WAPFire Mobile 4.1.26

## LivLiv Overview canvas sizing and non-blocking diagnostics

- Ensure the embedded LivLiv stage has a real minimum layout height in compact Overview mode and in the full Assistant view.
- Wait for measured Canvas, Stage, and Shell dimensions before creating WebGL; report all three sizes if layout still fails.
- Add ResizeObserver-based WebGL backing-buffer refresh when the Compose/WebView host changes size.
- Replace the opaque full-WebView diagnostic overlay with a small bottom status chip, so it no longer hides the character or covers the assistant screen.
- Preserve fully offline APK asset loading, LivLiv engine, Sena model, Overview integration, and state reactions.

Version: 4.1.26 (versionCode 67).
