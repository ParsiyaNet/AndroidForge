# WAPFire Mobile 3.2.8 — Code Review

## Findings and corrections

### Risk ring scale mismatch
The VF38 `/api/status` endpoint reports `threat_assessment.score_tenths` as 0–100, i.e. a risk value from 0.0 to 10.0. The app divided this by ten, obtaining 0–10, then drew the ring with a 0–100 percentage formula (`score * 3.6`). That capped the visible sweep at 36 degrees. The app now retains a Float value (one decimal) and computes `score / 10 * 360`, matching the WebUI's `score_tenths / 10` display. Risk-level colors now match firmware levels.

### Misleading engine status
The old Overview headline treated `configured=true` as “Protection engine active”. Configuration only confirms that setup is complete. The app now uses the live `promiscuous`, `self_protect`, and `self_protect_active` status fields to distinguish monitoring, armed self-protection, and an active protection response.

### Burst requests / short timeout
`HttpURLConnection` used a 7-second connect timeout and 12-second response timeout and allowed separate coroutines to issue concurrent requests. WebView `fetch()` has no default request timeout, so the browser UI could continue waiting while the native app gave up after 12 seconds. A per-client coroutine Mutex now serializes all API requests, including backup/restore and firmware upload, and response timeouts are operation-specific (30 seconds standard; longer for scan/logs/restore). No automatic POST retries are used.

### Polling request load
Telemetry refreshes could overlap with manual refresh or settings actions. Refresh cycles now coalesce, firmware metadata is not requested every telemetry cycle, and chart data is requested only on the Overview tab. The last known chart and firmware metadata are retained when those endpoints are skipped or briefly unavailable.

## Validation performed
- Verified the ring math at risk values 0.0, 5.0, and 10.0 (0°, 180°, 360°).
- Verified all native HTTP entry points route through the serialized request helper.
- Reviewed all `HttpURLConnection` creation sites for explicit timeouts and connection close behavior.
- Confirmed API polling no longer fetches firmware metadata every three seconds.
- Confirmed Kotlin source structure and archive integrity.
- Compared firmware tree hashes with 3.2.7; no firmware file was changed.

## Not performed
- No actual Gradle/Android SDK build was run in this environment.
- No physical-phone or live-device load test was run. AndroidForge/device validation is still required.
