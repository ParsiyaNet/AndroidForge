# WAPFire Mobile 3.0.8

- Replaced the sun/moon theme glyph with the exact single half-filled circle (contrast) icon shown on the original Welcome Back screen.
- The icon remains visually identical in dark and light themes; tapping the same compact rounded-square control toggles the theme.
- Matched the Discovery header order to the reference: language control first, theme control second.
