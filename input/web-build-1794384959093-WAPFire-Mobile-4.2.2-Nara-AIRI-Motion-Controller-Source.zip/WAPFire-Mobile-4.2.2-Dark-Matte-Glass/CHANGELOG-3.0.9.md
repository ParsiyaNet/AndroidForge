# WAPFire Mobile 3.0.9

- Made the header language and theme toggle controls the exact same fixed size (36dp × 36dp).
- Preserved the single contrast-circle theme icon and the existing button styling.
