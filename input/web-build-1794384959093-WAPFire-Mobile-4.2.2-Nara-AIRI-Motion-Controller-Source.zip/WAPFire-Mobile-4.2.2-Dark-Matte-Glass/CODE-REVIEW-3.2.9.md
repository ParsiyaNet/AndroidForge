# WAPFire Mobile 3.2.9 — Focused Code Review

## Changes

### Device link indicator
- Introduced `deviceOnline`, which tracks reachability of the authenticated WAPFire API separately from the ESP32 radio's `promiscuous` state.
- The top-bar badge now displays `LIVE` only after a successful `/api/status` response; transport/auth failures switch it to `OFFLINE`.
- Non-authentication transport failures do not force the user out of the Control screen and do not display a transient error toast.
- The existing periodic refresh loop remains active. On the next successful status response the badge returns to `LIVE` automatically.
- Failed reads do not clear the last good `Snapshot`, chart, client list, or event list. Successful reads alone replace cached data.

### Read timeout
- `/api/status` now uses a dedicated 5-second connect timeout and 7-second response timeout.
- Existing timeouts for chart, logs, clients, settings, backup, firmware upload, and write operations remain unchanged.

### Theme surfaces
- Network Telemetry metric tiles use fully opaque palette-derived surfaces (`panelAlt` → `bg2`) and an opaque palette border.
- Event rows and the empty Events state use the same fully opaque theme-derived surfaces and borders.
- Removed the translucent white overlay from those surfaces, improving separation in both Light and Dark themes.

## Safety / compatibility scope
- No attack implementation, API route, HTTP method, settings schema, or firmware source was changed.
- Firmware tree is expected to be byte-for-byte identical to 3.2.8.

## Validation limits
- ZIP integrity and firmware SHA-256 parity are checked during packaging.
- Kotlin compiler parsing was exercised, but a complete Android compile is not available in this environment because the Android SDK is absent and the Gradle distribution could not be downloaded (DNS/network unavailable).
- A real phone + ESP32 reconnect test remains necessary.
