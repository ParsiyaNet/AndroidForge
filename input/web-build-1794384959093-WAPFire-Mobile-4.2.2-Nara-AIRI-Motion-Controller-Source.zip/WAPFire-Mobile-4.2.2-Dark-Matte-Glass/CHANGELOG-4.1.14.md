# WAPFire Mobile 4.1.14

## Wi-Fi connection stays active after closing the screen
- Added `WifiConnectionKeepAliveService`, a user-started foreground service with the Android `connectedDevice` foreground-service type.
- The Activity and service now share one process-wide `WifiConnector` instance. The foreground service keeps the process that owns the `WifiNetworkSpecifier` request alive after the Activity is swiped away or closed.
- The ongoing notification shows the selected WAPFire SSID/BSSID and provides an explicit **Disconnect** action.
- The service uses `START_STICKY`; after a process recreation it can rebuild the exact SSID+BSSID request from the encrypted per-BSSID SoftAP password vault.
- Explicit disconnect, logout, firmware reboot, Wi-Fi restart, restore, and setup-reset flows release the network request and stop the keep-alive service.

## Discovery UI polish
- Added a soft neon-blue breathing halo around the **Connect to Selected Wi-Fi** panel.
- Selecting an access point now automatically scrolls the panel into view, even when the password field is not shown.
- If a password fallback is needed, the same scroll behavior brings the password field into view and focuses it.

## Version
- `versionName`: `4.1.14`
- `versionCode`: `55`

## Notes
- The foreground service improves the lifetime of the app-owned local-only Wi-Fi request; Android/OEM force-stop, user stopping the service from system settings, Wi-Fi being disabled, or loss of the AP can still interrupt connectivity.
- A full Android/Gradle build and physical-device lifecycle test were not available in this environment.
