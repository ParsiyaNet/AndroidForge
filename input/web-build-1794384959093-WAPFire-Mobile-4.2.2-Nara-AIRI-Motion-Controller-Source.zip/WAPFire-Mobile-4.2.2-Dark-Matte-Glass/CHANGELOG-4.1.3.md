# WAPFire Mobile 4.1.3 — Detection Breakdown notifications only

## Notification source and filtering
- Background monitoring no longer reads `/api/logs` and does not classify the general Events timeline.
- Notifications are driven only by the eight firmware `labels` counters in `/api/status`, matching the Overview's Detection Breakdown source.
- Exactly seven categories can notify: Auth Attack, Deauth Attack, Deauth Airplay, WPS Pixie Reaver, WPS Pixie Bully, Evil Twin, and WPA Wrong Password.
- WPA Correct Password is excluded even when its cumulative counter increases.
- Generic system, connection, disconnect, attempt, and unknown Events never generate security notifications.

## Notification subjects and delivery
- Notification subjects use the Detection Breakdown category name plus `Detected`.
- Notification body reports the number of new detections since the previous poll and the current cumulative counter.
- The first valid status response establishes a silent baseline, avoiding notifications for historical counts. Firmware counter decreases/reboots silently re-baseline.
- Non-detection operational problems update the silent foreground-status notification and do not post security alerts.

## Validation
- JVM test verifies all seven categories, exact titles, counter deltas, correct-password exclusion, and rejection of Events-only payloads.
- Session-recovery integration tests remain unchanged and pass.
- Full Android Gradle/APK build and runtime test on a physical VF38 device have not been performed in this environment.
