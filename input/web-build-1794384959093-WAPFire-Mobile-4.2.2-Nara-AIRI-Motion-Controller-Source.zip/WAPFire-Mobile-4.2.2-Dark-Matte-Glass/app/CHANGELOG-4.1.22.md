# WAPFire Mobile 4.1.22

- Replaced the custom WebView asset interceptor with AndroidX WebViewAssetLoader for app-bundled HTTPS assets.
- Kept all external requests blocked; local HTML, ES modules, model package and textures are served from APK assets only.
- Added visible native loading and main-frame failure status for the Overview assistant WebView.
- Added detailed WebView/JavaScript diagnostics under the `WapFireAssistant` Logcat tag.
- Preserved LivLiv character, Overview integration, Smart Join and Wi-Fi Keep Alive.

Version code: 63.
