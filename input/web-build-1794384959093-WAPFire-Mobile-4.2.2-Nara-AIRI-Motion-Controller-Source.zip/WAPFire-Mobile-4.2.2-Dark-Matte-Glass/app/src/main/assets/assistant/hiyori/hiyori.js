/* WAPFire 4.2.1 - Hiyori Momose (Live2D Cubism 4) assistant renderer.
 * Same native contract as the previous page: window.wapfireSetState(state),
 * WapFireNative.reportReady() / reportStatus(msg) / reportFatal(msg).
 * Expressions and gestures live in pose.js. */
(function () {
  'use strict';
  const BUILD = '4.2.1';
  window.__wfPreflightStarted = true;
  window.__wfAssistantBuildVersion = BUILD;
  window.__wfAssistantDocumentExpected = true;

  const q = new URLSearchParams(location.search);
  const fa = q.get('lang') !== 'en';
  const compact = q.get('compact') !== '0';
  const $ = (id) => document.getElementById(id);
  const bridge = window.WapFireNative;
  document.documentElement.lang = fa ? 'fa' : 'en';
  document.body.className = compact ? 'compact' : 'full';

  let ready = false;
  let model = null;
  let app = null;
  let rawModel = null;
  let pendingState = q.get('state') || 'idle';
  const userZoom = parseFloat(q.get('zoom') || '1') || 1;
  const userDy = parseFloat(q.get('dy') || '0') || 0;

  function report(message) { try { bridge && bridge.reportStatus && bridge.reportStatus(String(message).slice(0, 800)); } catch (e) { /* ignore */ } }
  function fatal(message) {
    const text = String(message).slice(0, 400);
    console.error(text);
    const box = $('loading');
    if (box) { box.className = 'loading error'; box.style.display = 'block'; box.textContent = text; }
    report(text);
    try { bridge && bridge.reportFatal && bridge.reportFatal(text); } catch (e) { /* ignore */ }
  }
  window.addEventListener('error', (e) => { if (!ready) fatal('Hiyori error: ' + (e.message || e)); });
  window.addEventListener('unhandledrejection', (e) => { if (!ready) fatal('Hiyori error: ' + ((e.reason && e.reason.message) || e.reason)); });

  /* ---------- states ---------- */
  const PILL = {
    idle: ['Ready', 'آماده‌به‌کار'], scanning: ['Monitoring', 'در حال پایش'], connecting: ['Connecting', 'در حال اتصال'],
    success: ['Connected', 'متصل شد'], password_success: ['Password accepted', 'رمز صحیح'], password_warning: ['Wrong password', 'رمز اشتباه'],
    warning: ['Threat detected', 'هشدار امنیتی'], angry: ['Attack detected', 'حمله شناسایی شد'], offline: ['Device offline', 'دستگاه در دسترس نیست'],
    setup: ['Setup required', 'نیازمند راه‌اندازی']
  };
  let poseEngine = null;
  const nowSec = () => performance.now() / 1000;

  function showState(name) {
    const state = PILL[name] ? name : 'idle';
    pendingState = state;
    $('shell').dataset.state = state;
    $('stateText').textContent = PILL[state][fa ? 1 : 0];
    if (poseEngine) poseEngine.setState(state, nowSec());
  }
  window.wapfireSetState = (state) => { try { showState(String(state)); } catch (e) { report(String(e)); } };

  /* ---------- parameter access (raw Cubism Core model) ---------- */
  const paramIndex = {};
  function bindParameters() {
    const ids = rawModel.parameters.ids;
    for (let i = 0; i < ids.length; i++) paramIndex[ids[i]] = i;
    const p = rawModel.parameters;
    poseEngine = window.WFPose.create({
      get: (id) => { const i = paramIndex[id]; return i === undefined ? undefined : p.values[i]; },
      set: (id, v) => { const i = paramIndex[id]; if (i !== undefined) p.values[i] = Math.max(p.minimumValues[i], Math.min(p.maximumValues[i], v)); }
    });
    poseEngine.setState(pendingState, nowSec());
  }

  let lastTime = performance.now();
  function applyPose() {
    if (!rawModel || !poseEngine) return;
    const nowMs = performance.now();
    const dt = Math.min(0.1, Math.max(0.001, (nowMs - lastTime) / 1000));
    lastTime = nowMs;
    poseEngine.apply(nowMs / 1000, dt);
  }

  /* ---------- framing ---------- */
  // Measured from Hiyori.moc3 with Cubism Core 4.2.2 (rest pose, canvas pixels):
  // canvas 2976x4175, hair/ahoge top y=303, chin y=1014, character x-range 922..2126.
  const M = { canvasW: 2976, top: 303, chin: 1014, left: 922, right: 2126 };
  // Targets taken from the Nara screenshots: where the head starts and how tall the head is,
  // as a fraction of the stage height (the body is cropped by the stage bottom like Nara's).
  const FRAME = {
    full: { top: 0.188, head: 0.32, maxW: 0.92 },
    compact: { top: 0.022, head: 0.41, maxW: 0.92 }
  };
  function fit() {
    if (!app || !model) return;
    const box = $('stageBox');
    const W = Math.max(40, box.clientWidth - 2), H = Math.max(40, box.clientHeight - 2);
    app.renderer.resize(W, H);
    const cfg = compact ? FRAME.compact : FRAME.full;
    const baseW = model.width / model.scale.x;          // should be the 2976px canvas
    const unit = baseW > 0 ? M.canvasW / baseW : 1;
    let s = (cfg.head * H) / (M.chin - M.top);
    s = Math.min(s, (cfg.maxW * W) / (M.right - M.left)) * userZoom;
    model.scale.set(s * unit);
    model.x = W / 2 - ((M.left + M.right) / 2) * s;
    model.y = H * (cfg.top + userDy) - M.top * s;
  }
  window.wapfireFrame = (zoom, dy) => { /* debugging aid: window.wapfireFrame(1.1, 0.02) */ fit(); return { zoom, dy }; };

  /* ---------- boot ---------- */
  async function boot() {
    if (!window.Live2DCubismCore) throw new Error('Live2D Cubism Core did not load.');
    if (!window.PIXI || !PIXI.live2d) throw new Error('Pixi / Live2D plugin did not load.');
    if (!window.WFPose) throw new Error('Pose script did not load.');
    window.__wfEngineBooted = true;
    try { PIXI.live2d.Live2DModel.registerTicker(PIXI.Ticker); } catch (e) { /* already registered */ }

    const canvas = $('stage');
    app = new PIXI.Application({
      view: canvas, autoStart: true, antialias: true, backgroundAlpha: 0,
      resolution: Math.min(window.devicePixelRatio || 1, 2), autoDensity: true,
      width: Math.max(40, canvas.clientWidth || 300), height: Math.max(40, canvas.clientHeight || 300)
    });
    model = await PIXI.live2d.Live2DModel.from('./model/Hiyori.model3.json', { autoInteract: false });
    app.stage.addChild(model);

    const core = model.internalModel.coreModel;
    rawModel = core._model || (core.getModel && core.getModel());
    if (!rawModel || !rawModel.parameters) throw new Error('Unexpected Live2D model structure.');
    bindParameters();
    model.internalModel.on('beforeModelUpdate', applyPose);

    fit();
    if (window.ResizeObserver) new ResizeObserver(() => requestAnimationFrame(fit)).observe($('stageBox'));
    window.addEventListener('resize', () => requestAnimationFrame(fit));
    showState(pendingState);
    // Let two frames render before announcing readiness so the native "preparing" label never hides a blank view.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    fit();
    ready = true;
    window.__wfRendererReady = true;
    $('loading').style.display = 'none';
    try { bridge && bridge.reportReady && bridge.reportReady(); } catch (e) { /* ignore */ }
  }
  showState(pendingState);
  boot().catch((error) => fatal('Hiyori failed to start: ' + ((error && error.message) || error)));
})();
