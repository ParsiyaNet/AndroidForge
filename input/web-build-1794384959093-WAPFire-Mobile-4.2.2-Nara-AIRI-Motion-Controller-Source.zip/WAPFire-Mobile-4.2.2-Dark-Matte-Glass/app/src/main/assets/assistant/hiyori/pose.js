/* WAPFire 4.2.1 - Hiyori expression/pose engine (pure logic, no DOM).
 * Every state blends Hiyori's own idle-motion face toward a target expression; head and body movement is
 * added on top of her idle sway. Nothing oscillates continuously except the slow gaze sweep while scanning.
 * One-shot gestures (a nod, a "no", a startle) play once when a state begins and then settle.
 * The expression values below were checked in an offline preview render of the real model. */
(function (root) {
  'use strict';
  const FACE = ['eyeOpen', 'eyeSmile', 'cheek', 'browLY', 'browRY', 'browAngle', 'browForm', 'mouthForm', 'mouthOpen'];
  const NEUTRAL = { eyeOpen: 1, eyeSmile: 0, cheek: 0, browLY: 0, browRY: 0, browAngle: 0, browForm: 0, mouthForm: 0.2, mouthOpen: 0 };

  const POSES = {
    // w = how strongly the expression replaces her idle-motion face (0 = pure idle motion).
    idle: { w: 0 },
    // focused, looking around slowly
    scanning: { w: 0.8, eyeOpen: 0.92, browLY: -0.25, browRY: -0.25, browAngle: -0.4, mouthForm: 0.1, head: { ay: 1 }, gaze: 'sweep' },
    // thinking: eyes up and to the side, one brow raised, head slightly tilted
    connecting: { w: 0.85, cheek: 0.2, browLY: 0.55, browRY: 0, mouthForm: 0, mouthOpen: 0.08, head: { az: 6, ay: 4 }, gaze: { x: -0.6, y: 0.7 } },
    // delighted: closed happy eyes, open smile, blush, one gentle nod
    success: { w: 0.9, eyeOpen: 0.2, eyeSmile: 1, cheek: 1, browLY: 0.3, browRY: 0.3, mouthForm: 1, mouthOpen: 0.35, gesture: 'nod' },
    // pleased: smiling eyes, soft smile, one nod
    password_success: { w: 0.9, eyeOpen: 0.5, eyeSmile: 1, cheek: 0.6, browLY: 0.2, browRY: 0.2, mouthForm: 0.9, mouthOpen: 0.15, gesture: 'nod' },
    // worried: inner brows up, small frown, head tilted and a soft "no"
    password_warning: { w: 0.9, eyeOpen: 0.95, browLY: 0.2, browRY: 0.2, browAngle: 1, browForm: -0.6, mouthForm: -0.5, head: { az: -6, ay: -3 }, gaze: { x: 0, y: -0.3 }, gesture: 'no' },
    // alert: eyes wide, brows up, small "o" mouth, a quick start then still
    warning: { w: 0.9, browLY: 0.8, browRY: 0.8, browForm: 0.8, mouthForm: -0.15, mouthOpen: 0.3, head: { ay: 4 }, gaze: { x: 0, y: 0 }, gesture: 'startle' },
    // angry: brows pulled down, eyes narrowed and looking up from under the bangs, frown, blush of annoyance,
    // head lowered and leaning in. Held steady - no trembling.
    angry: { w: 0.92, eyeOpen: 0.6, cheek: 0.5, browLY: -1, browRY: -1, browAngle: -1, browForm: -0.3, mouthForm: -1, head: { ay: -10 }, body: { ay: -3 }, gaze: { x: 0, y: 0.35 } },
    // sad / tired: heavy eyelids, inner brows up, frown, head drooping, looking down
    offline: { w: 0.9, eyeOpen: 0.55, browLY: -0.1, browRY: -0.1, browAngle: 0.8, browForm: -0.5, mouthForm: -0.6, head: { ay: -12, az: -4 }, body: { ay: -4 }, gaze: { x: 0, y: -0.5 } },
    // friendly and attentive
    setup: { w: 0.85, cheek: 0.4, browLY: 0.3, browRY: 0.3, mouthForm: 0.7, mouthOpen: 0.1, head: { az: 5 } }
  };

  function gesture(name, t) {
    const out = { ax: 0, ay: 0, by: 0 };
    if (name === 'nod') {
      const d = 0.9;
      if (t < d) { const e = Math.sin(Math.PI * t / d); out.ay = -9 * e; out.by = -2 * e; }
    } else if (name === 'no') {
      if (t < 1.8) out.ax = 12 * Math.exp(-t * 2.2) * Math.sin(2 * Math.PI * 1.6 * t);
    } else if (name === 'startle') {
      const e = Math.exp(-t * 4.5); out.ay = 7 * e; out.by = 2 * e;
    }
    return out;
  }

  /* model: { get(id) -> number|undefined, set(id, value) } over the live Cubism parameters. */
  function create(model) {
    const tv = Object.assign({}, NEUTRAL);
    const head = { ax: 0, ay: 0, az: 0 };
    const body = { ay: 0 };
    const gaze = { x: 0, y: 0, w: 0 };
    let w = 0, pose = POSES.idle, t0 = 0;

    function setState(name, now) { pose = POSES[name] || POSES.idle; t0 = now; }
    function lerp(id, target, weight) { const cur = model.get(id); if (cur !== undefined) model.set(id, cur + (target - cur) * weight); }
    function add(id, delta) { const cur = model.get(id); if (cur !== undefined) model.set(id, cur + delta); }

    function apply(now, dt) {
      const aFace = 1 - Math.exp(-dt / 0.28), aW = 1 - Math.exp(-dt / 0.35), aHead = 1 - Math.exp(-dt / 0.5), aGaze = 1 - Math.exp(-dt / 0.3);
      for (const k of FACE) tv[k] += ((pose[k] !== undefined ? pose[k] : NEUTRAL[k]) - tv[k]) * aFace;
      w += ((pose.w || 0) - w) * aW;
      const hd = pose.head || {}, bd = pose.body || {};
      head.ax += ((hd.ax || 0) - head.ax) * aHead;
      head.ay += ((hd.ay || 0) - head.ay) * aHead;
      head.az += ((hd.az || 0) - head.az) * aHead;
      body.ay += ((bd.ay || 0) - body.ay) * aHead;

      let gx = 0, gy = 0, gw = 0, follow = 0;
      if (pose.gaze === 'sweep') { const s = Math.sin(now * 1.3); gx = s * 0.7; gw = 0.9; follow = s; }
      else if (pose.gaze) { gx = pose.gaze.x; gy = pose.gaze.y; gw = 0.85; }
      gaze.x += (gx - gaze.x) * aGaze; gaze.y += (gy - gaze.y) * aGaze; gaze.w += (gw - gaze.w) * aGaze;
      const g = gesture(pose.gesture, Math.max(0, now - t0));

      // Face: blink (min) is kept so she still blinks in every state.
      const eyeCap = 1 + (tv.eyeOpen - 1) * w;
      for (const id of ['ParamEyeLOpen', 'ParamEyeROpen']) { const cur = model.get(id); if (cur !== undefined) model.set(id, Math.min(cur, eyeCap)); }
      lerp('ParamEyeLSmile', tv.eyeSmile, w); lerp('ParamEyeRSmile', tv.eyeSmile, w);
      lerp('ParamCheek', tv.cheek, w);
      lerp('ParamBrowLY', tv.browLY, w); lerp('ParamBrowRY', tv.browRY, w);
      lerp('ParamBrowLAngle', tv.browAngle, w); lerp('ParamBrowRAngle', tv.browAngle, w);
      lerp('ParamBrowLForm', tv.browForm, w); lerp('ParamBrowRForm', tv.browForm, w);
      lerp('ParamMouthForm', tv.mouthForm, w); lerp('ParamMouthOpenY', tv.mouthOpen, w);
      lerp('ParamEyeBallX', gaze.x, gaze.w); lerp('ParamEyeBallY', gaze.y, gaze.w);

      // Head / body: added to her idle sway.
      add('ParamAngleX', head.ax + g.ax + follow * gaze.w * 7);
      add('ParamAngleY', head.ay + g.ay);
      add('ParamAngleZ', head.az);
      add('ParamBodyAngleX', follow * gaze.w * 1.5);
      add('ParamBodyAngleY', body.ay + g.by);
    }
    return { setState, apply };
  }

  const api = { create, POSES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.WFPose = api;
})(typeof window !== 'undefined' ? window : this);
