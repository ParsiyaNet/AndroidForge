/* WAPFire 4.2.2 - Nara state-owned motion controller.
 *
 * Nara is a native LivLiv puppet (.livliv), not a Cubism .moc3 or VRM model.
 * Keep its own renderer/rig, but use AIRI's useful motion-system principles:
 * one motion owner, explicit priority by application state, staged updates,
 * smooth hand-offs, randomized eye saccades, and independent blink/breath layers.
 * The Player's own organic idle engine is enabled only for the true idle state.
 */
(function (root) {
  'use strict';

  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const smooth = (t) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const lerp = (a, b, t) => a + (b - a) * t;
  const randomBetween = (min, max) => min + Math.random() * (max - min);

  // Event reactions are short, authored motions. Persistent states settle into
  // their own restrained posture instead of replaying a looping animation.
  const MOTIONS = {
    scanning: { procedural: true, tracks: {} },
    connecting: {
      duration: 2.4,
      tracks: {
        eyeBallX: [[0, 0], [0.28, 0.26], [0.9, 0.18], [1.8, 0.12], [2.4, 0.08]],
        eyeBallY: [[0, 0], [0.32, 0.3], [1.0, 0.22], [2.4, 0.14]],
        angleX: [[0, 0], [0.45, -4.0], [1.45, -3.1], [2.4, -3.0]],
        angleY: [[0, 0], [0.52, 2.9], [1.5, 2.2], [2.4, 1.8]],
        angleZ: [[0, 0], [0.6, 2.7], [1.6, 2.0], [2.4, 1.8]],
        bodyX: [[0, 0], [0.6, -0.55], [1.6, -0.38], [2.4, -0.3]]
      }
    },
    success: {
      duration: 1.6,
      tracks: {
        angleY: [[0, 0], [0.2, -7.2], [0.5, 2.1], [0.86, -1.0], [1.25, 0.25], [1.6, 0]],
        angleZ: [[0, 0], [0.34, 1.1], [0.78, -0.55], [1.2, 0.2], [1.6, 0]],
        bodyX: [[0, 0], [0.32, 0.65], [0.9, 0.14], [1.6, 0]],
        eyeBallY: [[0, 0], [0.25, 0.12], [0.75, 0.04], [1.6, 0]]
      }
    },
    password_success: {
      duration: 1.35,
      tracks: {
        angleY: [[0, 0], [0.18, -5.7], [0.46, 1.55], [0.78, -0.5], [1.08, 0.12], [1.35, 0]],
        angleZ: [[0, 0], [0.32, 0.8], [0.76, -0.24], [1.35, 0]],
        bodyX: [[0, 0], [0.3, 0.42], [0.86, 0.06], [1.35, 0]]
      }
    },
    password_warning: {
      duration: 1.55,
      tracks: {
        angleX: [[0, 0], [0.18, 5.1], [0.44, -4.8], [0.74, 2.9], [1.1, -0.7], [1.55, 0]],
        angleZ: [[0, 0], [0.32, -2.3], [0.76, 1.6], [1.2, 0], [1.55, 0]],
        eyeBallX: [[0, 0], [0.2, -0.2], [0.8, -0.1], [1.55, 0]],
        bodyX: [[0, 0], [0.4, -0.28], [0.95, 0], [1.55, 0]]
      }
    },
    warning: {
      duration: 1.25,
      tracks: {
        angleY: [[0, 0], [0.12, 6.6], [0.36, 3.6], [0.78, 0.9], [1.25, 0.8]],
        angleZ: [[0, 0], [0.18, -2.2], [0.6, -0.8], [1.25, -0.55]],
        bodyX: [[0, 0], [0.16, -0.9], [0.58, -0.28], [1.25, -0.16]],
        eyeBallY: [[0, 0], [0.22, 0.13], [0.78, 0.02], [1.25, 0]]
      }
    },
    angry: {
      duration: 1.05,
      tracks: {
        angleY: [[0, 0], [0.28, -5.5], [0.72, -4.6], [1.05, -4.5]],
        angleX: [[0, 0], [0.34, 2.2], [0.8, 1.7], [1.05, 1.6]],
        angleZ: [[0, 0], [0.38, -1.6], [0.85, -1.1], [1.05, -1.0]],
        bodyX: [[0, 0], [0.42, -0.68], [1.05, -0.5]]
      }
    },
    offline: {
      duration: 1.2,
      tracks: {
        angleY: [[0, 0], [0.52, -6.5], [1.0, -5.9], [1.2, -5.8]],
        angleZ: [[0, 0], [0.6, -3.0], [1.08, -2.5], [1.2, -2.4]],
        eyeBallY: [[0, 0], [0.42, -0.3], [1.0, -0.25], [1.2, -0.24]],
        bodyX: [[0, 0], [0.58, -0.58], [1.2, -0.45]]
      }
    },
    setup: {
      duration: 1.15,
      tracks: {
        angleZ: [[0, 0], [0.38, 4.1], [0.86, 3.3], [1.15, 3.2]],
        angleX: [[0, 0], [0.38, 1.6], [0.86, 1.1], [1.15, 1.0]],
        eyeBallX: [[0, 0], [0.36, 0.15], [1.15, 0.12]],
        bodyX: [[0, 0], [0.48, 0.32], [1.15, 0.22]]
      }
    }
  };

  // Parameter values are offsets added to Nara's own rig parameters.
  const FACES = {
    idle: {},
    scanning: { browLY: -0.025, browRY: -0.025 },
    connecting: { browLY: 0.13, browRY: 0.04 },
    success: { browLY: 0.12, browRY: 0.12 },
    password_success: { browLY: 0.09, browRY: 0.09 },
    password_warning: { browLY: 0.25, browRY: 0.14, eyeLOpen: -0.035, eyeROpen: -0.035 },
    warning: { browLY: 0.34, browRY: 0.34 },
    angry: { browLY: -0.52, browRY: -0.52, eyeLOpen: -0.11, eyeROpen: -0.11 },
    offline: { browLY: 0.16, browRY: 0.16, eyeLOpen: -0.18, eyeROpen: -0.18 },
    setup: { browLY: 0.1, browRY: 0.1 }
  };

  const SMILE_STATES = new Set(['success', 'password_success', 'setup']);
  const PERSISTENT_GAZE_STATES = new Set(['connecting', 'success', 'password_success', 'password_warning', 'warning', 'angry', 'offline', 'setup']);
  const VALID_STATES = new Set(Object.keys(MOTIONS).concat('idle'));
  const MOTION_PARAMS = ['angleX', 'angleY', 'angleZ', 'eyeBallX', 'eyeBallY', 'bodyX', 'bodyZ', 'breath'];
  const FACE_PARAMS = ['browLY', 'browRY', 'eyeLOpen', 'eyeROpen'];
  const CAPTURE_PARAMS = [...MOTION_PARAMS, ...FACE_PARAMS];

  function sampleTrack(points, time) {
    if (!points || points.length === 0) return 0;
    if (time <= points[0][0]) return points[0][1];
    const last = points[points.length - 1];
    if (time >= last[0]) return last[1];
    let i = 0;
    while (i < points.length - 2 && time > points[i + 1][0]) i++;
    const a = points[i], b = points[i + 1];
    const u = smooth((time - a[0]) / Math.max(0.0001, b[0] - a[0]));
    return lerp(a[1], b[1], u);
  }

  // Bounded semi-implicit spring, similar to AIRI's spring-based head/gaze motion.
  function spring(value, target, velocity, dt, stiffness, damping) {
    const seconds = clamp(Number.isFinite(dt) ? dt : 0, 0, 0.05);
    const steps = Math.max(1, Math.ceil(seconds / (1 / 120)));
    const step = seconds / steps;
    let x = value, v = velocity;
    for (let i = 0; i < steps; i++) {
      const acceleration = stiffness * (target - x) - damping * v;
      v += acceleration * step;
      x += v * step;
    }
    if (Math.abs(target - x) < 0.001 && Math.abs(v) < 0.002) return [target, 0];
    return [x, v];
  }

  function captureNativePose(player) {
    const current = player?.frame?.params;
    const base = player?.params;
    if (!current || !base) return {};
    const captured = {};
    for (const key of CAPTURE_PARAMS) {
      const value = Number(current[key]);
      const neutral = Number(base[key] ?? 0);
      if (Number.isFinite(value) && Number.isFinite(neutral)) {
        const offset = value - neutral;
        if (Math.abs(offset) > 0.0005) captured[key] = offset;
      }
    }
    return captured;
  }

  class NaraMotionController {
    constructor() {
      this.state = 'idle';
      this.enteredAt = 0;
      this.transitionAt = 0;
      this.transitionDuration = 0.38;
      this.fromOffsets = {};
      this.lastOffsets = {};
      this.player = null;
      this.initialized = false;
      this.idleEnableAt = 0;
      this.breathOrigin = 0;
      this.breathPeriod = 3.65;
      this.breathPhase = randomBetween(0, Math.PI * 2);
      this.blinkStart = -1;
      this.blinkDuration = 0.145;
      this.nextBlink = randomBetween(2.2, 4.3);
      this.scan = null;
      this.microGaze = null;
    }

    createScanState(now) {
      return {
        targetEyeX: 0,
        targetEyeY: 0,
        targetHeadX: 0,
        targetHeadY: 0,
        targetHeadZ: 0,
        targetBodyX: 0,
        eyeX: 0, eyeXV: 0,
        eyeY: 0, eyeYV: 0,
        headX: 0, headXV: 0,
        headY: 0, headYV: 0,
        headZ: 0, headZV: 0,
        bodyX: 0, bodyXV: 0,
        nextShiftAt: now + randomBetween(0.65, 1.25)
      };
    }

    captureCurrentPose(player) {
      // During an active WAPFire motion our own offsets are authoritative.
      // When leaving native idle, capture its last rendered pose for a clean blend.
      return this.state === 'idle'
        ? captureNativePose(player)
        : { ...this.lastOffsets };
    }

    setState(name, now, player, force) {
      const next = VALID_STATES.has(name) ? name : 'idle';
      const t = Number.isFinite(now) ? now : 0;
      const targetPlayer = player || this.player;
      if (this.initialized && next === this.state && !force) return;

      this.fromOffsets = this.initialized
        ? this.captureCurrentPose(targetPlayer)
        : {};
      this.player = targetPlayer || null;
      this.state = next;
      this.enteredAt = t;
      this.transitionAt = t;
      this.breathOrigin = t;
      this.breathPeriod = randomBetween(3.35, 4.35);
      this.breathPhase = randomBetween(0, Math.PI * 2);
      this.blinkStart = -1;
      this.blinkDuration = randomBetween(0.13, 0.17);
      this.nextBlink = t + randomBetween(1.8, 3.6);
      this.idleEnableAt = next === 'idle' ? t + this.transitionDuration : 0;
      this.scan = next === 'scanning' ? this.createScanState(t) : null;
      this.microGaze = PERSISTENT_GAZE_STATES.has(next) ? {
        targetX: 0, targetY: 0, x: 0, xv: 0, y: 0, yv: 0,
        nextAt: t + randomBetween(0.9, 1.8)
      } : null;

      if (this.player) {
        // Only the initial idle state may start native idle immediately. On a
        // return to idle it stays disabled until our outgoing pose fades to zero.
        this.player.idle = next === 'idle' && !this.initialized;
        if (next === 'idle') this.player.lookAt?.(null, 0);
      }
      this.initialized = true;
    }

    updateScanning(now, dt, offsets) {
      const scan = this.scan || (this.scan = this.createScanState(now));
      if (now >= scan.nextShiftAt) {
        const eyeX = Math.random() < 0.22
          ? randomBetween(-0.14, 0.14)
          : randomBetween(-0.52, 0.52);
        const eyeY = Math.random() < 0.28
          ? randomBetween(0.12, 0.28)
          : randomBetween(-0.12, 0.12);
        scan.targetEyeX = eyeX;
        scan.targetEyeY = eyeY;
        // Eyes lead, then the head and shoulders follow with a softer spring.
        scan.targetHeadX = eyeX * 5.4 + randomBetween(-0.85, 0.85);
        scan.targetHeadY = eyeY * 2.2 + randomBetween(-0.55, 0.55);
        scan.targetHeadZ = eyeX * 1.35 + randomBetween(-0.35, 0.35);
        scan.targetBodyX = eyeX * 0.62 + randomBetween(-0.16, 0.16);
        scan.nextShiftAt = now + randomBetween(1.35, 3.05);
      }

      [scan.eyeX, scan.eyeXV] = spring(scan.eyeX, scan.targetEyeX, scan.eyeXV, dt, 115, 21);
      [scan.eyeY, scan.eyeYV] = spring(scan.eyeY, scan.targetEyeY, scan.eyeYV, dt, 105, 20);
      [scan.headX, scan.headXV] = spring(scan.headX, scan.targetHeadX, scan.headXV, dt, 25, 9.5);
      [scan.headY, scan.headYV] = spring(scan.headY, scan.targetHeadY, scan.headYV, dt, 22, 9);
      [scan.headZ, scan.headZV] = spring(scan.headZ, scan.targetHeadZ, scan.headZV, dt, 18, 8);
      [scan.bodyX, scan.bodyXV] = spring(scan.bodyX, scan.targetBodyX, scan.bodyXV, dt, 9, 5.8);

      offsets.eyeBallX = scan.eyeX;
      offsets.eyeBallY = scan.eyeY;
      offsets.angleX = scan.headX;
      offsets.angleY = scan.headY;
      offsets.angleZ = scan.headZ;
      offsets.bodyX = scan.bodyX;
    }

    resetNativeIdle(player, now) {
      // The native idle engine owns five organic gestures. Drop any interrupted
      // gesture and give it a fresh randomized pause before its next selection.
      const idleLayer = player?.idler?.lv;
      if (idleLayer) {
        idleLayer.move = null;
        idleLayer.last = '';
        idleLayer.nextMove = now + randomBetween(1.1, 2.8);
      }
    }

    update(frame, player) {
      if (!frame || !player) return;
      const now = Number.isFinite(frame.time)
        ? frame.time
        : (Number.isFinite(player.clock) ? player.clock : 0);
      const dt = clamp(Number.isFinite(frame.dt) ? frame.dt : 0, 0, 0.05);
      const isIdle = this.state === 'idle';

      if (isIdle && now >= this.idleEnableAt) {
        if (!player.idle) {
          this.resetNativeIdle(player, now);
          player.idle = true;
        }
        this.lastOffsets = {};
        return;
      }

      const transition = smooth((now - this.transitionAt) / this.transitionDuration);
      const profile = MOTIONS[this.state];
      const offsets = {};
      const motionTime = Math.max(0, now - this.enteredAt);

      if (!isIdle && profile) {
        if (profile.procedural && this.state === 'scanning') {
          this.updateScanning(now, dt, offsets);
        } else {
          for (const key of Object.keys(profile.tracks || {})) {
            offsets[key] = sampleTrack(profile.tracks[key], motionTime);
          }
        }
        const face = FACES[this.state] || {};
        for (const key of FACE_PARAMS) offsets[key] = face[key] || 0;
      }

      // Persistent states still have tiny, randomized eye saccades; these are
      // a face-only layer and never compete with the state's head/body motion.
      if (!isIdle && this.microGaze) {
        const gaze = this.microGaze;
        if (now >= gaze.nextAt) {
          gaze.targetX = randomBetween(-0.16, 0.16);
          gaze.targetY = randomBetween(-0.09, 0.11);
          gaze.nextAt = now + randomBetween(1.9, 4.1);
        }
        [gaze.x, gaze.xv] = spring(gaze.x, gaze.targetX, gaze.xv, dt, 48, 14);
        [gaze.y, gaze.yv] = spring(gaze.y, gaze.targetY, gaze.yv, dt, 42, 13);
        offsets.eyeBallX = (offsets.eyeBallX || 0) + gaze.x;
        offsets.eyeBallY = (offsets.eyeBallY || 0) + gaze.y;
      }

      // The native Player breath layer is paused with native idle. Recreate only
      // a quiet, continuous breathing offset during active WAPFire reactions.
      offsets.breath = isIdle
        ? 0
        : 0.5 + 0.12 * Math.sin((now - this.breathOrigin) / this.breathPeriod * Math.PI * 2 + this.breathPhase);

      // Blink is a final, face-only layer; it never takes ownership of body/head.
      if (!isIdle) {
        if (this.blinkStart < 0 && now >= this.nextBlink) {
          this.blinkStart = now;
          this.blinkDuration = randomBetween(0.13, 0.17);
        }
        let blink = 0;
        if (this.blinkStart >= 0) {
          const p = (now - this.blinkStart) / this.blinkDuration;
          if (p >= 1) {
            this.blinkStart = -1;
            this.nextBlink = now + randomBetween(2.3, 5.0);
          } else {
            blink = Math.sin(Math.PI * clamp(p, 0, 1));
          }
        }
        offsets.eyeLOpen = (offsets.eyeLOpen || 0) - blink * 0.96;
        offsets.eyeROpen = (offsets.eyeROpen || 0) - blink * 0.96;
      }

      const blended = {};
      const keys = new Set([...Object.keys(this.fromOffsets), ...Object.keys(offsets)]);
      for (const key of keys) {
        const from = this.fromOffsets[key] || 0;
        const to = offsets[key] || 0;
        blended[key] = isIdle ? lerp(from, 0, transition) : lerp(from, to, transition);
      }

      frame.add(blended);
      this.lastOffsets = blended;
    }

    dispose() {
      this.player = null;
      this.scan = null;
      this.microGaze = null;
    }
  }

  root.WFNaraMotionController = {
    create: () => new NaraMotionController(),
    states: Array.from(VALID_STATES),
    smiles: Array.from(SMILE_STATES)
  };
})(typeof window !== 'undefined' ? window : this);
