package io.wapfire.mobile.security

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.Locale

/** Stores WAPFire SoftAP passphrases as AES-GCM ciphertext; the key remains in Android Keystore. */
internal object SoftApPasswordVault {
    private const val KEY_ALIAS = "io.wapfire.mobile.softap-password.v1"
    private const val PREF_PREFIX = "wapfire_softap_pass_"
    private const val IV_LENGTH = 12

    private fun prefKey(bssid: String): String = PREF_PREFIX + bssid
        .trim().lowercase(Locale.ROOT).replace(":", "")

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    fun load(prefs: SharedPreferences, bssid: String): String? {
        if (!bssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}"))) return null
        val pref = prefKey(bssid)
        val encoded = prefs.getString(pref, null) ?: return null
        return runCatching {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > IV_LENGTH)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, packed.copyOfRange(0, IV_LENGTH)))
            cipher.doFinal(packed.copyOfRange(IV_LENGTH, packed.size)).toString(Charsets.UTF_8)
        }.getOrElse {
            prefs.edit().remove(pref).apply()
            null
        }
    }

    fun save(prefs: SharedPreferences, bssid: String, password: String): Boolean {
        if (!bssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}")) || password.length !in 8..63) return false
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val packed = cipher.iv + cipher.doFinal(password.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(prefKey(bssid), Base64.encodeToString(packed, Base64.NO_WRAP)).commit()
        }.getOrDefault(false)
    }

    fun clear(prefs: SharedPreferences, bssid: String) {
        if (bssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}"))) {
            prefs.edit().remove(prefKey(bssid)).apply()
        }
    }
}
