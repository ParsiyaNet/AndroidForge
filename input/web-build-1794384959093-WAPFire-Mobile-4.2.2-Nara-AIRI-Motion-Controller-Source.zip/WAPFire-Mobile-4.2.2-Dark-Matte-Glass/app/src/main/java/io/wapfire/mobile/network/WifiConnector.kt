package io.wapfire.mobile.network

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.LinkProperties
import android.net.MacAddress
import java.net.Inet4Address
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiInfo
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class WifiConnector(context: Context) {
    companion object {
        @Volatile private var sharedInstance: WifiConnector? = null

        /** One process-wide connector shared by the Activity and the Wi-Fi keep-alive service. */
        fun shared(context: Context): WifiConnector = synchronized(this) {
            sharedInstance ?: WifiConnector(context.applicationContext).also { sharedInstance = it }
        }
    }

    private val appContext = context.applicationContext
    private val connectivity = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeCallback: ConnectivityManager.NetworkCallback? = null
    private var activeReadinessPoll: Runnable? = null
    private var passiveWifiCallback: ConnectivityManager.NetworkCallback? = null
    private var activeRequestCancelled: AtomicBoolean? = null
    private var activeRecoveryRunnable: Runnable? = null

    /**
     * Bind app traffic to the currently active Wi-Fi when one exists. If Wi-Fi is
     * currently off/unavailable, explicitly clear any stale process binding so
     * Android can use its normal default network until Wi-Fi returns.
     */
    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak", "NewApi")
    fun bindToCurrentWifi(
        expectedBssid: String? = null,
        onRestored: ((Network) -> Unit)? = null,
        onLost: (() -> Unit)? = null
    ): Boolean {
        return try {
            if (expectedBssid.isNullOrBlank()) {
                // Manual Device Address has no BSSID to key on. It still needs a
                // persistent Wi-Fi watcher: binding only the current Network is not
                // enough because Android replaces the Network object after Wi-Fi OFF/ON.
                stopPassiveWifiWatcher()
                connectivity.bindProcessToNetwork(null)

                fun isWifiNetwork(network: Network): Boolean =
                    connectivity.getNetworkCapabilities(network)
                        ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

                val active = connectivity.activeNetwork
                var matchedNetwork: Network? =
                    (listOfNotNull(active) + connectivity.allNetworks.toList())
                        .distinct()
                        .firstOrNull { isWifiNetwork(it) }
                var hasBeenConnected = matchedNetwork != null
                var waitingForRestore = matchedNetwork == null

                fun acceptManualWifi(
                    network: Network,
                    capabilities: NetworkCapabilities?,
                    callback: ConnectivityManager.NetworkCallback
                ) {
                    if (passiveWifiCallback !== callback ||
                        capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) return

                    val previous = matchedNetwork
                    val restored = waitingForRestore || (hasBeenConnected && previous != null && previous != network)
                    matchedNetwork = network
                    hasBeenConnected = true
                    waitingForRestore = false
                    runCatching { connectivity.bindProcessToNetwork(network) }
                    if (restored) mainHandler.post { onRestored?.invoke(network) }
                }

                fun markManualWifiLost(network: Network, callback: ConnectivityManager.NetworkCallback) {
                    if (passiveWifiCallback !== callback || matchedNetwork != network) return
                    matchedNetwork = null
                    waitingForRestore = hasBeenConnected
                    runCatching { connectivity.bindProcessToNetwork(null) }
                    mainHandler.post { onLost?.invoke() }
                }

                val callback = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        // Wait for capabilities so we only bind a real Wi-Fi transport.
                    }

                    override fun onCapabilitiesChanged(
                        network: Network,
                        networkCapabilities: NetworkCapabilities
                    ) {
                        if (passiveWifiCallback === this) {
                            acceptManualWifi(network, networkCapabilities, this)
                        }
                    }

                    override fun onLost(network: Network) {
                        markManualWifiLost(network, this)
                    }
                }
                passiveWifiCallback = callback
                connectivity.registerNetworkCallback(
                    NetworkRequest.Builder()
                        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                        .build(),
                    callback
                )

                val currentMatch = matchedNetwork
                if (currentMatch != null) connectivity.bindProcessToNetwork(currentMatch)
                currentMatch != null
            } else {
                stopPassiveWifiWatcher()
                // Remove any old process pin before resolving the current target Network.
                connectivity.bindProcessToNetwork(null)
                val wantedBssid = expectedBssid.trim()
                var matchedNetwork: Network? = connectivity.allNetworks.firstOrNull { candidate ->
                    val caps = connectivity.getNetworkCapabilities(candidate)
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true &&
                        bssidForNetwork(caps).equals(wantedBssid, ignoreCase = true)
                }
                var hasBeenConnected = matchedNetwork != null
                var waitingForRestore = false

                // The callback must request location-sensitive transport info on Android 12+;
                // otherwise WifiInfo.BSSID is redacted and the app cannot recognize WAPFire.
                fun accept(network: Network, capabilities: NetworkCapabilities?) {
                    if (passiveWifiCallback == null || capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true) return
                    if (!bssidForNetwork(capabilities).equals(wantedBssid, ignoreCase = true)) return

                    val restored = waitingForRestore
                    matchedNetwork = network
                    hasBeenConnected = true
                    waitingForRestore = false
                    runCatching { connectivity.bindProcessToNetwork(network) }
                    if (restored) mainHandler.post { onRestored?.invoke(network) }
                }

                fun markLost(network: Network, callback: ConnectivityManager.NetworkCallback) {
                    if (passiveWifiCallback !== callback || matchedNetwork != network) return
                    matchedNetwork = null
                    if (hasBeenConnected) waitingForRestore = true
                    runCatching { connectivity.bindProcessToNetwork(null) }
                    mainHandler.post { onLost?.invoke() }
                }

                val callback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    object : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
                        override fun onAvailable(network: Network) {
                            // Wait for onCapabilitiesChanged; synchronous capability reads
                            // in onAvailable can race and return null on Android 10+.
                        }
                        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                            if (passiveWifiCallback === this) accept(network, networkCapabilities)
                        }
                        override fun onLost(network: Network) { markLost(network, this) }
                    }
                } else {
                    object : ConnectivityManager.NetworkCallback() {
                        override fun onAvailable(network: Network) {
                            // Wait for onCapabilitiesChanged; synchronous capability reads
                            // in onAvailable can race and return null on Android 10+.
                        }
                        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                            if (passiveWifiCallback === this) accept(network, networkCapabilities)
                        }
                        override fun onLost(network: Network) { markLost(network, this) }
                    }
                }
                passiveWifiCallback = callback
                connectivity.registerNetworkCallback(
                    NetworkRequest.Builder()
                        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build(),
                    callback
                )

                val currentMatch = matchedNetwork
                if (currentMatch != null) connectivity.bindProcessToNetwork(currentMatch)
                currentMatch != null
            }
        } catch (_: Exception) {
            stopPassiveWifiWatcher()
            runCatching { connectivity.bindProcessToNetwork(null) }
            false
        }
    }

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    private fun bssidForNetwork(capabilities: NetworkCapabilities?): String {
        val transportInfo = capabilities?.transportInfo as? WifiInfo
        val transportBssid = transportInfo?.bssid.orEmpty()
        if (transportBssid.isNotBlank() && transportBssid != "02:00:00:00:00:00") return transportBssid
        // On older Android releases WifiInfo may not be exposed through
        // NetworkCapabilities. WifiManager still exposes the currently associated BSSID.
        return try { wifiManager.connectionInfo?.bssid.orEmpty() } catch (_: Exception) { "" }
    }

    private fun stopPassiveWifiWatcher() {
        passiveWifiCallback?.let { callback ->
            runCatching { connectivity.unregisterNetworkCallback(callback) }
        }
        passiveWifiCallback = null
    }

    private fun ipv4Gateway(properties: LinkProperties?): String? {
        return properties?.routes
            ?.firstOrNull { route -> route.isDefaultRoute && route.gateway is Inet4Address }
            ?.gateway?.hostAddress
    }

    private fun hasUsableIpv4(properties: LinkProperties?): Boolean {
        return properties?.linkAddresses?.any { link ->
            val address = link.address as? Inet4Address
            address != null && !address.isLoopbackAddress && !address.isLinkLocalAddress
        } == true
    }

    @SuppressLint("MissingPermission", "WifiManagerPotentialLeak")
    fun connect(
        ssid: String,
        bssid: String,
        password: String,
        securityMode: String,
        onAvailable: (Network, String) -> Unit,
        onFailure: (String) -> Unit,
        onLost: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 29) {
            onFailure("Android 10 or newer is required for secure local Wi-Fi joining.")
            return
        }
        release()
        try {
            // Android persists Network Request approval per app + specific AP.
            // Always pin both SSID and the exact BSSID selected from scan results;
            // wildcard/pattern requests can trigger the approval UI again.
            if (!bssid.matches(Regex("(?i)[0-9a-f]{2}(:[0-9a-f]{2}){5}"))) {
                onFailure("A valid access-point BSSID is required. Re-scan and select the exact WAPFire device.")
                return
            }
            val specBuilder = WifiNetworkSpecifier.Builder()
                .setSsid(ssid)
                .setBssid(MacAddress.fromString(bssid))

            when (securityMode) {
                "WPA2_WPA3", "WPA3" -> specBuilder.setWpa3Passphrase(password)
                "WPA2" -> specBuilder.setWpa2Passphrase(password)
                "OPEN" -> Unit
                else -> if (password.isNotBlank()) specBuilder.setWpa2Passphrase(password)
            }

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specBuilder.build())
                .build()

            val requestFailed = AtomicBoolean(false)
            val everConnected = AtomicBoolean(false)
            val connected = AtomicBoolean(false)
            val cancelled = AtomicBoolean(false)
            activeRequestCancelled = cancelled

            var pendingNetwork: Network? = null
            var reportedNetwork: Network? = null
            var readinessPoll: Runnable? = null
            val recoveryAttempts = AtomicInteger(0)
            lateinit var registerRequest: () -> Unit
            lateinit var scheduleRecovery: (Long) -> Unit

            fun stopReadinessPoll() {
                readinessPoll?.let { pending -> mainHandler.removeCallbacks(pending) }
                readinessPoll = null
                activeReadinessPoll = null
            }

            fun stopRecovery() {
                activeRecoveryRunnable?.let { mainHandler.removeCallbacks(it) }
                activeRecoveryRunnable = null
            }

            fun terminateWithFailure(message: String) {
                if (cancelled.get() || !requestFailed.compareAndSet(false, true)) return
                cancelled.set(true)
                connected.set(false)
                pendingNetwork = null
                reportedNetwork = null
                stopReadinessPoll()
                stopRecovery()
                activeCallback?.let {
                    runCatching { connectivity.unregisterNetworkCallback(it) }
                    if (activeCallback === it) activeCallback = null
                }
                runCatching { connectivity.bindProcessToNetwork(null) }
                if (activeRequestCancelled === cancelled) activeRequestCancelled = null
                mainHandler.post { onFailure.invoke(message) }
            }

            fun reportAvailable(network: Network, properties: LinkProperties?, owner: ConnectivityManager.NetworkCallback) {
                if (cancelled.get() || requestFailed.get() || activeCallback !== owner || pendingNetwork != network) return
                val gateway = ipv4Gateway(properties)
                    ?: ipv4Gateway(connectivity.getLinkProperties(network))
                    ?: "192.168.4.1"
                stopReadinessPoll()
                val isNewUsableNetwork = reportedNetwork != network
                reportedNetwork = network
                connected.set(true)
                everConnected.set(true)
                recoveryAttempts.set(0)
                stopRecovery()
                if (isNewUsableNetwork) {
                    mainHandler.post {
                        if (!cancelled.get() && !requestFailed.get() && activeCallback === owner && reportedNetwork == network) {
                            onAvailable.invoke(network, gateway)
                        }
                    }
                }
            }

            fun startReadinessPoll(network: Network, owner: ConnectivityManager.NetworkCallback) {
                stopReadinessPoll()
                val poll = object : Runnable {
                    var waitedMs = 0
                    override fun run() {
                        if (cancelled.get() || requestFailed.get() || activeCallback !== owner || pendingNetwork != network || reportedNetwork == network) return
                        val properties = connectivity.getLinkProperties(network)
                        val gateway = ipv4Gateway(properties)
                        if (hasUsableIpv4(properties) && !gateway.isNullOrBlank()) {
                            reportAvailable(network, properties, owner)
                            return
                        }
                        waitedMs += 250
                        if (waitedMs >= 10_000) {
                            if (hasUsableIpv4(properties)) {
                                reportAvailable(network, properties, owner)
                            } else if (everConnected.get()) {
                                // DHCP may still be rebuilding after a radio toggle. Retry
                                // the request instead of permanently terminating the session.
                                scheduleRecovery(1_500)
                            } else {
                                terminateWithFailure("Android associated with $ssid but did not obtain an IPv4 address. Check that the WAPFire SoftAP/DHCP service is running, then retry.")
                            }
                            return
                        }
                        mainHandler.postDelayed(this, 250)
                    }
                }
                readinessPoll = poll
                activeReadinessPoll = poll
                mainHandler.post(poll)
            }

            scheduleRecovery = recoveryScheduling@{ delayMs ->
                if (cancelled.get() || requestFailed.get()) return@recoveryScheduling
                stopRecovery()
                val recovery = object : Runnable {
                    override fun run() {
                        if (cancelled.get() || requestFailed.get() || connected.get()) return
                        if (!wifiManager.isWifiEnabled) {
                            mainHandler.postDelayed(this, 1_000)
                            activeRecoveryRunnable = this
                            return
                        }
                        if (activeRecoveryRunnable === this) activeRecoveryRunnable = null

                        val oldCallback = activeCallback
                        if (oldCallback != null) {
                            runCatching { connectivity.unregisterNetworkCallback(oldCallback) }
                            if (activeCallback === oldCallback) activeCallback = null
                        }
                        stopReadinessPoll()
                        pendingNetwork = null
                        reportedNetwork = null
                        runCatching { connectivity.bindProcessToNetwork(null) }
                        recoveryAttempts.incrementAndGet()
                        registerRequest()
                    }
                }
                activeRecoveryRunnable = recovery
                mainHandler.postDelayed(recovery, delayMs)
            }

            registerRequest = requestRegistration@{
                if (cancelled.get() || requestFailed.get()) return@requestRegistration
                pendingNetwork = null
                reportedNetwork = null
                connected.set(false)

                val callback = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        if (activeCallback !== this || cancelled.get() || requestFailed.get()) return
                        stopRecovery()
                        pendingNetwork = network
                        runCatching { connectivity.bindProcessToNetwork(network) }
                        if (reportedNetwork != network) startReadinessPoll(network, this)
                    }

                    override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                        if (activeCallback === this && !cancelled.get() && !requestFailed.get() && pendingNetwork == network &&
                            reportedNetwork != network && hasUsableIpv4(linkProperties) &&
                            !ipv4Gateway(linkProperties).isNullOrBlank()) {
                            reportAvailable(network, linkProperties, this)
                        }
                    }

                    override fun onUnavailable() {
                        if (activeCallback !== this || cancelled.get() || requestFailed.get()) return
                        if (everConnected.get()) {
                            // Android can release a local-only WifiNetworkSpecifier request
                            // after Wi-Fi is toggled. Re-create the request when Wi-Fi is back.
                            if (activeCallback === this) activeCallback = null
                            connected.set(false)
                            stopReadinessPoll()
                            runCatching { connectivity.bindProcessToNetwork(null) }
                            val backoff = (1_500L * (1L shl recoveryAttempts.get().coerceAtMost(4))).coerceAtMost(24_000L)
                            scheduleRecovery(backoff)
                        } else {
                            terminateWithFailure("Android could not authenticate to $ssid using $securityMode. Check the WAPFire Wi-Fi password and retry.")
                        }
                    }

                    override fun onLost(network: Network) {
                        if (activeCallback !== this || cancelled.get() || requestFailed.get()) return
                        if (pendingNetwork != network && reportedNetwork != network) return
                        val wasUsable = reportedNetwork == network && connected.get()
                        if (pendingNetwork == network) pendingNetwork = null
                        if (reportedNetwork == network) reportedNetwork = null
                        if (wasUsable) connected.set(false)

                        stopReadinessPoll()
                        runCatching { connectivity.bindProcessToNetwork(null) }
                        if (wasUsable) mainHandler.post { onLost.invoke() }

                        // Give Android a brief chance to restore the same request. If it
                        // does not, unregister the stale request and submit it again.
                        scheduleRecovery(2_500)
                    }
                }

                activeCallback = callback
                try {
                    if (everConnected.get()) {
                        // No timeout during recovery: leave the request pending until the
                        // selected WAPFire SoftAP becomes available again.
                        connectivity.requestNetwork(request, callback)
                    } else {
                        connectivity.requestNetwork(request, callback, 60_000)
                    }
                } catch (e: Exception) {
                    if (everConnected.get()) {
                        if (activeCallback === callback) activeCallback = null
                        scheduleRecovery(4_000)
                    } else {
                        terminateWithFailure(e.message ?: "Could not create the Wi-Fi connection request.")
                    }
                }
            }

            registerRequest()
        } catch (e: Exception) {
            activeReadinessPoll?.let { mainHandler.removeCallbacks(it) }
            activeReadinessPoll = null
            activeRecoveryRunnable?.let { mainHandler.removeCallbacks(it) }
            activeRecoveryRunnable = null
            activeCallback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
            activeCallback = null
            runCatching { connectivity.bindProcessToNetwork(null) }
            activeRequestCancelled?.set(true)
            activeRequestCancelled = null
            onFailure(e.message ?: "Could not create the Wi-Fi connection request.")
        }
    }

    fun release() {
        activeRequestCancelled?.set(true)
        activeRequestCancelled = null
        activeRecoveryRunnable?.let { mainHandler.removeCallbacks(it) }
        activeRecoveryRunnable = null
        activeReadinessPoll?.let { mainHandler.removeCallbacks(it) }
        activeReadinessPoll = null
        stopPassiveWifiWatcher()
        try { connectivity.bindProcessToNetwork(null) } catch (_: Exception) { }
        activeCallback?.let {
            try { connectivity.unregisterNetworkCallback(it) } catch (_: Exception) { }
        }
        activeCallback = null
    }
}
