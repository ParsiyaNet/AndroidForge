package io.wapfire.mobile.monitor

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Notification policy intentionally reads ONLY the firmware's Detection Breakdown
 * counters from /api/status. It never classifies the general Events timeline.
 */
internal object MonitorEventPolicy {
    data class DetectionDelta(
        val label: String,
        val previousCount: Long,
        val currentCount: Long
    ) {
        val newCount: Long get() = (currentCount - previousCount).coerceAtLeast(0L)
        val notificationTitle: String get() = "$label Detected"
        val notificationBody: String
            get() = "Detection Breakdown · +$newCount new · Total $currentCount"
    }

    /** The seven alertable Detection Breakdown labels. WPA Correct Password is deliberately absent. */
    val monitoredLabels: List<String> = listOf(
        "Auth Attack",
        "Deauth Attack",
        "Deauth Airplay",
        "WPS Pixie Reaver",
        "WPS Pixie Bully",
        "Evil Twin",
        "WPA Wrong Password"
    )

    private val labelAliases = mapOf(
        "auth_attack" to "Auth Attack",
        "authentication_attack" to "Auth Attack",
        "deauth" to "Deauth Attack",
        "deauth_attack" to "Deauth Attack",
        "deauthentication_attack" to "Deauth Attack",
        "deauth_airplay" to "Deauth Airplay",
        "deauthentication_airplay" to "Deauth Airplay",
        "wps_pixie_reaver" to "WPS Pixie Reaver",
        "pixie_reaver" to "WPS Pixie Reaver",
        "reaver" to "WPS Pixie Reaver",
        "wps_pixie_bully" to "WPS Pixie Bully",
        "pixie_bully" to "WPS Pixie Bully",
        "bully" to "WPS Pixie Bully",
        "evil_twin" to "Evil Twin",
        "wrong_password" to "WPA Wrong Password",
        "wpa_wrong_password" to "WPA Wrong Password"
        // correct_password / wpa_correct_password are intentionally not alertable.
    )

    /**
     * Returns null when the API response does not contain a usable labels array.
     * Unknown labels and WPA Correct Password are ignored by design.
     */
    fun readDetectionCounts(status: JSONObject): Map<String, Long>? {
        val labels: JSONArray = status.optJSONArray("labels") ?: return null
        if (labels.length() == 0) return null

        val counts = monitoredLabels.associateWith { 0L }.toMutableMap()
        for (index in 0 until labels.length()) {
            val item = labels.optJSONObject(index) ?: continue
            val canonical = labelAliases[normalize(item.optString("name"))] ?: continue
            counts[canonical] = item.optLong("count").coerceAtLeast(0L)
        }
        return counts
    }

    /** Only increasing cumulative counters generate notifications. Counter resets re-baseline silently. */
    fun increasedCounts(
        previous: Map<String, Long>,
        current: Map<String, Long>
    ): List<DetectionDelta> = monitoredLabels.mapNotNull { label ->
        val before = previous[label] ?: 0L
        val after = current[label] ?: before
        if (after > before) DetectionDelta(label, before, after) else null
    }

    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)
        .replace('-', '_').replace(Regex("\\s+"), "_")
}
