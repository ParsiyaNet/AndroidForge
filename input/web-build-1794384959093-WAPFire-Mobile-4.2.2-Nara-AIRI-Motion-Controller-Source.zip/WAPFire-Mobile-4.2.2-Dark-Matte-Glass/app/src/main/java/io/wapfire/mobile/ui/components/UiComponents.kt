package io.wapfire.mobile.ui.components

import io.wapfire.mobile.model.*


import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject


@Composable
internal fun ColorPickerField(
    p: Palette,
    fa: Boolean,
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panelAlt.copy(alpha = .58f))
            .border(1.dp, p.border.copy(alpha = .75f), RoundedCornerShape(14.dp))
            .clickable { open = true }.padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(runCatching { Color(AndroidColor.parseColor(value)) }.getOrDefault(Color.Red))
            .border(1.dp, Color.White.copy(alpha = .45f), RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(value.uppercase(Locale.US), color = p.muted, fontSize = 10.sp)
        }
        Text(tx(fa, "Choose", "انتخاب رنگ"), color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    if (open) ColorPickerDialog(p, fa, label, value, onDismiss = { open = false }, onApply = { onValueChange(it); open = false })
}

@Composable
internal fun ColorPickerDialog(
    p: Palette,
    fa: Boolean,
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    val hsv = remember(initial) {
        val values = floatArrayOf(0f, 1f, 1f)
        runCatching { AndroidColor.colorToHSV(AndroidColor.parseColor(initial), values) }
        values
    }
    var hue by remember(initial) { mutableStateOf(hsv[0]) }
    var saturation by remember(initial) { mutableStateOf(hsv[1]) }
    var brightness by remember(initial) { mutableStateOf(hsv[2]) }
    val pickedInt = AndroidColor.HSVToColor(floatArrayOf(hue, saturation, brightness))
    val pickedCompose = Color(pickedInt)
    val hex = String.format(Locale.US, "#%06X", pickedInt and 0xFFFFFF)
    fun updateSv(x: Float, y: Float, width: Float, height: Float) {
        if (width <= 0f || height <= 0f) return
        saturation = (x / width).coerceIn(0f, 1f)
        brightness = (1f - y / height).coerceIn(0f, 1f)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = p.text) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SaturationValueColorPicker(
                    hue = hue, saturation = saturation, brightness = brightness,
                    onPick = { x, y, w, h -> updateSv(x, y, w, h) }
                )
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tx(fa, "Hue", "ته‌رنگ"), color = p.text, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${hue.roundToInt()}°", color = p.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = hue, onValueChange = { hue = it }, valueRange = 0f..360f)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(pickedCompose)
                        .border(1.dp, p.border, RoundedCornerShape(10.dp)))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(hex, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(tx(fa, "Selected color", "رنگ انتخاب‌شده"), color = p.muted, fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(hex) }) { Text(tx(fa, "Apply", "اعمال"), color = p.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(fa, "Cancel", "لغو"), color = p.muted) } }
    )
}

@Composable
internal fun SaturationValueColorPicker(
    hue: Float,
    saturation: Float,
    brightness: Float,
    onPick: (Float, Float, Float, Float) -> Unit
) {
    val hueColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, 1f, 1f)))
    Canvas(
        Modifier.fillMaxWidth().height(190.dp)
            .pointerInput(hue) {
                detectTapGestures { point -> onPick(point.x, point.y, size.width.toFloat(), size.height.toFloat()) }
            }
            .pointerInput(hue) {
                detectDragGestures { change, _ ->
                    onPick(change.position.x, change.position.y, size.width.toFloat(), size.height.toFloat())
                }
            }
    ) {
        drawRect(brush = Brush.horizontalGradient(listOf(Color.White, hueColor)))
        drawRect(brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
        val x = saturation * size.width
        val y = (1f - brightness) * size.height
        drawCircle(Color.Black.copy(alpha = .82f), radius = 11.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
        drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(x, y), style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
internal fun Brand(p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(p.accent, p.blue))), contentAlignment = Alignment.Center) {
            Text("W", color = Color(0xFF08202A), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("WAPFIRE", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.7.sp)
            Text("WIRELESS INTELLIGENCE", color = p.muted, fontSize = 8.sp, letterSpacing = 1.1.sp)
        }
    }
}

/**
 * Space covered by the translucent top bar / floating bottom bar. Pages add it INSIDE their
 * scrolling area, so content scrolls underneath the glass bars and shows through them.
 */
internal val LocalContentInset = androidx.compose.runtime.compositionLocalOf { androidx.compose.foundation.layout.PaddingValues(0.dp) }

@Composable
internal fun ThemeAction(p: Palette, dark: Boolean, onTheme: () -> Unit) {
    // Exact Welcome Back theme glyph: one half-filled circle (contrast icon).
    // Keep the same glyph in both themes; tapping it toggles the active theme.
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(shape)
            .background(p.panelAlt.copy(alpha = .70f))
            .border(1.dp, p.border.copy(alpha = .78f), shape)
            .clickable { onTheme() }
            .padding(horizontal = 9.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(17.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.minDimension * .42f
            val origin = Offset(cx - radius, cy - radius)
            val diameter = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f)
            val color = p.text

            // Solid left semicircle; the right half remains transparent.
            drawArc(
                color = color,
                startAngle = 90f,
                sweepAngle = 180f,
                useCenter = true,
                topLeft = origin,
                size = diameter
            )
            // Continuous outer ring and the straight center split.
            drawCircle(color = color, radius = radius, center = Offset(cx, cy), style = Stroke(width = 1.05.dp.toPx()))
            drawLine(
                color = color,
                start = Offset(cx, cy - radius),
                end = Offset(cx, cy + radius),
                strokeWidth = 1.05.dp.toPx()
            )
        }
    }
}

@Composable
internal fun SmallAction(p: Palette, label: String, onClick: () -> Unit) {
    // Match the theme control exactly: both controls are 36 × 36 dp.
    // Keep language codes LTR even inside the Persian RTL screen.
    Box(
        Modifier.size(36.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(p.panelAlt.copy(alpha = .70f))
            .border(1.dp, p.border.copy(alpha = .78f), RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = label,
                color = p.text,
                fontSize = if (label.length == 2) 11.sp else 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp)
            )
        }
    }
}

@Composable
internal fun SectionCard(p: Palette, title: String, subtitle: String = "", content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(23.dp)
    Column(Modifier.fillMaxWidth().shadow(14.dp, shape, ambientColor = Color.Black.copy(alpha = .12f), spotColor = p.accent.copy(alpha = .10f))
        .clip(shape)
        .background(Brush.linearGradient(listOf(p.panel.copy(alpha = .84f), p.panelAlt.copy(alpha = .70f), p.panel.copy(alpha = .78f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), p.border.copy(alpha = .78f), Color.White.copy(alpha = .05f))), shape)
        .padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title.uppercase(), color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = p.muted, fontSize = 10.sp, lineHeight = 15.sp)
        }
        content.invoke(this)
    }
}

@Composable
internal fun ScheduleTimePickerField(
    p: Palette,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    onTimeSelected: (String) -> Unit
) {
    val context = LocalContext.current
    val safeValue = normalizeScheduleTime(value, "22:00")
    val parts = safeValue.split(":")
    val initialHour = parts[0].toInt()
    val initialMinute = parts[1].toInt()
    OutlinedButton(
        onClick = {
            TimePickerDialog(
                context,
                { _, hour, minute -> onTimeSelected(String.format(Locale.US, "%02d:%02d", hour, minute)) },
                initialHour,
                initialMinute,
                true
            ).show()
        },
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(13.dp),
        border = BorderStroke(1.dp, p.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp), horizontalAlignment = Alignment.Start) {
            Text(label, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(safeValue, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
internal fun MessageCard(p: Palette, message: String, danger: Boolean, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(p.panel)
            .border(1.dp, (if (danger) p.red else p.green).copy(alpha = .72f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (danger) "!" else "✓", color = if (danger) p.red else p.green, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(9.dp))
        Text(
            message,
            color = p.text,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(28.dp).clip(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
            Text("×", color = p.muted, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun ActionButton(p: Palette, label: String, onClick: () -> Unit, enabled: Boolean = true, primary: Boolean = false, modifier: Modifier = Modifier) {
    val bg = if (primary) p.accent else p.panelAlt
    val fg = if (primary) Color(0xFF06232A) else p.text
    Box(modifier.clip(RoundedCornerShape(13.dp)).background(if (enabled) bg else bg.copy(alpha = .45f)).border(1.dp, if (primary) p.accent else p.border, RoundedCornerShape(13.dp)).clickable(enabled = enabled) { onClick() }.padding(horizontal = 14.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) fg else p.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun NativeField(p: Palette, value: String, onValue: (String) -> Unit, label: String, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text, focusRequester: FocusRequester? = null) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth().then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        label = { Text(label, fontSize = 12.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(13.dp),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = p.text, unfocusedTextColor = p.text,
            focusedBorderColor = p.accent, unfocusedBorderColor = p.border,
            focusedLabelColor = p.accent, unfocusedLabelColor = p.muted,
            cursorColor = p.accent
        )
    )
}

@Composable
internal fun DeviceResult(p: Palette, title: String, detail: String, badge: String, onClick: () -> Unit, action: String, selected: Boolean = false, enabled: Boolean = true) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape)
        .background(if (selected) Brush.linearGradient(listOf(p.accentSoft.copy(alpha = .82f), p.accentSoft.copy(alpha = .58f))) else Brush.linearGradient(listOf(p.panelAlt.copy(alpha = .82f), p.panel.copy(alpha = .64f))))
        .border(1.dp, if (selected) p.accent else p.border.copy(alpha = .68f), shape)
        .clickable(enabled = enabled && action.isNotBlank()) { onClick() }.padding(11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(p.accentSoft), contentAlignment = Alignment.Center) { Text("⌁", color = p.accent, fontSize = 18.sp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = p.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (badge.isNotBlank()) Text(badge, color = p.accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        if (action.isNotBlank()) Text(action, color = p.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun MetricTile(p: Palette, value: String, label: String, glyph: String, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.shadow(8.dp, shape).clip(shape)
        .background(Brush.linearGradient(listOf(p.panelAlt, p.bg2)))
        .border(1.dp, p.border, shape).padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(glyph, color = color, fontSize = 15.sp); Spacer(Modifier.weight(1f)); Box(Modifier.size(5.dp).clip(CircleShape).background(color)) }
        Text(value, color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = p.muted, fontSize = 10.sp)
    }
}

@Composable
internal fun ThreatRing(p: Palette, score: Float, level: String) {
    val normalizedScore = score.coerceIn(0f, 10f)
    // This ring is rendered on the Overview's always-dark glass card in BOTH themes.
    // Do not use the light palette's dark p.green/p.orange values here: they lose contrast.
    val color = when (level.uppercase()) {
        "CRITICAL", "HIGH" -> Color(0xFFFF9AAA)
        "WARNING", "MONITORING", "MEDIUM", "MODERATE" -> Color(0xFFFFD08C)
        "OPTIMAL", "LOW" -> Color(0xFF8CF0BE)
        else -> Color(0xFFA9C9FF)
    }
    val scoreText = String.format(Locale.US, "%.1f", normalizedScore)
    Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(color.copy(alpha = .18f), -90f, 360f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
            // Firmware score_tenths is 0..100 (= 0.0..10.0). One risk point is 36 degrees.
            drawArc(color, -90f, normalizedScore * 36f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("$scoreText/10", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(level.uppercase(), color = color, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
internal fun NativeLineChart(p: Palette, primary: List<Int>, secondary: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val pad = 8.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        for (i in 0..3) {
            val y = pad + h * i / 3f
            drawLine(p.border, Offset(pad, y), Offset(size.width - pad, y), 1.dp.toPx())
        }
        fun drawSeries(values: List<Int>, color: Color, stroke: Float) {
            if (values.size < 2) return
            val max = (primary + secondary).maxOrNull()?.coerceAtLeast(1) ?: 1
            val path = Path()
            values.forEachIndexed { index, v ->
                val x = pad + (w * index / (values.size - 1).toFloat())
                val y = pad + h - (v.coerceAtLeast(0).toFloat() / max) * h
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        drawSeries(primary, p.accent, 2.5.dp.toPx())
        drawSeries(secondary, p.blue, 2.dp.toPx())
    }
}

@Composable
internal fun LegendDot(color: Color, label: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(label, color = p.muted, fontSize = 9.sp)
    }
}

@Composable
internal fun MiniValue(p: Palette, value: String, label: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.muted, fontSize = 8.sp)
    }
}

@Composable
internal fun ToggleRow(p: Palette, title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = p.muted, fontSize = 9.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
internal fun DividerLine(p: Palette) { Box(Modifier.fillMaxWidth().height(1.dp).background(p.border)) }

@Composable
internal fun InfoLine(p: Palette, key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(key, color = p.muted, fontSize = 10.sp)
        Text(value, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
