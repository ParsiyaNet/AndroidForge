package io.wapfire.mobile.monitor

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import io.wapfire.mobile.MainActivity
import android.app.PendingIntent
import android.content.Intent
import org.json.JSONObject

/**
 * One notification pipeline shared by the in-app poller and the optional background service.
 * A single persisted counter baseline prevents duplicate notifications when both are active.
 */
internal object DetectionBreakdownNotificationCenter {
    private const val PREFS_NAME = "wapfire_native_v22"
    private const val PREF_COUNTS = "background_monitor_detection_breakdown_counts_v2"
    private const val CHANNEL_ALERTS = "wapfire_detection_breakdown_alerts"
    private const val NOTIFICATION_GROUP = "wapfire_detection_breakdown"
    private val lock = Any()

    fun process(context: Context, status: JSONObject) {
        synchronized(lock) {
            val current = MonitorEventPolicy.readDetectionCounts(status) ?: return
            val appContext = context.applicationContext
            val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedRaw = prefs.getString(PREF_COUNTS, null)

            // First valid snapshot is a quiet baseline. Never replay historical counters.
            if (savedRaw.isNullOrBlank()) {
                saveCounts(prefs, current)
                return
            }

            val previousJson = runCatching { JSONObject(savedRaw) }.getOrNull()
            if (previousJson == null) {
                saveCounts(prefs, current)
                return
            }

            val previous = MonitorEventPolicy.monitoredLabels.associateWith { label ->
                previousJson.optLong(label, 0L).coerceAtLeast(0L)
            }
            val deltas = MonitorEventPolicy.increasedCounts(previous, current)

            if (deltas.isNotEmpty()) {
                ensureAlertChannel(appContext)
                val manager = NotificationManagerCompat.from(appContext)
                if (manager.areNotificationsEnabled()) {
                    deltas.forEach { delta ->
                        val notification = NotificationCompat.Builder(appContext, CHANNEL_ALERTS)
                            .setSmallIcon(android.R.drawable.ic_lock_lock)
                            .setContentTitle(delta.notificationTitle)
                            .setContentText(delta.notificationBody)
                            .setStyle(NotificationCompat.BigTextStyle().bigText(delta.notificationBody))
                            .setContentIntent(openAppPendingIntent(appContext))
                            .setAutoCancel(true)
                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                            .setCategory(NotificationCompat.CATEGORY_ALARM)
                            .setDefaults(NotificationCompat.DEFAULT_ALL)
                            .setGroup(NOTIFICATION_GROUP)
                            .build()

                        // Stable IDs avoid duplicate posts if foreground/background polling overlaps
                        // or the process restarts between notify() and persisting the new baseline.
                        val stableKey = "${delta.label}|${delta.currentCount}"
                        val notificationId = (stableKey.hashCode() and 0x7fffffff).coerceAtLeast(1)
                        runCatching { manager.notify(notificationId, notification) }
                    }
                }
            }

            // Persist even when Android notifications are disabled: do not replay old detections later.
            // Decreases/reboots also become a new silent baseline through increasedCounts().
            saveCounts(prefs, current)
        }
    }

    private fun saveCounts(prefs: android.content.SharedPreferences, counts: Map<String, Long>) {
        val json = JSONObject()
        counts.forEach { (label, count) -> json.put(label, count) }
        prefs.edit().putString(PREF_COUNTS, json.toString()).apply()
    }

    private fun ensureAlertChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ALERTS) != null) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERTS,
                "WAPFire Detection Breakdown",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for the seven enabled WAPFire Detection Breakdown categories."
                enableVibration(true)
                setShowBadge(true)
            }
        )
    }

    private fun openAppPendingIntent(context: Context): PendingIntent = PendingIntent.getActivity(
        context,
        1,
        Intent(context, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        ),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
