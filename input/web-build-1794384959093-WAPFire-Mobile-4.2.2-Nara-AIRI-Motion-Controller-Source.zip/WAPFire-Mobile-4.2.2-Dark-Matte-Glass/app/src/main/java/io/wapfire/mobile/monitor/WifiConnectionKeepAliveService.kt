package io.wapfire.mobile.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import io.wapfire.mobile.MainActivity
import io.wapfire.mobile.network.WifiConnector
import io.wapfire.mobile.security.SoftApPasswordVault

/**
 * Keeps the process that owns the WifiNetworkSpecifier request in the foreground while
 * the user closes the WAPFire Activity. Android ties a local-only network request to
 * the requesting app process, so this service deliberately shares the Activity's
 * process-wide WifiConnector instance.
 */
class WifiConnectionKeepAliveService : Service() {
    companion object {
        const val ACTION_START = "io.wapfire.mobile.wifi_keepalive.START"
        const val ACTION_CONNECTED = "io.wapfire.mobile.wifi_keepalive.CONNECTED"
        const val ACTION_UPDATE = "io.wapfire.mobile.wifi_keepalive.UPDATE"
        const val ACTION_STOP = "io.wapfire.mobile.wifi_keepalive.STOP"

        private const val PREFS = "wapfire_native_v22"
        private const val PREF_ACTIVE = "wifi_connection_keepalive_active"
        private const val PREF_SSID = "wifi_connection_keepalive_ssid"
        private const val PREF_BSSID = "wifi_connection_keepalive_bssid"
        private const val PREF_SECURITY = "wifi_connection_keepalive_security"
        private const val CHANNEL_ID = "wapfire_wifi_connection"
        private const val NOTIFICATION_ID = 4140
        private const val EXTRA_SSID = "ssid"
        private const val EXTRA_BSSID = "bssid"
        private const val EXTRA_SECURITY = "security"
        private const val EXTRA_TEXT = "status_text"

        fun start(context: Context, ssid: String, bssid: String, securityMode: String) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_ACTIVE, true)
                .putString(PREF_SSID, ssid)
                .putString(PREF_BSSID, bssid)
                .putString(PREF_SECURITY, securityMode)
                .apply()
            val intent = Intent(context, WifiConnectionKeepAliveService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_SSID, ssid)
                .putExtra(EXTRA_BSSID, bssid)
                .putExtra(EXTRA_SECURITY, securityMode)
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (failure: Exception) {
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean(PREF_ACTIVE, false)
                    .apply()
                throw failure
            }
        }

        fun updateConnected(context: Context, ssid: String, bssid: String) {
            val intent = Intent(context, WifiConnectionKeepAliveService::class.java)
                .setAction(ACTION_CONNECTED)
                .putExtra(EXTRA_SSID, ssid)
                .putExtra(EXTRA_BSSID, bssid)
            runCatching { context.startService(intent) }
        }

        fun updateStatus(context: Context, message: String) {
            val intent = Intent(context, WifiConnectionKeepAliveService::class.java)
                .setAction(ACTION_UPDATE)
                .putExtra(EXTRA_TEXT, message)
            runCatching { context.startService(intent) }
        }

        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_ACTIVE, false)
                .remove(PREF_SSID)
                .remove(PREF_BSSID)
                .remove(PREF_SECURITY)
                .apply()
            // Release the exact shared request immediately, then stop the notification service.
            runCatching { WifiConnector.shared(context).release() }
            runCatching { context.stopService(Intent(context, WifiConnectionKeepAliveService::class.java)) }
        }

        fun isActive(context: Context): Boolean = context
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(PREF_ACTIVE, false)
    }

    private lateinit var connector: WifiConnector
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        // This must be the same singleton used by WapFireNativeApp, not a second request owner.
        connector = WifiConnector.shared(this)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean(PREF_ACTIVE, false)
                    .remove(PREF_SSID)
                    .remove(PREF_BSSID)
                    .remove(PREF_SECURITY)
                    .apply()
                connector.release()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
                return START_NOT_STICKY
            }
            ACTION_CONNECTED -> {
                val ssid = intent.getStringExtra(EXTRA_SSID).orEmpty()
                val bssid = intent.getStringExtra(EXTRA_BSSID).orEmpty()
                showStatus("Connected to $ssid · $bssid")
            }
            ACTION_UPDATE -> showStatus(intent.getStringExtra(EXTRA_TEXT).orEmpty().ifBlank { "Maintaining WAPFire Wi-Fi connection" })
            ACTION_START -> {
                val ssid = intent.getStringExtra(EXTRA_SSID).orEmpty()
                val bssid = intent.getStringExtra(EXTRA_BSSID).orEmpty()
                val security = intent.getStringExtra(EXTRA_SECURITY).orEmpty()
                showStatus("Keeping Wi-Fi connection to $ssid active")
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean(PREF_ACTIVE, true)
                    .putString(PREF_SSID, ssid)
                    .putString(PREF_BSSID, bssid)
                    .putString(PREF_SECURITY, security)
                    .apply()
            }
            null -> {
                // START_STICKY process recreation: reconstruct the request from the encrypted
                // per-BSSID credential once one has been verified and saved by the Activity.
                if (!isActive(this)) {
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                showStatus("Restoring WAPFire Wi-Fi connection…")
                restoreRequestAfterProcessRestart()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // A swipe from Recents must not stop this user-started connection service.
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Do not release on an OS-managed service/process teardown. The explicit STOP action
        // owns intentional disconnection; an abrupt process death already releases callbacks.
        super.onDestroy()
    }

    private fun restoreRequestAfterProcessRestart() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ssid = prefs.getString(PREF_SSID, "").orEmpty()
        val bssid = prefs.getString(PREF_BSSID, "").orEmpty()
        val security = prefs.getString(PREF_SECURITY, "OPEN").orEmpty()
        if (ssid.isBlank() || bssid.isBlank()) {
            showStatus("Open WAPFire and reconnect to restore the selected Wi-Fi link")
            return
        }
        val password = if (security == "OPEN") "" else SoftApPasswordVault.load(prefs, bssid).orEmpty()
        if (security != "OPEN" && password.isBlank()) {
            showStatus("Open WAPFire and enter the Wi-Fi password to restore this link")
            prefs.edit().putBoolean(PREF_ACTIVE, false).apply()
            stopSelf()
            return
        }
        connector.connect(
            ssid = ssid,
            bssid = bssid,
            password = password,
            securityMode = security,
            onAvailable = { _, _ -> showStatus("Connected to $ssid · connection maintained") },
            onFailure = { reason ->
                showStatus("Could not restore Wi-Fi link · ${reason.take(100)}")
                prefs.edit().putBoolean(PREF_ACTIVE, false).apply()
                stopSelf()
            },
            onLost = { showStatus("Wi-Fi link lost · attempting to reconnect…") }
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "WAPFire Wi-Fi connection", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the selected WAPFire SoftAP connection active while the app is closed"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun showStatus(text: String) {
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(text),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        )
        runCatching { NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification(text)) }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            4141,
            Intent(this, WifiConnectionKeepAliveService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this,
            4142,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("WAPFire Wi-Fi Connection")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
}
