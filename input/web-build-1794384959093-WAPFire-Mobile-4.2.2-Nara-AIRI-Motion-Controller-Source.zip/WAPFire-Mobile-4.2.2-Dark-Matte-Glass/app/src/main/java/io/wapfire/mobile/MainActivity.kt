package io.wapfire.mobile

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import io.wapfire.mobile.ui.WapFireNativeApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.rgb(7, 20, 29)
        window.navigationBarColor = AndroidColor.rgb(7, 20, 29)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        setContent { WapFireNativeApp() }
    }
}
