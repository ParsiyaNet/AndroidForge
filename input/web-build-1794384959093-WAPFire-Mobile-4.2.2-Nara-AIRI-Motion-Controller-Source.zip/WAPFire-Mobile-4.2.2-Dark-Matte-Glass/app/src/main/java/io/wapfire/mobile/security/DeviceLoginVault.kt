package io.wapfire.mobile.security

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.util.Locale
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal data class SavedDeviceLogin(val username: String, val password: String)

/** Stores only an AES-GCM ciphertext in preferences; the AES key stays in Android Keystore. */
internal object DeviceLoginVault {
    private const val KEY_ALIAS = "io.wapfire.mobile.device-login.v1"
    private const val PREF_REMEMBER = "remember_device_password"
    private const val PREF_HOST = "remembered_device_host"
    private const val PREF_CIPHER = "remembered_device_password_enc"
    private const val IV_LENGTH = 12

    private fun normalizeHost(value: String): String = value.trim()
        .removePrefix("http://").removePrefix("https://").substringBefore('/')
        .lowercase(Locale.ROOT)

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    fun load(prefs: android.content.SharedPreferences, host: String): SavedDeviceLogin? {
        if (!prefs.getBoolean(PREF_REMEMBER, false)) return null
        if (normalizeHost(prefs.getString(PREF_HOST, "").orEmpty()) != normalizeHost(host)) return null
        val encoded = prefs.getString(PREF_CIPHER, null) ?: return null
        return runCatching {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size > IV_LENGTH) { "Saved credential is invalid" }
            val iv = packed.copyOfRange(0, IV_LENGTH)
            val ciphertext = packed.copyOfRange(IV_LENGTH, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val clear = cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
            val split = clear.indexOf('\n')
            require(split >= 0) { "Saved credential is invalid" }
            SavedDeviceLogin(clear.substring(0, split), clear.substring(split + 1))
        }.getOrElse {
            clear(prefs)
            null
        }
    }

    fun save(prefs: android.content.SharedPreferences, host: String, username: String, password: String): Boolean {
        if (username.isBlank() || password.isEmpty()) return false
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ciphertext = cipher.doFinal((username + "\n" + password).toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + ciphertext
            prefs.edit()
                .putBoolean(PREF_REMEMBER, true)
                .putString(PREF_HOST, normalizeHost(host))
                .putString(PREF_CIPHER, Base64.encodeToString(packed, Base64.NO_WRAP))
                .apply()
            true
        }.getOrDefault(false)
    }

    fun clear(prefs: android.content.SharedPreferences) {
        prefs.edit()
            .putBoolean(PREF_REMEMBER, false)
            .remove(PREF_HOST)
            .remove(PREF_CIPHER)
            .apply()
    }
}
