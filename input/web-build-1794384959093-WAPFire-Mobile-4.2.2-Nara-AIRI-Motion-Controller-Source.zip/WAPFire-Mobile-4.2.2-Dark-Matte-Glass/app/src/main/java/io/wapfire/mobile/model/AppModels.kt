package io.wapfire.mobile.model

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

internal enum class Stage { DISCOVERY, ASSISTANT_PREVIEW, RESTORING, LOGIN, SETUP, CONTROL }

internal data class AdvancedSettingsBundle(
    val general: JSONObject = JSONObject(),
    val ethernet: JSONObject = JSONObject(),
    val httpApi: JSONObject = JSONObject(),
    val ntp: JSONObject = JSONObject(),
    val mikrotik: JSONObject = JSONObject(),
    val led: JSONObject = JSONObject(),
    val disconnectLed: JSONObject = JSONObject(),
    val schedule: JSONObject = JSONObject(),
    val whitelist: JSONObject = JSONObject(),
    val firmware: JSONObject = JSONObject(),
    val backupInfo: JSONObject = JSONObject()
)
internal enum class Tab(val label: String, val fa: String, val glyph: String) {
    OVERVIEW("Overview", "نمای کلی", "⌂"),
    CLIENTS("Clients", "کلاینت‌ها", "◎"),
    EVENTS("Events", "رویدادها", "≋"),
    ASSISTANT("Nara", "نارا", "✧"),
    SETTINGS("Settings", "تنظیمات", "")
}

internal data class Palette(
    val bg: Color,
    val bg2: Color,
    val panel: Color,
    val panelAlt: Color,
    val border: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val green: Color,
    val orange: Color,
    val red: Color,
    val blue: Color
)

internal fun colors(dark: Boolean) = if (dark) Palette(
    bg = Color(0xFF07141D), bg2 = Color(0xFF0C202B), panel = Color(0xFF102633),
    panelAlt = Color(0xFF16313E), border = Color(0xFF254652), text = Color(0xFFEAF5F7),
    muted = Color(0xFF91AAB5), accent = Color(0xFF4DE1CE), accentSoft = Color(0xFF173F45),
    green = Color(0xFF64E4A5), orange = Color(0xFFFFB86C), red = Color(0xFFFF7185), blue = Color(0xFF78A9FF)
) else Palette(
    bg = Color(0xFFF2F7F8), bg2 = Color(0xFFE5EFF2), panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFEAF3F4), border = Color(0xFFD4E2E5), text = Color(0xFF142D39),
    muted = Color(0xFF66808B), accent = Color(0xFF087F78), accentSoft = Color(0xFFD9F0EC),
    green = Color(0xFF168B5A), orange = Color(0xFFB76A18), red = Color(0xFFC33F54), blue = Color(0xFF426BC2)
)

internal val detectionBreakdownNames = listOf(
    "Auth Attack",
    "Deauth Attack",
    "Deauth Airplay",
    "WPS Pixie Reaver",
    "WPS Pixie Bully",
    "Evil Twin",
    "WPA Correct Password",
    "WPA Wrong Password"
)

internal val threatDisplayNames = mapOf(
    "auth_attack" to "Auth Attack",
    "deauth" to "Deauth Attack",
    "deauth_attack" to "Deauth Attack",
    "deauth_airplay" to "Deauth Airplay",
    "wps_pixie_reaver" to "WPS Pixie Reaver",
    "wps_pixie_bully" to "WPS Pixie Bully",
    "evil_twin" to "Evil Twin",
    "correct_password" to "WPA Correct Password",
    "wrong_password" to "WPA Wrong Password"
)

internal fun friendlyThreatName(value: String): String? {
    val raw = value.trim()
    if (raw.isBlank()) return null
    val normalized = raw.lowercase().replace('-', '_').replace(' ', '_')
    threatDisplayNames[normalized]?.let { return it }
    return when {
        normalized.contains("wps_pixie_bully") || normalized.contains("pixie_bully") || normalized == "bully" -> "WPS Pixie Bully"
        normalized.contains("wps_pixie_reaver") || normalized.contains("pixie_reaver") || normalized == "reaver" -> "WPS Pixie Reaver"
        normalized.contains("deauth_airplay") || normalized.contains("deauthentication_airplay") -> "Deauth Airplay"
        normalized.contains("evil_twin") || normalized.contains("evil twin") -> "Evil Twin"
        normalized.contains("wrong_password") || normalized.contains("wrong password") -> "WPA Wrong Password"
        normalized.contains("correct_password") || normalized.contains("correct password") -> "WPA Correct Password"
        normalized.contains("deauth_attack") || normalized == "deauth" || normalized.startsWith("deauth_") || normalized.startsWith("deauthentication") -> "Deauth Attack"
        normalized.contains("auth_attack") || normalized.contains("authentication") -> "Auth Attack"
        else -> null
    }
}

internal val threatIdRegex = Regex(
    threatDisplayNames.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) },
    RegexOption.IGNORE_CASE
)

private val macOrIpRegex = Regex("[0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5}|\\b\\d{1,3}(?:\\.\\d{1,3}){3}\\b")

/**
 * Keeps MAC/BSSID/IP text in its original left-to-right order inside the Persian (RTL) interface.
 * A purely technical line is embedded as one LTR unit; a line that also contains Persian words only
 * has its MAC/IP tokens isolated, so the Persian part keeps flowing right-to-left.
 */
internal fun ltrTechnical(fa: Boolean, text: String): String {
    if (!fa || text.isBlank()) return text
    val hasRtl = text.any {
        val d = Character.getDirectionality(it)
        d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }
    return if (!hasRtl) "\u202A$text\u202C" else macOrIpRegex.replace(text) { "\u202A${it.value}\u202C" }
}

/** Embeds an English technical fragment (e.g. a firmware reason) as one LTR unit in Persian text. */
internal fun ltrUnit(fa: Boolean, text: String): String =
    if (fa && text.isNotBlank()) "\u202A$text\u202C" else text

internal fun friendlyTechnicalText(value: String): String = threatIdRegex.replace(value) { match ->
    threatDisplayNames[match.value.lowercase()] ?: match.value
}

/** Stores only an AES-GCM ciphertext in preferences; the AES key stays in Android Keystore. */

internal fun ledModeLabel(mode: Int, fa: Boolean): String = when (mode) {
    0 -> tx(fa, "Threat detected", "تهدید شناسایی شد")
    1 -> tx(fa, "Authentication attempt", "تلاش احراز هویت")
    2 -> tx(fa, "Wrong password", "رمز اشتباه")
    3 -> tx(fa, "Correct password", "رمز صحیح")
    4 -> tx(fa, "Off", "خاموش")
    5 -> tx(fa, "Test / idle", "آزمایش / آماده")
    6 -> tx(fa, "Setup", "راه‌اندازی")
    7 -> tx(fa, "Protection", "محافظت")
    8 -> tx(fa, "Client disconnect", "قطع اتصال کلاینت")
    else -> tx(fa, "Unknown", "نامشخص")
}

internal fun eventDisplayName(event: JSONObject): String {
    val type = event.optString("event_type", "system").trim().lowercase()
    // A client leaving (e.g. "Reason: CLIENT->AP Deauth") is a disconnect, never a Deauth Attack.
    if (type == "disconnect") return "Client Disconnect"
    friendlyThreatName(type)?.let { return it }
    val message = event.optString("message")
    val details = event.optString("details")
    friendlyThreatName(message)?.let { return it }
    friendlyThreatName(details)?.let { return it }
    return when (type) {
        "attack" -> "Attack Detected"
        "attempt" -> "Connection Attempt"
        "disconnect" -> "Client Disconnect"
        "system" -> "System Event"
        else -> "Device Event"
    }
}

internal data class Snapshot(
    val configured: Boolean = false,
    val apSsid: String = "WAPFire",
    val target: String = "",
    val targetMac: String = "",
    val channel: Int = 0,
    val targetRssi: Int = 0,
    val targetAvailable: Boolean = false,
    val prom: String = "UNKNOWN",
    val traffic: Long = 0,
    val packets: Long = 0,
    val targetApRx: Long = 0,
    val dropped: Long = 0,
    val filtered: Long = 0,
    val freeHeap: Long = 0,
    val uptime: Long = 0,
    val wifiChannel: Int = 0,
    val threatLevel: String = "OPTIMAL",
    // Firmware score_tenths is 0..100, representing a 0.0..10.0 risk value.
    val threatScore: Float = 0f,
    val recentEvents: Int = 0,
    val lastEvent: String = "",
    val lastAttack: String = "",
    val ledMode: Int = 5,
    val led: Boolean = false,
    val smartLed: Boolean = false,
    val sound: Boolean = false,
    val autoChannel: Boolean = false,
    val selfProtect: Boolean = false,
    val selfProtectActive: Boolean = false,
    val softAp: Boolean = false,
    val ethernet: Boolean = false,
    val ethernetIp: String = "0.0.0.0",
    val firmware: String = "—",
    val labels: List<Pair<String, Long>> = emptyList(),
    val radioRates: List<Int> = emptyList(),
    val targetRates: List<Int> = emptyList()
) {
    companion object {
        fun from(status: JSONObject, settings: JSONObject?, chart: JSONObject?, firmwareInfo: JSONObject?): Snapshot {
            val threat = status.optJSONObject("threat_assessment") ?: JSONObject()
            val labelsJson = status.optJSONArray("labels") ?: JSONArray()
            val labelCounts = mutableMapOf<String, Long>()
            for (i in 0 until labelsJson.length()) {
                val item = labelsJson.optJSONObject(i) ?: continue
                val displayName = friendlyThreatName(item.optString("name")) ?: continue
                labelCounts[displayName] = (labelCounts[displayName] ?: 0L) + item.optLong("count")
            }
            val labels = detectionBreakdownNames.map { name -> name to (labelCounts[name] ?: 0L) }
            val radio = chart?.optJSONArray("radioRxRates") ?: JSONArray()
            val target = chart?.optJSONArray("targetApRxRates") ?: JSONArray()
            return Snapshot(
                configured = status.optBoolean("configured"),
                apSsid = status.optString("ap_ssid", "WAPFire"),
                target = status.optString("target"), targetMac = status.optString("target_mac"),
                channel = status.optInt("target_ch"), targetRssi = status.optInt("target_rssi"),
                targetAvailable = status.optBoolean("target_available"), prom = status.optString("promiscuous", "UNKNOWN"),
                traffic = status.optLong("traffic"), packets = status.optLong("packets"),
                targetApRx = chart?.optLong("target_ap_frames") ?: 0L,
                dropped = status.optLong("dropped"), filtered = status.optLong("filtered"),
                freeHeap = status.optLong("free_heap"), uptime = status.optLong("uptime"),
                wifiChannel = status.optInt("wifi_channel"), threatLevel = threat.optString("level", "OPTIMAL"),
                threatScore = (threat.optInt("score_tenths").coerceIn(0, 100) / 10f), recentEvents = threat.optInt("recent_events"),
                lastEvent = friendlyThreatName(threat.optString("last_event_label")) ?: if (threat.optString("last_event_label").isBlank()) "" else "Recent security activity", lastAttack = friendlyThreatName(status.optString("last_attack_label")) ?: "",
                ledMode = status.optInt("led_mode", 5),
                led = settings?.optBoolean("led") ?: status.optBoolean("led"),
                smartLed = settings?.optBoolean("smart_led") ?: status.optBoolean("smart_led"),
                sound = settings?.optBoolean("sound") ?: status.optBoolean("sound_enabled"),
                autoChannel = settings?.optBoolean("auto_channel") ?: status.optBoolean("auto_channel"),
                selfProtect = settings?.optBoolean("self_protect") ?: status.optBoolean("self_protect"),
                selfProtectActive = status.optBoolean("self_protect_active"),
                softAp = settings?.optBoolean("softap_enabled") ?: status.optBoolean("softap_enabled"),
                ethernet = status.optBoolean("ethernet_link_on"), ethernetIp = status.optString("ethernet_ip", "0.0.0.0"),
                firmware = firmwareInfo?.optString("version", "—") ?: "—", labels = labels,
                radioRates = (0 until radio.length()).map { radio.optInt(it) },
                targetRates = (0 until target.length()).map { target.optInt(it) }
            )
        }
    }
}

internal val BSSID_PATTERN = Regex("(?i)^[0-9a-f]{2}(:[0-9a-f]{2}){5}$")
internal val SCHEDULE_TIME_PATTERN = Regex("^\\d{2}:\\d{2}$")

internal fun isValidBssid(value: String): Boolean = BSSID_PATTERN.matches(value.trim())

internal fun normalizeScheduleTime(value: String, fallback: String): String {
    if (!SCHEDULE_TIME_PATTERN.matches(value)) return fallback
    val hour = value.substring(0, 2).toIntOrNull() ?: return fallback
    val minute = value.substring(3, 5).toIntOrNull() ?: return fallback
    return if (hour in 0..23 && minute in 0..59) value else fallback
}

internal fun tx(fa: Boolean, en: String, persian: String) = if (fa) persian else en
internal fun Long.compact(): String = when {
    this >= 1_000_000 -> String.format("%.1fM", this / 1_000_000.0)
    this >= 1_000 -> String.format("%.1fK", this / 1_000.0)
    else -> toString()
}
internal fun formatUptime(ms: Long): String {
    if (ms <= 0) return "—"
    val seconds = ms / 1000
    val days = seconds / 86400
    val hours = (seconds % 86400) / 3600
    val minutes = (seconds % 3600) / 60
    return if (days > 0) "${days}d ${hours}h" else if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
}
