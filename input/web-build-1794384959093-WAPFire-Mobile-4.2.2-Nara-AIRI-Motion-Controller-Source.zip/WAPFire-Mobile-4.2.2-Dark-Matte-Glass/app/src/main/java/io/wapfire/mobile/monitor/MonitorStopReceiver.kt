package io.wapfire.mobile.monitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Lets the persistent notification stop the running service without opening the UI. */
class MonitorStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val appContext = context.applicationContext
        appContext.getSharedPreferences("wapfire_native_v22", Context.MODE_PRIVATE)
            .edit().putBoolean("background_monitor_enabled", false).apply()
        appContext.stopService(Intent(appContext, BackgroundMonitorService::class.java))
    }
}
