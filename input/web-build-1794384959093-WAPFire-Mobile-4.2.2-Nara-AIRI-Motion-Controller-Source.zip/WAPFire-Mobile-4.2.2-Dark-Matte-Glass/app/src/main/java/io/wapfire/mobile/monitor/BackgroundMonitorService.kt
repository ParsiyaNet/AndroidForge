package io.wapfire.mobile.monitor

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import io.wapfire.mobile.MainActivity
import io.wapfire.mobile.network.WapFireApi
import io.wapfire.mobile.network.WapFireHttpException
import io.wapfire.mobile.network.WifiDiscovery
import io.wapfire.mobile.network.WapFireSessionManager
import io.wapfire.mobile.security.DeviceLoginVault
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** User-started foreground service that polls only Detection Breakdown counters from /api/status. */
class BackgroundMonitorService : Service() {
    companion object {
        const val ACTION_START = "io.wapfire.mobile.monitor.START"
        const val ACTION_STOP = "io.wapfire.mobile.monitor.STOP"
        const val ACTION_STATE_CHANGED = "io.wapfire.mobile.monitor.STATE_CHANGED"
        private const val PREFS = "wapfire_native_v22"
        private const val PREF_ENABLED = "background_monitor_enabled"
        private const val PREF_APP_FOREGROUND = "monitor_app_foreground"
        private const val CHANNEL_STATUS = "wapfire_monitor_status"
        private const val CHANNEL_ALERTS = "wapfire_detection_breakdown_alerts"
        private const val NOTIFICATION_ID = 4100
        private const val LOOP_INTERVAL_MS = 5_000L

        fun isRunning(context: Context): Boolean {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            @Suppress("DEPRECATION")
            return manager.getRunningServices(Int.MAX_VALUE).any {
                it.service.className == BackgroundMonitorService::class.java.name
            }
        }

        fun start(context: Context) {
            val intent = Intent(context, BackgroundMonitorService::class.java).setAction(ACTION_START)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(PREF_ENABLED, false).apply()
            context.stopService(Intent(context, BackgroundMonitorService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var connectivity: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val wifiNetworks = ConcurrentHashMap.newKeySet<Network>()
    @Volatile private var boundWifi: Network? = null
    private var monitorJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        createNotificationChannels()
        registerWifiWatcher()
        acquireCpuWakeLock()
        acquireWifiLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopFromUser()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_START) {
            prefs.edit().putBoolean(PREF_ENABLED, true).apply()
        } else if (!prefs.getBoolean(PREF_ENABLED, false)) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Must enter foreground immediately; Android 8+ gives a short startup window.
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            statusNotification("Starting WAPFire security monitor…"),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        )
        broadcastState(true)
        startMonitorLoop()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Deliberately keep monitoring when the user swipes the Activity from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        unregisterWifiWatcher()
        releaseWifiLock()
        releaseCpuWakeLock()
        prefs.edit().putBoolean(PREF_ENABLED, false).apply()
        broadcastState(false)
        scope.cancel()
        super.onDestroy()
    }

    private fun startMonitorLoop() {
        if (monitorJob?.isActive == true) return
        monitorJob = scope.launch {
            val host = prefs.getString("host", "192.168.4.1").orEmpty().ifBlank { "192.168.4.1" }
            val saved = DeviceLoginVault.load(prefs, host)
            if (saved == null) {
                updateStatus("Monitoring stopped · save your WAPFire password in Settings to enable background alerts.")
                stopFromUser()
                return@launch
            }

            val sessionManager = WapFireSessionManager()
            val discovery = WifiDiscovery(this@BackgroundMonitorService)
            var activeHost = host
            var client: WapFireApi? = null
            while (isActive && prefs.getBoolean(PREF_ENABLED, false)) {
                // When the Activity is visible, its own foreground poller handles alerts.
                // Avoid concurrent status requests and out-of-order cumulative snapshots.
                if (prefs.getBoolean(PREF_APP_FOREGROUND, false)) {
                    // The Activity is doing the foreground poll; release monitor locks to
                    // avoid keeping the CPU/Wi-Fi awake unnecessarily while the app is open.
                    releaseWifiLock()
                    releaseCpuWakeLock()
                    delay(1_000L)
                    continue
                }
                if (wakeLock?.isHeld != true) acquireCpuWakeLock()
                if (wifiLock?.isHeld != true) acquireWifiLock()
                try {
                    var network = boundWifi
                    if (network == null || connectivity.getNetworkCapabilities(network)
                            ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) != true
                    ) {
                        network = null
                        // Keep the process-wide cookie across a temporary Wi-Fi loss.
                        // VF38 itself decides whether the session survived the IP change;
                        // a later 401 clears this exact token and triggers safe recovery.
                        client = null
                        val candidates = (listOfNotNull(connectivity.activeNetwork) + wifiNetworks.toList())
                            .distinct()
                            .filter { candidate ->
                                connectivity.getNetworkCapabilities(candidate)
                                    ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                            }
                        for (candidateNetwork in candidates) {
                            val verified = discovery.findWapFireHost(candidateNetwork, activeHost)
                            if (verified != null) {
                                network = candidateNetwork
                                activeHost = verified
                                boundWifi = candidateNetwork
                                runCatching { connectivity.bindProcessToNetwork(candidateNetwork) }
                                if (!host.equals(activeHost, ignoreCase = true)) {
                                    // The saved credentials were verified against this WAPFire page first.
                                    if (!DeviceLoginVault.save(prefs, activeHost, saved.username, saved.password)) {
                                        updateStatus("Monitoring stopped · encrypted sign-in could not be updated.")
                                        stopFromUser()
                                        return@launch
                                    }
                                    prefs.edit().putString("host", activeHost).apply()
                                }
                                break
                            }
                        }
                        if (network == null) {
                            updateStatus("Waiting for the WAPFire SoftAP or Wi-Fi link…")
                            delay(LOOP_INTERVAL_MS)
                            continue
                        }
                    } else if (boundWifi != null) {
                        runCatching { connectivity.bindProcessToNetwork(network) }
                    }

                    if (client == null || !client!!.baseUrl.endsWith(activeHost.trim().removeSuffix("/"), ignoreCase = true)) {
                        client?.clearSession()
                        val candidate = WapFireApi(activeHost)
                        val identity = candidate.verifyDeviceIdentity()
                        if (identity.isFailure || !identity.getOrDefault(false)) {
                            candidate.clearSession()
                            updateStatus("Wi-Fi is connected; verifying the WAPFire device…")
                            delay(LOOP_INTERVAL_MS)
                            continue
                        }
                        val login = candidate.login(saved.username, saved.password, reuseExisting = true)
                        if (login.isFailure) {
                            candidate.clearSession()
                            val failure = login.exceptionOrNull()
                            val httpCode = (failure as? WapFireHttpException)?.statusCode
                            if (httpCode == 401 || httpCode == 403 || httpCode == 429) {
                                updateStatus("WAPFire sign-in needs attention")
                                updateStatus("Monitoring stopped · saved WAPFire sign-in was rejected.")
                                stopFromUser()
                                return@launch
                            }
                            updateStatus("WAPFire did not answer · retrying…")
                            delay(LOOP_INTERVAL_MS)
                            continue
                        }
                        client = candidate
                    }

                    val statusSnapshot = when (val result = sessionManager.statusWithRecovery(client!!, saved.username, saved.password)) {
                        is WapFireSessionManager.StatusResult.Online -> result.status
                        is WapFireSessionManager.StatusResult.Offline -> {
                            updateStatus("WAPFire temporarily unavailable; reconnecting…")
                            delay(LOOP_INTERVAL_MS)
                            continue
                        }
                        is WapFireSessionManager.StatusResult.LoginRequired -> {
                            client?.clearSession()
                            client = null
                            updateStatus("Monitoring stopped · ${result.message.take(120)}")
                            stopFromUser()
                            return@launch
                        }
                    }

                    updateStatus("Monitoring WAPFire · Detection Breakdown active")
                    processDetectionBreakdown(statusSnapshot)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (failure: Exception) {
                    updateStatus("Monitoring reconnecting · ${failure.message.orEmpty().take(70)}")
                }
                delay(LOOP_INTERVAL_MS)
            }
        }
    }

    /** Shared pipeline also used by the foreground app while its Activity is resumed. */
    private fun processDetectionBreakdown(status: JSONObject) {
        DetectionBreakdownNotificationCenter.process(this, status)
    }

    private fun broadcastState(active: Boolean) {
        sendBroadcast(
            Intent(ACTION_STATE_CHANGED)
                .setPackage(packageName)
                .putExtra("active", active)
        )
    }

    private fun updateStatus(text: String) {
        runCatching { NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, statusNotification(text)) }
    }

    private fun statusNotification(text: String): Notification {
        val stopIntent = PendingIntent.getBroadcast(
            this, 2, Intent(this, MonitorStopReceiver::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_STATUS)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("WAPFire Background Monitor")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openAppPendingIntent())
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun openAppPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this, 1,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_STATUS, "WAPFire monitoring", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows whether WAPFire Detection Breakdown monitoring is active."
                setShowBadge(false)
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "WAPFire Detection Breakdown", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alerts only for the seven enabled WAPFire Detection Breakdown categories."
                enableVibration(true)
                setShowBadge(true)
            }
        )
    }

    private fun registerWifiWatcher() {
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val capabilities = connectivity.getNetworkCapabilities(network)
                if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
                    wifiNetworks.add(network)
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                if (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    wifiNetworks.add(network)
                }
            }

            override fun onLost(network: Network) {
                wifiNetworks.remove(network)
                if (boundWifi == network) {
                    boundWifi = null
                    runCatching { connectivity.bindProcessToNetwork(null) }
                    updateStatus("WAPFire Wi-Fi disconnected · waiting to reconnect…")
                }
            }
        }
        networkCallback = callback
        runCatching {
            connectivity.registerNetworkCallback(request, callback)
            connectivity.allNetworks.forEach { network ->
                if (connectivity.getNetworkCapabilities(network)
                        ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                ) wifiNetworks.add(network)
            }
        }.onFailure { updateStatus("Waiting for Wi-Fi network access…") }
    }

    private fun unregisterWifiWatcher() {
        networkCallback?.let { callback -> runCatching { connectivity.unregisterNetworkCallback(callback) } }
        networkCallback = null
        wifiNetworks.clear()
        boundWifi = null
    }

    private fun acquireCpuWakeLock() {
        if (wakeLock?.isHeld == true) return
        runCatching {
            val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:WapFireMonitor").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseCpuWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    private fun acquireWifiLock() {
        if (wifiLock?.isHeld == true) return
        runCatching {
            val manager = getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = manager.createWifiLock(
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY,
                "$packageName:WapFireWifiMonitor"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseWifiLock() {
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        wifiLock = null
    }

    private fun stopFromUser() {
        prefs.edit().putBoolean(PREF_ENABLED, false).apply()
        broadcastState(false)
        monitorJob?.cancel()
        monitorJob = null
        // Service lifecycle operations are kept on the main thread even when an
        // authentication failure asks the monitor coroutine (Dispatchers.IO) to stop.
        mainHandler.post {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
}
