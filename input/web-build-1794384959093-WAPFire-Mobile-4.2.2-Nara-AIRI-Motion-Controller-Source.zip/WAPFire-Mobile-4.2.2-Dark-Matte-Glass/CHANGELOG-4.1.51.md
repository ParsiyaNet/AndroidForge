# WAPFire Mobile 4.1.51

### Bottom navigation glass readability

- Increased the bottom navigation pill's surface opacity in both dark and light themes.
- Reduced visual bleed-through from scrolling cards so tab names and icons remain easy to read.
- Preserved the floating rounded-glass treatment, gradient sheen, rim, selected-tab capsule, layout, and scrolling behavior.
- No changes to dashboard content, navigation behavior, assistant view, or monitoring logic.
- Android versionCode 97 / versionName 4.1.51.
