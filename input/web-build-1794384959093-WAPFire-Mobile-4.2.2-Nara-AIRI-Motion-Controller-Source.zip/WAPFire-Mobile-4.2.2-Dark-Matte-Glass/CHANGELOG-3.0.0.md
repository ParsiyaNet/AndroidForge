# WAPFire Mobile 3.0.0

## Full control pass
- Wired the full currently exposed VF38 native API surface: Ethernet, HTTP event reporting, NTP and phone-time sync, MikroTik, LED effects, disconnect LED, schedule, whitelist, backup/restore, firmware information, manual OTA, update-status query and maintenance actions.
- Added native force-setup support and confirmed reboot/restart/reset paths return the app to discovery instead of leaving it on a stale control screen.
- Implemented OTA multipart upload using the exact `firmware` form field expected by the VF38 firmware.
- Corrected MikroTik credential behavior: the firmware no longer sends the saved password back to the app and blank password updates retain the existing secret.
- Added `beacon_mode` to the settings read response so the app can display the actual device value.
- Loaded advanced modules sequentially to avoid concurrent connection pressure on the ESP32 WebServer; a partial API failure never overwrites existing form values with defaults.
- Added the device-advertised timezone picker, Ethernet diagnostic details and local whitelist validation (32-entry maximum, MAC format and name length).
- Removed duplicated language controls and kept Target within Settings.
- Strengthened event-type mapping so the eight requested event names are consistently shown, including detections logged under generic `attack` events.
- Kept transient banners dismissible and time-limited; Logout clears the local session and app state.
