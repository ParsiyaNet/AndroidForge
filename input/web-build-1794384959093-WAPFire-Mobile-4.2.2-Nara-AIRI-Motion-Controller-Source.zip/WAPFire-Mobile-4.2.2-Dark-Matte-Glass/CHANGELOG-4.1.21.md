# WAPFire Mobile 4.1.21 — Offline LivLiv WebView Fix

- Fixed the Overview assistant WebView being blank on Android.
- Removed the global `blockNetworkLoads` setting that could prevent the virtual `appassets.androidplatform.net` HTTPS page from loading.
- Kept offline-only behavior: the request interceptor serves only packaged `assets/assistant/` files and returns 403 for every external host/path; the HTML Content Security Policy remains same-origin only.
- Added WebView page lifecycle, main-frame/resource error and HTTP error diagnostics to Logcat (`WapFireAssistant`).
- Preserved the embedded LivLiv engine, model, offline assets, Overview integration and state mapping.

Version: 4.1.21 (versionCode 62).
