# WAPFire Mobile 4.1.31

## Overview and Assistant layout correction

- Return the Overview assistant card to 218dp, removing the 78dp unused area introduced in 4.1.30.
- Remove the visible `Character: Sena · LivLiv (livliv.ai)` caption and suppress the model corner watermark in Overview only.
- Preserve the required LivLiv character credit in Settings under Character Credits, and retain the bundled license/attribution files.
- Hide the app brand toolbar and five-tab navigation while the Assistant tab is open, giving the character the full app content viewport. Android system status/navigation bars remain visible.
- Add a close control plus floating language/theme toggles in the Assistant view, and route Android Back to Overview.
- Preserve the existing state reactions, animation, status indicator, and bottom mode selector.

Version: 4.1.31 (versionCode 72).
