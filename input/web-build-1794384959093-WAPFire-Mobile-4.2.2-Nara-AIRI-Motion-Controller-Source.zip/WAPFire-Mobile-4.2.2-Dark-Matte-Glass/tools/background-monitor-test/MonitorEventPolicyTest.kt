package io.wapfire.mobile.monitor

import org.json.JSONArray
import org.json.JSONObject

fun main() {
    fun label(name: String, count: Long) = JSONObject().put("name", name).put("count", count)
    fun status(vararg labels: JSONObject) = JSONObject().put("labels", JSONArray(labels.toList()))

    val initial = status(
        label("auth_attack", 2),
        label("deauth_attack", 3),
        label("deauth_airplay", 4),
        label("wps_pixie_reaver", 5),
        label("wps_pixie_bully", 6),
        label("evil_twin", 7),
        label("correct_password", 8),
        label("wrong_password", 9)
    )
    val baseline = MonitorEventPolicy.readDetectionCounts(initial) ?: error("Detection Breakdown labels were not read")

    check(baseline.size == 7) { "Expected exactly seven alertable Detection Breakdown classes" }
    check("WPA Correct Password" !in baseline) { "WPA Correct Password must never be notified" }
    check(baseline["Auth Attack"] == 2L)
    check(baseline["Deauth Attack"] == 3L)
    check(baseline["Deauth Airplay"] == 4L)
    check(baseline["WPS Pixie Reaver"] == 5L)
    check(baseline["WPS Pixie Bully"] == 6L)
    check(baseline["Evil Twin"] == 7L)
    check(baseline["WPA Wrong Password"] == 9L)

    val updated = status(
        label("auth_attack", 3),
        label("deauth_attack", 5),
        label("deauth_airplay", 5),
        label("wps_pixie_reaver", 8),
        label("wps_pixie_bully", 7),
        label("evil_twin", 9),
        label("correct_password", 999),
        label("wrong_password", 10),
        label("system", 500),
        label("disconnect", 700)
    )
    val current = MonitorEventPolicy.readDetectionCounts(updated) ?: error("Updated Detection Breakdown labels were not read")
    val deltas = MonitorEventPolicy.increasedCounts(baseline, current)

    check(deltas.map { it.label }.toSet() == MonitorEventPolicy.monitoredLabels.toSet()) {
        "All seven Detection Breakdown categories must notify when their counters increase"
    }
    check(deltas.none { it.label == "WPA Correct Password" })
    val expectedTitles = mapOf(
        "Auth Attack" to "Auth Attack Detected",
        "Deauth Attack" to "Deauth Attack Detected",
        "Deauth Airplay" to "Deauth Airplay Detected",
        "WPS Pixie Reaver" to "WPS Pixie Reaver Detected",
        "WPS Pixie Bully" to "WPS Pixie Bully Detected",
        "Evil Twin" to "Evil Twin Detected",
        "WPA Wrong Password" to "WPA Wrong Password Detected"
    )
    expectedTitles.forEach { (labelName, title) ->
        check(deltas.first { it.label == labelName }.notificationTitle == title) {
            "Unexpected notification subject for $labelName"
        }
    }
    check(deltas.first { it.label == "WPS Pixie Reaver" }.notificationBody.contains("+3 new"))

    // An Events-style object is not a Detection Breakdown status response and is ignored.
    check(MonitorEventPolicy.readDetectionCounts(JSONObject().put("events", JSONArray(listOf(label("deauth_attack", 999))))) == null)

    // Counter resets are silent; a subsequent increase is measured from the new baseline.
    val reset = baseline.mapValues { (_, count) -> count - 1L }
    check(MonitorEventPolicy.increasedCounts(baseline, reset).isEmpty())

    println("PASS: only seven Detection Breakdown counters can notify; correct-password and Events data are ignored; titles and deltas are correct")
}
