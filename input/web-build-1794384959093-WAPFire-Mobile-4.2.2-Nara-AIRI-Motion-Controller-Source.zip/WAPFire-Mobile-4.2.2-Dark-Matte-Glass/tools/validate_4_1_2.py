#!/usr/bin/env python3
"""Static integrity checks for WAPFire Mobile 4.1.2 source."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = {"android": "http://schemas.android.com/apk/res/android"}
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

try:
    manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
    app = manifest.find("application")
    permissions = {p.attrib.get("{" + NS["android"] + "}name") for p in manifest.findall("uses-permission")}
    service = app.find("service") if app is not None else None
    receiver = app.find("receiver") if app is not None else None
    check("Manifest XML parses", True)
    required_permissions = {
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE",
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.WAKE_LOCK",
        "android.permission.CHANGE_NETWORK_STATE",
        "android.permission.CHANGE_WIFI_STATE",
    }
    check("Foreground-service and notification permissions", required_permissions.issubset(permissions), str(sorted(required_permissions - permissions)))
    check("Service is declared as connectedDevice and not exported", service is not None and
          service.attrib.get("{" + NS["android"] + "}name") == ".monitor.BackgroundMonitorService" and
          service.attrib.get("{" + NS["android"] + "}foregroundServiceType") == "connectedDevice" and
          service.attrib.get("{" + NS["android"] + "}exported") == "false")
    check("Notification Stop receiver is declared and not exported", receiver is not None and
          receiver.attrib.get("{" + NS["android"] + "}name") == ".monitor.MonitorStopReceiver" and
          receiver.attrib.get("{" + NS["android"] + "}exported") == "false")
except Exception as exc:
    check("Manifest XML parses", False, repr(exc))


def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.exists() else ""

service = read("app/src/main/java/io/wapfire/mobile/monitor/BackgroundMonitorService.kt")
policy = read("app/src/main/java/io/wapfire/mobile/monitor/MonitorEventPolicy.kt")
receiver = read("app/src/main/java/io/wapfire/mobile/monitor/MonitorStopReceiver.kt")
api = read("app/src/main/java/io/wapfire/mobile/network/WapFireApi.kt")
ui = read("app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt")
screens = read("app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt")
settings_source = read("app/src/main/java/io/wapfire/mobile/ui/screens/SettingsScreens.kt")
gradle = read("app/build.gradle.kts")

check("Version is 4.1.2 / versionCode 43", "versionName = \"4.1.2\"" in gradle and "versionCode = 43" in gradle)
check("Invalid standalone onDispose import is absent", "import androidx.compose.runtime.onDispose" not in ui)
stub_files = list((ROOT / "tools/test-support/stubs").rglob("*.kt"))
json_stub_declarations = sum(len(re.findall(r"^\s*class\s+JSONObject\b", f.read_text(encoding="utf-8"), re.MULTILINE)) for f in stub_files)
check("Test-only org.json JSONObject stub is centralized", json_stub_declarations == 1 and not (ROOT / "tools/background-monitor-test/stubs/org/json/JSONObject.kt").exists() and not (ROOT / "tools/session-recovery-test/stubs/org/json/JSONObject.kt").exists())
check("Foreground service starts with connectedDevice type", "FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE" in service and "ServiceCompat.startForeground" in service)
check("Explicit foreground notification has Stop action", ".addAction(android.R.drawable.ic_media_pause, \"Stop\", stopIntent)" in service)
check("Service survives Activity task removal by design", "override fun onTaskRemoved" in service and "stopWithTask=\"false\"" in read("app/src/main/AndroidManifest.xml"))
check("CPU and Wi-Fi low-latency locks are acquired and released", "PARTIAL_WAKE_LOCK" in service and "releaseCpuWakeLock()" in service and "WIFI_MODE_FULL_LOW_LATENCY" in service and "releaseWifiLock()" in service)
check("Logs polling has independent short connect/read timeouts", "connectTimeoutMs: Int = 10_000" in api and "client?.logs(timeoutMs = 8_000, connectTimeoutMs = 3_500)" in service)
check("Device identity check precedes background login", service.find("candidate.verifyDeviceIdentity()") >= 0 and service.find("candidate.verifyDeviceIdentity()") < service.find("candidate.login(saved.username, saved.password, reuseExisting = true)"))
check("Activity and service share one host-scoped session and serialized request queue", "SharedSessionCookieStore" in api and "processRequestMutex" in api and "reuseExisting = true" in service and "reuseExisting = true" in read("app/src/main/java/io/wapfire/mobile/network/WapFireSessionManager.kt"))
check("Only authenticated event log is polled; no write endpoint in service", "client?.logs(" in service and not any(x in service for x in ["updateSettings(", "restoreSettings(", "deviceAction(", "firmwareUpload("]))
check("Baseline avoids replaying historical events", "PREF_BASELINE" in service and "if (baselineReady && !alreadySeen" in service)
check("Event signatures persisted and bounded", "PREF_SEEN" in service and "MAX_SEEN_SIGNATURES = 256" in service and "MessageDigest.getInstance(\"SHA-256\")" in policy)
check("Known threat categories are classified; benign correct-password excluded", all(x in policy for x in ["deauth", "evil_twin", "pixie_reaver", "pixie_bully", "wrong_password"]) and "correct_password" in policy)
check("UI has monitoring switch and battery settings route", "onBatterySettings" in settings_source and "Battery settings" in settings_source and "ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS" in ui)
check("Permission flow and credential-consent path are present", "POST_NOTIFICATIONS" in ui and "DeviceLoginVault.save(prefs, host, username, password)" in ui)
check("Explicit stop/logout paths exist", "stopService(Intent(appContext, BackgroundMonitorService::class.java))" in receiver and ui.count("BackgroundMonitorService.stop(context)") >= 3)
check("No firmware source was modified or bundled in this Android app tree", not list(ROOT.rglob("*.ino")) and not list(ROOT.rglob("*.h")))

# 4.1.2 behavior regressions requested by the user.
app_source = ui
dash_source = screens
check("Background alerts are rendered in Settings", "BACKGROUND ALERTS" in settings_source and "onBackgroundMonitor" in settings_source)
overview_start = dash_source.find("internal fun OverviewPage")
overview_end = dash_source.find("internal fun ClientsPage", overview_start)
overview_source = dash_source[overview_start:overview_end] if overview_start >= 0 and overview_end > overview_start else dash_source
check("Overview has no background-monitor control", "BACKGROUND SECURITY MONITOR" not in overview_source and "backgroundMonitorActive" not in overview_source and "onBackgroundMonitor" not in overview_source)
check("Toolbar has no background-monitor shortcut", 'SmallAction(p, if (backgroundMonitorActive) "ON" else "BG"' not in dash_source)
check("Saved login is restored automatically on app launch", "LaunchedEffect(Unit)" in app_source and "sessionManager.statusWithRecovery(client, saved.username, saved.password)" in app_source)
check("Remember password defaults on unless user opted out", 'remember_password_preference' in app_source and 'savedLoginAtLaunch != null || prefs.getBoolean("remember_password_preference", true)' in app_source)
check("Explicit logout clears the saved login", app_source.count("DeviceLoginVault.clear(prefs)") >= 3)

for name, ok, detail in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))

failed = sum(not ok for _, ok, _ in checks)
print(f"\n{len(checks) - failed}/{len(checks)} static checks passed")
sys.exit(1 if failed else 0)
