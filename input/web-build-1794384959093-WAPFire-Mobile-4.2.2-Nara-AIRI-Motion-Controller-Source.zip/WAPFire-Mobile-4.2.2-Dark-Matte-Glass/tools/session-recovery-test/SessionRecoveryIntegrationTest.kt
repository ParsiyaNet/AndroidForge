import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import io.wapfire.mobile.network.WapFireApi
import io.wapfire.mobile.network.WapFireSessionManager
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

private fun HttpExchange.reply(code: Int, body: String, headers: Map<String, String> = emptyMap()) {
    headers.forEach { (key, value) -> responseHeaders.add(key, value) }
    val bytes = body.toByteArray()
    sendResponseHeaders(code, bytes.size.toLong())
    responseBody.use { it.write(bytes) }
}

fun main() = runBlocking {
    val expectedPassword = "correct-password"
    val tokenCounter = AtomicInteger(0)
    val activeToken = AtomicReference("")
    val logins = AtomicInteger(0)
    val statusCalls = AtomicInteger(0)
    val rootCalls = AtomicInteger(0)
    val identityPage = AtomicReference("<html><title>WAPFire - Authentication</title></html>")
    val statusMode = AtomicReference("auth")

    val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
    server.createContext("/login") { ex ->
        logins.incrementAndGet()
        val body = ex.requestBody.bufferedReader().readText()
        if (body.contains("pass=$expectedPassword")) {
            val token = "test-token-${tokenCounter.incrementAndGet()}-abcdefghijklmnopqrstuvwxyz"
            activeToken.set(token)
            ex.reply(200, "OK", mapOf("Set-Cookie" to "wg_auth=$token; Path=/; HttpOnly; SameSite=Strict"))
        } else ex.reply(401, "Invalid credentials")
    }
    server.createContext("/api/status") { ex ->
        statusCalls.incrementAndGet()
        when (statusMode.get()) {
            "server-error" -> ex.reply(503, "temporarily unavailable")
            else -> {
                val cookie = ex.requestHeaders.getFirst("Cookie").orEmpty()
                if (cookie.contains("wg_auth=${activeToken.get()}")) ex.reply(200, "{}")
                else ex.reply(401, "Unauthorized")
            }
        }
    }
    server.createContext("/") { ex ->
        rootCalls.incrementAndGet()
        ex.reply(200, identityPage.get())
    }
    server.executor = java.util.concurrent.Executors.newCachedThreadPool()
    server.start()
    val host = "http://127.0.0.1:${server.address.port}"
    val manager = WapFireSessionManager()

    try {
        // Initial login succeeds; the simulated firmware then invalidates the IP-bound session.
        val api = WapFireApi(host)
        check(api.login("admin", expectedPassword).isSuccess) { "Initial login failed" }
        activeToken.set("a-different-server-side-session-token")
        val recovered = manager.statusWithRecovery(api, "admin", expectedPassword)
        check(recovered is WapFireSessionManager.StatusResult.Online && recovered.recovered) {
            "Expected automatic recovery; got $recovered"
        }
        check(logins.get() == 2) { "Expected exactly one re-login after invalidated session; login count=${logins.get()}" }
        check(statusCalls.get() == 2) { "Expected initial status + one safe retry; count=${statusCalls.get()}" }
        check(rootCalls.get() == 1) { "Expected one identity verification; count=${rootCalls.get()}" }

        // Activity and foreground service must share one VF38 token per client IP.
        val serviceApi = WapFireApi(host)
        val loginsBeforeReuse = logins.get()
        check(serviceApi.login("admin", expectedPassword, reuseExisting = true).isSuccess) {
            "Background service failed to reuse the Activity session"
        }
        check(logins.get() == loginsBeforeReuse) { "Background service created a second token for the same client IP" }
        check(serviceApi.status().isSuccess && api.status().isSuccess) {
            "Two API clients did not share the same active VF38 session"
        }

        // An explicit foreground sign-in may rotate the token; every API client must
        // read the newly shared cookie rather than retaining its old instance-local copy.
        check(serviceApi.login("admin", expectedPassword).isSuccess) { "Explicit sign-in failed" }
        check(api.status().isSuccess) { "Activity client did not follow the rotated shared cookie" }

        // Concurrent recovery attempts must still create only one new device token.
        api.clearSession()
        val loginsBeforeConcurrentRecovery = logins.get()
        listOf(
            async { api.login("admin", expectedPassword, reuseExisting = true) },
            async { serviceApi.login("admin", expectedPassword, reuseExisting = true) }
        ).awaitAll().forEach { result -> check(result.isSuccess) { "Concurrent shared-session recovery failed" } }
        check(logins.get() == loginsBeforeConcurrentRecovery + 1) {
            "Concurrent recovery created more than one active token; login count=${logins.get()}"
        }
        check(api.status().isSuccess && serviceApi.status().isSuccess) {
            "Concurrent API clients did not converge on the same active session"
        }

        // A non-WAPFire page must never receive stored credentials.
        val otherApi = WapFireApi(host)
        activeToken.set("different-token-again")
        identityPage.set("<html><title>Other device</title></html>")
        val loginsBefore = logins.get()
        val identityRejected = manager.statusWithRecovery(otherApi, "admin", expectedPassword)
        check(identityRejected is WapFireSessionManager.StatusResult.Offline) { "Expected identity rejection; got $identityRejected" }
        check(logins.get() == loginsBefore) { "Credentials were sent to an unverified endpoint" }

        // Server faults do not trigger login attempts or force a sign-out.
        statusMode.set("server-error")
        val serverErrorApi = WapFireApi(host)
        val loginsBeforeServerError = logins.get()
        val serverError = manager.statusWithRecovery(serverErrorApi, "admin", expectedPassword)
        check(serverError is WapFireSessionManager.StatusResult.Offline) { "Expected offline result for HTTP 503; got $serverError" }
        check(logins.get() == loginsBeforeServerError) { "Unexpected login attempt after HTTP 503" }

        println("PASS: 401 -> identity verify -> single re-login -> one status retry")
        println("PASS: Activity and foreground service share one per-host VF38 session cookie")
        println("PASS: explicit login cookie rotation is visible to all API clients")
        println("PASS: concurrent Activity/service recovery creates one shared active token")
        println("PASS: non-WAPFire identity -> credentials are not sent")
        println("PASS: HTTP 503 -> no login attempt and no sign-out transition")
    } finally {
        server.stop(0)
        server.executor?.let { (it as java.util.concurrent.ExecutorService).shutdownNow() }
    }
}
