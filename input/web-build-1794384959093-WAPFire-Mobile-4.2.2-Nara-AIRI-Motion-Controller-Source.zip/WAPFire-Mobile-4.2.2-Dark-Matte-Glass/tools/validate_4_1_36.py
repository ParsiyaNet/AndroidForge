#!/usr/bin/env python3
"""Static validation for WAPFire Mobile 4.1.36 Assistant crash/RTL fixes."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

build = read("app/build.gradle.kts")
assert "versionCode = 77" in build
assert 'versionName = "4.1.36"' in build

js = read("app/src/main/assets/assistant/assistant-preflight.js")
assert "const classAction = (element, action" in js
assert "element && element.classList" in js
assert "loading.classList" not in js
assert "classAction(loading, 'add', 'error')" in js
assert "classAction(button, 'toggle', 'active'" in js
assert "Assistant DOM is incomplete" in js
assert "event.reason?.stack" not in js  # stack-safe event.reason path is explicitly expanded
assert "reason?.stack" in js
assert "String(event.error.stack)" in js

view = read("app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt")
assert "CompositionLocalProvider(" in view
assert "LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr" in view
assert "TextDirection.Rtl" in view and "TextDirection.Ltr" in view
assert "textAlign = if (fa) TextAlign.End else TextAlign.Start" in view
assert "message?.take(900)" in view
assert "message.sourceId()" in view and "message.lineNumber()" in view

html = read("app/src/main/assets/assistant/assistant-live.html")
for element_id in ("shell", "speechText", "stateText", "dot", "loading", "stage"):
    assert f'id="{element_id}"' in html

for path in [ROOT / "app/src/main/AndroidManifest.xml", *((ROOT / "app/src/main/res").rglob("*.xml"))]:
    ET.parse(path)

print("PASS: WAPFire Mobile 4.1.36 static validation")
