#!/usr/bin/env python3
"""Static checks for WAPFire Mobile 4.1.4 foreground/background notification behavior."""
from pathlib import Path
import xml.etree.ElementTree as ET
import sys

ROOT = Path(__file__).resolve().parents[1]
NS = {"android": "http://schemas.android.com/apk/res/android"}
checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.exists() else ""

try:
    manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
    app = manifest.find("application")
    service = app.find("service") if app is not None else None
    permissions = {p.attrib.get("{" + NS["android"] + "}name") for p in manifest.findall("uses-permission")}
    required = {"android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE", "android.permission.POST_NOTIFICATIONS", "android.permission.WAKE_LOCK"}
    check("Manifest parses and notification/foreground permissions exist", required.issubset(permissions))
    check("Connected-device foreground service remains private", service is not None and service.attrib.get("{" + NS["android"] + "}foregroundServiceType") == "connectedDevice" and service.attrib.get("{" + NS["android"] + "}exported") == "false")
except Exception as exc:
    check("Manifest parses", False, repr(exc))

policy = read("app/src/main/java/io/wapfire/mobile/monitor/MonitorEventPolicy.kt")
center = read("app/src/main/java/io/wapfire/mobile/monitor/DetectionBreakdownNotificationCenter.kt")
service = read("app/src/main/java/io/wapfire/mobile/monitor/BackgroundMonitorService.kt")
ui = read("app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt")
ring = read("app/src/main/java/io/wapfire/mobile/ui/components/UiComponents.kt")
dash = read("app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt")
gradle = read("app/build.gradle.kts")
settings = read("app/src/main/java/io/wapfire/mobile/ui/screens/SettingsScreens.kt")

check("Version bumped to 4.1.4 / versionCode 45", 'versionName = "4.1.4"' in gradle and "versionCode = 45" in gradle)
check("Exactly seven alertable Detection Breakdown labels remain", all(x in policy for x in ["Auth Attack", "Deauth Attack", "Deauth Airplay", "WPS Pixie Reaver", "WPS Pixie Bully", "Evil Twin", "WPA Wrong Password"]))
check("WPA Correct Password is not an alertable alias", "correct_password" not in policy.split("private val labelAliases = mapOf(", 1)[1].split("// correct_password", 1)[0])
check("Notifier uses the same persisted counter key as prior background monitor", '"background_monitor_detection_breakdown_counts_v2"' in center)
check("Central notifier uses only Detection Breakdown policy and does not read Events/logs", "MonitorEventPolicy.readDetectionCounts(status)" in center and ".logs(" not in center and "\"events\"" not in center.lower())
check("Background service delegates to shared notifier", "DetectionBreakdownNotificationCenter.process(this, status)" in service)
check("Background and foreground use one poller at a time", 'PREF_APP_FOREGROUND = "monitor_app_foreground"' in service and 'prefs.getBoolean(PREF_APP_FOREGROUND, false)' in service)
check("Foreground Activity sends app-resumed state to shared preferences", 'putBoolean("monitor_app_foreground", true)' in ui and 'putBoolean("monitor_app_foreground", false)' in ui)
check("Foreground detection notifications work independently from Background Alerts switch", "DetectionBreakdownNotificationCenter.process(context.applicationContext, status)" in ui and "if (appInForeground)" in ui)
check("Foreground loop is lifecycle-gated", "stage == Stage.CONTROL && api != null && appInForeground" in ui and "while (stage == Stage.CONTROL && appInForeground)" in ui)
check("Detection status is polled at most every 5 seconds on non-Overview tabs", "delay(if (tab == Tab.OVERVIEW) 3000 else 5000)" in ui)
check("Foreground notification permission is requested independently", "foregroundNotificationPermissionLauncher" in ui and "foreground_detection_permission_requested" in ui)
overview_block = dash.split("internal fun OverviewPage(", 1)[1].split("internal fun ClientsPage(", 1)[0] if "internal fun OverviewPage(" in dash and "internal fun ClientsPage(" in dash else dash
check("Background toggle is not rendered on Overview and remains in Settings", "onBackgroundMonitor" in settings and "Background Alerts" not in overview_block and "onBackgroundMonitor" not in overview_block)
check("Light-theme OPTIMAL ring uses high-contrast mint on dark glass", '"OPTIMAL", "LOW" -> Color(0xFF8CF0BE)' in ring)
check("Target ONLINE label uses high-contrast mint", 'Color(0xFF91F2C4)' in dash)
check("No firmware source is bundled or modified", not list(ROOT.rglob("*.ino")) and not list(ROOT.rglob("*.h")))

for name, ok, detail in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
failed = sum(not ok for _, ok, _ in checks)
print(f"\n{len(checks)-failed}/{len(checks)} static checks passed")
sys.exit(1 if failed else 0)
