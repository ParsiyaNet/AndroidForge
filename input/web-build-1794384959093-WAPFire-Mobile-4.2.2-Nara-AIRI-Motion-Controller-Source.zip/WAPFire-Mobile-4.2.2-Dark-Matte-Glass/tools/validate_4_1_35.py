#!/usr/bin/env python3
"""Static checks for WAPFire Mobile 4.1.35 assistant layout/language fixes."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")

build = read("app/build.gradle.kts")
assert "versionCode = 76" in build
assert 'versionName = "4.1.35"' in build

view = read("app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt")
msg = view.split("private fun overviewAssistantMessage", 1)[1].split("\n}", 1)[0]
assert msg.count("tx(fa,") == 10
for line in msg.splitlines():
    if "tx(fa," in line:
        args = line.split("tx(fa,", 1)[1]
        assert args.lstrip().startswith('"') and '", "' in args, line
assert "Arrangement.spacedBy(3.dp)" in view
assert "TextAlign.End" in view and "TextAlign.Start" in view

screen = read("app/src/main/java/io/wapfire/mobile/ui/screens/AssistantPreviewScreen.kt")
assert "SmallAction" not in screen
assert "onLanguage" not in screen
assert ".padding(18.dp)" in screen

html = read("app/src/main/assets/assistant/assistant-live.html")
assert "inset:0!important" in html
assert "left:22px;right:22px;bottom:10px" in html

js = read("app/src/main/assets/assistant/assistant-preflight.js")
assert "compactMode ? 1.38 : fullZoom" in js
assert "controlLabels[language]" in js

for path in [
    "app/src/main/assets/assistant/favicon.ico",
    "app/src/main/assets/assistant/characters/k01.livliv",
    "app/src/main/assets/assistant/characters/k01/cover.webp",
]:
    assert (ROOT / path).is_file(), path

for path in [ROOT / "app/src/main/AndroidManifest.xml", *((ROOT / "app/src/main/res").rglob("*.xml"))]:
    ET.parse(path)

print("PASS: WAPFire Mobile 4.1.35 static validation")
