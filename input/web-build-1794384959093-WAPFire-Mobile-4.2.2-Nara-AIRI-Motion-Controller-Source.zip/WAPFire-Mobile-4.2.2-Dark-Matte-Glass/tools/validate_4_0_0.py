#!/usr/bin/env python3
"""Offline source-integrity checks for WAPFire Mobile 4.0.0."""
from __future__ import annotations
import hashlib
import re
import sys
import zipfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
FIRMWARE = PROJECT.parent / "WAPFireVF38"
BASELINE_ZIP = Path("/mnt/data/WAPFire-Mobile-3.2.13-Manual-Address-Reconnect-Fix-Full-Compatibility-Reviewed.zip")
checks: list[tuple[str, bool, str]] = []

def check(label: str, ok: bool, detail: str = "") -> None:
    checks.append((label, ok, detail))

main = PROJECT / "app/src/main/java/io/wapfire/mobile/MainActivity.kt"
models = PROJECT / "app/src/main/java/io/wapfire/mobile/model/AppModels.kt"
api = PROJECT / "app/src/main/java/io/wapfire/mobile/network/WapFireApi.kt"
session = PROJECT / "app/src/main/java/io/wapfire/mobile/network/WapFireSessionManager.kt"
wifi = PROJECT / "app/src/main/java/io/wapfire/mobile/network/WifiDiscovery.kt"
connector = PROJECT / "app/src/main/java/io/wapfire/mobile/network/WifiConnector.kt"
vault = PROJECT / "app/src/main/java/io/wapfire/mobile/security/DeviceLoginVault.kt"
app = PROJECT / "app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt"
screens = [
    PROJECT / "app/src/main/java/io/wapfire/mobile/ui/screens/DiscoveryAndSetupScreens.kt",
    PROJECT / "app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt",
    PROJECT / "app/src/main/java/io/wapfire/mobile/ui/screens/SettingsScreens.kt",
]
components = PROJECT / "app/src/main/java/io/wapfire/mobile/ui/components/UiComponents.kt"
all_sources = list((PROJECT / "app/src/main/java").rglob("*.kt"))
read = lambda p: p.read_text(encoding="utf-8")

check("MainActivity is a thin entry point", main.exists() and len(read(main).splitlines()) <= 25)
check("Modular model/API/session/Wi-Fi/security/UI files exist", all(p.exists() for p in [models, api, session, wifi, connector, vault, app, components, *screens]))
check("Four primary dashboard destinations exist", all(re.search(rf"fun\s+{name}\s*\(", read(screens[1])) for name in ["ControlCenter", "OverviewPage", "ClientsPage", "EventsPage"]))
check("Discovery, login, first setup and Settings surfaces exist", all(any(re.search(rf"fun\s+{name}\s*\(", read(p)) for p in screens) for name in ["DiscoveryScreen", "LoginScreen", "FirstSetupScreen", "SettingsPage", "AdvancedSettingsPanel"]))
check("BSSID signature discovery is retained", "02:57:41" in read(wifi))
check("BLE transport has not been added", not any(re.search(r"\bBLE\b|Bluetooth", read(p), re.I) for p in all_sources))
check("HTTP status code is preserved as a typed exception", "class WapFireHttpException" in read(api) and "val statusCode: Int" in read(api))
check("Unauthenticated WAPFire identity probe exists", "verifyDeviceIdentity" in read(api) and "includeCookie = false" in read(api))
check("Recovery retries only the status GET", "statusWithRecovery" in read(session) and "api.status()" in read(session) and "api.login(username, password)" in read(session))
check("Existing credential storage schema is retained", all(x in read(vault) for x in ["io.wapfire.mobile.device-login.v1", "remember_device_password", "remembered_device_host", "remembered_device_password_enc"]))
check("App ID and Android version settings are retained", "applicationId = \"io.wapfire.mobile\"" in read(PROJECT / "app/build.gradle.kts") and "minSdk = 29" in read(PROJECT / "app/build.gradle.kts"))

if not BASELINE_ZIP.exists():
    check("VF38 firmware files unchanged versus 3.2.13 archive", False, f"baseline not found: {BASELINE_ZIP}")
else:
    with zipfile.ZipFile(BASELINE_ZIP) as archive:
        baseline = {n for n in archive.namelist() if n.startswith("WAPFireVF38/") and not n.endswith("/")}
        missing, changed = [], []
        for name in sorted(baseline):
            path = FIRMWARE.parent / name
            if not path.is_file():
                missing.append(name); continue
            before = hashlib.sha256(archive.read(name)).digest()
            after = hashlib.sha256(path.read_bytes()).digest()
            if before != after:
                changed.append(name)
        current = {"WAPFireVF38/" + p.relative_to(FIRMWARE).as_posix() for p in FIRMWARE.rglob("*") if p.is_file()}
        extra = sorted(current - baseline)
        firmware_ok = not missing and not changed and not extra
        detail = f"{len(baseline)} baseline files; missing={len(missing)}, changed={len(changed)}, extra={len(extra)}"
        check("VF38 firmware files unchanged versus 3.2.13 archive", firmware_ok, detail)

version = read(PROJECT / "app/build.gradle.kts")
check("Version is 4.0.0 / versionCode 40", "versionCode = 40" in version and 'versionName = "4.0.0"' in version)

failed = 0
for label, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {label}" + (f" — {detail}" if detail else ""))
    failed += not ok
print(f"RESULT: {len(checks)-failed}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
