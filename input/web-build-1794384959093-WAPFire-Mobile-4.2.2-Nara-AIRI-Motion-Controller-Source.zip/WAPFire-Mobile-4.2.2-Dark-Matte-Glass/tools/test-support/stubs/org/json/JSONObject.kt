package org.json

/** Minimal JSON stand-ins used only by the isolated JVM source tests.
 * Android app builds use the platform org.json implementation.
 */
class JSONObject {
    private val values = linkedMapOf<String, Any?>()

    constructor()

    constructor(source: String) {
        val field = Regex("\\\"([^\\\"]+)\\\"\\s*:\\s*(?:\\\"((?:\\\\\\.|[^\\\"])*)\\\"|([^,}\\s]+))")
        field.findAll(source).forEach { match ->
            val key = match.groupValues[1]
            val quoted = match.groupValues[2]
            val raw = match.groupValues[3]
            values[key] = if (quoted.isNotEmpty()) quoted.replace("\\\"", "\"") else raw
        }
    }

    constructor(source: Map<String, String>) { values.putAll(source) }

    fun optString(name: String): String = values[name]?.toString().orEmpty()
    fun optString(name: String, fallback: String): String = optString(name).ifEmpty { fallback }
    fun optLong(name: String, fallback: Long = 0L): Long = when (val value = values[name]) {
        is Number -> value.toLong()
        is String -> value.toLongOrNull() ?: fallback
        else -> fallback
    }
    fun optJSONArray(name: String): JSONArray? = values[name] as? JSONArray
    fun optBoolean(name: String, fallback: Boolean = false): Boolean =
        when (val value = values[name]) {
            is Boolean -> value
            is String -> value.toBooleanStrictOrNull() ?: fallback
            else -> fallback
        }
    fun has(name: String): Boolean = values.containsKey(name)
    fun put(name: String, value: Any?): JSONObject { values[name] = value; return this }
    override fun toString(): String = values.toSortedMap().toString()
}

class JSONArray {
    private val values = mutableListOf<Any?>()

    constructor()
    constructor(source: String) {
        // Test inputs use an empty array or simple quoted strings.
        val item = Regex("\\\"((?:\\\\\\.|[^\\\"])*)\\\"")
        item.findAll(source).forEach { values += it.groupValues[1].replace("\\\"", "\"") }
    }
    constructor(source: Collection<*>) { values.addAll(source) }

    fun length(): Int = values.size
    fun optJSONObject(index: Int): JSONObject? = values.getOrNull(index) as? JSONObject
    fun optString(index: Int): String = values.getOrNull(index)?.toString().orEmpty()
    override fun toString(): String = values.toString()
}
