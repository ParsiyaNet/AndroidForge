#!/usr/bin/env python3
"""Static validation for WAPFire Mobile 4.1.5 Location-aware Wi-Fi discovery."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt"
GRADLE = ROOT / "app/build.gradle.kts"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
source = UI.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")
checks = []

def check(label, condition):
    checks.append((label, bool(condition)))

check("Version is 4.1.5 / versionCode 46", 'versionName = "4.1.5"' in gradle and "versionCode = 46" in gradle)
check("LocationManager system service is checked", "getSystemService(Context.LOCATION_SERVICE) as LocationManager" in source and "manager.isLocationEnabled" in source)
check("Scan action checks missing Wi-Fi permissions before scanning", source.index("missing.isNotEmpty() ->") < source.index("else -> runDiscoveryScan()"))
check("Runtime permission callback re-checks actual permission state", "RequestMultiplePermissions()) {" in source and "WifiDiscovery.requiredPermissions().all { permission ->" in source)
check("One-time permission explanation is present", "Only this time" in source)
check("Location-off prompt is present in English and Persian", "Turn on Location to scan?" in source and "برای اسکن، Location را روشن کنیم؟" in source)
check("Prompt offers Android Location settings", "Settings.ACTION_LOCATION_SOURCE_SETTINGS" in source and "Enable Location" in source)
check("Returning from settings automatically resumes scan when Location is on", "if (allPermissionsGranted && locationServicesEnabled()) {\n            runDiscoveryScan()" in source)
check("Cancel/Location-still-off does not trigger scan", "Location is still turned off" in source)
check("Manual-IP fallback remains available", "Manual IP remains available" in source)
check("Discovery scan is centralized in one coroutine function", source.count("discovery.scan()") == 1 and "fun runDiscoveryScan()" in source)
check("Existing WAPFire BSSID-based duplicate suppression is preserved", "WifiDiscovery.isWapFireBssid(activeWifi.bssid)" in source)

try:
    manifest = ET.parse(MANIFEST).getroot()
    permissions = {node.attrib.get("{http://schemas.android.com/apk/res/android}name") for node in manifest.findall("uses-permission")}
    check("Manifest still declares fine-location and nearby-Wi-Fi permissions", {"android.permission.ACCESS_FINE_LOCATION", "android.permission.NEARBY_WIFI_DEVICES", "android.permission.ACCESS_WIFI_STATE", "android.permission.CHANGE_WIFI_STATE"}.issubset(permissions))
except Exception:
    check("Manifest parses", False)

for label, passed in checks:
    print(f"[{ 'PASS' if passed else 'FAIL' }] {label}")
failed = sum(not passed for _, passed in checks)
print(f"\n{len(checks)-failed}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
