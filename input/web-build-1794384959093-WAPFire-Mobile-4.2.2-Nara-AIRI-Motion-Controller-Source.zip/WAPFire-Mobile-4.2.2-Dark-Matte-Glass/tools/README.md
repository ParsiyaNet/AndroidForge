# WAPFire Mobile 4.0.0 source checks

Run the static source and firmware-integrity checks from any directory:

```bash
python3 tools/validate_4_0_0.py
```

Run the local HTTP-server session-recovery integration test:

```bash
tools/session-recovery-test/run.sh
```

The second test uses `kotlinc` and the Kotlin distribution's bundled
`kotlinx-coroutines-core-jvm.jar`. A minimal `org.json` stub is included only to
isolate the HTTP/session behavior on a plain JVM; it does not test Android JSON
parsing or UI rendering. Neither script replaces a full Android Gradle build or
tests on a physical phone connected to VF38 hardware. See `VALIDATION-4.0.0.txt`.
