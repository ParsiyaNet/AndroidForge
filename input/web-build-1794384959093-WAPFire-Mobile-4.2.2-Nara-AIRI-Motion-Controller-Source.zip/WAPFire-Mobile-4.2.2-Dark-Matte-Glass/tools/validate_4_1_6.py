#!/usr/bin/env python3
"""Static source checks for WAPFire Mobile 4.1.6 native Location Accuracy flow."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
app = (root / "app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt").read_text(encoding="utf-8")
policy = (root / "app/src/main/java/io/wapfire/mobile/monitor/MonitorEventPolicy.kt").read_text(encoding="utf-8")
checks = []

def check(label, condition):
    checks.append((label, bool(condition)))

check("Version 4.1.6 / versionCode 47", 'versionName = "4.1.6"' in gradle and "versionCode = 47" in gradle)
check("Google Play services Location dependency pinned", 'com.google.android.gms:play-services-location:21.4.0' in gradle)
check("SettingsClient is used", "LocationServices.getSettingsClient(activity).checkLocationSettings(settingsRequest)" in app)
check("High-accuracy settings requirement is used", "LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY" in app)
check("Native resolution dialog is requested", ".setAlwaysShow(true)" in app and "ResolvableApiException" in app)
check("Activity Result API launches the resolution PendingIntent", "StartIntentSenderForResult()" in app and "IntentSenderRequest.Builder(failure.resolution)" in app)
check("Accepting native prompt triggers a fresh settings check", "if (result.resultCode == Activity.RESULT_OK)" in app and "recheckLocationSettingsAfterResolution?.invoke()" in app)
check("Canceled native prompt does not start scan", "Location settings were not enabled. Nearby scan was cancelled." in app)
check("Runtime permission callback continues into settings flow", "checkLocationSettingsAndScan()" in app)
check("Only-this-time permission path remains supported", "A one-time permission is valid here" in app)
check("No-GMS fallback is retained", "GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context)" in app and "showLocationServicesDialog = true" in app)
check("Fallback returns to automatic scan", "if (allPermissionsGranted && locationServicesEnabled())" in app and "runDiscoveryScan()" in app)
check("Seven alert categories policy stays present", "The seven alertable Detection Breakdown labels" in policy)
check("WPA Correct Password remains explicitly excluded", "WPA Correct Password" in policy and "ignored by design" in policy)

for label, ok in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {label}")
print(f"{sum(ok for _, ok in checks)}/{len(checks)} checks passed")
if not all(ok for _, ok in checks):
    raise SystemExit(1)
