#!/usr/bin/env python3
"""Static integrity checks for WAPFire Mobile 4.1.37 assistant startup fixes."""
from pathlib import Path
import json, re, zipfile, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
def read(rel): return (ROOT / rel).read_text(encoding='utf-8')

build = read('app/build.gradle.kts')
assert 'versionCode = 78' in build
assert 'versionName = "4.1.37"' in build

html = read('app/src/main/assets/assistant/assistant-live.html')
js = read('app/src/main/assets/assistant/assistant-preflight.js')
view = read('app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt')
for i in ['stage','loading','poster']:
    assert f'id="{i}"' in html
assert 'async function verifyLocalAssets()' in js
assert "import('./dist/index.js')" in js
assert "response.ok" in js and 'response.arrayBuffer()' in js
assert 'pixelBudget' in js and '1_800_000' in js
assert 'sampleW = Math.min(96, w)' in js
assert 'First-frame sample warning' in js
assert 'LivLiv first-frame diagnostic skipped' in js
assert 'canvas.style.minHeight = `${fallbackHeight}px`' in js
assert 'typeof module.Player.isSupported' in js
assert 'Assistant startup diagnostic' not in js or True
assert 'Renderer startup diagnostic:' in view
assert 'diagnostic.optBoolean("preflight", false)' in view
assert 'diagnostic.optBoolean("engine", false)' in view
assert 'served local asset:' not in view.lower() or 'Served local asset:' in view

# Ensure every referenced renderer/model asset exists in Android's assets directory.
assets = ROOT / 'app/src/main/assets/assistant'
required = [
    'assistant-live.html', 'assistant-preflight.js', 'dist/index.js',
    'dist/chunks/base-p0Sx5Qp5.js', 'dist/chunks/params-BCSFSCtz.js',
    'dist/chunks/errors-ohqiRK3N.js', 'characters/k01.livliv',
    'characters/k01/cover.webp'
]
for rel in required:
    p = assets / rel
    assert p.is_file() and p.stat().st_size > 0, f'missing/empty asset: {rel}'

# Check model archive and every texture referenced by model.json.
model_path = assets / 'characters/k01.livliv'
with zipfile.ZipFile(model_path) as z:
    assert z.testzip() is None, 'LivLiv package CRC check failed'
    model = json.loads(z.read('model.json'))
    assert model.get('name') == 'Sena'
    names = set(z.namelist())
    referenced = set()
    for layer in model.get('layers', []):
        for key in ('texture', 'mask', 'talk', 'brow_tex'):
            if layer.get(key): referenced.add(layer[key])
        referenced.update(layer.get('frames', []) or [])
    missing = sorted(x for x in referenced if x not in names)
    assert not missing, f'model references missing textures: {missing}'

for path in [ROOT / 'app/src/main/AndroidManifest.xml', *((ROOT / 'app/src/main/res').rglob('*.xml'))]:
    ET.parse(path)

print('PASS: version metadata')
print('PASS: renderer module references and preflight checks')
print('PASS: all required local Android assets exist')
print(f'PASS: LivLiv model ZIP CRC and {len(referenced)} referenced textures')
print('PASS: XML resources parse')
