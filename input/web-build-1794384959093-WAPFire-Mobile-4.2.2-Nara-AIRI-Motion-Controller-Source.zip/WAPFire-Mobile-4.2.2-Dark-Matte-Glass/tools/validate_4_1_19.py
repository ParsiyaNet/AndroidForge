from pathlib import Path
import re, subprocess, zipfile, sys
root=Path(__file__).resolve().parents[1]
assets=root/'app/src/main/assets/assistant'
html=assets/'assistant-live.html'
text=html.read_text(encoding='utf-8')
assert 'import { Player } from \'./dist/index.js\'' in text
assert "player.load('./characters/k01.livliv'" in text
assert 'window.wapfireSetState' in text
assert 'https://' not in text.replace('https://appassets.androidplatform.net',''), 'Unexpected external URL in assistant HTML'
module=re.search(r'<script type="module">(.*?)</script>', text, re.S)
assert module
script=Path('/tmp/wapfire-assistant-validation.mjs')
script.write_text(module.group(1), encoding='utf-8')
subprocess.run(['node','--check',str(script)],check=True)
entry=assets/'dist/index.js'
assert entry.is_file()
for js in (assets/'dist').rglob('*.js'):
    content=js.read_text(encoding='utf-8')
    for spec in re.findall(r'''(?:from\s*|import\s*)['"](\.[^'"]+)['"]''', content):
        target=(js.parent/spec).resolve()
        assert target.is_file(), f'Missing JS import {spec} in {js}'
model=assets/'characters/k01.livliv'
assert model.is_file() and model.stat().st_size > 100_000
with zipfile.ZipFile(model) as z:
    assert z.testzip() is None
    names=set(z.namelist())
    assert 'model.json' in names and any(n.startswith('textures/') for n in names)
for f in ['LICENSE-APACHE-2.0.txt','NOTICE.txt','characters-LICENSE.md','ATTRIBUTION.txt']:
    assert (assets/f).is_file(), f
kotlin=(root/'app/src/main/java/io/wapfire/mobile/ui/screens/LivLivAssistantView.kt').read_text()
assert 'blockNetworkLoads = true' in kotlin
assert 'allowFileAccess = false' in kotlin and 'allowContentAccess = false' in kotlin
assert 'appassets.androidplatform.net' in kotlin
screens=(root/'app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt').read_text()
assert 'LivLivAssistantOverviewCard' in screens and 'assistantState' in screens
assert 'warning' in screens and 'success' in screens and 'scanning' in screens and 'connecting' in screens
print('WAPFire Mobile 4.1.19 static validation: PASS')
print('LivLiv renderer bytes:', sum(p.stat().st_size for p in (assets/'dist').rglob('*.js')))
print('Sena model bytes:', model.stat().st_size)
