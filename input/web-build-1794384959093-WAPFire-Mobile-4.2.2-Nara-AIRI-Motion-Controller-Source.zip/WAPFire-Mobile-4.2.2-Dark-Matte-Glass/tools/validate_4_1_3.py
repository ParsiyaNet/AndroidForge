#!/usr/bin/env python3
"""Static integrity checks for WAPFire Mobile 4.1.3 Detection Breakdown alerts."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = {"android": "http://schemas.android.com/apk/res/android"}
checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.exists() else ""

try:
    manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
    app = manifest.find("application")
    service = app.find("service") if app is not None else None
    permissions = {p.attrib.get("{" + NS["android"] + "}name") for p in manifest.findall("uses-permission")}
    required = {"android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE", "android.permission.POST_NOTIFICATIONS", "android.permission.WAKE_LOCK"}
    check("Manifest parses and required foreground/notification permissions exist", required.issubset(permissions))
    check("Connected-device foreground service remains declared and private", service is not None and service.attrib.get("{" + NS["android"] + "}foregroundServiceType") == "connectedDevice" and service.attrib.get("{" + NS["android"] + "}exported") == "false")
except Exception as exc:
    check("Manifest parses", False, repr(exc))

service = read("app/src/main/java/io/wapfire/mobile/monitor/BackgroundMonitorService.kt")
policy = read("app/src/main/java/io/wapfire/mobile/monitor/MonitorEventPolicy.kt")
gradle = read("app/build.gradle.kts")
readme = read("README.md")
settings = read("app/src/main/java/io/wapfire/mobile/ui/screens/SettingsScreens.kt")
dash = read("app/src/main/java/io/wapfire/mobile/ui/screens/DashboardScreens.kt")

check("Version is 4.1.3 / versionCode 44", 'versionName = "4.1.3"' in gradle and "versionCode = 44" in gradle)
check("Service reads Detection Breakdown counters from status snapshots", "processDetectionBreakdown(statusSnapshot)" in service and "readDetectionCounts(status" in policy)
check("No logs endpoint or Events timeline is used by monitor", ".logs(" not in service and "client?.logs(" not in service)
check("Exactly seven alertable Detection Breakdown categories are defined", all(x in policy for x in ["Auth Attack", "Deauth Attack", "Deauth Airplay", "WPS Pixie Reaver", "WPS Pixie Bully", "Evil Twin", "WPA Wrong Password"]))
alias_block = policy.split("private val labelAliases = mapOf(", 1)[1].split("// correct_password", 1)[0] if "private val labelAliases = mapOf(" in policy else ""
check("WPA Correct Password is excluded from label aliases", "correct_password" not in alias_block and "wpa_correct_password" not in alias_block)
check("Only counter increases trigger security notifications", "increasedCounts(previous, current)" in service and "if (after > before)" in policy)
check("First valid counts establish a silent baseline", "if (savedRaw.isNullOrBlank())" in service and "Establish a baseline without replaying historical cumulative totals" in service)
check("Notification titles use exact category subject plus Detected", 'get() = "$label Detected"' in policy and ".setContentTitle(delta.notificationTitle)" in service)
check("Operational problems do not call a security-alert post method", "postAlert(" not in service)
check("Status and security alert channels remain separate", "CHANNEL_STATUS" in service and "CHANNEL_ALERTS" in service and "WAPFire Detection Breakdown" in service and "IMPORTANCE_LOW" in service and "IMPORTANCE_HIGH" in service)
check("Settings remains the sole location for monitor controls", "onBackgroundMonitor" in settings and "BACKGROUND SECURITY MONITOR" not in dash)
check("No firmware source was bundled or modified", not list(ROOT.rglob("*.ino")) and not list(ROOT.rglob("*.h")))
check("Documentation describes exact seven labels and events exclusion", "WPA Correct Password is excluded" in readme and "never polls `/api/logs`" in readme)

for name, ok, detail in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
failed = sum(not ok for _, ok, _ in checks)
print(f"\n{len(checks)-failed}/{len(checks)} static checks passed")
sys.exit(1 if failed else 0)
