#!/usr/bin/env python3
"""Static checks for the 4.1.14 Wi-Fi keep-alive and discovery UI changes."""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = '{http://schemas.android.com/apk/res/android}'

manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
permissions = {node.attrib.get(NS + 'name') for node in manifest.findall('uses-permission')}
required_permissions = {
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE',
    'android.permission.CHANGE_NETWORK_STATE',
    'android.permission.CHANGE_WIFI_STATE',
}
assert required_permissions.issubset(permissions), required_permissions - permissions

services = {node.attrib.get(NS + 'name'): node for node in manifest.findall('./application/service')}
service = services.get('.monitor.WifiConnectionKeepAliveService')
assert service is not None
assert service.attrib.get(NS + 'exported') == 'false'
assert service.attrib.get(NS + 'stopWithTask') == 'false'
assert service.attrib.get(NS + 'foregroundServiceType') == 'connectedDevice'

build = (ROOT / 'app/build.gradle.kts').read_text()
assert 'versionCode = 55' in build
assert 'versionName = "4.1.14"' in build

connector = (ROOT / 'app/src/main/java/io/wapfire/mobile/network/WifiConnector.kt').read_text()
assert 'fun shared(context: Context): WifiConnector' in connector

app = (ROOT / 'app/src/main/java/io/wapfire/mobile/ui/WapFireApp.kt').read_text()
assert 'WifiConnector.shared(context)' in app
assert 'WifiConnectionKeepAliveService.start(context, ap.ssid, ap.bssid, ap.securityMode)' in app
assert 'WifiConnectionKeepAliveService.updateConnected(context, ap.ssid, ap.bssid)' in app
assert 'fun releaseWifiConnection()' in app

service_source = (ROOT / 'app/src/main/java/io/wapfire/mobile/monitor/WifiConnectionKeepAliveService.kt').read_text()
for token in ('START_STICKY', 'ACTION_STOP', 'restoreRequestAfterProcessRestart', 'SoftApPasswordVault.load', 'connector.release()'):
    assert token in service_source, token

ui = (ROOT / 'app/src/main/java/io/wapfire/mobile/ui/screens/DiscoveryAndSetupScreens.kt').read_text()
assert 'NeonBreathingFrame' in ui
assert 'rememberInfiniteTransition' in ui
assert 'passwordBringIntoViewRequester.bringIntoView()' in ui
assert 'CONNECT TO SELECTED WI-FI' in ui

print('PASS: manifest, foreground service, shared connector, stop lifecycle, version, neon animation, and auto-scroll checks')
