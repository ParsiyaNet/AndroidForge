# WAPFire Mobile 4.1.53

- Discovery (first page): removed the MEET NARA card and the CURRENT NETWORK card. "Use network" only re-ran the scan, which DEVICE DISCOVERY already does.
- Settings: removed the CHARACTER CREDITS card (character model is purchased). License files in `assets/assistant/` are unchanged.
- First setup: after setup completes, the app now resets the selected tab to Overview and persists it (`last_tab`), so the next sign-in (including the SoftAP-restart path) opens Overview instead of Settings.
- Sign-in: removed the icon above AUTHENTICATION and its spacer so the page no longer scrolls needlessly.
- Android versionCode/versionName: 99 / 4.1.53.
