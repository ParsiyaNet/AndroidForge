# WAPFire Mobile 4.1.52

### Dark bottom navigation — slightly more matte

- Increased only the dark-theme bottom navigation surface alpha from 0.90/0.86 to 0.94/0.92 for slightly less content bleed-through.
- Kept the light theme unchanged at 0.92/0.88.
- Preserved the glass gradient sheen, border, selected-tab capsule, dimensions, labels, icons, navigation behavior, and content insets.
- No other UI, assistant, or monitoring logic changes.
- Android versionCode 98 / versionName 4.1.52.
