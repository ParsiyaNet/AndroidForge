# WAPFire Mobile 4.1.5

## Nearby Wi-Fi scan: Location recovery
- The Scan nearby devices action now checks both runtime Wi-Fi permissions and the device-wide Location Services switch.
- If the required runtime permission is missing, Android's permission prompt is requested first. A one-time grant is accepted for the current scan while the app is in use.
- If the phone's Location Services switch is off, the app explains that a one-time permission does not enable the system switch and offers a direct shortcut to Android Location settings.
- When the user returns after enabling Location, the app automatically starts the pending nearby-device scan; no second tap is required.
- If the user cancels or Location remains off, scanning does not start and a clear message is shown.
- The existing WAPFire BSSID filtering, LAN discovery, manual-IP fallback, and connection flow are preserved.
