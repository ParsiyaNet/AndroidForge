pluginManagement {
    repositories {
maven {
            url = uri("https://artifacts-oss.talend.com/nexus/content/repositories/central")
            content {
                includeModule("org.jetbrains.kotlin", "kotlin-compiler-embeddable")
            }
        }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
maven {
            url = uri("https://artifacts-oss.talend.com/nexus/content/repositories/central")
            content {
                includeModule("org.jetbrains.kotlin", "kotlin-compiler-embeddable")
            }
        }
        google()
        mavenCentral()
    }
}
rootProject.name = "WAPFire-Mobile"
include(":app")
