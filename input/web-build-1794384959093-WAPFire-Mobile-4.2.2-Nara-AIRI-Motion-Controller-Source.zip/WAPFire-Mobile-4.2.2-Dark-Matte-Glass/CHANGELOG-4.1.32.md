# WAPFire Mobile 4.1.32

## Improve Sena framing and eliminate favicon 404 diagnostics

- Increase the Overview assistant viewport to 264dp and enlarge Sena's rendered scale while keeping the speech card in its own footer.
- Keep the WebGL canvas height locked to the actual measured Overview stage; remove the old unconditional 200px minimum that could overflow the frame and leave a dark strip.
- Add a framed character stage with a softly blurred, low-opacity cover image behind the transparent model so side and lower empty space looks intentional rather than black/empty.
- Increase Assistant character scale to use more of the available portrait viewport without stretching model proportions.
- Package a local WAPFire favicon and declare it explicitly; support ICO MIME type in WebViewAssetLoader.
- Ignore favicon-only resource failures in WebView diagnostics so browser metadata cannot be misreported as an assistant engine failure.
- Preserve the existing full-screen Assistant layout, state reactions, language/theme actions, and navigation behavior.

Version: 4.1.32 (versionCode 73).
