# WAPFire Mobile 3.0.1 — Settings UX and VF38 compile fix

## Native Android app
- Added consistent vertical rhythm and larger spacing between controls and Save actions in every expandable settings group.
- Replaced hexadecimal color text fields with an interactive HSV color picker for WS2812 primary/secondary colors and client-disconnect alert color.
- Replaced numeric LED speed and brightness entry fields with sliders matching the firmware ranges (10–1000 ms and 0–255).
- Rebuilt the Deauth whitelist editor around live tracked-client selection, MAC autofill, editable device alias, add/remove rows, validation and the 32-entry firmware limit.
- Tracked clients are refreshed while Settings is open and can be refreshed from the whitelist editor.
- Removed the misleading manual Beacon Mode switch from device credentials. The UI now reports its state and explains that VF38 enables beacon transmission automatically during Self-Protect.
- Added spacing to firmware maintenance buttons to prevent crowded controls.

## VF38 firmware
- Moved `WAPFIRE_BUILD_TAG` before `#include "webui.h"`, because WebUI service handlers reference the macro while they are included. Removed the later duplicate definition from `wapfire_shared_state.h`.
- This resolves the reported `WAPFIRE_BUILD_TAG was not declared in this scope` compile failure.

## Verification
- Checked include/macro ordering and firmware file presence.
- Android Gradle build was attempted, but the wrapper could not download Gradle because this environment has no DNS/network access to `services.gradle.org`; APK compilation remains unverified here.
- ESP32 Arduino compilation could not be run here because Arduino CLI / ESP32 toolchain is not installed.
