# WAPFire Mobile 3.0.7

- Restored the original single-button Dark/Light action used beside the Welcome Back header in 3.0.3.
- The same compact, rounded action button is used consistently in Discovery, Login, Setup, Control and Settings.
- The button shows a drawn sun in dark mode (tap to switch to light) and a drawn crescent moon in light mode (tap to switch to dark).
- Removed the two-segment split control. No firmware changes.
