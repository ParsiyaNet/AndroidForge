# WAPFire Mobile 3.2.12 — Wi-Fi return / reconnect recovery

## Fixes
- Reworked the `WifiNetworkSpecifier` recovery path. After a successful first connection, an `onLost` now starts a bounded-delay recovery; if Android does not restore the existing request, the old callback is released and the same WAPFire-specific request is submitted again.
- Recovery waits while the phone Wi-Fi radio is disabled, then resubmits the selected SSID+BSSID request when Wi-Fi is enabled. The request remains pending without an artificial timeout during recovery.
- `onUnavailable` after a previously successful join no longer terminates the authenticated app session; it schedules a fresh request with backoff. Initial-join failures still report an error.
- The already-connected `Current Network → Use network` path now requests location-sensitive Wi-Fi transport information on Android 12+ using `FLAG_INCLUDE_LOCATION_INFO`, so the app can read the restored BSSID instead of receiving Android's redacted value.
- The passive WAPFire watcher now waits for `onCapabilitiesChanged` rather than synchronously querying capabilities inside `onAvailable`, and explicitly accepts local-only Wi-Fi networks without Internet capability.
- Recovery callbacks and timers are cancelled when the user leaves Discovery or starts a new connection, preventing stale reconnect attempts.

## Preserved
- Android minimum remains API 29 (Android 10).
- WAPFire BSSID signature `02:57:41` remains unchanged.
- Firmware remains unchanged from VF38 3.0.5.
- No changes to RF detection, Async Target Scan, SoftAP BSSID generation, API routes, authentication, or UI layout.

## Validation limits
- Source-level checks confirm that both the `WifiNetworkSpecifier` join path and the already-connected BSSID watcher have recovery handling.
- Full Android Gradle/Kotlin build was not run because this environment has no Android SDK and cannot resolve `services.gradle.org`.
- Physical Wi-Fi OFF → ON testing remains required on the target phone.
