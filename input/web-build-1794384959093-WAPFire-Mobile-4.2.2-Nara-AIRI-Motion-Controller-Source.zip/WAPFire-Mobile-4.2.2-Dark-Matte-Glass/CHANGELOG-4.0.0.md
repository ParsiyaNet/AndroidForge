# WAPFire Mobile 4.0.0 — Modular Rebuild

## Architecture
- Split the monolithic Android activity source into an activity entry point, app composition, feature screens, reusable UI components, app models, Wi-Fi transport, API client, session recovery, and credential storage.
- Kept the four primary navigation destinations, the five-step initial setup, Persian RTL/English UI, themes, target selection, telemetry, events, clients, and the full advanced Settings surface.
- Preserved application ID, minSdk, preference names, Android Keystore key alias, and the saved-credential ciphertext format for upgrade compatibility.

## Reliability
- HTTP failures now retain status code, endpoint, and response body as a typed exception. No caller needs to search arbitrary error text for `401`.
- Added an unauthenticated root-page identity probe that verifies the WAPFire VF38 login page before any automatic credential resend.
- Added bounded automatic session recovery for IP-bound VF38 sessions. Only `/api/status` is retried after a successful fresh login; mutating API calls are never replayed.
- Added an 8-second cooldown after temporary network failures during re-authentication to avoid repeated login bursts. Credential rejection and rate limiting return the user to the login screen rather than entering a retry loop.
- On reconnect to the same exact SoftAP BSSID, a changed verified address can establish a new API session without rediscovery. Unknown endpoint changes still require manual sign-in.
- Failed post-login status checks now clear the partially initialized API session rather than leaving a half-authenticated object active.

## Compatibility
- No BLE integration or BLE permissions/dependencies were added.
- The `WAPFireVF38/` firmware source tree is unchanged.
- Full Android compilation and real device Wi-Fi OFF/ON testing remain required before considering this release production-validated.
