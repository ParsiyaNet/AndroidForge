# WAPFire Mobile 4.1.2 — UX and session fix

Background Security Monitor is available only under **Settings → Background Alerts**. It is no longer shown on Overview or as a dashboard toolbar shortcut.

When Remember password is enabled (default for a new install), WAPFire credentials are stored encrypted with Android Keystore. On the next app launch, the app checks whether the existing session is still valid. If the process was recreated, it verifies the VF38 login page and signs in automatically. A temporary Wi-Fi outage does not delete the saved credentials. Only the explicit **Log out** action clears the saved credentials and ends the authenticated session.

Users can still turn off Remember password on the login screen. In that case, automatic sign-in is intentionally unavailable.

APK compilation has not been performed in this environment; run the ZIP through AndroidForge to verify the full Gradle build and device behavior.
