# WAPFire Mobile 4.1.37

## Assistant renderer startup and local asset loading
- Validate all local engine modules, model package, and poster assets before importing the renderer.
- Check HTTP status, MIME type, and non-empty payloads; report the exact failing local asset.
- Add a 20-second ES-module import timeout and an explicit WebGL2 support check.
- Replace the large full-frame CPU readback with a bounded central sample. A non-fatal first-frame sampling warning no longer disposes a successfully loaded model.
- Bound WebGL backing-buffer density and total pixel area for high-DPI Android devices.
- Restore the known-good definite canvas minimum-height behavior from 4.1.28.
- Make optional Overview watermark styling non-fatal to renderer startup.
- Replace the generic native timeout message with a structured boot-stage diagnostic (preflight, module, canvas, loading text).

## Build metadata
- Version name: 4.1.37
- Version code: 78
