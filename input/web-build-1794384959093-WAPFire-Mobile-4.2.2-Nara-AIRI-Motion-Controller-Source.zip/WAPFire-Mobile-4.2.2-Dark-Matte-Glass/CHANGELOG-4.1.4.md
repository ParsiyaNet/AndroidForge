# WAPFire Mobile 4.1.4 — Foreground Detection Alerts & Light Theme Contrast

- Detection Breakdown alerts now work while the app is open, even when Settings → Background Alerts is OFF.
- In-app polling is lifecycle-aware: it runs while the Activity is resumed and pauses when the app leaves the foreground.
- Background Alerts remains an independent opt-in Foreground Service for monitoring after leaving the app.
- Foreground and background monitoring share one persisted counter baseline and one notifier to avoid duplicate alerts.
- Android 13+ notification permission is requested independently for in-app detection alerts.
- Detection notifications remain limited to seven Detection Breakdown categories; WPA Correct Password is excluded. Events/logs are not used.
- Overview Monitoring Status ring colors now use light high-contrast colors on its dark glass card in both themes.
- Target ONLINE status color is slightly brighter for readability.

## Validation status
- Existing isolated Kotlin Detection Breakdown policy test: expected to be rerun.
- Existing isolated Kotlin session-recovery test: expected to be rerun.
- Static source validation: expected to be rerun.
- Full Gradle/APK build and device runtime verification: not performed in this environment.
