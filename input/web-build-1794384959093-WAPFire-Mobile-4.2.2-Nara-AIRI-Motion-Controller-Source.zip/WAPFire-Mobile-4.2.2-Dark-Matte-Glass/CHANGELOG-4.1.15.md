# WAPFire Mobile 4.1.15

## Neon edge breathing refinement
- Reworked the `Connect to Selected Wi-Fi` panel breathing effect to originate visually from the panel edges.
- Increased neon brightness and edge definition with layered electric-blue, cyan, and ice-blue strokes.
- Added a stronger expanding outer aura while keeping the card's text and controls clear.
- Preserved the automatic scroll-to-join-panel behavior and the 4.1.14 Wi-Fi keep-alive implementation.
- Bumped Android versionCode to 56 and versionName to 4.1.15.

## Validation
- ZIP integrity checked with `unzip -t`.
- Source-level checks confirm the new version metadata and neon edge animation are present.
- Android/Gradle compilation and on-device animation testing were not run in this environment.
