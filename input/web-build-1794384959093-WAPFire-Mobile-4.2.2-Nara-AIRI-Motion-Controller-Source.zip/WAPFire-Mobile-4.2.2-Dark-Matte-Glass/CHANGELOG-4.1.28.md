# WAPFire Mobile 4.1.28

## Detection Breakdown reactions and persistent Overview assistant

- Connect the eight cumulative Detection Breakdown counters to Sena's live state: WPA Correct Password → password-success reaction; WPA Wrong Password → warning reaction; Auth Attack, Deauth Attack, Deauth Airplay, WPS Pixie Reaver/Bully, and Evil Twin → angry attack reaction.
- Use the first complete counter snapshot as a quiet baseline, so historical counters do not trigger false reactions after app launch or reconnect.
- Keep the event reaction visible for 4.2 seconds; a newer detection restarts the display interval. Attacks take priority over wrong-password and correct-password events when counters rise together.
- Replace Overview's virtualized LazyColumn with a normal vertically scrollable Column. The seven-section Overview stays composed while scrolling, preventing its embedded WebView from being disposed, blanked, and recreated from the start.
- Preserve the full Assistant tab, offline LivLiv model, WebGL renderer, and existing connection/risk ambient states.

Version: 4.1.28 (versionCode 69).
