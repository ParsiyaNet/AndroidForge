# WAPFire Mobile 4.1.46 — Nara character replacement

- Replaced the packaged LivLiv model at the existing offline asset path `assistant/characters/v03.livliv` with the user-provided `my_character_final.livliv` package.
- Replaced the Overview/Assistant poster with the `cover.webp` included in the new model package.
- Updated the visible assistant name and Settings character credit from Mira to Nara.
- Preserved the model package metadata and its LivLiv watermark declaration.
- Kept the existing Renderer, WebView loading flow, model path, texture-loading logic, Assistant controls, Overview layout, and Persian RTL behavior unchanged.
- Updated app version metadata to 4.1.46 (versionCode 87).
