# WAPFire Mobile 3.2.11 — Wi-Fi reconnect recovery

## Android Wi-Fi recovery
- Kept the `WifiNetworkSpecifier` NetworkCallback registered after a temporary `onLost`; it now waits for Android to report `onAvailable` again when phone Wi-Fi is switched back on.
- Re-binds the app process to the returned WAPFire Wi-Fi `Network` each time it becomes available. The process binding is cleared on loss so requests do not remain attached to a stale Android `Network` object.
- Rebuilds the IPv4 readiness check for each reconnection and avoids duplicate connection callbacks for the same live `Network`.
- Added a passive Wi-Fi NetworkCallback for the already-connected WAPFire path (`Current Network → Use network`). It tracks the selected WAPFire BSSID, rebinds the app when that exact AP returns, and ignores unrelated Wi-Fi networks.
- After reconnection, the app verifies the WAPFire login page and restores API reachability without forcing the user back to Discovery/Login when the authenticated session and endpoint are still valid.
- During temporary Wi-Fi loss, the app preserves the current tab, authenticated API session, last dashboard snapshot, logs and clients; the top status changes to OFFLINE and returns to LIVE after a successful status refresh.

## Compatibility and scope
- Minimum Android remains API 29 (Android 10).
- BSSID discovery signature `02:57:41` and firmware 3.0.5 are unchanged.
- No changes to WAPFire firmware, RF detection, Async Target Scan, SoftAP identity, UI layout, or BLE (none included).

## Validation limits
- Kotlin source-level inspection and static recovery-path checks performed.
- Full Android Gradle/Kotlin compilation and APK build were not available: the Gradle wrapper could not resolve `services.gradle.org` in this environment, and Android SDK/dependencies were not present.
- Real-device test of Wi-Fi OFF → ON and reconnect is still required.
