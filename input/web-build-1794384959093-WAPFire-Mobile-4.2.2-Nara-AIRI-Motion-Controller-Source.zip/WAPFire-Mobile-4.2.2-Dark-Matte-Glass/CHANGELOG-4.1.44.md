# WAPFire Mobile 4.1.44

## Overview assistant card
- Enlarged the character frame from 218dp to 300dp tall. The engine fits the model by height, so Sena renders about 38% larger with the same framing (head and hairline stay inside).
- Reduced the gap between the character frame and the speech frame: card padding 8dp -> 6dp, spacing 3dp -> 2dp.
- Compact HTML shell/stage/canvas are now pinned to the full WebView viewport (position: fixed, inset 0), so the framed stage can no longer end above the bottom of the WebView and leave an empty band above the speech card.
- Speech card, Persian RTL alignment, Assistant tab controls and the offline asset loader are unchanged.

## Build metadata
- Version name: 4.1.44
- Version code: 85
- Renamed bootstrap to `assistant-preflight-4.1.44.js` (unique name, same convention as before).

## Verification limits
- Static checks only (asset references, version strings, zip integrity). No Android device or SDK in this environment; build with `build-apk.bat` / Android Studio and check the Overview on a device.
