# WAPFire Mobile 3.2.5 — follow-up UX update

## Applied changes

### Main Discovery flow
- Selecting a Wi-Fi access point now changes the discovery card into a selected-network state. The other nearby AP rows are no longer rendered while a target AP is selected.
- The selected network remains visible with its BSSID, signal level and security mode.
- The connection/password card is attached to a `BringIntoViewRequester`, so selection scrolls the user to that card.
- Secured APs focus the password field and request the software keyboard automatically.
- `Choose another network` clears the selected SSID, BSSID and password state. The previous scan results remain in memory and can be selected again; they are not destructively erased.
- Clearing the selected AP also hides the software keyboard.

### Notifications
- The global Toast-style `MessageCard` now uses the opaque theme panel surface instead of a 10%-alpha red/green fill.
- A higher-opacity success/error border preserves the status cue without making the text transparent or low-contrast.

### Setup language and controls
- Initial Setup now exposes the same FA / EN switch used by Discovery and Login.
- The switch and Dark / Light control both use 36 × 36dp bounds.
- The language code remains LTR and centered in Persian RTL mode.

### Release metadata
- Android version updated to `3.2.5`, versionCode `23`.
- Firmware source was not modified.

## Validation performed
- Kotlin parser pass: no `expecting`, unexpected-token, or syntax diagnostics were emitted. The standalone compiler invocation could not resolve Android/Compose symbols because the Android/Compose classpath is not installed, so this is not a successful app compile.
- Firmware source tree compared against the supplied original tree: no differences.
- Full Android Gradle build and physical-device interaction test were unavailable because Android SDK variables/directories are absent and the Gradle 8.9 wrapper distribution is not cached.

## Device checks still recommended
1. Select a secured AP, confirm all other AP rows disappear, and confirm the password field becomes visible/focused with the keyboard open.
2. Tap `Choose another network`, confirm the keyboard closes and the scan list returns.
3. Repeat in Persian and English, in both Dark and Light themes.
4. Confirm success/error notifications remain readable against both themes and do not move the underlying page.
