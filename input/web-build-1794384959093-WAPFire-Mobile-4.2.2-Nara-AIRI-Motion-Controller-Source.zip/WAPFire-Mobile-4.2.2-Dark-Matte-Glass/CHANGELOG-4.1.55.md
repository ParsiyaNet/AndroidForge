# WAPFire Mobile 4.1.55

- Persian UI: MAC addresses, BSSIDs and IPs keep their left-to-right order (e.g. `18:19:D6:2E:7B:3E` no longer shows as `D6:2E:7B:3E:18:19`). New helpers `ltrTechnical` / `ltrUnit` (AppModels.kt) embed technical text as an LTR unit; applied to Clients, Events, Overview target, Discovery list, first-setup target list and Settings (target, Ethernet MAC, whitelist).
- Events: a `disconnect` event is no longer treated as a threat. Its title stays "Client Disconnect" with the DISCONNECT badge, and its text is shown exactly as sent by the firmware. Previously the bare word "deauth" in `Reason: CLIENT->AP Deauth` was rewritten to "Deauth Attack" by `friendlyTechnicalText`; that rewrite now only applies to threat/credential events.
- Background notifications are unchanged (they only read the Detection Breakdown counters).
- Android versionCode/versionName: 101 / 4.1.55.
