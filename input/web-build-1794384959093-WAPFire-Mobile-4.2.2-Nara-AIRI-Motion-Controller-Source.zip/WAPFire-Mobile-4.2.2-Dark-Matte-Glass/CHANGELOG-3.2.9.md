# WAPFire Mobile 3.2.9

## Link state and cached dashboard
- The top-bar badge now reflects Android-to-WAPFire API reachability (`LIVE` / `OFFLINE`), independently of the radio promiscuous state.
- A failed status poll marks the device offline without clearing the last successful snapshot, chart values, clients, or event list.
- The lightweight status heartbeat uses a short, dedicated connection/response timeout so a lost device link is reflected promptly; existing chart, logs, clients, settings, and write-operation timeouts are preserved.
- Transient polling failures no longer replace the cached dashboard with a toast; the existing polling loop automatically restores `LIVE` after the next successful status response.

## Theme surfaces
- Network Telemetry metric tiles now use opaque palette-based surfaces.
- Events cards now use opaque palette-based surfaces and theme-matched borders instead of translucent white overlays, improving contrast in Light and Dark modes.

## Compatibility
- No API routes, attack behavior, firmware files, or settings formats changed.
