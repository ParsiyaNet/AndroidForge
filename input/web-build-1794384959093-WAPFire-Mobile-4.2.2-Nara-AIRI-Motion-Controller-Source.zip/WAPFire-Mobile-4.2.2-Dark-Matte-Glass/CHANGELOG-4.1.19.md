# WAPFire Mobile 4.1.19 — Offline LivLiv Assistant in Overview

## Overview integration
- Added the real LivLiv 2.5D character player to the top of the Overview page.
- The assistant state is driven from live app/device state: connecting/reconnecting, successful reconnection, active radio monitoring, elevated/critical threat, and setup-required.
- The Overview card links to the full Assistant tab, which retains manual state controls for preview/testing.

## Offline implementation
- Bundled the official LivLiv Player browser build (`dist/index.js` and its local chunks) inside `app/src/main/assets/assistant/`.
- Bundled the Sena (`k01`) `.livliv` model and cover locally. The character model includes its own layered textures in the `.livliv` package.
- Added an appassets-style HTTPS origin using a custom WebViewClient asset loader. ES modules and the `.livliv` package are served from Android assets; external hosts are rejected and WebView network loads are blocked.
- No CDN, internet, camera, microphone, MediaPipe, VRM runtime, or extra Gradle dependency is required for this character view.
- Kept a visible LivLiv attribution and bundled the renderer and character license notices.

## Technical notes
- Version: 4.1.19 / versionCode 60.
- WebGL2 is required. If unavailable, the bundled cover image remains as the visual fallback and the WebView shows an error message.
- The included Sena featured character is licensed for personal, non-commercial use with credit. Obtain written permission from LivLiv before commercial distribution or using this character in a commercial WAPFire product. The renderer code is Apache-2.0; its license is included separately.
