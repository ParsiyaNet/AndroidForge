# WAPFire Mobile 4.1.34

## Fix Overview assistant card spacing and character scale

- Move the Overview speech bubble out of the compact WebView and render it as a native Compose panel directly below the character frame.
- Make the compact WebView show only the character stage, filling the measured viewport instead of reserving an HTML speech footer.
- Remove the unexplained empty area beneath the speech bubble by using a content-sized Compose column containing only the character frame and speech panel.
- Increase compact Overview character zoom from 1.34 to 1.52 while preserving the model's aspect ratio.
- Keep state-specific messages synchronized with the existing network and detection state values in both Persian and English.
- Preserve Assistant full-screen view, animations, and all existing local model assets/attribution.

Version: 4.1.34 (versionCode 75).
