# WAPFire Mobile 4.1.6

## Native Android Location Accuracy prompt
- Replaced the app-only Location explanation as the primary flow with Google Play services `SettingsClient`.
- The nearby scan now requests the standard Android/Google Play services resolution dialog (`No thanks` / `Turn on`) when Location or Location Accuracy settings do not meet the scan requirement.
- The request uses a high-accuracy `LocationRequest` only to validate/enable system settings; WAPFire does not request, collect, or store a GPS location fix.
- After the user accepts, settings are checked again and the pending nearby scan resumes automatically.
- Canceling the dialog does not start a scan.
- The previous Android Location Settings page remains a fallback on devices without a usable Google Play services resolution.
- Existing one-time permission behavior, WAPFire BSSID discovery, LAN scan, manual-IP fallback, detection notifications, and session recovery are preserved.

## Build
- Version: 4.1.6 (versionCode 47)
- Added `com.google.android.gms:play-services-location:21.4.0`.
