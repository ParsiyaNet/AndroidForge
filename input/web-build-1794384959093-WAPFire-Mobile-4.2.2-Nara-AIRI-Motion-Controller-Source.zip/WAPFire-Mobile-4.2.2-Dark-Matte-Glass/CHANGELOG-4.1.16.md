# WAPFire Mobile 4.1.16

## Rounded neon edge glow refinement
- Kept the 4.1.15 breathing animation and refined the `Connect to Selected Wi-Fi` frame.
- Matched the glow path to the card's 23dp rounded corners so the light follows the curved perimeter cleanly.
- Increased the outer blue bloom slightly and added a secondary cyan bloom behind the rounded edge.
- Increased the neon rim and icy inner highlight brightness while keeping the card surface and controls readable.
- Expanded transparent drawing space around the card so the outer glow is not clipped at the frame bounds.
- Preserved automatic scrolling and all Wi-Fi keep-alive / Smart Join behavior.
- Bumped Android versionCode to 57 and versionName to 4.1.16.

## Validation
- ZIP integrity checked with `unzip -t`.
- Source-level checks confirm matching corner geometry, increased outer glow layers, version metadata, and preserved scroll / keep-alive source.
- Android/Gradle compilation and physical-device visual testing were not run in this environment.
