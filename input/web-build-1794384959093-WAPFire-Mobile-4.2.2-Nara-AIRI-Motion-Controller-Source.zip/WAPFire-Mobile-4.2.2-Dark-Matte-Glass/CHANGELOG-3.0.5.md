# WAPFire Mobile 3.0.5

- Replaced the changing single theme icon with a permanent split Dark / Light selector.
- The left half is always dark with a light moon icon; the right half is always light with a dark sun icon.
- The selected half is highlighted with the app accent outline. Both halves remain visible in either theme.
- Tapping either half explicitly selects that appearance. The same selector is used on Discovery, Sign in, First-time setup, Control Center, and Settings.
- Updated Android version metadata to 3.0.5 (versionCode 12).
