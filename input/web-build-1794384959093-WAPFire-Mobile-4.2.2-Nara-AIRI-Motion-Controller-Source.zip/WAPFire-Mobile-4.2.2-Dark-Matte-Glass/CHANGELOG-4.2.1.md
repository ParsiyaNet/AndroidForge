# WAPFire Mobile 4.2.1

- Voice removed completely: no text-to-speech, no speaker/mute button, no lip-sync hook (`AssistantVoice.kt`, the Nara-tab toggle and `setSpeaking` / `wapfireSetSpeaking` are gone). The 4.2.0 voice notes in CHANGELOG-4.2.0.md no longer apply.
- Natural movement: the constant shaking/bouncing is gone. New `assets/assistant/hiyori/pose.js` engine:
  - each state blends Hiyori's own idle-motion face toward a target expression (idle uses her pure idle motion);
  - head and body movement is added on top of her idle sway and eases in over about half a second;
  - one-shot gestures instead of oscillation: a nod (Connected / Pass OK), a decaying "no" (Wrong pass), a quick start (Warning);
  - Scanning does a slow gaze sweep with the head following;
  - Attack = angry: brows pulled down, eyes narrowed and looking up from under the bangs, frown, light blush, head lowered and leaning in, held steady;
  - Offline = sad/tired, Connecting = thinking (eyes up and aside, one brow raised, head tilt), Setup = friendly.
- Expression values were tuned on an offline preview render of the real model (Cubism Core geometry + the real textures).
- Page/build marker 4.2.1; `pose.js` added to the required-assets list (the automatic fallback to the older Nara page still applies).
- Android versionCode/versionName: 103 / 4.2.1.
