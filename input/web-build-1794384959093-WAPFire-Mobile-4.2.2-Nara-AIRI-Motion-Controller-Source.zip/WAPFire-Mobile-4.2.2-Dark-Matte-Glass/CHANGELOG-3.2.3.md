# WAPFire Mobile 3.2.3

- Replaced the Schedule Start and End text inputs with native Android 24-hour time-picker dialogs. Both controls have equal width; schedule values continue to use the firmware-compatible `HH:MM` format and existing `start` / `end` API fields.
- Filtered radio-scan results by the selected target BSSID in both Initial Setup and Settings. Other access points stay hidden after a target is selected; Setup includes an explicit “Choose another AP” action, and Settings retains “Clear target” to reopen the full scan list.
- Moved app-wide success and error messages out of scrollable screen content into a top overlay. Toasts no longer resize pages or shift scroll position, use a narrower maximum width, and auto-dismiss after 3.2 seconds (success) / 4.8 seconds (error).
- No WAPFire firmware detection, RF, WPA2 or WPA3 logic was changed. The 3.2.2 VF38 firmware source remains compatible and unchanged.

Build status: source-level changes and structural checks completed. Android Gradle compilation and device interaction tests must be run in Android Studio / on the target phone.
