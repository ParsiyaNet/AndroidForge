# WAPFire Mobile 3.2.10 — BSSID-based discovery

## Device identity
- WAPFire SoftAP now uses a locally administered, unicast BSSID signature: `02:57:41`.
- The lower three MAC bytes are retained from the factory-derived SoftAP MAC to keep a per-device suffix.
- Renaming the SoftAP SSID no longer changes how the Android app identifies WAPFire.

## Android discovery
- `WifiDiscovery.scan()` returns only access points whose BSSID matches the WAPFire signature.
- **Device Discovery → Scan nearby devices** no longer displays unrelated Wi-Fi networks.
- **Current Network → Use network** now runs the same WAPFire-only discovery flow and presents the matching device(s) for explicit selection.
- When Android omits the currently connected AP from scan results, the app adds it from `WifiInfo` if its BSSID matches the WAPFire signature. The currently connected WAPFire is sorted first and selecting it uses its existing gateway instead of attempting a redundant rejoin.
- Existing LAN discovery remains available for devices on the current subnet; it is skipped when the phone is already connected to the WAPFire SoftAP to avoid showing the same device twice. Manual IP entry and the verified WebUI connection flow are preserved.

## Compatibility
- Android minimum remains API 29 (Android 10). The app uses the existing Wi-Fi scan APIs and BSSID field; no Android 11-only Information Element API is required.
- No BLE implementation is included.
