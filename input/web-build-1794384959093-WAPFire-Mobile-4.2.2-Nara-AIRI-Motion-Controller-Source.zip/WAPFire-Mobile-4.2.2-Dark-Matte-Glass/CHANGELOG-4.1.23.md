# WAPFire Mobile 4.1.23 — LivLiv blank-screen diagnostic and bootstrap fix

## Changes
- Load the main assistant HTML directly from packaged APK assets with `WebView.loadDataWithBaseURL()` and the local virtual HTTPS origin.
- Keep `WebViewAssetLoader` for all same-origin ES module, model package, and texture requests.
- Keep external hosts and out-of-scope paths blocked.
- Add a JavaScript bridge for explicit renderer status and ready notifications.
- Preserve main-frame and subresource failures instead of clearing diagnostics from `onPageFinished()`.
- Add a renderer-startup timeout so the Overview no longer remains an unexplained blank panel.
- Add visible reporting for JS errors, rejected promises, missing local assets, WebGL2 initialization, and model-load failures.
- Bump versionName to 4.1.23 and versionCode to 64.

## Validation
- Verified the `.livliv` ZIP package opens and contains `model.json` plus all 41 companion files.
- Verified the HTML, engine module and its relative chunk paths are packaged under `app/src/main/assets/assistant/`.
- Verified model texture paths exist inside the `.livliv` package.
- ZIP integrity and SHA-256 checked at packaging time.
- Android Gradle compilation and real-device WebView/WebGL2 rendering have not been run in this environment.
