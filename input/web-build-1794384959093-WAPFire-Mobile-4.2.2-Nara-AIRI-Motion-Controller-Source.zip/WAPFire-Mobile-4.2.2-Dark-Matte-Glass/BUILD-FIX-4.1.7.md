# WAPFire Mobile 4.1.7 — Kotlin metadata compatibility fix

## AndroidForge build failure diagnosis

AndroidForge run 41993348081 failed at `:app:compileDebugKotlin` because
`play-services-location:21.4.0` contains Kotlin metadata version 2.3.0 while
the project used Kotlin Gradle Plugin 2.0.21 (compiler expected metadata 2.0.0).

## Changes

- Updated `org.jetbrains.kotlin.android` from 2.0.21 to 2.3.0.
- Updated `org.jetbrains.kotlin.plugin.compose` from 2.0.21 to 2.3.0.
- Kept Android Gradle Plugin 8.7.3 and Gradle 8.9 unchanged.
- Kept `play-services-location:21.4.0` and all 4.1.6 location prompt logic unchanged.
- Bumped app version to 4.1.7 / versionCode 48.

Kotlin 2.3.0 supports Gradle 7.6.3–9.0.0 and AGP 8.2.2–8.13.0, so the
existing Gradle 8.9 / AGP 8.7.3 toolchain falls within the documented range.

## Verification

Static verification confirms both Kotlin plugin declarations are 2.3.0 and app
version metadata is 4.1.7 / 48. A full Android Gradle build was not run in this
environment because the Android SDK and Gradle executable are not installed.
The next AndroidForge run is the definitive compile check.
