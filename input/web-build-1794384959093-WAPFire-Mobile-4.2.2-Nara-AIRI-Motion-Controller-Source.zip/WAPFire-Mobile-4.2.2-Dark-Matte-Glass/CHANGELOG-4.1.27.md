# WAPFire Mobile 4.1.27 — Assistant Layout & Fit Fix

- The dashboard Assistant tab now uses a direct full-size canvas surface instead of a padded/weighted preview column.
- Full Assistant mode removes the large speech overlay so the character is not covered by long status text.
- Full-mode controls are arranged in a compact, horizontally scrollable dock; the state indicator remains small.
- The LivLiv HTML shell is anchored to the WebView viewport to avoid unused black space below the renderer.
- Overview compact mode uses a wider character framing and smaller two-line labels to keep Sena inside the 218dp card.
- App version bumped to 4.1.27 (versionCode 68).
