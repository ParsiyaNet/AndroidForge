# WAPFire Mobile 4.1.47 — Nara purchased model

- Replaced the previous character package with the user-purchased `my_character_final2.livliv` archive, preserved byte-for-byte at the existing internal path `assistant/characters/v03.livliv`.
- Kept the LivLiv renderer and its startup/control code unchanged.
- Updated active character labels to Nara.
- Updated the external app poster using a clean composite from the package's unmarked texture layers; the original vendor `.livliv` archive, including its own cover and license metadata, remains unchanged.
- Preserved the `LicenseRef-LivLiv-Terms` metadata and separate Apache-2.0 renderer notices.
- Version: 4.1.47 (versionCode 88).
