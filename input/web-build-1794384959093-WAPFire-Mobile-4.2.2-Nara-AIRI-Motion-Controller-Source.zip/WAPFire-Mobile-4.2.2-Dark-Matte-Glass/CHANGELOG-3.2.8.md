# WAPFire Mobile 3.2.8

## Protection risk ring
- Fixed the risk-ring scale: firmware `score_tenths` is 0–100 (0.0–10.0), while the old UI treated the converted 0–10 score as 0–100.
- The ring now fills proportionally across the complete 0–10 range and keeps one decimal place, matching the WebUI.
- Corrected risk-level colors for `OPTIMAL`, `MONITORING`, `WARNING`, and `CRITICAL`.
- The overview status now distinguishes radio monitoring, armed self-protection, and an active protection response using live firmware fields instead of treating `configured` as proof that protection is active.

## Request reliability under load
- Serialized all app-to-device HTTP exchanges through a per-session coroutine mutex so refreshes and user actions cannot open overlapping ESP32 API requests.
- Raised the standard response timeout from 12 seconds to 30 seconds; scans, logs, settings updates, restore, and backup use longer operation-appropriate limits.
- Added an explicit `Connection: close` request header for the ESP32 WebServer.
- Timeout errors now identify the endpoint and are not automatically retried, avoiding duplicate POST actions.
- Prevented overlapping telemetry and advanced-settings refresh cycles.
- Removed the firmware-info request from each telemetry poll and fetches chart data only on Overview, reducing routine request volume.

## Compatibility
- Firmware source was not modified.
- Version: 3.2.8 (`versionCode` 26).
