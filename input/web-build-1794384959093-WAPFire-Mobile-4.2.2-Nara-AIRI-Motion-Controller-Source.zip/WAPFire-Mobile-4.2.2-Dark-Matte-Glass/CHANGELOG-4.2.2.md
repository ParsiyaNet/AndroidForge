# WAPFire Mobile 4.2.2 — Nara Motion Controller

- Restored the user-owned Nara LivLiv character as the default assistant renderer; Hiyori remains packaged but is no longer forced as the default.
- Added a single-owner, AIRI-style staged motion controller for Nara: autonomous idle is active only in Idle, while each WAPFire state exclusively owns its own motion curve.
- Idle retains Nara Player's native random glance/look-around/sway/think/look-down motions, natural blinking and rig physics.
- Scanning uses randomized gaze targets and spring-smoothed eye-first/head-follow movement instead of a repeating loop; connecting has a thinking glance; success/password-success have one gentle nod; wrong-password has a short restrained no; warning has a brief startle; attack has a steady firm pose; offline has a soft droop; setup has a welcoming tilt.
- Added state-safe breathing, randomized micro-saccades for persistent reaction states, and blinking while the idle layer is gated off. State changes crossfade from the previous rendered pose (including native idle), and returning to Idle clears any interrupted native gesture before enabling autonomous idle after a short randomized pause.
- Removed invalid `shy`, `angry`, and `sad` expressions from the Nara path; the Nara package only defines the `smile` expression.
- No model textures or rig files were replaced.
- Android versionCode/versionName: 104 / 4.2.2.

## Engine compatibility note

The Nara asset in this project is a `livliv-model` package (`.livliv`), not a VRM or Cubism model. AIRI's published renderers support VRM and Live2D; they cannot load this `.livliv` asset directly. This release therefore preserves Nara and applies AIRI's explicit motion-ownership / staged-update approach through the Nara Player's supported driver API. Switching to AIRI's actual VRM or Cubism renderer requires exporting/re-rigging Nara to one of those model formats.
