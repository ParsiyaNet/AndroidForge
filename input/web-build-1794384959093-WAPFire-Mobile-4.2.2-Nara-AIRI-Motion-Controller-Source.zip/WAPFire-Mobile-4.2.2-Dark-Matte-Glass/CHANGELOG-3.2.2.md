# WAPFire Mobile 3.2.2

- Added and registered the missing authenticated, read-only `/api/mobile_settings` endpoint in the matching VF38 firmware source. The mobile response includes `ap_pass_set` and `beacon_mode` but does not disclose the SoftAP passphrase; configuration writes continue through `/api/settings`.
- Fixed current Wi-Fi state detection by using `ConnectivityManager` transport and IPv4 `LinkProperties`, with DHCP fallback. The app no longer reports “No Wi-Fi connection detected” simply because Android hides the SSID.
- Improved Wi-Fi joining: keeps the exact selected BSSID, waits up to 10 seconds for IPv4/DHCP readiness, then verifies the actual WAPFire login page over that selected Android `Network`.
- Corrected the FA/EN language action shown in the supplied Persian screenshot: two-letter labels now use a wider control and explicit LTR text direction so “EN” is not clipped to “E” and both labels remain centered.
- Preserved the five-stage Setup flow and the supplied firmware's current RF, WPA2 retry, WPA3 SAE Status Code 1 and packet-processing implementation.

Build status: source and ZIP integrity / API route checks passed. Android SDK is not configured in this environment, so Android Gradle compilation and APK generation are not claimed as verified.
