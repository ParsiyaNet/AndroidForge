# WAPFire Mobile 3.2.6

## Settings target scanning and replacement
- Removed the Settings scan filter that restricted results to the currently configured target BSSID. A scan now presents every access point returned by the WAPFire radio even when a target is already selected.
- Removed the Settings UI filter that hid newly scanned access points whenever an existing target was configured.
- Users can select a new target directly from the fresh scan results without clearing the old target first.
- After successful target verification, the result list is replaced with the single selected AP; the rest of the list disappears.
- The scan cache is no longer pruned by periodic status refreshes while the user is reviewing scan results. Clearing the target still clears stale target rows.
- AP rows are disabled during an active scan or selection operation to avoid overlapping actions.

## Release metadata
- Android version updated to `3.2.6`, versionCode `24`.
- Firmware sources were not modified.
