# WAPFire Mobile 3.1.0

- Fixed the language toggle label clipping in RTL layouts: `EN` and `FA` now use the full 36dp button width.
- Removed the internal horizontal/vertical text padding that reduced the label content width.
- Explicitly centers the label, keeps it on one line, and preserves the existing 36dp button size and styling.
