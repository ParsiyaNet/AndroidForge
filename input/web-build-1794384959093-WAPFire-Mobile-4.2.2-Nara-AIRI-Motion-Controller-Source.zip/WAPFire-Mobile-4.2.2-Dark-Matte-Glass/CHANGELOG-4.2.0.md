# WAPFire Mobile 4.2.0

- New default character: Hiyori Momose (Live2D Cubism 4 sample model), rendered with PixiJS + pixi-live2d-display inside the existing WebView contract (`assets/assistant/hiyori/`). Framing (head position and head size) is derived from the Nara screenshots for both the Overview card and the Nara tab; `zoom`/`dy` URL parameters in `hiyori.js` allow fine tuning.
- All ten assistant states (idle, scanning, connecting, success, password_success, password_warning, warning, angry, offline, setup) are expressed as small parameter poses on top of Hiyori's idle motions; the status pill texts are unchanged.
- Offline voice: `AssistantVoice` uses the phone's text-to-speech engine and only offline voices (never network voices), English and Persian, with lip movement driven from the speaking callbacks. A speaker button on the Nara tab mutes/unmutes (remembered). A toast explains when no offline voice exists for the language.
- Automatic fallback: if Hiyori's page cannot start (assets missing, Core/model error, main-frame error, or no ready signal within 40 s) the previous Nara page is loaded instead.
- Settings: CHARACTER CREDITS card restored with the copyright notice required by the Live2D sample-data terms.
- WebView contract: new `WapFireNative.reportFatal`, `window.wapfireSetSpeaking`.
- Android versionCode/versionName: 102 / 4.2.0.
