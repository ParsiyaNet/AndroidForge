# WAPFire Mobile 3.2.6 — Settings target re-scan fix

## Root cause

The Settings `onTargetScan` callback filtered the `/api/scan` response against `snapshot.targetMac`. If the current target was no longer seen, it assigned an empty list and explicitly told the user to clear the target before choosing another AP. A second filter in `SettingsPage` also rendered only the currently selected BSSID whenever a target existed. Consequently, tapping Scan could not expose alternative APs until Clear target was used.

## Changes

- Settings scanning now replaces `targetNetworks` with the full list returned by `/api/scan`, regardless of the configured target.
- Settings UI renders that scan-result list directly.
- After successful selection and verification, the existing selection path continues to set `targetNetworks = listOf(selectedAp)`, hiding all other APs.
- `applySnapshot` no longer collapses scan results to the active BSSID on every status refresh. It still clears stale rows when a configured target is removed.
- Rows are disabled during scanning and target selection.

## Expected behavior

1. A target is configured.
2. The user taps **Scan networks** without tapping **Clear target**.
3. All APs returned by the device scan appear, including APs with a different BSSID/SSID from the current target.
4. The user selects one AP.
5. Following successful verification, only that AP remains in the result list and becomes the new target.

## Validation limits

Source-level checks and archive integrity checks were performed. An actual Android APK build and on-device test could not be run because Android SDK Platform 35 and cached Gradle 8.9 are not available in this environment.
