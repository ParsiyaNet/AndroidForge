# WAPFire Mobile 3.0.4

- Reversed the global appearance action icon so the moon is shown while Dark mode is active and the sun while Light mode is active, consistently across all pages.
- Replaced the Network Telemetry `Dropped frames` tile with `Target AP RX`. The value is read from the firmware chart API's `target_ap_frames` counter (`g_target_ap_rx_frame_count`), not inferred from another metric.
- Existing dropped/filtered diagnostics remain available in their system diagnostic locations.
- Android version metadata updated to 3.0.4 (versionCode 11).
