# WAPFire Mobile 4.1.13 — Smart Join

## Join flow
- Removed the 15-second Android Saved-network auto-join wait from 4.1.12. Join now submits the Android Wi-Fi Network Request API immediately.
- Reuses the BSSID-keyed AES-GCM passphrase from Android Keystore-backed `SoftApPasswordVault`.
- Requires an exact scanned BSSID in `WifiNetworkSpecifier`, in addition to the SSID. This keeps the request specific to the selected WAPFire radio and allows Android to reuse its per-app/per-AP approval.
- For a first-time app connection without a vault entry, the app asks for the WAPFire passphrase once, then stores it only after the requested AP is joined and the WAPFire WebUI identity is verified.
- Preserves the existing current-connection fast path: if the phone is already associated with the selected BSSID, it proceeds straight to WebUI discovery.
- Does not open Android Wi-Fi Settings and does not attempt to read Android's protected Saved-network passwords.

## Failure handling
- `NetworkCallback.onUnavailable()` is ambiguous (approval denied, timeout, or authentication failure). It no longer clears the encrypted passphrase automatically.
- On failure, the password field is revealed with the saved value retained so the user can edit it if the AP password really changed.
- Existing session restore, login vault, discovery, monitoring, and dashboard flows are preserved.

## Android behavior
- Android's Wi-Fi Network Request API is the supported peer-to-peer/IoT SoftAP connection path. After approval for a specific app/AP pair, Android can skip the approval UI on subsequent identical specific requests. The system may ask again if the AP is forgotten, app identity changes, or the AP identity/request changes.
- Apps cannot retrieve passwords from Android's Saved networks. A network saved only in Android but never entered into WAPFire's own vault cannot be used as an app-supplied passphrase by this flow.
