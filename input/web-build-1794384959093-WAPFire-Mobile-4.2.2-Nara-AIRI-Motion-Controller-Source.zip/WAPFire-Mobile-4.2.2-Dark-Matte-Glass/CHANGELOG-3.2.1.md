# WAPFire Mobile 3.2.1

- Confirmed the VF38 SoftAP uses `WIFI_AUTH_WPA2_WPA3_PSK` with PMF capable and not required. Android 10+ connection requests use `setWpa3Passphrase()` for WPA2/WPA3 transition networks and WPA3-only networks; WPA2-only uses `setWpa2Passphrase()`.
- Pin the exact selected BSSID in `WifiNetworkSpecifier`; preserve duplicate SSIDs during scanning by deduplicating on BSSID.
- Derive the IPv4 gateway from the selected Android `Network` routes and verify the real WAPFire login page through that network.
- If Wi-Fi association succeeds but the WAPFire WebUI does not respond, remain on Discovery and show a diagnostic instead of advancing to a login screen that cannot work.
- Separate AP selection from connection: select once, enter the password, then press Connect.
- Match the five-step initial Setup to the VF38 WebUI and use the existing firmware endpoints for backup restore, AP credentials, target scan/selection, advanced settings and final apply.
- Validate AP passwords as printable ASCII so the mobile app can reconnect through Android's WPA2/WPA3 `WifiNetworkSpecifier` API.
- No firmware source or WPA detection logic was changed. The supplied VF38 source is included unchanged.

Build status: source/ZIP validation only. Android Gradle compilation has not been completed in this environment.
