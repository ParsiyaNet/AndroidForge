# WAPFire Mobile 4.1.30

## Restore the Overview speech bubble beneath Sena

- Restore the live speech bubble in the Overview card; the original state-driven message text and reaction styling remain active.
- Move the speech bubble into a dedicated full-width footer below the character canvas instead of drawing it over Sena.
- Increase the Overview assistant card height so the character keeps its previous 218dp canvas area while the new message frame sits below it.
- Keep the Overview state badge, demo controls, and title hidden; detection-driven facial expressions and animations continue unchanged.
- Leave the full Assistant tab layout and its separate status/control footer unchanged.

Version: 4.1.30 (versionCode 71).
