# WAPFire Mobile 4.1.38

## Renderer recovery based on the device-confirmed 4.1.34 startup path
- Restored direct ES-module import and the original Player boot sequence used by 4.1.34.
- Removed the added full local-asset prefetch pass and `Player.isSupported()` probe. The latter creates a temporary WebGL2 context and explicitly loses it; it is unnecessary before the real canvas is initialized.
- Added a DOM-ready gate so the engine cannot start until `#stage`, `#loading`, and the page body exist.
- Added explicit missing-canvas diagnostics and null-safe status/loading updates.
- Kept the latest Overview/Assistant layout and Persian/English UI direction fixes.
- Preserved the 4.1.37 zoom (1.38) and the proven 4.1.34 Canvas sizing and Player lifecycle.
- Fixed native diagnostic handling so absent values are shown as missing, not as the string `null`.

## Build metadata
- Version name: 4.1.38
- Version code: 79
