# WAPFire Mobile 4.1.36

## Assistant runtime stability
- Guard every assistant DOM class-list operation against missing/detached nodes during WebView teardown, delayed WebGL callbacks, and navigation.
- Validate required speech/state DOM nodes before updating a character state.
- Catch state-update and control callback exceptions so late UI callbacks do not become uncaught promise failures.
- Preserve JavaScript stack traces and source line details in Assistant diagnostics and Android WebView console logs.

## Persian speech bubble direction
- Apply RTL layout direction to the complete native Compose speech panel when Persian is selected.
- Set explicit RTL text direction and end alignment on both the speech heading and message body.
- Keep the English speech panel explicitly LTR.

## Build metadata
- Version name: 4.1.36
- Version code: 77
