# WAPFire Mobile 4.1.8 — Kotlin compiler options migration

- Migrated the Android module from the removed `android.kotlinOptions { jvmTarget = "17" }` DSL to the typed Kotlin 2.3 `kotlin.compilerOptions` DSL.
- Kept Java source/target compatibility and Kotlin JVM bytecode target aligned at Java 17.
- Preserved Kotlin Android and Compose plugin version 2.3.0, AGP 8.7.3, Gradle 8.9, and Google Play services Location 21.4.0.
- Preserved the 4.1.6 native Location Accuracy prompt, Detection Breakdown notification rules, and background monitoring behavior.
- Bumped app version to 4.1.8 / versionCode 49.
