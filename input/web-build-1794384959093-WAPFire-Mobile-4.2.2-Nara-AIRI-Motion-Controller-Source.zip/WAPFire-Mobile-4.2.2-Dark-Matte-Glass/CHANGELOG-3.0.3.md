# WAPFire Mobile 3.0.3

- Renamed the first discovery-page headline to **WAPFire**.
- Unified the sun/moon theme toggle across Discovery, Login, Setup and Control pages.
- Added opt-in Remember password on Sign in. The password is encrypted with AES-GCM and an Android Keystore key; only ciphertext is kept in SharedPreferences. Turning the option off removes the stored credential.
- Detection Breakdown now renders all eight firmware detection categories, including zero-count categories.
- Removed Free memory from Network Telemetry; the metric remains under Device Status where a heap statistic belongs. Network Telemetry now shows traffic, packet, dropped-frame and filtered-frame counters.
- Lighting color controls now follow the actual WS2812 implementation: primary color appears for effects 8, 9, 10, 11, 13, 17 and 18; secondary color appears only for Alternate (13); generated-palette effects show no custom color fields.

- README and Android version metadata updated to 3.0.3 (versionCode 10).
- The Remember password choice is retained on a successful sign-in; the stored password is never written as plaintext to SharedPreferences.
- Existing device status reporting, Wi-Fi session handling, and firmware API contract remain unchanged.
