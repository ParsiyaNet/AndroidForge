# WAPFire Mobile 4.1.9 — Seamless remembered-session startup

- Added a dedicated branded `RESTORING` state so the login form is not rendered while saved credentials are being verified.
- On app launch, remembered credentials are checked against the verified WAPFire endpoint before the control UI is shown.
- The current-device/manual-host and Wi-Fi-rejoin paths now use the same silent restore behavior when a credential is securely saved for that host.
- The sign-in form is shown only when no saved credentials exist or WAPFire explicitly rejects the saved login. Temporary network failures return to device discovery instead of being treated as sign-out.
- The last selected dashboard tab is persisted and restored after successful automatic sign-in.
- Existing Background Alerts, Detection Breakdown filtering, Location Accuracy prompt, and Kotlin 2.3.0 compiler configuration are retained.
- App version: 4.1.9 / versionCode 50.
