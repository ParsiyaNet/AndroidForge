# WAPFire Mobile 4.1.39

## WebView stale-bootstrap recovery
- The exact `Assistant loading element #loading is missing` diagnostic seen on-device is present in the 4.1.37 bootstrap but absent from the 4.1.38 source. This is strong evidence that an older WebView bootstrap response or APK was still being used.
- Added a uniquely named `assistant-preflight-4.1.39.js` asset and build-specific query strings for the HTML document, bootstrap script, and renderer module.
- Clear the WebView cache before starting the local assistant page and retain `LOAD_NO_CACHE`.
- Expose the bootstrap build marker to native diagnostics; if an old script is used again, the UI reports the exact loaded and expected build IDs.
- Retains the direct Player startup flow based on 4.1.34 and the existing Overview/Assistant layout and language fixes.

## Build metadata
- Version name: 4.1.39
- Version code: 80
