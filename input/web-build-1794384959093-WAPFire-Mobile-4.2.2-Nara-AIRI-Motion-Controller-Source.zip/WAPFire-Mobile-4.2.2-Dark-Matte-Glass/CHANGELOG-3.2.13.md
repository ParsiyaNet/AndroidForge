# WAPFire Mobile 3.2.13 — Manual device address Wi-Fi recovery

## Fix
- Fixed the Manual Device Address path, which previously bound the process to the current Wi-Fi `Network` only once and did not register a persistent `NetworkCallback`.
- Manual address mode now monitors Wi-Fi networks continuously, including networks with and without Internet capability.
- When the associated Wi-Fi `Network` is lost, the app clears the stale process binding and marks the device link OFFLINE while preserving the authenticated API session and UI state.
- When Wi-Fi returns, the callback binds the app process to the new Wi-Fi `Network` and invokes the existing WAPFire WebUI verification flow using the manually entered host (with the standard SoftAP address as fallback).
- Unrelated Wi-Fi networks may be rebound at the transport level, but the device is not marked LIVE unless the expected manual host passes WAPFire WebUI verification and the API status request succeeds.
- Existing BSSID-specific discovery and `WifiNetworkSpecifier` reconnect paths remain unchanged.

## Preserved
- Firmware is unchanged from VF38 3.0.5 BSSID Signature.
- BSSID identity prefix `02:57:41` unchanged.
- RF detection, Async Target Scan, API routes, authentication, UI layout, and BLE-free architecture unchanged.
- Minimum Android remains API 29 (Android 10).

## Validation limits
- Source-level control-flow checks, version checks, and ZIP integrity checks performed.
- Full Android Gradle/Kotlin compilation was not run because Android SDK/Gradle dependencies are not installed/available in this environment.
- Physical Wi-Fi OFF → ON test using Manual Device Address remains required.
