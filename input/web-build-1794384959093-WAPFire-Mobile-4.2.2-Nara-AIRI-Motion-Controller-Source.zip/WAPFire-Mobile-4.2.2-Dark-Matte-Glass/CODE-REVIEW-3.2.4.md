# WAPFire Mobile 3.2.4 — code and UX review

## Changes applied

### Notifications
The app-wide notice is rendered in a Compose `Popup`, not in the page's layout tree. Its maximum width is 320 dp, the message is capped at three lines with ellipsis, and the close target has a defined 28 dp hit area. This prevents the notification from changing the measured height or scroll position of the underlying page.

### Target AP selection
Target radio identity is now treated as the BSSID, not just the SSID. Setup and Settings only retain/display the exact selected BSSID once a target exists. Settings also disables duplicate selection attempts while the first target is being verified, and its empty-state copy no longer claims that the selected AP is active when scan results are absent. Selecting another AP in Setup first clears the old result set; Settings requires clearing the existing target before selecting a different one. Missing/invalid BSSID values and channels outside the supported 1–13 range are rejected before the API call. The old SSID fallback was removed because several physical radios can legitimately advertise the same SSID.

### Automation schedule
Start and End are equal-width native Android 24-hour time-picker controls. Android's picker allows direct numeric input through its keyboard/input-mode icon. The app normalizes malformed stored times before creating the picker, disables Save when an enabled schedule has no weekdays or identical Start/End values, and explains both invalid states inline.

An additional warning appears when the interval crosses midnight. The supplied VF38 firmware checks the weekday bit for the current calendar day even in the early-hours portion of an overnight interval. The practical workaround is to select the following weekday as well. The real correction belongs in the firmware scheduler and is deliberately not mixed into this Android-only update.

### Wi-Fi request lifecycle
Connection failure now removes the delayed IP-readiness poll and unregisters the corresponding network callback. Link loss also clears the bound process network and unregisters that callback. This reduces the chance of an old request hanging around when the user retries.

## Findings and recommended next refinements

1. **Localization consistency — medium priority.** Most primary screen labels have Persian/English pairs, but some raw exception messages and a few operational notices are displayed directly from the API layer in English. The clean long-term solution is to map known API/network error codes into a shared bilingual message catalog and reserve raw technical details for an expandable diagnostic line.

2. **Small secondary typography — medium priority.** Some metadata, helper text, and compact labels use 9–10 sp. That is visually compact but can be hard to read on smaller phones or with increased display scaling. For the next visual pass, prefer 11–12 sp for ordinary helper text and 12–13 sp for important values; keep 9–10 sp only for truly secondary telemetry.

3. **Large Settings surface — low/medium priority.** Settings is comprehensive and grouped, but its advanced controls form a long vertical page. A lightweight section index or search/filter at the top would make frequently used controls (Schedule, MikroTik, Ethernet, LED) quicker to reach without splitting the configuration model into unrelated screens.

4. **Wi-Fi scan freshness — medium priority.** Android can throttle `WifiManager.startScan()` and return cached scan results. The current implementation waits briefly and reads the scan cache, so a future hardening pass should expose scan freshness (using each result's timestamp and the scan-results broadcast) and distinguish “cached results” from a new radio scan. Target AP selection itself remains protected by the device-side BSSID verification.

5. **Automated tests — high priority before release.** There are no project-level unit/UI tests covering schedule payloads, BSSID sibling filtering, login/session expiry, callback cleanup, backup restore, or OTA file handling. Add pure Kotlin tests for validation/filtering first, followed by device tests on Android 10, Android 13+, and a current Android release with the actual VF38 hardware.

## Build and verification boundary

The source tree was reviewed and the edits above were applied. A parser-only Kotlin pass found no syntax/parser diagnostics, but it could not type-check the Android app because Android/Compose dependencies are not installed in this environment. The Gradle 8.9 wrapper could not fetch its distribution and there is no configured Android SDK, so no APK was produced. Physical-device validation remains outstanding.

The sibling `WAPFireVF38/` firmware source was left untouched in this app update. In particular, the overnight weekday-mask behavior described above remains a firmware limitation.
