# WAPFire Mobile 4.1.48 — Kotlin compiler artifact mirror

- Kept Kotlin Android and Compose plugins at 2.3.0 to preserve compatibility with the Kotlin 2.3.0 metadata used by the current Play Services Location dependency.
- Added a narrowly scoped Maven mirror for `org.jetbrains.kotlin:kotlin-compiler-embeddable` before Maven Central in both plugin and dependency repository scopes.
- The AndroidForge logs showed Maven Central redirecting the Kotlin compiler JAR download to a GitHub Releases URL that returned HTTP 504. The mirror directly hosts the 2.3.0 JAR (57,669,576 bytes), with a published SHA-1 sidecar.
- No application Kotlin source, Nara model assets, LivLiv renderer assets, or offline runtime logic were changed.
- App version: 4.1.48 / versionCode 89.

This is a build-dependency routing fix. AndroidForge must still complete the APK build to confirm it.
