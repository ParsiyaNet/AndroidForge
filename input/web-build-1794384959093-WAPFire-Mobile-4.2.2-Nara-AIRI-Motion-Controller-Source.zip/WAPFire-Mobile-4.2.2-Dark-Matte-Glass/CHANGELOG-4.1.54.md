# WAPFire Mobile 4.1.54

- Nara no longer reloads when switching tabs. The WebViews are now owned by `ControlCenter` (new `AssistantWebViewCache`, provided through `LocalAssistantWebViews`) instead of being created and destroyed together with each tab page.
- Two long-lived views are created lazily: the compact one on first visit to Overview and the full one on first visit to the Nara tab. After that they are only detached/attached (paused while hidden), never recreated.
- The views are destroyed only when leaving the signed-in screens (log out / back to discovery) or when the interface language changes (the language is part of the page URL).
- Status text ("Preparing assistant…") now lives with the cached view, so it does not reappear after a tab switch.
- Standalone assistant preview (outside ControlCenter) keeps the old create-and-destroy behaviour through a private fallback cache.
- Android versionCode/versionName: 100 / 4.1.54.
