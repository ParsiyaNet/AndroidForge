# WAPFire Mobile 4.1.18 — Live Animated Anime Assistant

## Replaced the static pose preview
- Replaced the five static character images / crossfade slideshow with a live, original SVG character rig rendered inside a local Android WebView.
- The character's torso breathes, head tilts and bobs, hair sections sway independently, eyelids blink, pupils follow touch/pointer movement, eyebrows react, and mouth shapes change with the selected state.
- Added five live expressions/states: Idle, Scanning, Connecting, Success, and Warning. State changes alter the actual facial rig and movement rather than swapping still pictures.
- Added a rotating scan ring, success sparkles, and warning indicator as state-specific effects.
- Kept manual state selection and Auto Demo controls.
- Added English and Persian UI strings. The preview is stored under `app/src/main/assets/assistant/assistant-live.html` and works offline.

## Android integration
- `AssistantPreviewScreen` now hosts the local animated page in WebView using `AndroidView`.
- Network loads, content access, universal file URL access, popups and zoom are disabled. The page uses only bundled HTML/CSS/SVG/JavaScript assets; it does not request camera or microphone access.
- The existing entry points from Discovery and the dashboard Assistant tab are preserved.
- Kept the small static thumbnail on the Discovery card only; the actual Assistant screen is animated.

## Scope and limitations
- This is an original CSS/SVG rig with independently animated face and body parts. It is not yet the LivLiv WebGL2 renderer or a `.livliv` model integration.
- The state buttons are a prototype control surface. Wiring real app events (Wi-Fi scan, join, success, threat notifications) is a follow-up integration step.
