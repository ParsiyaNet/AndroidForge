@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo Build failed. Open the project in Android Studio and check the Build output.
  pause
  exit /b 1
)
echo.
echo APK created at:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
pause
