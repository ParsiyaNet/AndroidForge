# WAPFire Mobile 4.1.33

## Fix Overview blank space and restore a larger Sena preview

- Correct the compact speech footer positioning by clearing the inherited `top` offset; the previous rule left `top` and `bottom` active together and caused the message placement to conflict with the reserved character stage.
- Keep the Overview speech panel in a dedicated footer below the character stage.
- Increase the Overview card height to 320dp so the avatar has enough vertical room without squeezing the speech panel.
- Increase compact character zoom from 1.18 to 1.34 while preserving the model's aspect ratio.
- Keep the blurred cover artwork as a soft background fill; the animated model remains on its own canvas and is not stretched.
- Preserve the Assistant view, language/theme controls, state reactions, local favicon handling, and LivLiv attribution/license.

Version: 4.1.33 (versionCode 74).
