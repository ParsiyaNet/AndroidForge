# WAPFire Mobile 4.1.1 — AndroidForge compile hotfix

## Root cause

AndroidForge run `41897782100` stopped at `:app:compileDebugKotlin` with:

`WapFireApp.kt:94:33 Unresolved reference 'onDispose'`

The reported line was an invalid standalone import:

`import androidx.compose.runtime.onDispose`

`onDispose { ... }` is valid inside the `DisposableEffect` receiver scope and remains in place. The invalid import has been removed.

## Secondary cleanup

AndroidForge also reported duplicate test-only `org.json.JSONObject` declarations. The duplicate stubs were consolidated into `tools/test-support/stubs/org/json/JSONObject.kt`; both isolated JVM test runners now use this shared stub.

## Version

- `versionName`: `4.1.1`
- `versionCode`: `42`
- Application ID: `io.wapfire.mobile`

## Verification performed

- 22/22 static source checks passed.
- All Android XML resources parsed successfully.
- Background monitor event-policy JVM test passed.
- Session recovery JVM integration test compiled and passed all six scenarios.
- ZIP archive integrity and SHA-256 are supplied separately.

A full Android Gradle/APK build has not yet been rerun after this fix. Re-upload this ZIP to AndroidForge to verify the complete APK build. The previous failure was traced to and corrected at the exact reported source line.
