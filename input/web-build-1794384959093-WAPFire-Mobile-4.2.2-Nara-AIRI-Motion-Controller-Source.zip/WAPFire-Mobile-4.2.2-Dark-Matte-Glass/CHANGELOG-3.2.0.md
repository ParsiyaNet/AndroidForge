# WAPFire Mobile 3.2.0 — Setup and Wi-Fi Join Fix

## Android connection to the VF38 SoftAP
- Matched connection security to the firmware's `WIFI_AUTH_WPA2_WPA3_PSK` transition mode: Android uses WPA3-SAE for WPA2/WPA3 transition access points and WPA2-PSK for WPA2-only networks.
- The exact BSSID selected in the scan list is now passed to `WifiNetworkSpecifier`, preventing same-SSID access points from being confused.
- Wi-Fi scan results are deduplicated by BSSID rather than SSID.
- The app waits for IPv4 route information before selecting the gateway, then verifies the actual WAPFire login page over the selected Android `Network`; it also checks the standard ESP32 SoftAP address if the reported gateway does not respond.
- The local-only request explicitly removes the Internet capability, which is appropriate for the WAPFire SoftAP that provides device access rather than Internet routing.
- The connection request timeout is extended to 60 seconds, and failed/lost connections leave the UI in a recoverable state with a diagnostic message.
- The connection UI now separates selecting an AP from joining it: select one BSSID, enter the passphrase once, then use the dedicated Connect button. WPA/WEP password constraints are validated before requesting the Android connection.

## Native setup wizard aligned with VF38 WebUI
- Five stages: Welcome + Restore Backup, Access Point credentials, Target Network selection, Advanced Options, and Final Review.
- Target selection uses the firmware's `/api/scan` and `/api/select_target` endpoints and persists the exact SSID/BSSID/channel through `/api/settings`.
- Advanced switches map to the firmware keys `led`, `sound`, `auto_channel`, `self_protect`, and `softap_enabled`.
- The final configuration maps to the firmware's actual `/api/settings` payload and honors `wifi_restart_needed` by waiting for the SoftAP restart before asking the user to reconnect.
- Disabling SoftAP now displays a direct warning that Wi-Fi access will be lost and Ethernet must already be configured.
- Restore waits for the firmware reboot before returning to Discovery.

## Firmware baseline
- The VF38 firmware folder is carried forward unchanged from the supplied WPA2 retry + WPA3 SAE Status Code 1 baseline. No WPA detection, RF model, or LED disconnect behavior was changed in this Android-only compatibility update.


## 3.2.1 connection state and credential validation
- The app now enters Sign In only after the selected Wi-Fi network returns the actual WAPFire authentication page. If Android associates but the device HTTP server does not answer, the app stays on Discovery, preserves the selected gateway, and explains the distinction.
- Setup validates AP passphrases as printable ASCII because Android's `WifiNetworkSpecifier` WPA2/WPA3 passphrase setters require ASCII input; this prevents saving a password the Android app cannot subsequently use to reconnect.
