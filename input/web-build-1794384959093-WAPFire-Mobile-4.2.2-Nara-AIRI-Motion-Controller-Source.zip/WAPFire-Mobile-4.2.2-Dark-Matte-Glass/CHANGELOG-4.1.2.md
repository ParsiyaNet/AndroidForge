# WAPFire Mobile 4.1.2

## Requested UX corrections
- Moved Background Security Monitor controls into Settings > Background Alerts.
- Removed the monitor card from Overview and the BG/ON shortcut from the dashboard toolbar.
- Added automatic session restoration on app launch when the encrypted remembered device credentials are available.
- Remember password is enabled by default on first use; an explicit user opt-out is remembered.
- A temporary app/process close no longer clears the saved login. The explicit Log out action still clears saved credentials and ends the monitor/session.

## Authentication behavior
- The app first checks the existing in-process session. If Android recreated the app process, it verifies the WAPFire VF38 login page and obtains a new session using the encrypted Android Keystore-backed credentials.
- Temporary network unavailability leaves the saved login intact and returns to Discovery instead of treating it as a logout.
- No password is sent until the endpoint has passed the WAPFire identity check.

## Validation notes
- Background monitor Kotlin policy and session-recovery test suites are run separately.
- Android APK/Gradle build must be confirmed in AndroidForge; this environment does not have the Android SDK/Gradle installation needed for a full APK build.
