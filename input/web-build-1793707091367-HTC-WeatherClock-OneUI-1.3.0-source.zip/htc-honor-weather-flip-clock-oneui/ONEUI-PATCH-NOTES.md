# HTC Weather Clock — One UI / standalone weather source patch

Prepared from the uploaded `BuksaPC/htc-honor-weather-flip-clock` source archive on 2026-11-03.

## Patch target

- Version name: `1.3.0-oneui`
- Manifest `versionCode`: `663091327`
- Package: `com.htc.widget.weatherclock`

The version code is intentionally higher than the v1.2.7 (`663091326`) release in the related standalone repository, so Android will not reject this package as a version downgrade.

## Changes in this source tree

- Weather data is requested directly from Open-Meteo; Breezy Weather is no longer needed as an installed app or content provider.
- First setup requests Android approximate location permission and obtains a one-shot location while the settings screen is in the foreground. Coordinates are saved locally. No background-location permission or continuous GPS tracking is requested.
- The last successful weather response is cached by coordinates and can be reused when a later network refresh fails.
- The unlock-weather animation waits up to five seconds for the launcher to become foreground and retries if the overlay cannot be attached. It only counts an attempt as successful once `WindowManager.addView()` succeeds.
- Weather-provider queries return a valid empty cursor if a transient query error occurs, rather than allowing an exception to escape into the launcher.
- Sync requests are serialized and a forced refresh requested during an active sync is queued for a follow-up run.
- The binary-manifest patch adds Internet and approximate-location permissions, removes Breezy package visibility/permission/receiver entries, and changes the version to `1.3.0-oneui` / `663091327`.

## Build status: source prepared, APK not built

This archive is **not an APK** and has not been compiled or tested on a Samsung device. The uploaded upstream source ZIP does not contain the proprietary/base decoded APK trees or build JARs required by its custom builder. These required inputs are absent:

- `source/apktool-project-124/` (decoded base project, including `AndroidManifest.xml`)
- `source/apktool-project-breezy/` (decoded build project and its resources/smali)
- `source/tools/apktool.jar` (Apktool 2.12.1)
- `source/tools/signer.jar` (uber-apk-signer 1.3.0)
- Android SDK Platform 36 and Build Tools 36.0.0 (`android.jar` and `d8`)

The project is **not a Gradle app**. A generic `gradle assembleDebug` / `bundleDebug` AndroidForge job will not build it. Once the missing inputs and SDK are available, use the repository's own build script from the project root:

```bash
cd source
./build-breezy.sh
```

The output is written one directory above `source/` as `HTC-WeatherClock-v1.3.0-oneui.apk`.

## Device validation still required

The location flow, the black-widget fallback, and the unlock animation need testing on the actual Samsung model and One UI version. If the launcher still reports **Problem loading widget**, capture the first relevant exception from `adb logcat` (`AndroidRuntime`, `RemoteViews`, `AppWidgetProvider`, `OpenMeteoBridge`).
